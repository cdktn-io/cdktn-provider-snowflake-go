/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StorageIntegrationAwsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the storage integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#comment StorageIntegrationAws#comment}
    */
    readonly comment?: string;
    /**
    * Specifies whether this storage integration is available for usage in stages. `TRUE` allows users to create new stages that reference this integration. Existing stages that reference this integration function normally. `FALSE` prevents users from creating new stages that reference this integration. Existing stages that reference this integration cannot access the storage location in the stage definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#enabled StorageIntegrationAws#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#id StorageIntegrationAws#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * String that specifies the identifier (i.e. name) for the integration; must be unique in your account. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#name StorageIntegrationAws#name}
    */
    readonly name: string;
    /**
    * Explicitly limits external stages that use the integration to reference one or more storage locations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#storage_allowed_locations StorageIntegrationAws#storage_allowed_locations}
    */
    readonly storageAllowedLocations: string[];
    /**
    * Optionally specifies an external ID that Snowflake uses to establish a trust relationship with AWS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#storage_aws_external_id StorageIntegrationAws#storage_aws_external_id}
    */
    readonly storageAwsExternalId?: string;
    /**
    * Enables support for AWS access control lists (ACLs) to grant the bucket owner full control. `bucket-owner-full-control` is the only currently supported value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#storage_aws_object_acl StorageIntegrationAws#storage_aws_object_acl}
    */
    readonly storageAwsObjectAcl?: string;
    /**
    * Specifies the Amazon Resource Name (ARN) of the AWS identity and access management (IAM) role that grants privileges on the S3 bucket containing your data files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#storage_aws_role_arn StorageIntegrationAws#storage_aws_role_arn}
    */
    readonly storageAwsRoleArn: string;
    /**
    * Explicitly prohibits external stages that use the integration from referencing one or more storage locations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#storage_blocked_locations StorageIntegrationAws#storage_blocked_locations}
    */
    readonly storageBlockedLocations?: string[];
    /**
    * Specifies the storage provider for the integration. Valid options are: `S3` | `S3GOV` | `S3CHINA` | `GCS` | `AZURE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#storage_provider StorageIntegrationAws#storage_provider}
    */
    readonly storageProvider: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether to use outbound private connectivity to harden the security posture. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#use_privatelink_endpoint StorageIntegrationAws#use_privatelink_endpoint}
    */
    readonly usePrivatelinkEndpoint?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#timeouts StorageIntegrationAws#timeouts}
    */
    readonly timeouts?: StorageIntegrationAwsTimeouts;
}
export interface StorageIntegrationAwsDescribeOutput {
}
export declare function storageIntegrationAwsDescribeOutputToTerraform(struct?: StorageIntegrationAwsDescribeOutput): any;
export declare function storageIntegrationAwsDescribeOutputToHclTerraform(struct?: StorageIntegrationAwsDescribeOutput): any;
export declare class StorageIntegrationAwsDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationAwsDescribeOutput | undefined;
    set internalValue(value: StorageIntegrationAwsDescribeOutput | undefined);
    get allowedLocations(): string[];
    get blockedLocations(): string[];
    get comment(): string;
    get enabled(): cdktn.IResolvable;
    get externalId(): string;
    get iamUserArn(): string;
    get id(): string;
    get objectAcl(): string;
    get provider(): string;
    get roleArn(): string;
    get usePrivatelinkEndpoint(): cdktn.IResolvable;
}
export declare class StorageIntegrationAwsDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationAwsDescribeOutputOutputReference;
}
export interface StorageIntegrationAwsShowOutput {
}
export declare function storageIntegrationAwsShowOutputToTerraform(struct?: StorageIntegrationAwsShowOutput): any;
export declare function storageIntegrationAwsShowOutputToHclTerraform(struct?: StorageIntegrationAwsShowOutput): any;
export declare class StorageIntegrationAwsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationAwsShowOutput | undefined;
    set internalValue(value: StorageIntegrationAwsShowOutput | undefined);
    get category(): string;
    get comment(): string;
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
    get storageType(): string;
}
export declare class StorageIntegrationAwsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationAwsShowOutputOutputReference;
}
export interface StorageIntegrationAwsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#create StorageIntegrationAws#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#delete StorageIntegrationAws#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#read StorageIntegrationAws#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#update StorageIntegrationAws#update}
    */
    readonly update?: string;
}
export declare function storageIntegrationAwsTimeoutsToTerraform(struct?: StorageIntegrationAwsTimeouts | cdktn.IResolvable): any;
export declare function storageIntegrationAwsTimeoutsToHclTerraform(struct?: StorageIntegrationAwsTimeouts | cdktn.IResolvable): any;
export declare class StorageIntegrationAwsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageIntegrationAwsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: StorageIntegrationAwsTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws snowflake_storage_integration_aws}
*/
export declare class StorageIntegrationAws extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_storage_integration_aws";
    /**
    * Generates CDKTN code for importing a StorageIntegrationAws resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StorageIntegrationAws to import
    * @param importFromId The id of the existing StorageIntegrationAws that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StorageIntegrationAws to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/storage_integration_aws snowflake_storage_integration_aws} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StorageIntegrationAwsConfig
    */
    constructor(scope: Construct, id: string, config: StorageIntegrationAwsConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): StorageIntegrationAwsDescribeOutputList;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _showOutput;
    get showOutput(): StorageIntegrationAwsShowOutputList;
    private _storageAllowedLocations?;
    get storageAllowedLocations(): string[];
    set storageAllowedLocations(value: string[]);
    get storageAllowedLocationsInput(): string[] | undefined;
    private _storageAwsExternalId?;
    get storageAwsExternalId(): string;
    set storageAwsExternalId(value: string);
    resetStorageAwsExternalId(): void;
    get storageAwsExternalIdInput(): string | undefined;
    private _storageAwsObjectAcl?;
    get storageAwsObjectAcl(): string;
    set storageAwsObjectAcl(value: string);
    resetStorageAwsObjectAcl(): void;
    get storageAwsObjectAclInput(): string | undefined;
    private _storageAwsRoleArn?;
    get storageAwsRoleArn(): string;
    set storageAwsRoleArn(value: string);
    get storageAwsRoleArnInput(): string | undefined;
    private _storageBlockedLocations?;
    get storageBlockedLocations(): string[];
    set storageBlockedLocations(value: string[]);
    resetStorageBlockedLocations(): void;
    get storageBlockedLocationsInput(): string[] | undefined;
    private _storageProvider?;
    get storageProvider(): string;
    set storageProvider(value: string);
    get storageProviderInput(): string | undefined;
    private _usePrivatelinkEndpoint?;
    get usePrivatelinkEndpoint(): string;
    set usePrivatelinkEndpoint(value: string);
    resetUsePrivatelinkEndpoint(): void;
    get usePrivatelinkEndpointInput(): string | undefined;
    private _timeouts;
    get timeouts(): StorageIntegrationAwsTimeoutsOutputReference;
    putTimeouts(value: StorageIntegrationAwsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | StorageIntegrationAwsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
