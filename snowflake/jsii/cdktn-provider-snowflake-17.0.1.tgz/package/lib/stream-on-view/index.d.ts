/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StreamOnViewConfig extends cdktn.TerraformMetaArguments {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether this is an append-only stream. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#append_only StreamOnView#append_only}
    */
    readonly appendOnly?: string;
    /**
    * Specifies a comment for the stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#comment StreamOnView#comment}
    */
    readonly comment?: string;
    /**
    * (Default: `false`) Retains the access permissions from the original stream when a stream is recreated using the OR REPLACE clause. This is used when the provider detects changes for fields that can not be changed by ALTER. This value will not have any effect during creating a new object with Terraform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#copy_grants StreamOnView#copy_grants}
    */
    readonly copyGrants?: boolean | cdktn.IResolvable;
    /**
    * The database in which to create the stream. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#database StreamOnView#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#id StreamOnView#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the stream; must be unique for the database and schema in which the stream is created. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#name StreamOnView#name}
    */
    readonly name: string;
    /**
    * The schema in which to create the stream. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#schema StreamOnView#schema}
    */
    readonly schema: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether to return all existing rows in the source table as row inserts the first time the stream is consumed. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#show_initial_rows StreamOnView#show_initial_rows}
    */
    readonly showInitialRows?: string;
    /**
    * Specifies an identifier for the view the stream will monitor. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`. For more information about this resource, see [docs](./view).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#view StreamOnView#view}
    */
    readonly view: string;
    /**
    * at block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#at StreamOnView#at}
    */
    readonly at?: StreamOnViewAt;
    /**
    * before block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#before StreamOnView#before}
    */
    readonly before?: StreamOnViewBefore;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#timeouts StreamOnView#timeouts}
    */
    readonly timeouts?: StreamOnViewTimeouts;
}
export interface StreamOnViewDescribeOutput {
}
export declare function streamOnViewDescribeOutputToTerraform(struct?: StreamOnViewDescribeOutput): any;
export declare function streamOnViewDescribeOutputToHclTerraform(struct?: StreamOnViewDescribeOutput): any;
export declare class StreamOnViewDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StreamOnViewDescribeOutput | undefined;
    set internalValue(value: StreamOnViewDescribeOutput | undefined);
    get baseTables(): string[];
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get invalidReason(): string;
    get mode(): string;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get schemaName(): string;
    get sourceType(): string;
    get stale(): cdktn.IResolvable;
    get staleAfter(): string;
    get tableName(): string;
    get type(): string;
}
export declare class StreamOnViewDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StreamOnViewDescribeOutputOutputReference;
}
export interface StreamOnViewShowOutput {
}
export declare function streamOnViewShowOutputToTerraform(struct?: StreamOnViewShowOutput): any;
export declare function streamOnViewShowOutputToHclTerraform(struct?: StreamOnViewShowOutput): any;
export declare class StreamOnViewShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StreamOnViewShowOutput | undefined;
    set internalValue(value: StreamOnViewShowOutput | undefined);
    get baseTables(): string[];
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get invalidReason(): string;
    get mode(): string;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get schemaName(): string;
    get sourceType(): string;
    get stale(): cdktn.IResolvable;
    get staleAfter(): string;
    get tableName(): string;
    get type(): string;
}
export declare class StreamOnViewShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StreamOnViewShowOutputOutputReference;
}
export interface StreamOnViewAt {
    /**
    * Specifies the difference in seconds from the current time to use for Time Travel, in the form -N where N can be an integer or arithmetic expression (e.g. -120 is 120 seconds, -30*60 is 1800 seconds or 30 minutes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#offset StreamOnView#offset}
    */
    readonly offset?: string;
    /**
    * Specifies the query ID of a statement to use as the reference point for Time Travel. This parameter supports any statement of one of the following types: DML (e.g. INSERT, UPDATE, DELETE), TCL (BEGIN, COMMIT transaction), SELECT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#statement StreamOnView#statement}
    */
    readonly statement?: string;
    /**
    * Specifies the identifier (i.e. name) for an existing stream on the queried table or view. The current offset in the stream is used as the AT point in time for returning change data for the source object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#stream StreamOnView#stream}
    */
    readonly stream?: string;
    /**
    * Specifies an exact date and time to use for Time Travel. The value must be explicitly cast to a TIMESTAMP, TIMESTAMP_LTZ, TIMESTAMP_NTZ, or TIMESTAMP_TZ data type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#timestamp StreamOnView#timestamp}
    */
    readonly timestamp?: string;
}
export declare function streamOnViewAtToTerraform(struct?: StreamOnViewAtOutputReference | StreamOnViewAt): any;
export declare function streamOnViewAtToHclTerraform(struct?: StreamOnViewAtOutputReference | StreamOnViewAt): any;
export declare class StreamOnViewAtOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StreamOnViewAt | undefined;
    set internalValue(value: StreamOnViewAt | undefined);
    private _offset?;
    get offset(): string;
    set offset(value: string);
    resetOffset(): void;
    get offsetInput(): string | undefined;
    private _statement?;
    get statement(): string;
    set statement(value: string);
    resetStatement(): void;
    get statementInput(): string | undefined;
    private _stream?;
    get stream(): string;
    set stream(value: string);
    resetStream(): void;
    get streamInput(): string | undefined;
    private _timestamp?;
    get timestamp(): string;
    set timestamp(value: string);
    resetTimestamp(): void;
    get timestampInput(): string | undefined;
}
export interface StreamOnViewBefore {
    /**
    * Specifies the difference in seconds from the current time to use for Time Travel, in the form -N where N can be an integer or arithmetic expression (e.g. -120 is 120 seconds, -30*60 is 1800 seconds or 30 minutes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#offset StreamOnView#offset}
    */
    readonly offset?: string;
    /**
    * Specifies the query ID of a statement to use as the reference point for Time Travel. This parameter supports any statement of one of the following types: DML (e.g. INSERT, UPDATE, DELETE), TCL (BEGIN, COMMIT transaction), SELECT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#statement StreamOnView#statement}
    */
    readonly statement?: string;
    /**
    * Specifies the identifier (i.e. name) for an existing stream on the queried table or view. The current offset in the stream is used as the AT point in time for returning change data for the source object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#stream StreamOnView#stream}
    */
    readonly stream?: string;
    /**
    * Specifies an exact date and time to use for Time Travel. The value must be explicitly cast to a TIMESTAMP, TIMESTAMP_LTZ, TIMESTAMP_NTZ, or TIMESTAMP_TZ data type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#timestamp StreamOnView#timestamp}
    */
    readonly timestamp?: string;
}
export declare function streamOnViewBeforeToTerraform(struct?: StreamOnViewBeforeOutputReference | StreamOnViewBefore): any;
export declare function streamOnViewBeforeToHclTerraform(struct?: StreamOnViewBeforeOutputReference | StreamOnViewBefore): any;
export declare class StreamOnViewBeforeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StreamOnViewBefore | undefined;
    set internalValue(value: StreamOnViewBefore | undefined);
    private _offset?;
    get offset(): string;
    set offset(value: string);
    resetOffset(): void;
    get offsetInput(): string | undefined;
    private _statement?;
    get statement(): string;
    set statement(value: string);
    resetStatement(): void;
    get statementInput(): string | undefined;
    private _stream?;
    get stream(): string;
    set stream(value: string);
    resetStream(): void;
    get streamInput(): string | undefined;
    private _timestamp?;
    get timestamp(): string;
    set timestamp(value: string);
    resetTimestamp(): void;
    get timestampInput(): string | undefined;
}
export interface StreamOnViewTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#create StreamOnView#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#delete StreamOnView#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#read StreamOnView#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#update StreamOnView#update}
    */
    readonly update?: string;
}
export declare function streamOnViewTimeoutsToTerraform(struct?: StreamOnViewTimeouts | cdktn.IResolvable): any;
export declare function streamOnViewTimeoutsToHclTerraform(struct?: StreamOnViewTimeouts | cdktn.IResolvable): any;
export declare class StreamOnViewTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StreamOnViewTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: StreamOnViewTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view snowflake_stream_on_view}
*/
export declare class StreamOnView extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_stream_on_view";
    /**
    * Generates CDKTN code for importing a StreamOnView resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StreamOnView to import
    * @param importFromId The id of the existing StreamOnView that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StreamOnView to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/stream_on_view snowflake_stream_on_view} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StreamOnViewConfig
    */
    constructor(scope: Construct, id: string, config: StreamOnViewConfig);
    private _appendOnly?;
    get appendOnly(): string;
    set appendOnly(value: string);
    resetAppendOnly(): void;
    get appendOnlyInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _copyGrants?;
    get copyGrants(): boolean | cdktn.IResolvable;
    set copyGrants(value: boolean | cdktn.IResolvable);
    resetCopyGrants(): void;
    get copyGrantsInput(): boolean | cdktn.IResolvable | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): StreamOnViewDescribeOutputList;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showInitialRows?;
    get showInitialRows(): string;
    set showInitialRows(value: string);
    resetShowInitialRows(): void;
    get showInitialRowsInput(): string | undefined;
    private _showOutput;
    get showOutput(): StreamOnViewShowOutputList;
    get stale(): cdktn.IResolvable;
    get streamType(): string;
    private _view?;
    get view(): string;
    set view(value: string);
    get viewInput(): string | undefined;
    private _at;
    get at(): StreamOnViewAtOutputReference;
    putAt(value: StreamOnViewAt): void;
    resetAt(): void;
    get atInput(): StreamOnViewAt | undefined;
    private _before;
    get before(): StreamOnViewBeforeOutputReference;
    putBefore(value: StreamOnViewBefore): void;
    resetBefore(): void;
    get beforeInput(): StreamOnViewBefore | undefined;
    private _timeouts;
    get timeouts(): StreamOnViewTimeoutsOutputReference;
    putTimeouts(value: StreamOnViewTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | StreamOnViewTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
