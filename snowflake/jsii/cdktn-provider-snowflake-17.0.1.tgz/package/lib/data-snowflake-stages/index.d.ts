/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeStagesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/data-sources/stages#id DataSnowflakeStages#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/data-sources/stages#like DataSnowflakeStages#like}
    */
    readonly like?: string;
    /**
    * (Default: `true`) Runs DESC STAGE for each stage returned by SHOW STAGES. The output of describe is saved to the describe_output field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/data-sources/stages#with_describe DataSnowflakeStages#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * in block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/data-sources/stages#in DataSnowflakeStages#in}
    */
    readonly in?: DataSnowflakeStagesIn;
}
export interface DataSnowflakeStagesStagesDescribeOutputDirectoryTable {
}
export declare function dataSnowflakeStagesStagesDescribeOutputDirectoryTableToTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputDirectoryTable): any;
export declare function dataSnowflakeStagesStagesDescribeOutputDirectoryTableToHclTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputDirectoryTable): any;
export declare class DataSnowflakeStagesStagesDescribeOutputDirectoryTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStagesStagesDescribeOutputDirectoryTable | undefined;
    set internalValue(value: DataSnowflakeStagesStagesDescribeOutputDirectoryTable | undefined);
    get autoRefresh(): cdktn.IResolvable;
    get enable(): cdktn.IResolvable;
    get lastRefreshedOn(): string;
}
export declare class DataSnowflakeStagesStagesDescribeOutputDirectoryTableList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStagesStagesDescribeOutputDirectoryTableOutputReference;
}
export interface DataSnowflakeStagesStagesDescribeOutputFileFormatAvro {
}
export declare function dataSnowflakeStagesStagesDescribeOutputFileFormatAvroToTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputFileFormatAvro): any;
export declare function dataSnowflakeStagesStagesDescribeOutputFileFormatAvroToHclTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputFileFormatAvro): any;
export declare class DataSnowflakeStagesStagesDescribeOutputFileFormatAvroOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStagesStagesDescribeOutputFileFormatAvro | undefined;
    set internalValue(value: DataSnowflakeStagesStagesDescribeOutputFileFormatAvro | undefined);
    get compression(): string;
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
}
export declare class DataSnowflakeStagesStagesDescribeOutputFileFormatAvroList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStagesStagesDescribeOutputFileFormatAvroOutputReference;
}
export interface DataSnowflakeStagesStagesDescribeOutputFileFormatCsv {
}
export declare function dataSnowflakeStagesStagesDescribeOutputFileFormatCsvToTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputFileFormatCsv): any;
export declare function dataSnowflakeStagesStagesDescribeOutputFileFormatCsvToHclTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputFileFormatCsv): any;
export declare class DataSnowflakeStagesStagesDescribeOutputFileFormatCsvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStagesStagesDescribeOutputFileFormatCsv | undefined;
    set internalValue(value: DataSnowflakeStagesStagesDescribeOutputFileFormatCsv | undefined);
    get binaryFormat(): string;
    get compression(): string;
    get dateFormat(): string;
    get emptyFieldAsNull(): cdktn.IResolvable;
    get encoding(): string;
    get errorOnColumnCountMismatch(): cdktn.IResolvable;
    get escape(): string;
    get escapeUnenclosedField(): string;
    get fieldDelimiter(): string;
    get fieldOptionallyEnclosedBy(): string;
    get fileExtension(): string;
    get multiLine(): cdktn.IResolvable;
    get nullIf(): string[];
    get parseHeader(): cdktn.IResolvable;
    get recordDelimiter(): string;
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipBlankLines(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get skipHeader(): number;
    get timeFormat(): string;
    get timestampFormat(): string;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
    get validateUtf8(): cdktn.IResolvable;
}
export declare class DataSnowflakeStagesStagesDescribeOutputFileFormatCsvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStagesStagesDescribeOutputFileFormatCsvOutputReference;
}
export interface DataSnowflakeStagesStagesDescribeOutputFileFormatJson {
}
export declare function dataSnowflakeStagesStagesDescribeOutputFileFormatJsonToTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputFileFormatJson): any;
export declare function dataSnowflakeStagesStagesDescribeOutputFileFormatJsonToHclTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputFileFormatJson): any;
export declare class DataSnowflakeStagesStagesDescribeOutputFileFormatJsonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStagesStagesDescribeOutputFileFormatJson | undefined;
    set internalValue(value: DataSnowflakeStagesStagesDescribeOutputFileFormatJson | undefined);
    get allowDuplicate(): cdktn.IResolvable;
    get binaryFormat(): string;
    get compression(): string;
    get dateFormat(): string;
    get enableOctal(): cdktn.IResolvable;
    get fileExtension(): string;
    get ignoreUtf8Errors(): cdktn.IResolvable;
    get multiLine(): cdktn.IResolvable;
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get stripNullValues(): cdktn.IResolvable;
    get stripOuterArray(): cdktn.IResolvable;
    get timeFormat(): string;
    get timestampFormat(): string;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
}
export declare class DataSnowflakeStagesStagesDescribeOutputFileFormatJsonList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStagesStagesDescribeOutputFileFormatJsonOutputReference;
}
export interface DataSnowflakeStagesStagesDescribeOutputFileFormatOrc {
}
export declare function dataSnowflakeStagesStagesDescribeOutputFileFormatOrcToTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputFileFormatOrc): any;
export declare function dataSnowflakeStagesStagesDescribeOutputFileFormatOrcToHclTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputFileFormatOrc): any;
export declare class DataSnowflakeStagesStagesDescribeOutputFileFormatOrcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStagesStagesDescribeOutputFileFormatOrc | undefined;
    set internalValue(value: DataSnowflakeStagesStagesDescribeOutputFileFormatOrc | undefined);
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
}
export declare class DataSnowflakeStagesStagesDescribeOutputFileFormatOrcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStagesStagesDescribeOutputFileFormatOrcOutputReference;
}
export interface DataSnowflakeStagesStagesDescribeOutputFileFormatParquet {
}
export declare function dataSnowflakeStagesStagesDescribeOutputFileFormatParquetToTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputFileFormatParquet): any;
export declare function dataSnowflakeStagesStagesDescribeOutputFileFormatParquetToHclTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputFileFormatParquet): any;
export declare class DataSnowflakeStagesStagesDescribeOutputFileFormatParquetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStagesStagesDescribeOutputFileFormatParquet | undefined;
    set internalValue(value: DataSnowflakeStagesStagesDescribeOutputFileFormatParquet | undefined);
    get binaryAsText(): cdktn.IResolvable;
    get compression(): string;
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
    get useLogicalType(): cdktn.IResolvable;
    get useVectorizedScanner(): cdktn.IResolvable;
}
export declare class DataSnowflakeStagesStagesDescribeOutputFileFormatParquetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStagesStagesDescribeOutputFileFormatParquetOutputReference;
}
export interface DataSnowflakeStagesStagesDescribeOutputFileFormatXml {
}
export declare function dataSnowflakeStagesStagesDescribeOutputFileFormatXmlToTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputFileFormatXml): any;
export declare function dataSnowflakeStagesStagesDescribeOutputFileFormatXmlToHclTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputFileFormatXml): any;
export declare class DataSnowflakeStagesStagesDescribeOutputFileFormatXmlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStagesStagesDescribeOutputFileFormatXml | undefined;
    set internalValue(value: DataSnowflakeStagesStagesDescribeOutputFileFormatXml | undefined);
    get compression(): string;
    get disableAutoConvert(): cdktn.IResolvable;
    get ignoreUtf8Errors(): cdktn.IResolvable;
    get preserveSpace(): cdktn.IResolvable;
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get stripOuterElement(): cdktn.IResolvable;
    get type(): string;
}
export declare class DataSnowflakeStagesStagesDescribeOutputFileFormatXmlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStagesStagesDescribeOutputFileFormatXmlOutputReference;
}
export interface DataSnowflakeStagesStagesDescribeOutputFileFormat {
}
export declare function dataSnowflakeStagesStagesDescribeOutputFileFormatToTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputFileFormat): any;
export declare function dataSnowflakeStagesStagesDescribeOutputFileFormatToHclTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputFileFormat): any;
export declare class DataSnowflakeStagesStagesDescribeOutputFileFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStagesStagesDescribeOutputFileFormat | undefined;
    set internalValue(value: DataSnowflakeStagesStagesDescribeOutputFileFormat | undefined);
    private _avro;
    get avro(): DataSnowflakeStagesStagesDescribeOutputFileFormatAvroList;
    private _csv;
    get csv(): DataSnowflakeStagesStagesDescribeOutputFileFormatCsvList;
    get formatName(): string;
    private _json;
    get json(): DataSnowflakeStagesStagesDescribeOutputFileFormatJsonList;
    private _orc;
    get orc(): DataSnowflakeStagesStagesDescribeOutputFileFormatOrcList;
    private _parquet;
    get parquet(): DataSnowflakeStagesStagesDescribeOutputFileFormatParquetList;
    private _xml;
    get xml(): DataSnowflakeStagesStagesDescribeOutputFileFormatXmlList;
}
export declare class DataSnowflakeStagesStagesDescribeOutputFileFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStagesStagesDescribeOutputFileFormatOutputReference;
}
export interface DataSnowflakeStagesStagesDescribeOutputLocation {
}
export declare function dataSnowflakeStagesStagesDescribeOutputLocationToTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputLocation): any;
export declare function dataSnowflakeStagesStagesDescribeOutputLocationToHclTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputLocation): any;
export declare class DataSnowflakeStagesStagesDescribeOutputLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStagesStagesDescribeOutputLocation | undefined;
    set internalValue(value: DataSnowflakeStagesStagesDescribeOutputLocation | undefined);
    get awsAccessPointArn(): string;
    get url(): string[];
}
export declare class DataSnowflakeStagesStagesDescribeOutputLocationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStagesStagesDescribeOutputLocationOutputReference;
}
export interface DataSnowflakeStagesStagesDescribeOutputPrivatelink {
}
export declare function dataSnowflakeStagesStagesDescribeOutputPrivatelinkToTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputPrivatelink): any;
export declare function dataSnowflakeStagesStagesDescribeOutputPrivatelinkToHclTerraform(struct?: DataSnowflakeStagesStagesDescribeOutputPrivatelink): any;
export declare class DataSnowflakeStagesStagesDescribeOutputPrivatelinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStagesStagesDescribeOutputPrivatelink | undefined;
    set internalValue(value: DataSnowflakeStagesStagesDescribeOutputPrivatelink | undefined);
    get usePrivatelinkEndpoint(): cdktn.IResolvable;
}
export declare class DataSnowflakeStagesStagesDescribeOutputPrivatelinkList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStagesStagesDescribeOutputPrivatelinkOutputReference;
}
export interface DataSnowflakeStagesStagesDescribeOutput {
}
export declare function dataSnowflakeStagesStagesDescribeOutputToTerraform(struct?: DataSnowflakeStagesStagesDescribeOutput): any;
export declare function dataSnowflakeStagesStagesDescribeOutputToHclTerraform(struct?: DataSnowflakeStagesStagesDescribeOutput): any;
export declare class DataSnowflakeStagesStagesDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStagesStagesDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeStagesStagesDescribeOutput | undefined);
    private _directoryTable;
    get directoryTable(): DataSnowflakeStagesStagesDescribeOutputDirectoryTableList;
    private _fileFormat;
    get fileFormat(): DataSnowflakeStagesStagesDescribeOutputFileFormatList;
    private _location;
    get location(): DataSnowflakeStagesStagesDescribeOutputLocationList;
    private _privatelink;
    get privatelink(): DataSnowflakeStagesStagesDescribeOutputPrivatelinkList;
}
export declare class DataSnowflakeStagesStagesDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStagesStagesDescribeOutputOutputReference;
}
export interface DataSnowflakeStagesStagesShowOutput {
}
export declare function dataSnowflakeStagesStagesShowOutputToTerraform(struct?: DataSnowflakeStagesStagesShowOutput): any;
export declare function dataSnowflakeStagesStagesShowOutputToHclTerraform(struct?: DataSnowflakeStagesStagesShowOutput): any;
export declare class DataSnowflakeStagesStagesShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStagesStagesShowOutput | undefined;
    set internalValue(value: DataSnowflakeStagesStagesShowOutput | undefined);
    get cloud(): string;
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get directoryEnabled(): cdktn.IResolvable;
    get endpoint(): string;
    get hasCredentials(): cdktn.IResolvable;
    get hasEncryptionKey(): cdktn.IResolvable;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get region(): string;
    get schemaName(): string;
    get storageIntegration(): string;
    get type(): string;
    get url(): string;
}
export declare class DataSnowflakeStagesStagesShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStagesStagesShowOutputOutputReference;
}
export interface DataSnowflakeStagesStages {
}
export declare function dataSnowflakeStagesStagesToTerraform(struct?: DataSnowflakeStagesStages): any;
export declare function dataSnowflakeStagesStagesToHclTerraform(struct?: DataSnowflakeStagesStages): any;
export declare class DataSnowflakeStagesStagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStagesStages | undefined;
    set internalValue(value: DataSnowflakeStagesStages | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeStagesStagesDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeStagesStagesShowOutputList;
}
export declare class DataSnowflakeStagesStagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStagesStagesOutputReference;
}
export interface DataSnowflakeStagesIn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/data-sources/stages#account DataSnowflakeStages#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the specified application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/data-sources/stages#application DataSnowflakeStages#application}
    */
    readonly application?: string;
    /**
    * Returns records for the specified application package.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/data-sources/stages#application_package DataSnowflakeStages#application_package}
    */
    readonly applicationPackage?: string;
    /**
    * Returns records for the current database in use or for a specified database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/data-sources/stages#database DataSnowflakeStages#database}
    */
    readonly database?: string;
    /**
    * Returns records for the current schema in use or a specified schema. Use fully qualified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/data-sources/stages#schema DataSnowflakeStages#schema}
    */
    readonly schema?: string;
}
export declare function dataSnowflakeStagesInToTerraform(struct?: DataSnowflakeStagesInOutputReference | DataSnowflakeStagesIn): any;
export declare function dataSnowflakeStagesInToHclTerraform(struct?: DataSnowflakeStagesInOutputReference | DataSnowflakeStagesIn): any;
export declare class DataSnowflakeStagesInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeStagesIn | undefined;
    set internalValue(value: DataSnowflakeStagesIn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _application?;
    get application(): string;
    set application(value: string);
    resetApplication(): void;
    get applicationInput(): string | undefined;
    private _applicationPackage?;
    get applicationPackage(): string;
    set applicationPackage(value: string);
    resetApplicationPackage(): void;
    get applicationPackageInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/data-sources/stages snowflake_stages}
*/
export declare class DataSnowflakeStages extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_stages";
    /**
    * Generates CDKTN code for importing a DataSnowflakeStages resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeStages to import
    * @param importFromId The id of the existing DataSnowflakeStages that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/data-sources/stages#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeStages to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/data-sources/stages snowflake_stages} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeStagesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeStagesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _stages;
    get stages(): DataSnowflakeStagesStagesList;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _in;
    get in(): DataSnowflakeStagesInOutputReference;
    putIn(value: DataSnowflakeStagesIn): void;
    resetIn(): void;
    get inInput(): DataSnowflakeStagesIn | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
