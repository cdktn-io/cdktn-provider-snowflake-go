/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ListingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the application package attached to the listing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#application_package Listing#application_package}
    */
    readonly applicationPackage?: string;
    /**
    * Specifies a comment for the listing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#comment Listing#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#id Listing#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the listing identifier (name). It must be unique within the organization, regardless of which Snowflake region the account is located in. Must start with an alphabetic character and cannot contain spaces or special characters except for underscores.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#name Listing#name}
    */
    readonly name: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Determines if the listing should be published.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#publish Listing#publish}
    */
    readonly publish?: string;
    /**
    * Specifies the identifier for the share to attach to the listing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#share Listing#share}
    */
    readonly share?: string;
    /**
    * manifest block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#manifest Listing#manifest}
    */
    readonly manifest: ListingManifest;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#timeouts Listing#timeouts}
    */
    readonly timeouts?: ListingTimeouts;
}
export interface ListingShowOutput {
}
export declare function listingShowOutputToTerraform(struct?: ListingShowOutput): any;
export declare function listingShowOutputToHclTerraform(struct?: ListingShowOutput): any;
export declare class ListingShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ListingShowOutput | undefined;
    set internalValue(value: ListingShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get detailedTargetAccounts(): string;
    get distribution(): string;
    get globalName(): string;
    get isApplication(): cdktn.IResolvable;
    get isByRequest(): cdktn.IResolvable;
    get isLimitedTrial(): cdktn.IResolvable;
    get isMonetized(): cdktn.IResolvable;
    get isMountlessQueryable(): cdktn.IResolvable;
    get isTargeted(): cdktn.IResolvable;
    get name(): string;
    get organizationProfileName(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get profile(): string;
    get publishedOn(): string;
    get regions(): string;
    get rejectedOn(): string;
    get reviewState(): string;
    get state(): string;
    get subtitle(): string;
    get targetAccounts(): string;
    get title(): string;
    get uniformListingLocator(): string;
    get updatedOn(): string;
}
export declare class ListingShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ListingShowOutputOutputReference;
}
export interface ListingManifestFromStage {
    /**
    * Location of the manifest file in the stage. If not specified, the manifest file will be expected to be at the root of the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#location Listing#location}
    */
    readonly location?: string;
    /**
    * Identifier of the stage where the manifest file is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#stage Listing#stage}
    */
    readonly stage: string;
    /**
    * Specifies a comment for the listing version. Whenever a new version is created, this comment will be associated with it. The comment on the version will be visible in the [SHOW VERSIONS IN LISTING](https://docs.snowflake.com/en/sql-reference/sql/show-versions-in-listing) command output.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#version_comment Listing#version_comment}
    */
    readonly versionComment?: string;
    /**
    * Represents manifest version name. It's case-sensitive and used in manifest versioning. Version name should be specified or changed whenever any changes in the manifest should be applied to the listing. Later on the versions of the listing can be analyzed by calling the [SHOW VERSIONS IN LISTING](https://docs.snowflake.com/en/sql-reference/sql/show-versions-in-listing) command. The resource does not track the changes on the specified stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#version_name Listing#version_name}
    */
    readonly versionName?: string;
}
export declare function listingManifestFromStageToTerraform(struct?: ListingManifestFromStageOutputReference | ListingManifestFromStage): any;
export declare function listingManifestFromStageToHclTerraform(struct?: ListingManifestFromStageOutputReference | ListingManifestFromStage): any;
export declare class ListingManifestFromStageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ListingManifestFromStage | undefined;
    set internalValue(value: ListingManifestFromStage | undefined);
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _stage?;
    get stage(): string;
    set stage(value: string);
    get stageInput(): string | undefined;
    private _versionComment?;
    get versionComment(): string;
    set versionComment(value: string);
    resetVersionComment(): void;
    get versionCommentInput(): string | undefined;
    private _versionName?;
    get versionName(): string;
    set versionName(value: string);
    resetVersionName(): void;
    get versionNameInput(): string | undefined;
}
export interface ListingManifest {
    /**
    * Manifest provided as a string. Wrapping `$$` signs are added by the provider automatically; do not include them. For more information on manifest syntax, see [Listing manifest reference](https://docs.snowflake.com/en/progaccess/listing-manifest-reference). Also, the [multiline string syntax](https://developer.hashicorp.com/terraform/language/expressions/strings#heredoc-strings) is a must here. A proper YAML indentation (2 spaces) is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#from_string Listing#from_string}
    */
    readonly fromString?: string;
    /**
    * from_stage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#from_stage Listing#from_stage}
    */
    readonly fromStage?: ListingManifestFromStage;
}
export declare function listingManifestToTerraform(struct?: ListingManifestOutputReference | ListingManifest): any;
export declare function listingManifestToHclTerraform(struct?: ListingManifestOutputReference | ListingManifest): any;
export declare class ListingManifestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ListingManifest | undefined;
    set internalValue(value: ListingManifest | undefined);
    private _fromString?;
    get fromString(): string;
    set fromString(value: string);
    resetFromString(): void;
    get fromStringInput(): string | undefined;
    private _fromStage;
    get fromStage(): ListingManifestFromStageOutputReference;
    putFromStage(value: ListingManifestFromStage): void;
    resetFromStage(): void;
    get fromStageInput(): ListingManifestFromStage | undefined;
}
export interface ListingTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#create Listing#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#delete Listing#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#read Listing#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#update Listing#update}
    */
    readonly update?: string;
}
export declare function listingTimeoutsToTerraform(struct?: ListingTimeouts | cdktn.IResolvable): any;
export declare function listingTimeoutsToHclTerraform(struct?: ListingTimeouts | cdktn.IResolvable): any;
export declare class ListingTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ListingTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ListingTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing snowflake_listing}
*/
export declare class Listing extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_listing";
    /**
    * Generates CDKTN code for importing a Listing resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Listing to import
    * @param importFromId The id of the existing Listing that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Listing to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.15.0/docs/resources/listing snowflake_listing} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ListingConfig
    */
    constructor(scope: Construct, id: string, config: ListingConfig);
    private _applicationPackage?;
    get applicationPackage(): string;
    set applicationPackage(value: string);
    resetApplicationPackage(): void;
    get applicationPackageInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _publish?;
    get publish(): string;
    set publish(value: string);
    resetPublish(): void;
    get publishInput(): string | undefined;
    private _share?;
    get share(): string;
    set share(value: string);
    resetShare(): void;
    get shareInput(): string | undefined;
    private _showOutput;
    get showOutput(): ListingShowOutputList;
    private _manifest;
    get manifest(): ListingManifestOutputReference;
    putManifest(value: ListingManifest): void;
    get manifestInput(): ListingManifest | undefined;
    private _timeouts;
    get timeouts(): ListingTimeoutsOutputReference;
    putTimeouts(value: ListingTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ListingTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
