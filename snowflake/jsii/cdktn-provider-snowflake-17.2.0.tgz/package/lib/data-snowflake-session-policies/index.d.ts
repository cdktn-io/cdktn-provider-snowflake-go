/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeSessionPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#id DataSnowflakeSessionPolicies#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#like DataSnowflakeSessionPolicies#like}
    */
    readonly like?: string;
    /**
    * Filters the output with **case-sensitive** characters indicating the beginning of the object name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#starts_with DataSnowflakeSessionPolicies#starts_with}
    */
    readonly startsWith?: string;
    /**
    * (Default: `true`) Runs DESC SESSION POLICY for each object returned by SHOW SESSION POLICIES. The output of describe is saved to the describe_output field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#with_describe DataSnowflakeSessionPolicies#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * in block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#in DataSnowflakeSessionPolicies#in}
    */
    readonly in?: DataSnowflakeSessionPoliciesIn;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#limit DataSnowflakeSessionPolicies#limit}
    */
    readonly limit?: DataSnowflakeSessionPoliciesLimit;
    /**
    * on block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#on DataSnowflakeSessionPolicies#on}
    */
    readonly on?: DataSnowflakeSessionPoliciesOn;
}
export interface DataSnowflakeSessionPoliciesSessionPoliciesDescribeOutput {
}
export declare function dataSnowflakeSessionPoliciesSessionPoliciesDescribeOutputToTerraform(struct?: DataSnowflakeSessionPoliciesSessionPoliciesDescribeOutput): any;
export declare function dataSnowflakeSessionPoliciesSessionPoliciesDescribeOutputToHclTerraform(struct?: DataSnowflakeSessionPoliciesSessionPoliciesDescribeOutput): any;
export declare class DataSnowflakeSessionPoliciesSessionPoliciesDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeSessionPoliciesSessionPoliciesDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeSessionPoliciesSessionPoliciesDescribeOutput | undefined);
    get allowedSecondaryRoles(): string[];
    get blockedSecondaryRoles(): string[];
    get comment(): string;
    get id(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get sessionIdleTimeoutMins(): number;
    get sessionUiIdleTimeoutMins(): number;
}
export declare class DataSnowflakeSessionPoliciesSessionPoliciesDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeSessionPoliciesSessionPoliciesDescribeOutputOutputReference;
}
export interface DataSnowflakeSessionPoliciesSessionPoliciesShowOutput {
}
export declare function dataSnowflakeSessionPoliciesSessionPoliciesShowOutputToTerraform(struct?: DataSnowflakeSessionPoliciesSessionPoliciesShowOutput): any;
export declare function dataSnowflakeSessionPoliciesSessionPoliciesShowOutputToHclTerraform(struct?: DataSnowflakeSessionPoliciesSessionPoliciesShowOutput): any;
export declare class DataSnowflakeSessionPoliciesSessionPoliciesShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeSessionPoliciesSessionPoliciesShowOutput | undefined;
    set internalValue(value: DataSnowflakeSessionPoliciesSessionPoliciesShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get kind(): string;
    get name(): string;
    get options(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get schemaName(): string;
}
export declare class DataSnowflakeSessionPoliciesSessionPoliciesShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeSessionPoliciesSessionPoliciesShowOutputOutputReference;
}
export interface DataSnowflakeSessionPoliciesSessionPolicies {
}
export declare function dataSnowflakeSessionPoliciesSessionPoliciesToTerraform(struct?: DataSnowflakeSessionPoliciesSessionPolicies): any;
export declare function dataSnowflakeSessionPoliciesSessionPoliciesToHclTerraform(struct?: DataSnowflakeSessionPoliciesSessionPolicies): any;
export declare class DataSnowflakeSessionPoliciesSessionPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeSessionPoliciesSessionPolicies | undefined;
    set internalValue(value: DataSnowflakeSessionPoliciesSessionPolicies | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeSessionPoliciesSessionPoliciesDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeSessionPoliciesSessionPoliciesShowOutputList;
}
export declare class DataSnowflakeSessionPoliciesSessionPoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeSessionPoliciesSessionPoliciesOutputReference;
}
export interface DataSnowflakeSessionPoliciesIn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#account DataSnowflakeSessionPolicies#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the specified application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#application DataSnowflakeSessionPolicies#application}
    */
    readonly application?: string;
    /**
    * Returns records for the specified application package.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#application_package DataSnowflakeSessionPolicies#application_package}
    */
    readonly applicationPackage?: string;
    /**
    * Returns records for the current database in use or for a specified database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#database DataSnowflakeSessionPolicies#database}
    */
    readonly database?: string;
    /**
    * Returns records for the current schema in use or a specified schema. Use fully qualified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#schema DataSnowflakeSessionPolicies#schema}
    */
    readonly schema?: string;
}
export declare function dataSnowflakeSessionPoliciesInToTerraform(struct?: DataSnowflakeSessionPoliciesInOutputReference | DataSnowflakeSessionPoliciesIn): any;
export declare function dataSnowflakeSessionPoliciesInToHclTerraform(struct?: DataSnowflakeSessionPoliciesInOutputReference | DataSnowflakeSessionPoliciesIn): any;
export declare class DataSnowflakeSessionPoliciesInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeSessionPoliciesIn | undefined;
    set internalValue(value: DataSnowflakeSessionPoliciesIn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _application?;
    get application(): string;
    set application(value: string);
    resetApplication(): void;
    get applicationInput(): string | undefined;
    private _applicationPackage?;
    get applicationPackage(): string;
    set applicationPackage(value: string);
    resetApplicationPackage(): void;
    get applicationPackageInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export interface DataSnowflakeSessionPoliciesLimit {
    /**
    * Specifies a **case-sensitive** pattern that is used to match object name. After the first match, the limit on the number of rows will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#from DataSnowflakeSessionPolicies#from}
    */
    readonly from?: string;
    /**
    * The maximum number of rows to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#rows DataSnowflakeSessionPolicies#rows}
    */
    readonly rows: number;
}
export declare function dataSnowflakeSessionPoliciesLimitToTerraform(struct?: DataSnowflakeSessionPoliciesLimitOutputReference | DataSnowflakeSessionPoliciesLimit): any;
export declare function dataSnowflakeSessionPoliciesLimitToHclTerraform(struct?: DataSnowflakeSessionPoliciesLimitOutputReference | DataSnowflakeSessionPoliciesLimit): any;
export declare class DataSnowflakeSessionPoliciesLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeSessionPoliciesLimit | undefined;
    set internalValue(value: DataSnowflakeSessionPoliciesLimit | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _rows?;
    get rows(): number;
    set rows(value: number);
    get rowsInput(): number | undefined;
}
export interface DataSnowflakeSessionPoliciesOn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#account DataSnowflakeSessionPolicies#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the specified user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#user DataSnowflakeSessionPolicies#user}
    */
    readonly user?: string;
}
export declare function dataSnowflakeSessionPoliciesOnToTerraform(struct?: DataSnowflakeSessionPoliciesOnOutputReference | DataSnowflakeSessionPoliciesOn): any;
export declare function dataSnowflakeSessionPoliciesOnToHclTerraform(struct?: DataSnowflakeSessionPoliciesOnOutputReference | DataSnowflakeSessionPoliciesOn): any;
export declare class DataSnowflakeSessionPoliciesOnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeSessionPoliciesOn | undefined;
    set internalValue(value: DataSnowflakeSessionPoliciesOn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies snowflake_session_policies}
*/
export declare class DataSnowflakeSessionPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_session_policies";
    /**
    * Generates CDKTN code for importing a DataSnowflakeSessionPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeSessionPolicies to import
    * @param importFromId The id of the existing DataSnowflakeSessionPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeSessionPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/session_policies snowflake_session_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeSessionPoliciesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeSessionPoliciesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _sessionPolicies;
    get sessionPolicies(): DataSnowflakeSessionPoliciesSessionPoliciesList;
    private _startsWith?;
    get startsWith(): string;
    set startsWith(value: string);
    resetStartsWith(): void;
    get startsWithInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _in;
    get in(): DataSnowflakeSessionPoliciesInOutputReference;
    putIn(value: DataSnowflakeSessionPoliciesIn): void;
    resetIn(): void;
    get inInput(): DataSnowflakeSessionPoliciesIn | undefined;
    private _limit;
    get limit(): DataSnowflakeSessionPoliciesLimitOutputReference;
    putLimit(value: DataSnowflakeSessionPoliciesLimit): void;
    resetLimit(): void;
    get limitInput(): DataSnowflakeSessionPoliciesLimit | undefined;
    private _on;
    get on(): DataSnowflakeSessionPoliciesOnOutputReference;
    putOn(value: DataSnowflakeSessionPoliciesOn): void;
    resetOn(): void;
    get onInput(): DataSnowflakeSessionPoliciesOn | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
