/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApiIntegrationGitRepositoryGithubAppConfig extends cdktn.TerraformMetaArguments {
    /**
    * Explicitly limits external functions that use the integration to reference one or more HTTPS proxy service and remote service endpoints and resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_github_app#api_allowed_prefixes ApiIntegrationGitRepositoryGithubApp#api_allowed_prefixes}
    */
    readonly apiAllowedPrefixes: string[];
    /**
    * Lists the endpoints and resources in the HTTPS proxy service that are not allowed to be called from Snowflake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_github_app#api_blocked_prefixes ApiIntegrationGitRepositoryGithubApp#api_blocked_prefixes}
    */
    readonly apiBlockedPrefixes?: string[];
    /**
    * Specifies a comment for the integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_github_app#comment ApiIntegrationGitRepositoryGithubApp#comment}
    */
    readonly comment?: string;
    /**
    * Specifies whether this API integration is enabled or disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_github_app#enabled ApiIntegrationGitRepositoryGithubApp#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_github_app#id ApiIntegrationGitRepositoryGithubApp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier (i.e. name) for the integration. This value must be unique in your account. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_github_app#name ApiIntegrationGitRepositoryGithubApp#name}
    */
    readonly name: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_github_app#timeouts ApiIntegrationGitRepositoryGithubApp#timeouts}
    */
    readonly timeouts?: ApiIntegrationGitRepositoryGithubAppTimeouts;
}
export interface ApiIntegrationGitRepositoryGithubAppDescribeOutput {
}
export declare function apiIntegrationGitRepositoryGithubAppDescribeOutputToTerraform(struct?: ApiIntegrationGitRepositoryGithubAppDescribeOutput): any;
export declare function apiIntegrationGitRepositoryGithubAppDescribeOutputToHclTerraform(struct?: ApiIntegrationGitRepositoryGithubAppDescribeOutput): any;
export declare class ApiIntegrationGitRepositoryGithubAppDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiIntegrationGitRepositoryGithubAppDescribeOutput | undefined;
    set internalValue(value: ApiIntegrationGitRepositoryGithubAppDescribeOutput | undefined);
    get allowedPrefixes(): string[];
    get apiProvider(): string;
    get blockedPrefixes(): string[];
    get comment(): string;
    get enabled(): cdktn.IResolvable;
    get userAuthType(): string;
}
export declare class ApiIntegrationGitRepositoryGithubAppDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiIntegrationGitRepositoryGithubAppDescribeOutputOutputReference;
}
export interface ApiIntegrationGitRepositoryGithubAppShowOutput {
}
export declare function apiIntegrationGitRepositoryGithubAppShowOutputToTerraform(struct?: ApiIntegrationGitRepositoryGithubAppShowOutput): any;
export declare function apiIntegrationGitRepositoryGithubAppShowOutputToHclTerraform(struct?: ApiIntegrationGitRepositoryGithubAppShowOutput): any;
export declare class ApiIntegrationGitRepositoryGithubAppShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiIntegrationGitRepositoryGithubAppShowOutput | undefined;
    set internalValue(value: ApiIntegrationGitRepositoryGithubAppShowOutput | undefined);
    get apiType(): string;
    get category(): string;
    get comment(): string;
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
}
export declare class ApiIntegrationGitRepositoryGithubAppShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiIntegrationGitRepositoryGithubAppShowOutputOutputReference;
}
export interface ApiIntegrationGitRepositoryGithubAppTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_github_app#create ApiIntegrationGitRepositoryGithubApp#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_github_app#delete ApiIntegrationGitRepositoryGithubApp#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_github_app#read ApiIntegrationGitRepositoryGithubApp#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_github_app#update ApiIntegrationGitRepositoryGithubApp#update}
    */
    readonly update?: string;
}
export declare function apiIntegrationGitRepositoryGithubAppTimeoutsToTerraform(struct?: ApiIntegrationGitRepositoryGithubAppTimeouts | cdktn.IResolvable): any;
export declare function apiIntegrationGitRepositoryGithubAppTimeoutsToHclTerraform(struct?: ApiIntegrationGitRepositoryGithubAppTimeouts | cdktn.IResolvable): any;
export declare class ApiIntegrationGitRepositoryGithubAppTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiIntegrationGitRepositoryGithubAppTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApiIntegrationGitRepositoryGithubAppTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_github_app snowflake_api_integration_git_repository_github_app}
*/
export declare class ApiIntegrationGitRepositoryGithubApp extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_api_integration_git_repository_github_app";
    /**
    * Generates CDKTN code for importing a ApiIntegrationGitRepositoryGithubApp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApiIntegrationGitRepositoryGithubApp to import
    * @param importFromId The id of the existing ApiIntegrationGitRepositoryGithubApp that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_github_app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApiIntegrationGitRepositoryGithubApp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_github_app snowflake_api_integration_git_repository_github_app} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApiIntegrationGitRepositoryGithubAppConfig
    */
    constructor(scope: Construct, id: string, config: ApiIntegrationGitRepositoryGithubAppConfig);
    private _apiAllowedPrefixes?;
    get apiAllowedPrefixes(): string[];
    set apiAllowedPrefixes(value: string[]);
    get apiAllowedPrefixesInput(): string[] | undefined;
    private _apiBlockedPrefixes?;
    get apiBlockedPrefixes(): string[];
    set apiBlockedPrefixes(value: string[]);
    resetApiBlockedPrefixes(): void;
    get apiBlockedPrefixesInput(): string[] | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): ApiIntegrationGitRepositoryGithubAppDescribeOutputList;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _showOutput;
    get showOutput(): ApiIntegrationGitRepositoryGithubAppShowOutputList;
    private _timeouts;
    get timeouts(): ApiIntegrationGitRepositoryGithubAppTimeoutsOutputReference;
    putTimeouts(value: ApiIntegrationGitRepositoryGithubAppTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApiIntegrationGitRepositoryGithubAppTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
