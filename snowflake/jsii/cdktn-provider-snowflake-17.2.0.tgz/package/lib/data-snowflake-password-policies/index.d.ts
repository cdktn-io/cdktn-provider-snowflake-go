/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakePasswordPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#id DataSnowflakePasswordPolicies#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#like DataSnowflakePasswordPolicies#like}
    */
    readonly like?: string;
    /**
    * Filters the output with **case-sensitive** characters indicating the beginning of the object name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#starts_with DataSnowflakePasswordPolicies#starts_with}
    */
    readonly startsWith?: string;
    /**
    * (Default: `true`) Runs DESC PASSWORD POLICY for each password policy returned by SHOW PASSWORD POLICIES. The output of describe is saved to the describe_output field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#with_describe DataSnowflakePasswordPolicies#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * in block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#in DataSnowflakePasswordPolicies#in}
    */
    readonly in?: DataSnowflakePasswordPoliciesIn;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#limit DataSnowflakePasswordPolicies#limit}
    */
    readonly limit?: DataSnowflakePasswordPoliciesLimit;
    /**
    * on block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#on DataSnowflakePasswordPolicies#on}
    */
    readonly on?: DataSnowflakePasswordPoliciesOn;
}
export interface DataSnowflakePasswordPoliciesPasswordPoliciesDescribeOutput {
}
export declare function dataSnowflakePasswordPoliciesPasswordPoliciesDescribeOutputToTerraform(struct?: DataSnowflakePasswordPoliciesPasswordPoliciesDescribeOutput): any;
export declare function dataSnowflakePasswordPoliciesPasswordPoliciesDescribeOutputToHclTerraform(struct?: DataSnowflakePasswordPoliciesPasswordPoliciesDescribeOutput): any;
export declare class DataSnowflakePasswordPoliciesPasswordPoliciesDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakePasswordPoliciesPasswordPoliciesDescribeOutput | undefined;
    set internalValue(value: DataSnowflakePasswordPoliciesPasswordPoliciesDescribeOutput | undefined);
    get comment(): string;
    get name(): string;
    get owner(): string;
    get passwordHistory(): number;
    get passwordLockoutTimeMins(): number;
    get passwordMaxAgeDays(): number;
    get passwordMaxLength(): number;
    get passwordMaxRetries(): number;
    get passwordMinAgeDays(): number;
    get passwordMinLength(): number;
    get passwordMinLowerCaseChars(): number;
    get passwordMinNumericChars(): number;
    get passwordMinSpecialChars(): number;
    get passwordMinUpperCaseChars(): number;
}
export declare class DataSnowflakePasswordPoliciesPasswordPoliciesDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakePasswordPoliciesPasswordPoliciesDescribeOutputOutputReference;
}
export interface DataSnowflakePasswordPoliciesPasswordPoliciesShowOutput {
}
export declare function dataSnowflakePasswordPoliciesPasswordPoliciesShowOutputToTerraform(struct?: DataSnowflakePasswordPoliciesPasswordPoliciesShowOutput): any;
export declare function dataSnowflakePasswordPoliciesPasswordPoliciesShowOutputToHclTerraform(struct?: DataSnowflakePasswordPoliciesPasswordPoliciesShowOutput): any;
export declare class DataSnowflakePasswordPoliciesPasswordPoliciesShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakePasswordPoliciesPasswordPoliciesShowOutput | undefined;
    set internalValue(value: DataSnowflakePasswordPoliciesPasswordPoliciesShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get kind(): string;
    get name(): string;
    get options(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get schemaName(): string;
}
export declare class DataSnowflakePasswordPoliciesPasswordPoliciesShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakePasswordPoliciesPasswordPoliciesShowOutputOutputReference;
}
export interface DataSnowflakePasswordPoliciesPasswordPolicies {
}
export declare function dataSnowflakePasswordPoliciesPasswordPoliciesToTerraform(struct?: DataSnowflakePasswordPoliciesPasswordPolicies): any;
export declare function dataSnowflakePasswordPoliciesPasswordPoliciesToHclTerraform(struct?: DataSnowflakePasswordPoliciesPasswordPolicies): any;
export declare class DataSnowflakePasswordPoliciesPasswordPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakePasswordPoliciesPasswordPolicies | undefined;
    set internalValue(value: DataSnowflakePasswordPoliciesPasswordPolicies | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakePasswordPoliciesPasswordPoliciesDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakePasswordPoliciesPasswordPoliciesShowOutputList;
}
export declare class DataSnowflakePasswordPoliciesPasswordPoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakePasswordPoliciesPasswordPoliciesOutputReference;
}
export interface DataSnowflakePasswordPoliciesIn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#account DataSnowflakePasswordPolicies#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the specified application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#application DataSnowflakePasswordPolicies#application}
    */
    readonly application?: string;
    /**
    * Returns records for the specified application package.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#application_package DataSnowflakePasswordPolicies#application_package}
    */
    readonly applicationPackage?: string;
    /**
    * Returns records for the current database in use or for a specified database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#database DataSnowflakePasswordPolicies#database}
    */
    readonly database?: string;
    /**
    * Returns records for the current schema in use or a specified schema. Use fully qualified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#schema DataSnowflakePasswordPolicies#schema}
    */
    readonly schema?: string;
}
export declare function dataSnowflakePasswordPoliciesInToTerraform(struct?: DataSnowflakePasswordPoliciesInOutputReference | DataSnowflakePasswordPoliciesIn): any;
export declare function dataSnowflakePasswordPoliciesInToHclTerraform(struct?: DataSnowflakePasswordPoliciesInOutputReference | DataSnowflakePasswordPoliciesIn): any;
export declare class DataSnowflakePasswordPoliciesInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakePasswordPoliciesIn | undefined;
    set internalValue(value: DataSnowflakePasswordPoliciesIn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _application?;
    get application(): string;
    set application(value: string);
    resetApplication(): void;
    get applicationInput(): string | undefined;
    private _applicationPackage?;
    get applicationPackage(): string;
    set applicationPackage(value: string);
    resetApplicationPackage(): void;
    get applicationPackageInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export interface DataSnowflakePasswordPoliciesLimit {
    /**
    * Specifies a **case-sensitive** pattern that is used to match object name. After the first match, the limit on the number of rows will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#from DataSnowflakePasswordPolicies#from}
    */
    readonly from?: string;
    /**
    * The maximum number of rows to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#rows DataSnowflakePasswordPolicies#rows}
    */
    readonly rows: number;
}
export declare function dataSnowflakePasswordPoliciesLimitToTerraform(struct?: DataSnowflakePasswordPoliciesLimitOutputReference | DataSnowflakePasswordPoliciesLimit): any;
export declare function dataSnowflakePasswordPoliciesLimitToHclTerraform(struct?: DataSnowflakePasswordPoliciesLimitOutputReference | DataSnowflakePasswordPoliciesLimit): any;
export declare class DataSnowflakePasswordPoliciesLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakePasswordPoliciesLimit | undefined;
    set internalValue(value: DataSnowflakePasswordPoliciesLimit | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _rows?;
    get rows(): number;
    set rows(value: number);
    get rowsInput(): number | undefined;
}
export interface DataSnowflakePasswordPoliciesOn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#account DataSnowflakePasswordPolicies#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the specified user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#user DataSnowflakePasswordPolicies#user}
    */
    readonly user?: string;
}
export declare function dataSnowflakePasswordPoliciesOnToTerraform(struct?: DataSnowflakePasswordPoliciesOnOutputReference | DataSnowflakePasswordPoliciesOn): any;
export declare function dataSnowflakePasswordPoliciesOnToHclTerraform(struct?: DataSnowflakePasswordPoliciesOnOutputReference | DataSnowflakePasswordPoliciesOn): any;
export declare class DataSnowflakePasswordPoliciesOnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakePasswordPoliciesOn | undefined;
    set internalValue(value: DataSnowflakePasswordPoliciesOn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies snowflake_password_policies}
*/
export declare class DataSnowflakePasswordPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_password_policies";
    /**
    * Generates CDKTN code for importing a DataSnowflakePasswordPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakePasswordPolicies to import
    * @param importFromId The id of the existing DataSnowflakePasswordPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakePasswordPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/password_policies snowflake_password_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakePasswordPoliciesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakePasswordPoliciesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _passwordPolicies;
    get passwordPolicies(): DataSnowflakePasswordPoliciesPasswordPoliciesList;
    private _startsWith?;
    get startsWith(): string;
    set startsWith(value: string);
    resetStartsWith(): void;
    get startsWithInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _in;
    get in(): DataSnowflakePasswordPoliciesInOutputReference;
    putIn(value: DataSnowflakePasswordPoliciesIn): void;
    resetIn(): void;
    get inInput(): DataSnowflakePasswordPoliciesIn | undefined;
    private _limit;
    get limit(): DataSnowflakePasswordPoliciesLimitOutputReference;
    putLimit(value: DataSnowflakePasswordPoliciesLimit): void;
    resetLimit(): void;
    get limitInput(): DataSnowflakePasswordPoliciesLimit | undefined;
    private _on;
    get on(): DataSnowflakePasswordPoliciesOnOutputReference;
    putOn(value: DataSnowflakePasswordPoliciesOn): void;
    resetOn(): void;
    get onInput(): DataSnowflakePasswordPoliciesOn | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
