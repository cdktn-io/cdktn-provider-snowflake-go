/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NotebookConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the notebook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#comment Notebook#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the notebook. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#database Notebook#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#id Notebook#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the number of seconds of idle time before the notebook is shut down automatically.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#idle_auto_shutdown_time_seconds Notebook#idle_auto_shutdown_time_seconds}
    */
    readonly idleAutoShutdownTimeSeconds?: number;
    /**
    * Specifies a user-specified identifier for the notebook file name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#main_file Notebook#main_file}
    */
    readonly mainFile?: string;
    /**
    * Specifies the identifier for the notebook; must be unique for the schema in which the notebook is created. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#name Notebook#name}
    */
    readonly name: string;
    /**
    * Specifies the warehouse where SQL queries in the notebook are run. Only upper-case identifiers are supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#query_warehouse Notebook#query_warehouse}
    */
    readonly queryWarehouse?: string;
    /**
    * The schema in which to create the notebook. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#schema Notebook#schema}
    */
    readonly schema: string;
    /**
    * Specifies the warehouse that runs the notebook kernel and python code. Only upper-case identifiers are supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#warehouse Notebook#warehouse}
    */
    readonly warehouse?: string;
    /**
    * from block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#from Notebook#from}
    */
    readonly from?: NotebookFrom[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#timeouts Notebook#timeouts}
    */
    readonly timeouts?: NotebookTimeouts;
}
export interface NotebookDescribeOutput {
}
export declare function notebookDescribeOutputToTerraform(struct?: NotebookDescribeOutput): any;
export declare function notebookDescribeOutputToHclTerraform(struct?: NotebookDescribeOutput): any;
export declare class NotebookDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NotebookDescribeOutput | undefined;
    set internalValue(value: NotebookDescribeOutput | undefined);
    get codeWarehouse(): string;
    get comment(): string;
    get computePool(): string;
    get defaultPackages(): string;
    get defaultVersion(): string;
    get defaultVersionAlias(): string;
    get defaultVersionGitCommitHash(): string;
    get defaultVersionLocationUri(): string;
    get defaultVersionName(): string;
    get defaultVersionSourceLocationUri(): string;
    get externalAccessIntegrations(): string;
    get externalAccessSecrets(): string;
    get idleAutoShutdownTimeSeconds(): number;
    get importUrls(): string;
    get lastVersionAlias(): string;
    get lastVersionGitCommitHash(): string;
    get lastVersionLocationUri(): string;
    get lastVersionName(): string;
    get lastVersionSourceLocationUri(): string;
    get liveVersionLocationUri(): string;
    get mainFile(): string;
    get name(): string;
    get owner(): string;
    get queryWarehouse(): string;
    get runtimeEnvironmentVersion(): string;
    get runtimeName(): string;
    get title(): string;
    get urlId(): string;
    get userPackages(): string;
}
export declare class NotebookDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NotebookDescribeOutputOutputReference;
}
export interface NotebookShowOutput {
}
export declare function notebookShowOutputToTerraform(struct?: NotebookShowOutput): any;
export declare function notebookShowOutputToHclTerraform(struct?: NotebookShowOutput): any;
export declare class NotebookShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NotebookShowOutput | undefined;
    set internalValue(value: NotebookShowOutput | undefined);
    get codeWarehouse(): string;
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get queryWarehouse(): string;
    get schemaName(): string;
    get urlId(): string;
}
export declare class NotebookShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NotebookShowOutputOutputReference;
}
export interface NotebookFrom {
    /**
    * Location of the .ipynb file in the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#path Notebook#path}
    */
    readonly path?: string;
    /**
    * Identifier of the stage where the .ipynb file is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#stage Notebook#stage}
    */
    readonly stage: string;
}
export declare function notebookFromToTerraform(struct?: NotebookFrom | cdktn.IResolvable): any;
export declare function notebookFromToHclTerraform(struct?: NotebookFrom | cdktn.IResolvable): any;
export declare class NotebookFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NotebookFrom | cdktn.IResolvable | undefined;
    set internalValue(value: NotebookFrom | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _stage?;
    get stage(): string;
    set stage(value: string);
    get stageInput(): string | undefined;
}
export declare class NotebookFromList extends cdktn.ComplexList {
    internalValue?: NotebookFrom[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NotebookFromOutputReference;
}
export interface NotebookTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#create Notebook#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#delete Notebook#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#read Notebook#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#update Notebook#update}
    */
    readonly update?: string;
}
export declare function notebookTimeoutsToTerraform(struct?: NotebookTimeouts | cdktn.IResolvable): any;
export declare function notebookTimeoutsToHclTerraform(struct?: NotebookTimeouts | cdktn.IResolvable): any;
export declare class NotebookTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotebookTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: NotebookTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook snowflake_notebook}
*/
export declare class Notebook extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_notebook";
    /**
    * Generates CDKTN code for importing a Notebook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Notebook to import
    * @param importFromId The id of the existing Notebook that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Notebook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/notebook snowflake_notebook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NotebookConfig
    */
    constructor(scope: Construct, id: string, config: NotebookConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): NotebookDescribeOutputList;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idleAutoShutdownTimeSeconds?;
    get idleAutoShutdownTimeSeconds(): number;
    set idleAutoShutdownTimeSeconds(value: number);
    resetIdleAutoShutdownTimeSeconds(): void;
    get idleAutoShutdownTimeSecondsInput(): number | undefined;
    private _mainFile?;
    get mainFile(): string;
    set mainFile(value: string);
    resetMainFile(): void;
    get mainFileInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _queryWarehouse?;
    get queryWarehouse(): string;
    set queryWarehouse(value: string);
    resetQueryWarehouse(): void;
    get queryWarehouseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): NotebookShowOutputList;
    private _warehouse?;
    get warehouse(): string;
    set warehouse(value: string);
    resetWarehouse(): void;
    get warehouseInput(): string | undefined;
    private _from;
    get from(): NotebookFromList;
    putFrom(value: NotebookFrom[] | cdktn.IResolvable): void;
    resetFrom(): void;
    get fromInput(): cdktn.IResolvable | NotebookFrom[] | undefined;
    private _timeouts;
    get timeouts(): NotebookTimeoutsOutputReference;
    putTimeouts(value: NotebookTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | NotebookTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
