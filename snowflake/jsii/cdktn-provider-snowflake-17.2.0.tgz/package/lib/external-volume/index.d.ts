/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ExternalVolumeConfig extends cdktn.TerraformMetaArguments {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether write operations are allowed for the external volume; must be set to TRUE for Iceberg tables that use Snowflake as the catalog. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#allow_writes ExternalVolume#allow_writes}
    */
    readonly allowWrites?: string;
    /**
    * Specifies a comment for the external volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#comment ExternalVolume#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#id ExternalVolume#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Identifier for the external volume; must be unique for your account. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#name ExternalVolume#name}
    */
    readonly name: string;
    /**
    * storage_location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#storage_location ExternalVolume#storage_location}
    */
    readonly storageLocation: ExternalVolumeStorageLocation[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#timeouts ExternalVolume#timeouts}
    */
    readonly timeouts?: ExternalVolumeTimeouts;
}
export interface ExternalVolumeDescribeOutputStorageLocationsAzureStorageLocation {
}
export declare function externalVolumeDescribeOutputStorageLocationsAzureStorageLocationToTerraform(struct?: ExternalVolumeDescribeOutputStorageLocationsAzureStorageLocation): any;
export declare function externalVolumeDescribeOutputStorageLocationsAzureStorageLocationToHclTerraform(struct?: ExternalVolumeDescribeOutputStorageLocationsAzureStorageLocation): any;
export declare class ExternalVolumeDescribeOutputStorageLocationsAzureStorageLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ExternalVolumeDescribeOutputStorageLocationsAzureStorageLocation | undefined;
    set internalValue(value: ExternalVolumeDescribeOutputStorageLocationsAzureStorageLocation | undefined);
    get azureConsentUrl(): string;
    get azureMultiTenantAppName(): string;
    get azureTenantId(): string;
    get usePrivatelinkEndpoint(): string;
}
export declare class ExternalVolumeDescribeOutputStorageLocationsAzureStorageLocationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ExternalVolumeDescribeOutputStorageLocationsAzureStorageLocationOutputReference;
}
export interface ExternalVolumeDescribeOutputStorageLocationsGcsStorageLocation {
}
export declare function externalVolumeDescribeOutputStorageLocationsGcsStorageLocationToTerraform(struct?: ExternalVolumeDescribeOutputStorageLocationsGcsStorageLocation): any;
export declare function externalVolumeDescribeOutputStorageLocationsGcsStorageLocationToHclTerraform(struct?: ExternalVolumeDescribeOutputStorageLocationsGcsStorageLocation): any;
export declare class ExternalVolumeDescribeOutputStorageLocationsGcsStorageLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ExternalVolumeDescribeOutputStorageLocationsGcsStorageLocation | undefined;
    set internalValue(value: ExternalVolumeDescribeOutputStorageLocationsGcsStorageLocation | undefined);
    get encryptionKmsKeyId(): string;
    get storageGcpServiceAccount(): string;
}
export declare class ExternalVolumeDescribeOutputStorageLocationsGcsStorageLocationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ExternalVolumeDescribeOutputStorageLocationsGcsStorageLocationOutputReference;
}
export interface ExternalVolumeDescribeOutputStorageLocationsS3CompatStorageLocation {
}
export declare function externalVolumeDescribeOutputStorageLocationsS3CompatStorageLocationToTerraform(struct?: ExternalVolumeDescribeOutputStorageLocationsS3CompatStorageLocation): any;
export declare function externalVolumeDescribeOutputStorageLocationsS3CompatStorageLocationToHclTerraform(struct?: ExternalVolumeDescribeOutputStorageLocationsS3CompatStorageLocation): any;
export declare class ExternalVolumeDescribeOutputStorageLocationsS3CompatStorageLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ExternalVolumeDescribeOutputStorageLocationsS3CompatStorageLocation | undefined;
    set internalValue(value: ExternalVolumeDescribeOutputStorageLocationsS3CompatStorageLocation | undefined);
    get awsAccessKeyId(): string;
    get encryptionKmsKeyId(): string;
    get endpoint(): string;
}
export declare class ExternalVolumeDescribeOutputStorageLocationsS3CompatStorageLocationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ExternalVolumeDescribeOutputStorageLocationsS3CompatStorageLocationOutputReference;
}
export interface ExternalVolumeDescribeOutputStorageLocationsS3StorageLocation {
}
export declare function externalVolumeDescribeOutputStorageLocationsS3StorageLocationToTerraform(struct?: ExternalVolumeDescribeOutputStorageLocationsS3StorageLocation): any;
export declare function externalVolumeDescribeOutputStorageLocationsS3StorageLocationToHclTerraform(struct?: ExternalVolumeDescribeOutputStorageLocationsS3StorageLocation): any;
export declare class ExternalVolumeDescribeOutputStorageLocationsS3StorageLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ExternalVolumeDescribeOutputStorageLocationsS3StorageLocation | undefined;
    set internalValue(value: ExternalVolumeDescribeOutputStorageLocationsS3StorageLocation | undefined);
    get encryptionKmsKeyId(): string;
    get storageAwsAccessPointArn(): string;
    get storageAwsExternalId(): string;
    get storageAwsIamUserArn(): string;
    get storageAwsRoleArn(): string;
    get usePrivatelinkEndpoint(): string;
}
export declare class ExternalVolumeDescribeOutputStorageLocationsS3StorageLocationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ExternalVolumeDescribeOutputStorageLocationsS3StorageLocationOutputReference;
}
export interface ExternalVolumeDescribeOutputStorageLocations {
}
export declare function externalVolumeDescribeOutputStorageLocationsToTerraform(struct?: ExternalVolumeDescribeOutputStorageLocations): any;
export declare function externalVolumeDescribeOutputStorageLocationsToHclTerraform(struct?: ExternalVolumeDescribeOutputStorageLocations): any;
export declare class ExternalVolumeDescribeOutputStorageLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ExternalVolumeDescribeOutputStorageLocations | undefined;
    set internalValue(value: ExternalVolumeDescribeOutputStorageLocations | undefined);
    private _azureStorageLocation;
    get azureStorageLocation(): ExternalVolumeDescribeOutputStorageLocationsAzureStorageLocationList;
    get encryptionType(): string;
    private _gcsStorageLocation;
    get gcsStorageLocation(): ExternalVolumeDescribeOutputStorageLocationsGcsStorageLocationList;
    get name(): string;
    private _s3CompatStorageLocation;
    get s3CompatStorageLocation(): ExternalVolumeDescribeOutputStorageLocationsS3CompatStorageLocationList;
    private _s3StorageLocation;
    get s3StorageLocation(): ExternalVolumeDescribeOutputStorageLocationsS3StorageLocationList;
    get storageAllowedLocations(): string[];
    get storageBaseUrl(): string;
    get storageProvider(): string;
}
export declare class ExternalVolumeDescribeOutputStorageLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ExternalVolumeDescribeOutputStorageLocationsOutputReference;
}
export interface ExternalVolumeDescribeOutput {
}
export declare function externalVolumeDescribeOutputToTerraform(struct?: ExternalVolumeDescribeOutput): any;
export declare function externalVolumeDescribeOutputToHclTerraform(struct?: ExternalVolumeDescribeOutput): any;
export declare class ExternalVolumeDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ExternalVolumeDescribeOutput | undefined;
    set internalValue(value: ExternalVolumeDescribeOutput | undefined);
    get active(): string;
    get allowWrites(): string;
    get comment(): string;
    private _storageLocations;
    get storageLocations(): ExternalVolumeDescribeOutputStorageLocationsList;
}
export declare class ExternalVolumeDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ExternalVolumeDescribeOutputOutputReference;
}
export interface ExternalVolumeShowOutput {
}
export declare function externalVolumeShowOutputToTerraform(struct?: ExternalVolumeShowOutput): any;
export declare function externalVolumeShowOutputToHclTerraform(struct?: ExternalVolumeShowOutput): any;
export declare class ExternalVolumeShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ExternalVolumeShowOutput | undefined;
    set internalValue(value: ExternalVolumeShowOutput | undefined);
    get allowWrites(): cdktn.IResolvable;
    get comment(): string;
    get name(): string;
}
export declare class ExternalVolumeShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ExternalVolumeShowOutputOutputReference;
}
export interface ExternalVolumeStorageLocation {
    /**
    * Specifies the ID for your Office 365 tenant that the allowed and blocked storage accounts belong to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#azure_tenant_id ExternalVolume#azure_tenant_id}
    */
    readonly azureTenantId?: string;
    /**
    * Specifies the ID for the KMS-managed key used to encrypt files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#encryption_kms_key_id ExternalVolume#encryption_kms_key_id}
    */
    readonly encryptionKmsKeyId?: string;
    /**
    * Specifies the encryption type used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#encryption_type ExternalVolume#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Specifies the access point ARN for the S3 bucket containing your data files. Only applicable for S3 and S3GOV storage providers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#storage_aws_access_point_arn ExternalVolume#storage_aws_access_point_arn}
    */
    readonly storageAwsAccessPointArn?: string;
    /**
    * External ID that Snowflake uses to establish a trust relationship with AWS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#storage_aws_external_id ExternalVolume#storage_aws_external_id}
    */
    readonly storageAwsExternalId?: string;
    /**
    * Specifies the AWS key ID for the S3-compatible storage location. Only applicable for S3COMPAT storage provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#storage_aws_key_id ExternalVolume#storage_aws_key_id}
    */
    readonly storageAwsKeyId?: string;
    /**
    * Specifies the case-sensitive Amazon Resource Name (ARN) of the AWS identity and access management (IAM) role that grants privileges on the S3 bucket containing your data files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#storage_aws_role_arn ExternalVolume#storage_aws_role_arn}
    */
    readonly storageAwsRoleArn?: string;
    /**
    * Specifies the AWS secret key for the S3-compatible storage location. Only applicable for S3COMPAT storage provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#storage_aws_secret_key ExternalVolume#storage_aws_secret_key}
    */
    readonly storageAwsSecretKey?: string;
    /**
    * Specifies the base URL for your cloud storage location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#storage_base_url ExternalVolume#storage_base_url}
    */
    readonly storageBaseUrl: string;
    /**
    * Specifies the endpoint for the S3-compatible storage location. Only applicable for S3COMPAT storage provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#storage_endpoint ExternalVolume#storage_endpoint}
    */
    readonly storageEndpoint?: string;
    /**
    * Name of the storage location. Must be unique for the external volume. Do not use the name `terraform_provider_sentinel_storage_location` - this is reserved for the provider for performing update operations. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#storage_location_name ExternalVolume#storage_location_name}
    */
    readonly storageLocationName: string;
    /**
    * Specifies the cloud storage provider that stores your data files. Valid values are (case-insensitive): `GCS` | `AZURE` | `S3` | `S3GOV` | `S3COMPAT`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#storage_provider ExternalVolume#storage_provider}
    */
    readonly storageProvider: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether to use a privatelink endpoint for the storage location. Only applicable for S3, S3GOV, and AZURE storage providers. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#use_privatelink_endpoint ExternalVolume#use_privatelink_endpoint}
    */
    readonly usePrivatelinkEndpoint?: string;
}
export declare function externalVolumeStorageLocationToTerraform(struct?: ExternalVolumeStorageLocation | cdktn.IResolvable): any;
export declare function externalVolumeStorageLocationToHclTerraform(struct?: ExternalVolumeStorageLocation | cdktn.IResolvable): any;
export declare class ExternalVolumeStorageLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ExternalVolumeStorageLocation | cdktn.IResolvable | undefined;
    set internalValue(value: ExternalVolumeStorageLocation | cdktn.IResolvable | undefined);
    private _azureTenantId?;
    get azureTenantId(): string;
    set azureTenantId(value: string);
    resetAzureTenantId(): void;
    get azureTenantIdInput(): string | undefined;
    private _encryptionKmsKeyId?;
    get encryptionKmsKeyId(): string;
    set encryptionKmsKeyId(value: string);
    resetEncryptionKmsKeyId(): void;
    get encryptionKmsKeyIdInput(): string | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _storageAwsAccessPointArn?;
    get storageAwsAccessPointArn(): string;
    set storageAwsAccessPointArn(value: string);
    resetStorageAwsAccessPointArn(): void;
    get storageAwsAccessPointArnInput(): string | undefined;
    private _storageAwsExternalId?;
    get storageAwsExternalId(): string;
    set storageAwsExternalId(value: string);
    resetStorageAwsExternalId(): void;
    get storageAwsExternalIdInput(): string | undefined;
    private _storageAwsKeyId?;
    get storageAwsKeyId(): string;
    set storageAwsKeyId(value: string);
    resetStorageAwsKeyId(): void;
    get storageAwsKeyIdInput(): string | undefined;
    private _storageAwsRoleArn?;
    get storageAwsRoleArn(): string;
    set storageAwsRoleArn(value: string);
    resetStorageAwsRoleArn(): void;
    get storageAwsRoleArnInput(): string | undefined;
    private _storageAwsSecretKey?;
    get storageAwsSecretKey(): string;
    set storageAwsSecretKey(value: string);
    resetStorageAwsSecretKey(): void;
    get storageAwsSecretKeyInput(): string | undefined;
    private _storageBaseUrl?;
    get storageBaseUrl(): string;
    set storageBaseUrl(value: string);
    get storageBaseUrlInput(): string | undefined;
    private _storageEndpoint?;
    get storageEndpoint(): string;
    set storageEndpoint(value: string);
    resetStorageEndpoint(): void;
    get storageEndpointInput(): string | undefined;
    private _storageLocationName?;
    get storageLocationName(): string;
    set storageLocationName(value: string);
    get storageLocationNameInput(): string | undefined;
    private _storageProvider?;
    get storageProvider(): string;
    set storageProvider(value: string);
    get storageProviderInput(): string | undefined;
    private _usePrivatelinkEndpoint?;
    get usePrivatelinkEndpoint(): string;
    set usePrivatelinkEndpoint(value: string);
    resetUsePrivatelinkEndpoint(): void;
    get usePrivatelinkEndpointInput(): string | undefined;
}
export declare class ExternalVolumeStorageLocationList extends cdktn.ComplexList {
    internalValue?: ExternalVolumeStorageLocation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ExternalVolumeStorageLocationOutputReference;
}
export interface ExternalVolumeTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#create ExternalVolume#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#delete ExternalVolume#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#read ExternalVolume#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#update ExternalVolume#update}
    */
    readonly update?: string;
}
export declare function externalVolumeTimeoutsToTerraform(struct?: ExternalVolumeTimeouts | cdktn.IResolvable): any;
export declare function externalVolumeTimeoutsToHclTerraform(struct?: ExternalVolumeTimeouts | cdktn.IResolvable): any;
export declare class ExternalVolumeTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalVolumeTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ExternalVolumeTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume snowflake_external_volume}
*/
export declare class ExternalVolume extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_external_volume";
    /**
    * Generates CDKTN code for importing a ExternalVolume resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ExternalVolume to import
    * @param importFromId The id of the existing ExternalVolume that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ExternalVolume to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/external_volume snowflake_external_volume} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ExternalVolumeConfig
    */
    constructor(scope: Construct, id: string, config: ExternalVolumeConfig);
    private _allowWrites?;
    get allowWrites(): string;
    set allowWrites(value: string);
    resetAllowWrites(): void;
    get allowWritesInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): ExternalVolumeDescribeOutputList;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _showOutput;
    get showOutput(): ExternalVolumeShowOutputList;
    private _storageLocation;
    get storageLocation(): ExternalVolumeStorageLocationList;
    putStorageLocation(value: ExternalVolumeStorageLocation[] | cdktn.IResolvable): void;
    get storageLocationInput(): cdktn.IResolvable | ExternalVolumeStorageLocation[] | undefined;
    private _timeouts;
    get timeouts(): ExternalVolumeTimeoutsOutputReference;
    putTimeouts(value: ExternalVolumeTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ExternalVolumeTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
