/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface UserAuthenticationPolicyAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Fully qualified name of the authentication policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_authentication_policy_attachment#authentication_policy_name UserAuthenticationPolicyAttachment#authentication_policy_name}
    */
    readonly authenticationPolicyName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_authentication_policy_attachment#id UserAuthenticationPolicyAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * User name of the user you want to attach the authentication policy to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_authentication_policy_attachment#user_name UserAuthenticationPolicyAttachment#user_name}
    */
    readonly userName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_authentication_policy_attachment#timeouts UserAuthenticationPolicyAttachment#timeouts}
    */
    readonly timeouts?: UserAuthenticationPolicyAttachmentTimeouts;
}
export interface UserAuthenticationPolicyAttachmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_authentication_policy_attachment#create UserAuthenticationPolicyAttachment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_authentication_policy_attachment#delete UserAuthenticationPolicyAttachment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_authentication_policy_attachment#read UserAuthenticationPolicyAttachment#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_authentication_policy_attachment#update UserAuthenticationPolicyAttachment#update}
    */
    readonly update?: string;
}
export declare function userAuthenticationPolicyAttachmentTimeoutsToTerraform(struct?: UserAuthenticationPolicyAttachmentTimeouts | cdktn.IResolvable): any;
export declare function userAuthenticationPolicyAttachmentTimeoutsToHclTerraform(struct?: UserAuthenticationPolicyAttachmentTimeouts | cdktn.IResolvable): any;
export declare class UserAuthenticationPolicyAttachmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): UserAuthenticationPolicyAttachmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: UserAuthenticationPolicyAttachmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_authentication_policy_attachment snowflake_user_authentication_policy_attachment}
*/
export declare class UserAuthenticationPolicyAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_user_authentication_policy_attachment";
    /**
    * Generates CDKTN code for importing a UserAuthenticationPolicyAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserAuthenticationPolicyAttachment to import
    * @param importFromId The id of the existing UserAuthenticationPolicyAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_authentication_policy_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserAuthenticationPolicyAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_authentication_policy_attachment snowflake_user_authentication_policy_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserAuthenticationPolicyAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: UserAuthenticationPolicyAttachmentConfig);
    private _authenticationPolicyName?;
    get authenticationPolicyName(): string;
    set authenticationPolicyName(value: string);
    get authenticationPolicyNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    get userNameInput(): string | undefined;
    private _timeouts;
    get timeouts(): UserAuthenticationPolicyAttachmentTimeoutsOutputReference;
    putTimeouts(value: UserAuthenticationPolicyAttachmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | UserAuthenticationPolicyAttachmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
