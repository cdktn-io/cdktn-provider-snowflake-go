/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApiIntegrationGitRepositoryPrivateLinkConfig extends cdktn.TerraformMetaArguments {
    /**
    * When set to true, all authentication secrets are allowed to be used when authenticating to the git repository. Conflicts with `no_allowed_authentication_secrets` and `allowed_authentication_secrets`. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#all_allowed_authentication_secrets ApiIntegrationGitRepositoryPrivateLink#all_allowed_authentication_secrets}
    */
    readonly allAllowedAuthenticationSecrets?: boolean | cdktn.IResolvable;
    /**
    * A list of fully-qualified secret identifiers (database.schema.secret) allowed to be used when authenticating to the git repository. Conflicts with `all_allowed_authentication_secrets` and `no_allowed_authentication_secrets`. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#allowed_authentication_secrets ApiIntegrationGitRepositoryPrivateLink#allowed_authentication_secrets}
    */
    readonly allowedAuthenticationSecrets?: string[];
    /**
    * Explicitly limits external functions that use the integration to reference one or more HTTPS proxy service and remote service endpoints and resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#api_allowed_prefixes ApiIntegrationGitRepositoryPrivateLink#api_allowed_prefixes}
    */
    readonly apiAllowedPrefixes: string[];
    /**
    * Lists the endpoints and resources in the HTTPS proxy service that are not allowed to be called from Snowflake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#api_blocked_prefixes ApiIntegrationGitRepositoryPrivateLink#api_blocked_prefixes}
    */
    readonly apiBlockedPrefixes?: string[];
    /**
    * Specifies a comment for the integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#comment ApiIntegrationGitRepositoryPrivateLink#comment}
    */
    readonly comment?: string;
    /**
    * Specifies whether this API integration is enabled or disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#enabled ApiIntegrationGitRepositoryPrivateLink#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#id ApiIntegrationGitRepositoryPrivateLink#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier (i.e. name) for the integration. This value must be unique in your account. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#name ApiIntegrationGitRepositoryPrivateLink#name}
    */
    readonly name: string;
    /**
    * When set to true, no authentication secrets are allowed to be used when authenticating to the git repository. Conflicts with `all_allowed_authentication_secrets` and `allowed_authentication_secrets`. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#no_allowed_authentication_secrets ApiIntegrationGitRepositoryPrivateLink#no_allowed_authentication_secrets}
    */
    readonly noAllowedAuthenticationSecrets?: boolean | cdktn.IResolvable;
    /**
    * Specifies secrets containing self-signed certificates to be used when authenticating with a Git repository server over private link. Only needed when the certificate is self-signed rather than signed by a certificate authority. Each entry must be a fully-qualified name of a Snowflake secret of type generic string whose value is Base64-encoded certificate data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#tls_trusted_certificates ApiIntegrationGitRepositoryPrivateLink#tls_trusted_certificates}
    */
    readonly tlsTrustedCertificates?: string[];
    /**
    * Specifies whether to use the private link endpoint for the git repository. When set to true, Snowflake uses the VNet-injected endpoint for the git repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#use_privatelink_endpoint ApiIntegrationGitRepositoryPrivateLink#use_privatelink_endpoint}
    */
    readonly usePrivatelinkEndpoint: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#timeouts ApiIntegrationGitRepositoryPrivateLink#timeouts}
    */
    readonly timeouts?: ApiIntegrationGitRepositoryPrivateLinkTimeouts;
}
export interface ApiIntegrationGitRepositoryPrivateLinkDescribeOutput {
}
export declare function apiIntegrationGitRepositoryPrivateLinkDescribeOutputToTerraform(struct?: ApiIntegrationGitRepositoryPrivateLinkDescribeOutput): any;
export declare function apiIntegrationGitRepositoryPrivateLinkDescribeOutputToHclTerraform(struct?: ApiIntegrationGitRepositoryPrivateLinkDescribeOutput): any;
export declare class ApiIntegrationGitRepositoryPrivateLinkDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiIntegrationGitRepositoryPrivateLinkDescribeOutput | undefined;
    set internalValue(value: ApiIntegrationGitRepositoryPrivateLinkDescribeOutput | undefined);
    get allowedAuthenticationSecrets(): string;
    get allowedPrefixes(): string[];
    get apiProvider(): string;
    get blockedPrefixes(): string[];
    get comment(): string;
    get enabled(): cdktn.IResolvable;
    get tlsTrustedCertificates(): string[];
    get usePrivatelinkEndpoint(): cdktn.IResolvable;
}
export declare class ApiIntegrationGitRepositoryPrivateLinkDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiIntegrationGitRepositoryPrivateLinkDescribeOutputOutputReference;
}
export interface ApiIntegrationGitRepositoryPrivateLinkShowOutput {
}
export declare function apiIntegrationGitRepositoryPrivateLinkShowOutputToTerraform(struct?: ApiIntegrationGitRepositoryPrivateLinkShowOutput): any;
export declare function apiIntegrationGitRepositoryPrivateLinkShowOutputToHclTerraform(struct?: ApiIntegrationGitRepositoryPrivateLinkShowOutput): any;
export declare class ApiIntegrationGitRepositoryPrivateLinkShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiIntegrationGitRepositoryPrivateLinkShowOutput | undefined;
    set internalValue(value: ApiIntegrationGitRepositoryPrivateLinkShowOutput | undefined);
    get apiType(): string;
    get category(): string;
    get comment(): string;
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
}
export declare class ApiIntegrationGitRepositoryPrivateLinkShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiIntegrationGitRepositoryPrivateLinkShowOutputOutputReference;
}
export interface ApiIntegrationGitRepositoryPrivateLinkTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#create ApiIntegrationGitRepositoryPrivateLink#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#delete ApiIntegrationGitRepositoryPrivateLink#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#read ApiIntegrationGitRepositoryPrivateLink#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#update ApiIntegrationGitRepositoryPrivateLink#update}
    */
    readonly update?: string;
}
export declare function apiIntegrationGitRepositoryPrivateLinkTimeoutsToTerraform(struct?: ApiIntegrationGitRepositoryPrivateLinkTimeouts | cdktn.IResolvable): any;
export declare function apiIntegrationGitRepositoryPrivateLinkTimeoutsToHclTerraform(struct?: ApiIntegrationGitRepositoryPrivateLinkTimeouts | cdktn.IResolvable): any;
export declare class ApiIntegrationGitRepositoryPrivateLinkTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiIntegrationGitRepositoryPrivateLinkTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApiIntegrationGitRepositoryPrivateLinkTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link snowflake_api_integration_git_repository_private_link}
*/
export declare class ApiIntegrationGitRepositoryPrivateLink extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_api_integration_git_repository_private_link";
    /**
    * Generates CDKTN code for importing a ApiIntegrationGitRepositoryPrivateLink resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApiIntegrationGitRepositoryPrivateLink to import
    * @param importFromId The id of the existing ApiIntegrationGitRepositoryPrivateLink that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApiIntegrationGitRepositoryPrivateLink to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/api_integration_git_repository_private_link snowflake_api_integration_git_repository_private_link} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApiIntegrationGitRepositoryPrivateLinkConfig
    */
    constructor(scope: Construct, id: string, config: ApiIntegrationGitRepositoryPrivateLinkConfig);
    private _allAllowedAuthenticationSecrets?;
    get allAllowedAuthenticationSecrets(): boolean | cdktn.IResolvable;
    set allAllowedAuthenticationSecrets(value: boolean | cdktn.IResolvable);
    resetAllAllowedAuthenticationSecrets(): void;
    get allAllowedAuthenticationSecretsInput(): boolean | cdktn.IResolvable | undefined;
    private _allowedAuthenticationSecrets?;
    get allowedAuthenticationSecrets(): string[];
    set allowedAuthenticationSecrets(value: string[]);
    resetAllowedAuthenticationSecrets(): void;
    get allowedAuthenticationSecretsInput(): string[] | undefined;
    private _apiAllowedPrefixes?;
    get apiAllowedPrefixes(): string[];
    set apiAllowedPrefixes(value: string[]);
    get apiAllowedPrefixesInput(): string[] | undefined;
    private _apiBlockedPrefixes?;
    get apiBlockedPrefixes(): string[];
    set apiBlockedPrefixes(value: string[]);
    resetApiBlockedPrefixes(): void;
    get apiBlockedPrefixesInput(): string[] | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): ApiIntegrationGitRepositoryPrivateLinkDescribeOutputList;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _noAllowedAuthenticationSecrets?;
    get noAllowedAuthenticationSecrets(): boolean | cdktn.IResolvable;
    set noAllowedAuthenticationSecrets(value: boolean | cdktn.IResolvable);
    resetNoAllowedAuthenticationSecrets(): void;
    get noAllowedAuthenticationSecretsInput(): boolean | cdktn.IResolvable | undefined;
    private _showOutput;
    get showOutput(): ApiIntegrationGitRepositoryPrivateLinkShowOutputList;
    private _tlsTrustedCertificates?;
    get tlsTrustedCertificates(): string[];
    set tlsTrustedCertificates(value: string[]);
    resetTlsTrustedCertificates(): void;
    get tlsTrustedCertificatesInput(): string[] | undefined;
    private _usePrivatelinkEndpoint?;
    get usePrivatelinkEndpoint(): boolean | cdktn.IResolvable;
    set usePrivatelinkEndpoint(value: boolean | cdktn.IResolvable);
    get usePrivatelinkEndpointInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): ApiIntegrationGitRepositoryPrivateLinkTimeoutsOutputReference;
    putTimeouts(value: ApiIntegrationGitRepositoryPrivateLinkTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApiIntegrationGitRepositoryPrivateLinkTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
