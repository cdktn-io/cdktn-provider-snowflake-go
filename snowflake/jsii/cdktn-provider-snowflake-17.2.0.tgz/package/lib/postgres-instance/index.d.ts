/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PostgresInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the authentication authority for the Postgres instance. Valid values are (case-insensitive): `POSTGRES` | `POSTGRES_OR_SNOWFLAKE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#authentication_authority PostgresInstance#authentication_authority}
    */
    readonly authenticationAuthority: string;
    /**
    * Specifies a comment for the Postgres instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#comment PostgresInstance#comment}
    */
    readonly comment?: string;
    /**
    * Specifies the compute family for the Postgres instance. Valid values are (case-insensitive): `STANDARD_M` | `STANDARD_L` | `STANDARD_XL` | `STANDARD_2XL` | `STANDARD_4XL` | `STANDARD_8XL` | `STANDARD_12XL` | `STANDARD_24XL` | `HIGHMEM_L` | `HIGHMEM_XL` | `HIGHMEM_2XL` | `HIGHMEM_4XL` | `HIGHMEM_8XL` | `HIGHMEM_12XL` | `HIGHMEM_16XL` | `HIGHMEM_24XL` | `HIGHMEM_32XL` | `HIGHMEM_48XL` | `BURST_XS` | `BURST_S` | `BURST_M`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#compute_family PostgresInstance#compute_family}
    */
    readonly computeFamily: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether the Postgres instance should be configured for high availability. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#high_availability PostgresInstance#high_availability}
    */
    readonly highAvailability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#id PostgresInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`-1`)) Specifies the hour (0-23 UTC) at which the maintenance window starts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#maintenance_window_start PostgresInstance#maintenance_window_start}
    */
    readonly maintenanceWindowStart?: number;
    /**
    * Specifies the identifier for the Postgres instance; must be unique for your account. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#name PostgresInstance#name}
    */
    readonly name: string;
    /**
    * Specifies the network policy to associate with the Postgres instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#network_policy PostgresInstance#network_policy}
    */
    readonly networkPolicy?: string;
    /**
    * Specifies custom Postgres settings as a JSON string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#postgres_settings PostgresInstance#postgres_settings}
    */
    readonly postgresSettings?: string;
    /**
    * Specifies the Postgres version for the instance. Note that Snowflake does not allow downgrading; the version can only be upgraded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#postgres_version PostgresInstance#postgres_version}
    */
    readonly postgresVersion: number;
    /**
    * Specifies the storage integration for the Postgres instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#storage_integration PostgresInstance#storage_integration}
    */
    readonly storageIntegration?: string;
    /**
    * Specifies the storage size in GB for the Postgres instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#storage_size_gb PostgresInstance#storage_size_gb}
    */
    readonly storageSizeGb: number;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#timeouts PostgresInstance#timeouts}
    */
    readonly timeouts?: PostgresInstanceTimeouts;
}
export interface PostgresInstanceDescribeOutput {
}
export declare function postgresInstanceDescribeOutputToTerraform(struct?: PostgresInstanceDescribeOutput): any;
export declare function postgresInstanceDescribeOutputToHclTerraform(struct?: PostgresInstanceDescribeOutput): any;
export declare class PostgresInstanceDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PostgresInstanceDescribeOutput | undefined;
    set internalValue(value: PostgresInstanceDescribeOutput | undefined);
    get authenticationAuthority(): string;
    get comment(): string;
    get computeFamily(): string;
    get createdOn(): string;
    get highAvailability(): cdktn.IResolvable;
    get host(): string;
    get maintenanceWindowStart(): number;
    get name(): string;
    get networkPolicy(): string;
    get origin(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get postgresSettings(): string;
    get postgresVersion(): number;
    get privatelinkServiceIdentifier(): string;
    get retentionTime(): number;
    get state(): string;
    get storageIntegration(): string;
    get storageSizeGb(): number;
    get type(): string;
    get updatedOn(): string;
}
export declare class PostgresInstanceDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PostgresInstanceDescribeOutputOutputReference;
}
export interface PostgresInstanceShowOutput {
}
export declare function postgresInstanceShowOutputToTerraform(struct?: PostgresInstanceShowOutput): any;
export declare function postgresInstanceShowOutputToHclTerraform(struct?: PostgresInstanceShowOutput): any;
export declare class PostgresInstanceShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PostgresInstanceShowOutput | undefined;
    set internalValue(value: PostgresInstanceShowOutput | undefined);
    get authenticationAuthority(): string;
    get comment(): string;
    get computeFamily(): string;
    get createdOn(): string;
    get host(): string;
    get isHa(): cdktn.IResolvable;
    get name(): string;
    get origin(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get postgresSettings(): string;
    get postgresVersion(): string;
    get privatelinkServiceIdentifier(): string;
    get retentionTime(): number;
    get state(): string;
    get storageSize(): number;
    get type(): string;
    get updatedOn(): string;
}
export declare class PostgresInstanceShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PostgresInstanceShowOutputOutputReference;
}
export interface PostgresInstanceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#create PostgresInstance#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#delete PostgresInstance#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#read PostgresInstance#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#update PostgresInstance#update}
    */
    readonly update?: string;
}
export declare function postgresInstanceTimeoutsToTerraform(struct?: PostgresInstanceTimeouts | cdktn.IResolvable): any;
export declare function postgresInstanceTimeoutsToHclTerraform(struct?: PostgresInstanceTimeouts | cdktn.IResolvable): any;
export declare class PostgresInstanceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresInstanceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresInstanceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance snowflake_postgres_instance}
*/
export declare class PostgresInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_postgres_instance";
    /**
    * Generates CDKTN code for importing a PostgresInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostgresInstance to import
    * @param importFromId The id of the existing PostgresInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostgresInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/postgres_instance snowflake_postgres_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostgresInstanceConfig
    */
    constructor(scope: Construct, id: string, config: PostgresInstanceConfig);
    private _authenticationAuthority?;
    get authenticationAuthority(): string;
    set authenticationAuthority(value: string);
    get authenticationAuthorityInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _computeFamily?;
    get computeFamily(): string;
    set computeFamily(value: string);
    get computeFamilyInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): PostgresInstanceDescribeOutputList;
    get fullyQualifiedName(): string;
    private _highAvailability?;
    get highAvailability(): string;
    set highAvailability(value: string);
    resetHighAvailability(): void;
    get highAvailabilityInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maintenanceWindowStart?;
    get maintenanceWindowStart(): number;
    set maintenanceWindowStart(value: number);
    resetMaintenanceWindowStart(): void;
    get maintenanceWindowStartInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkPolicy?;
    get networkPolicy(): string;
    set networkPolicy(value: string);
    resetNetworkPolicy(): void;
    get networkPolicyInput(): string | undefined;
    private _postgresSettings?;
    get postgresSettings(): string;
    set postgresSettings(value: string);
    resetPostgresSettings(): void;
    get postgresSettingsInput(): string | undefined;
    private _postgresVersion?;
    get postgresVersion(): number;
    set postgresVersion(value: number);
    get postgresVersionInput(): number | undefined;
    private _showOutput;
    get showOutput(): PostgresInstanceShowOutputList;
    private _storageIntegration?;
    get storageIntegration(): string;
    set storageIntegration(value: string);
    resetStorageIntegration(): void;
    get storageIntegrationInput(): string | undefined;
    private _storageSizeGb?;
    get storageSizeGb(): number;
    set storageSizeGb(value: number);
    get storageSizeGbInput(): number | undefined;
    private _timeouts;
    get timeouts(): PostgresInstanceTimeoutsOutputReference;
    putTimeouts(value: PostgresInstanceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | PostgresInstanceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
