/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeAuthenticationPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#id DataSnowflakeAuthenticationPolicies#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#like DataSnowflakeAuthenticationPolicies#like}
    */
    readonly like?: string;
    /**
    * Filters the output with **case-sensitive** characters indicating the beginning of the object name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#starts_with DataSnowflakeAuthenticationPolicies#starts_with}
    */
    readonly startsWith?: string;
    /**
    * (Default: `true`) Runs DESC AUTHENTICATION POLICY for each service returned by SHOW AUTHENTICATION POLICIES. The output of describe is saved to the description field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#with_describe DataSnowflakeAuthenticationPolicies#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * in block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#in DataSnowflakeAuthenticationPolicies#in}
    */
    readonly in?: DataSnowflakeAuthenticationPoliciesIn;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#limit DataSnowflakeAuthenticationPolicies#limit}
    */
    readonly limit?: DataSnowflakeAuthenticationPoliciesLimit;
    /**
    * on block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#on DataSnowflakeAuthenticationPolicies#on}
    */
    readonly on?: DataSnowflakeAuthenticationPoliciesOn;
}
export interface DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesDescribeOutput {
}
export declare function dataSnowflakeAuthenticationPoliciesAuthenticationPoliciesDescribeOutputToTerraform(struct?: DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesDescribeOutput): any;
export declare function dataSnowflakeAuthenticationPoliciesAuthenticationPoliciesDescribeOutputToHclTerraform(struct?: DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesDescribeOutput): any;
export declare class DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesDescribeOutput | undefined);
    get authenticationMethods(): string;
    get clientPolicy(): string;
    get clientTypes(): string;
    get comment(): string;
    get mfaEnrollment(): string;
    get mfaPolicy(): string;
    get name(): string;
    get owner(): string;
    get patPolicy(): string;
    get securityIntegrations(): string;
    get workloadIdentityPolicy(): string;
}
export declare class DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesDescribeOutputOutputReference;
}
export interface DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesShowOutput {
}
export declare function dataSnowflakeAuthenticationPoliciesAuthenticationPoliciesShowOutputToTerraform(struct?: DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesShowOutput): any;
export declare function dataSnowflakeAuthenticationPoliciesAuthenticationPoliciesShowOutputToHclTerraform(struct?: DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesShowOutput): any;
export declare class DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesShowOutput | undefined;
    set internalValue(value: DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get kind(): string;
    get name(): string;
    get options(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get schemaName(): string;
}
export declare class DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesShowOutputOutputReference;
}
export interface DataSnowflakeAuthenticationPoliciesAuthenticationPolicies {
}
export declare function dataSnowflakeAuthenticationPoliciesAuthenticationPoliciesToTerraform(struct?: DataSnowflakeAuthenticationPoliciesAuthenticationPolicies): any;
export declare function dataSnowflakeAuthenticationPoliciesAuthenticationPoliciesToHclTerraform(struct?: DataSnowflakeAuthenticationPoliciesAuthenticationPolicies): any;
export declare class DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAuthenticationPoliciesAuthenticationPolicies | undefined;
    set internalValue(value: DataSnowflakeAuthenticationPoliciesAuthenticationPolicies | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesShowOutputList;
}
export declare class DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesOutputReference;
}
export interface DataSnowflakeAuthenticationPoliciesIn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#account DataSnowflakeAuthenticationPolicies#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the specified application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#application DataSnowflakeAuthenticationPolicies#application}
    */
    readonly application?: string;
    /**
    * Returns records for the specified application package.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#application_package DataSnowflakeAuthenticationPolicies#application_package}
    */
    readonly applicationPackage?: string;
    /**
    * Returns records for the current database in use or for a specified database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#database DataSnowflakeAuthenticationPolicies#database}
    */
    readonly database?: string;
    /**
    * Returns records for the current schema in use or a specified schema. Use fully qualified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#schema DataSnowflakeAuthenticationPolicies#schema}
    */
    readonly schema?: string;
}
export declare function dataSnowflakeAuthenticationPoliciesInToTerraform(struct?: DataSnowflakeAuthenticationPoliciesInOutputReference | DataSnowflakeAuthenticationPoliciesIn): any;
export declare function dataSnowflakeAuthenticationPoliciesInToHclTerraform(struct?: DataSnowflakeAuthenticationPoliciesInOutputReference | DataSnowflakeAuthenticationPoliciesIn): any;
export declare class DataSnowflakeAuthenticationPoliciesInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeAuthenticationPoliciesIn | undefined;
    set internalValue(value: DataSnowflakeAuthenticationPoliciesIn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _application?;
    get application(): string;
    set application(value: string);
    resetApplication(): void;
    get applicationInput(): string | undefined;
    private _applicationPackage?;
    get applicationPackage(): string;
    set applicationPackage(value: string);
    resetApplicationPackage(): void;
    get applicationPackageInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export interface DataSnowflakeAuthenticationPoliciesLimit {
    /**
    * Specifies a **case-sensitive** pattern that is used to match object name. After the first match, the limit on the number of rows will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#from DataSnowflakeAuthenticationPolicies#from}
    */
    readonly from?: string;
    /**
    * The maximum number of rows to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#rows DataSnowflakeAuthenticationPolicies#rows}
    */
    readonly rows: number;
}
export declare function dataSnowflakeAuthenticationPoliciesLimitToTerraform(struct?: DataSnowflakeAuthenticationPoliciesLimitOutputReference | DataSnowflakeAuthenticationPoliciesLimit): any;
export declare function dataSnowflakeAuthenticationPoliciesLimitToHclTerraform(struct?: DataSnowflakeAuthenticationPoliciesLimitOutputReference | DataSnowflakeAuthenticationPoliciesLimit): any;
export declare class DataSnowflakeAuthenticationPoliciesLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeAuthenticationPoliciesLimit | undefined;
    set internalValue(value: DataSnowflakeAuthenticationPoliciesLimit | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _rows?;
    get rows(): number;
    set rows(value: number);
    get rowsInput(): number | undefined;
}
export interface DataSnowflakeAuthenticationPoliciesOn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#account DataSnowflakeAuthenticationPolicies#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the specified user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#user DataSnowflakeAuthenticationPolicies#user}
    */
    readonly user?: string;
}
export declare function dataSnowflakeAuthenticationPoliciesOnToTerraform(struct?: DataSnowflakeAuthenticationPoliciesOnOutputReference | DataSnowflakeAuthenticationPoliciesOn): any;
export declare function dataSnowflakeAuthenticationPoliciesOnToHclTerraform(struct?: DataSnowflakeAuthenticationPoliciesOnOutputReference | DataSnowflakeAuthenticationPoliciesOn): any;
export declare class DataSnowflakeAuthenticationPoliciesOnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeAuthenticationPoliciesOn | undefined;
    set internalValue(value: DataSnowflakeAuthenticationPoliciesOn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies snowflake_authentication_policies}
*/
export declare class DataSnowflakeAuthenticationPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_authentication_policies";
    /**
    * Generates CDKTN code for importing a DataSnowflakeAuthenticationPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeAuthenticationPolicies to import
    * @param importFromId The id of the existing DataSnowflakeAuthenticationPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeAuthenticationPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/authentication_policies snowflake_authentication_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeAuthenticationPoliciesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeAuthenticationPoliciesConfig);
    private _authenticationPolicies;
    get authenticationPolicies(): DataSnowflakeAuthenticationPoliciesAuthenticationPoliciesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _startsWith?;
    get startsWith(): string;
    set startsWith(value: string);
    resetStartsWith(): void;
    get startsWithInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _in;
    get in(): DataSnowflakeAuthenticationPoliciesInOutputReference;
    putIn(value: DataSnowflakeAuthenticationPoliciesIn): void;
    resetIn(): void;
    get inInput(): DataSnowflakeAuthenticationPoliciesIn | undefined;
    private _limit;
    get limit(): DataSnowflakeAuthenticationPoliciesLimitOutputReference;
    putLimit(value: DataSnowflakeAuthenticationPoliciesLimit): void;
    resetLimit(): void;
    get limitInput(): DataSnowflakeAuthenticationPoliciesLimit | undefined;
    private _on;
    get on(): DataSnowflakeAuthenticationPoliciesOnOutputReference;
    putOn(value: DataSnowflakeAuthenticationPoliciesOn): void;
    resetOn(): void;
    get onInput(): DataSnowflakeAuthenticationPoliciesOn | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
