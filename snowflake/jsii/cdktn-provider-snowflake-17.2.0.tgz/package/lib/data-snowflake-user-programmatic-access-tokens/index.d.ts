/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeUserProgrammaticAccessTokensConfig extends cdktn.TerraformMetaArguments {
    /**
    * Returns programmatic access tokens for the specified user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/user_programmatic_access_tokens#for_user DataSnowflakeUserProgrammaticAccessTokens#for_user}
    */
    readonly forUser: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/user_programmatic_access_tokens#id DataSnowflakeUserProgrammaticAccessTokens#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensShowOutput {
}
export declare function dataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensShowOutputToTerraform(struct?: DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensShowOutput): any;
export declare function dataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensShowOutputToHclTerraform(struct?: DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensShowOutput): any;
export declare class DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensShowOutput | undefined;
    set internalValue(value: DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensShowOutput | undefined);
    get comment(): string;
    get createdBy(): string;
    get createdOn(): string;
    get expiresAt(): string;
    get minsToBypassNetworkPolicyRequirement(): number;
    get name(): string;
    get roleRestriction(): string;
    get rotatedTo(): string;
    get status(): string;
    get userName(): string;
}
export declare class DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensShowOutputOutputReference;
}
export interface DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokens {
}
export declare function dataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensToTerraform(struct?: DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokens): any;
export declare function dataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensToHclTerraform(struct?: DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokens): any;
export declare class DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokens | undefined;
    set internalValue(value: DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokens | undefined);
    private _showOutput;
    get showOutput(): DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensShowOutputList;
}
export declare class DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/user_programmatic_access_tokens snowflake_user_programmatic_access_tokens}
*/
export declare class DataSnowflakeUserProgrammaticAccessTokens extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_user_programmatic_access_tokens";
    /**
    * Generates CDKTN code for importing a DataSnowflakeUserProgrammaticAccessTokens resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeUserProgrammaticAccessTokens to import
    * @param importFromId The id of the existing DataSnowflakeUserProgrammaticAccessTokens that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/user_programmatic_access_tokens#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeUserProgrammaticAccessTokens to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/user_programmatic_access_tokens snowflake_user_programmatic_access_tokens} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeUserProgrammaticAccessTokensConfig
    */
    constructor(scope: Construct, id: string, config: DataSnowflakeUserProgrammaticAccessTokensConfig);
    private _forUser?;
    get forUser(): string;
    set forUser(value: string);
    get forUserInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _userProgrammaticAccessTokens;
    get userProgrammaticAccessTokens(): DataSnowflakeUserProgrammaticAccessTokensUserProgrammaticAccessTokensList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
