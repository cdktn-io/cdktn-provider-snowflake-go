/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeCatalogIntegrationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/catalog_integrations#id DataSnowflakeCatalogIntegrations#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/catalog_integrations#like DataSnowflakeCatalogIntegrations#like}
    */
    readonly like?: string;
    /**
    * (Default: `true`) Runs DESC CATALOG INTEGRATION for each catalog integration returned by SHOW CATALOG INTEGRATIONS. The output of describe is saved to the description field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/catalog_integrations#with_describe DataSnowflakeCatalogIntegrations#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
}
export interface DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputBearerRestAuthentication {
}
export declare function dataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputBearerRestAuthenticationToTerraform(struct?: DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputBearerRestAuthentication): any;
export declare function dataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputBearerRestAuthenticationToHclTerraform(struct?: DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputBearerRestAuthentication): any;
export declare class DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputBearerRestAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputBearerRestAuthentication | undefined;
    set internalValue(value: DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputBearerRestAuthentication | undefined);
}
export declare class DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputBearerRestAuthenticationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputBearerRestAuthenticationOutputReference;
}
export interface DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputOauthRestAuthentication {
}
export declare function dataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputOauthRestAuthenticationToTerraform(struct?: DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputOauthRestAuthentication): any;
export declare function dataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputOauthRestAuthenticationToHclTerraform(struct?: DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputOauthRestAuthentication): any;
export declare class DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputOauthRestAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputOauthRestAuthentication | undefined;
    set internalValue(value: DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputOauthRestAuthentication | undefined);
    get oauthAllowedScopes(): string[];
    get oauthClientId(): string;
    get oauthTokenUri(): string;
}
export declare class DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputOauthRestAuthenticationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputOauthRestAuthenticationOutputReference;
}
export interface DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputRestConfig {
}
export declare function dataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputRestConfigToTerraform(struct?: DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputRestConfig): any;
export declare function dataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputRestConfigToHclTerraform(struct?: DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputRestConfig): any;
export declare class DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputRestConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputRestConfig | undefined;
    set internalValue(value: DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputRestConfig | undefined);
    get accessDelegationMode(): string;
    get catalogApiType(): string;
    get catalogName(): string;
    get catalogUri(): string;
    get prefix(): string;
}
export declare class DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputRestConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputRestConfigOutputReference;
}
export interface DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputSigv4RestAuthentication {
}
export declare function dataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputSigv4RestAuthenticationToTerraform(struct?: DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputSigv4RestAuthentication): any;
export declare function dataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputSigv4RestAuthenticationToHclTerraform(struct?: DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputSigv4RestAuthentication): any;
export declare class DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputSigv4RestAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputSigv4RestAuthentication | undefined;
    set internalValue(value: DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputSigv4RestAuthentication | undefined);
    get sigv4IamRole(): string;
    get sigv4SigningRegion(): string;
}
export declare class DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputSigv4RestAuthenticationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputSigv4RestAuthenticationOutputReference;
}
export interface DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutput {
}
export declare function dataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputToTerraform(struct?: DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutput): any;
export declare function dataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputToHclTerraform(struct?: DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutput): any;
export declare class DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutput | undefined);
    private _bearerRestAuthentication;
    get bearerRestAuthentication(): DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputBearerRestAuthenticationList;
    get catalogNamespace(): string;
    get catalogSource(): string;
    get comment(): string;
    get enabled(): cdktn.IResolvable;
    get glueAwsExternalId(): string;
    get glueAwsIamUserArn(): string;
    get glueAwsRoleArn(): string;
    get glueCatalogId(): string;
    get glueRegion(): string;
    get id(): string;
    private _oauthRestAuthentication;
    get oauthRestAuthentication(): DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputOauthRestAuthenticationList;
    get refreshIntervalSeconds(): number;
    private _restConfig;
    get restConfig(): DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputRestConfigList;
    private _sigv4RestAuthentication;
    get sigv4RestAuthentication(): DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputSigv4RestAuthenticationList;
    get tableFormat(): string;
}
export declare class DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputOutputReference;
}
export interface DataSnowflakeCatalogIntegrationsCatalogIntegrationsShowOutput {
}
export declare function dataSnowflakeCatalogIntegrationsCatalogIntegrationsShowOutputToTerraform(struct?: DataSnowflakeCatalogIntegrationsCatalogIntegrationsShowOutput): any;
export declare function dataSnowflakeCatalogIntegrationsCatalogIntegrationsShowOutputToHclTerraform(struct?: DataSnowflakeCatalogIntegrationsCatalogIntegrationsShowOutput): any;
export declare class DataSnowflakeCatalogIntegrationsCatalogIntegrationsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeCatalogIntegrationsCatalogIntegrationsShowOutput | undefined;
    set internalValue(value: DataSnowflakeCatalogIntegrationsCatalogIntegrationsShowOutput | undefined);
    get category(): string;
    get comment(): string;
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
    get type(): string;
}
export declare class DataSnowflakeCatalogIntegrationsCatalogIntegrationsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeCatalogIntegrationsCatalogIntegrationsShowOutputOutputReference;
}
export interface DataSnowflakeCatalogIntegrationsCatalogIntegrations {
}
export declare function dataSnowflakeCatalogIntegrationsCatalogIntegrationsToTerraform(struct?: DataSnowflakeCatalogIntegrationsCatalogIntegrations): any;
export declare function dataSnowflakeCatalogIntegrationsCatalogIntegrationsToHclTerraform(struct?: DataSnowflakeCatalogIntegrationsCatalogIntegrations): any;
export declare class DataSnowflakeCatalogIntegrationsCatalogIntegrationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeCatalogIntegrationsCatalogIntegrations | undefined;
    set internalValue(value: DataSnowflakeCatalogIntegrationsCatalogIntegrations | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeCatalogIntegrationsCatalogIntegrationsDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeCatalogIntegrationsCatalogIntegrationsShowOutputList;
}
export declare class DataSnowflakeCatalogIntegrationsCatalogIntegrationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeCatalogIntegrationsCatalogIntegrationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/catalog_integrations snowflake_catalog_integrations}
*/
export declare class DataSnowflakeCatalogIntegrations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_catalog_integrations";
    /**
    * Generates CDKTN code for importing a DataSnowflakeCatalogIntegrations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeCatalogIntegrations to import
    * @param importFromId The id of the existing DataSnowflakeCatalogIntegrations that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/catalog_integrations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeCatalogIntegrations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/data-sources/catalog_integrations snowflake_catalog_integrations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeCatalogIntegrationsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeCatalogIntegrationsConfig);
    private _catalogIntegrations;
    get catalogIntegrations(): DataSnowflakeCatalogIntegrationsCatalogIntegrationsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
