/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface UserSessionPolicyAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_session_policy_attachment#id UserSessionPolicyAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Fully qualified name of the session policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_session_policy_attachment#session_policy_name UserSessionPolicyAttachment#session_policy_name}
    */
    readonly sessionPolicyName: string;
    /**
    * User name of the user you want to attach the session policy to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_session_policy_attachment#user_name UserSessionPolicyAttachment#user_name}
    */
    readonly userName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_session_policy_attachment#timeouts UserSessionPolicyAttachment#timeouts}
    */
    readonly timeouts?: UserSessionPolicyAttachmentTimeouts;
}
export interface UserSessionPolicyAttachmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_session_policy_attachment#create UserSessionPolicyAttachment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_session_policy_attachment#delete UserSessionPolicyAttachment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_session_policy_attachment#read UserSessionPolicyAttachment#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_session_policy_attachment#update UserSessionPolicyAttachment#update}
    */
    readonly update?: string;
}
export declare function userSessionPolicyAttachmentTimeoutsToTerraform(struct?: UserSessionPolicyAttachmentTimeouts | cdktn.IResolvable): any;
export declare function userSessionPolicyAttachmentTimeoutsToHclTerraform(struct?: UserSessionPolicyAttachmentTimeouts | cdktn.IResolvable): any;
export declare class UserSessionPolicyAttachmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): UserSessionPolicyAttachmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: UserSessionPolicyAttachmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_session_policy_attachment snowflake_user_session_policy_attachment}
*/
export declare class UserSessionPolicyAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_user_session_policy_attachment";
    /**
    * Generates CDKTN code for importing a UserSessionPolicyAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserSessionPolicyAttachment to import
    * @param importFromId The id of the existing UserSessionPolicyAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_session_policy_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserSessionPolicyAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.18.0/docs/resources/user_session_policy_attachment snowflake_user_session_policy_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserSessionPolicyAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: UserSessionPolicyAttachmentConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _sessionPolicyName?;
    get sessionPolicyName(): string;
    set sessionPolicyName(value: string);
    get sessionPolicyNameInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    get userNameInput(): string | undefined;
    private _timeouts;
    get timeouts(): UserSessionPolicyAttachmentTimeoutsOutputReference;
    putTimeouts(value: UserSessionPolicyAttachmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | UserSessionPolicyAttachmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
