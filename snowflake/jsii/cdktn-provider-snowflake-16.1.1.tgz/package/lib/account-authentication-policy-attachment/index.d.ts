/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountAuthenticationPolicyAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Qualified name (`"db"."schema"."policy_name"`) of the authentication policy to apply to the current account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/account_authentication_policy_attachment#authentication_policy AccountAuthenticationPolicyAttachment#authentication_policy}
    */
    readonly authenticationPolicy: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/account_authentication_policy_attachment#id AccountAuthenticationPolicyAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/account_authentication_policy_attachment#timeouts AccountAuthenticationPolicyAttachment#timeouts}
    */
    readonly timeouts?: AccountAuthenticationPolicyAttachmentTimeouts;
}
export interface AccountAuthenticationPolicyAttachmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/account_authentication_policy_attachment#create AccountAuthenticationPolicyAttachment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/account_authentication_policy_attachment#delete AccountAuthenticationPolicyAttachment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/account_authentication_policy_attachment#read AccountAuthenticationPolicyAttachment#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/account_authentication_policy_attachment#update AccountAuthenticationPolicyAttachment#update}
    */
    readonly update?: string;
}
export declare function accountAuthenticationPolicyAttachmentTimeoutsToTerraform(struct?: AccountAuthenticationPolicyAttachmentTimeouts | cdktn.IResolvable): any;
export declare function accountAuthenticationPolicyAttachmentTimeoutsToHclTerraform(struct?: AccountAuthenticationPolicyAttachmentTimeouts | cdktn.IResolvable): any;
export declare class AccountAuthenticationPolicyAttachmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountAuthenticationPolicyAttachmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccountAuthenticationPolicyAttachmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/account_authentication_policy_attachment snowflake_account_authentication_policy_attachment}
*/
export declare class AccountAuthenticationPolicyAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_account_authentication_policy_attachment";
    /**
    * Generates CDKTN code for importing a AccountAuthenticationPolicyAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountAuthenticationPolicyAttachment to import
    * @param importFromId The id of the existing AccountAuthenticationPolicyAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/account_authentication_policy_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountAuthenticationPolicyAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/account_authentication_policy_attachment snowflake_account_authentication_policy_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountAuthenticationPolicyAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: AccountAuthenticationPolicyAttachmentConfig);
    private _authenticationPolicy?;
    get authenticationPolicy(): string;
    set authenticationPolicy(value: string);
    get authenticationPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _timeouts;
    get timeouts(): AccountAuthenticationPolicyAttachmentTimeoutsOutputReference;
    putTimeouts(value: AccountAuthenticationPolicyAttachmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccountAuthenticationPolicyAttachmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
