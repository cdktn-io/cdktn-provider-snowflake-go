/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MaterializedViewConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the view.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#comment MaterializedView#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the view. Don't use the | character.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#database MaterializedView#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#id MaterializedView#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * (Default: `false`) Specifies that the view is secure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#is_secure MaterializedView#is_secure}
    */
    readonly isSecure?: boolean | cdktn.IResolvable;
    /**
    * Specifies the identifier for the view; must be unique for the schema in which the view is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#name MaterializedView#name}
    */
    readonly name: string;
    /**
    * (Default: `false`) Specifies whether to use CREATE OR REPLACE when creating the materialized view. Note: this does not enable in-place updates when other fields forcing object recreation change; such fields always trigger delete and create operations in Terraform plan.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#or_replace MaterializedView#or_replace}
    */
    readonly orReplace?: boolean | cdktn.IResolvable;
    /**
    * The schema in which to create the view. Don't use the | character.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#schema MaterializedView#schema}
    */
    readonly schema: string;
    /**
    * Specifies the query used to create the view. Changing this value will trigger a drop and recreate of the materialized view.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#statement MaterializedView#statement}
    */
    readonly statement: string;
    /**
    * The warehouse name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#warehouse MaterializedView#warehouse}
    */
    readonly warehouse: string;
    /**
    * tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#tag MaterializedView#tag}
    */
    readonly tag?: MaterializedViewTag[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#timeouts MaterializedView#timeouts}
    */
    readonly timeouts?: MaterializedViewTimeouts;
}
export interface MaterializedViewTag {
    /**
    * Name of the database that the tag was created in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#database MaterializedView#database}
    */
    readonly database?: string;
    /**
    * Tag name, e.g. department.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#name MaterializedView#name}
    */
    readonly name: string;
    /**
    * Name of the schema that the tag was created in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#schema MaterializedView#schema}
    */
    readonly schema?: string;
    /**
    * Tag value, e.g. marketing_info.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#value MaterializedView#value}
    */
    readonly value: string;
}
export declare function materializedViewTagToTerraform(struct?: MaterializedViewTag | cdktn.IResolvable): any;
export declare function materializedViewTagToHclTerraform(struct?: MaterializedViewTag | cdktn.IResolvable): any;
export declare class MaterializedViewTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MaterializedViewTag | cdktn.IResolvable | undefined;
    set internalValue(value: MaterializedViewTag | cdktn.IResolvable | undefined);
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class MaterializedViewTagList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: MaterializedViewTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MaterializedViewTagOutputReference;
}
export interface MaterializedViewTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#create MaterializedView#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#delete MaterializedView#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#read MaterializedView#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#update MaterializedView#update}
    */
    readonly update?: string;
}
export declare function materializedViewTimeoutsToTerraform(struct?: MaterializedViewTimeouts | cdktn.IResolvable): any;
export declare function materializedViewTimeoutsToHclTerraform(struct?: MaterializedViewTimeouts | cdktn.IResolvable): any;
export declare class MaterializedViewTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MaterializedViewTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: MaterializedViewTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view snowflake_materialized_view}
*/
export declare class MaterializedView extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_materialized_view";
    /**
    * Generates CDKTN code for importing a MaterializedView resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MaterializedView to import
    * @param importFromId The id of the existing MaterializedView that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MaterializedView to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/materialized_view snowflake_materialized_view} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MaterializedViewConfig
    */
    constructor(scope: Construct, id: string, config: MaterializedViewConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isSecure?;
    get isSecure(): boolean | cdktn.IResolvable;
    set isSecure(value: boolean | cdktn.IResolvable);
    resetIsSecure(): void;
    get isSecureInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _orReplace?;
    get orReplace(): boolean | cdktn.IResolvable;
    set orReplace(value: boolean | cdktn.IResolvable);
    resetOrReplace(): void;
    get orReplaceInput(): boolean | cdktn.IResolvable | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _statement?;
    get statement(): string;
    set statement(value: string);
    get statementInput(): string | undefined;
    private _warehouse?;
    get warehouse(): string;
    set warehouse(value: string);
    get warehouseInput(): string | undefined;
    private _tag;
    get tag(): MaterializedViewTagList;
    putTag(value: MaterializedViewTag[] | cdktn.IResolvable): void;
    resetTag(): void;
    get tagInput(): cdktn.IResolvable | MaterializedViewTag[] | undefined;
    private _timeouts;
    get timeouts(): MaterializedViewTimeoutsOutputReference;
    putTimeouts(value: MaterializedViewTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | MaterializedViewTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
