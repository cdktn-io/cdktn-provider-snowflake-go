/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StorageIntegrationAzureConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the ID for your Office 365 tenant that the allowed and blocked storage accounts belong to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure#azure_tenant_id StorageIntegrationAzure#azure_tenant_id}
    */
    readonly azureTenantId: string;
    /**
    * Specifies a comment for the storage integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure#comment StorageIntegrationAzure#comment}
    */
    readonly comment?: string;
    /**
    * Specifies whether this storage integration is available for usage in stages. `TRUE` allows users to create new stages that reference this integration. Existing stages that reference this integration function normally. `FALSE` prevents users from creating new stages that reference this integration. Existing stages that reference this integration cannot access the storage location in the stage definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure#enabled StorageIntegrationAzure#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure#id StorageIntegrationAzure#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * String that specifies the identifier (i.e. name) for the integration; must be unique in your account. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure#name StorageIntegrationAzure#name}
    */
    readonly name: string;
    /**
    * Explicitly limits external stages that use the integration to reference one or more storage locations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure#storage_allowed_locations StorageIntegrationAzure#storage_allowed_locations}
    */
    readonly storageAllowedLocations: string[];
    /**
    * Explicitly prohibits external stages that use the integration from referencing one or more storage locations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure#storage_blocked_locations StorageIntegrationAzure#storage_blocked_locations}
    */
    readonly storageBlockedLocations?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether to use outbound private connectivity to harden the security posture. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure#use_privatelink_endpoint StorageIntegrationAzure#use_privatelink_endpoint}
    */
    readonly usePrivatelinkEndpoint?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure#timeouts StorageIntegrationAzure#timeouts}
    */
    readonly timeouts?: StorageIntegrationAzureTimeouts;
}
export interface StorageIntegrationAzureDescribeOutput {
}
export declare function storageIntegrationAzureDescribeOutputToTerraform(struct?: StorageIntegrationAzureDescribeOutput): any;
export declare function storageIntegrationAzureDescribeOutputToHclTerraform(struct?: StorageIntegrationAzureDescribeOutput): any;
export declare class StorageIntegrationAzureDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationAzureDescribeOutput | undefined;
    set internalValue(value: StorageIntegrationAzureDescribeOutput | undefined);
    get allowedLocations(): string[];
    get blockedLocations(): string[];
    get comment(): string;
    get consentUrl(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get multiTenantAppName(): string;
    get provider(): string;
    get tenantId(): string;
    get usePrivatelinkEndpoint(): cdktn.IResolvable;
}
export declare class StorageIntegrationAzureDescribeOutputList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationAzureDescribeOutputOutputReference;
}
export interface StorageIntegrationAzureShowOutput {
}
export declare function storageIntegrationAzureShowOutputToTerraform(struct?: StorageIntegrationAzureShowOutput): any;
export declare function storageIntegrationAzureShowOutputToHclTerraform(struct?: StorageIntegrationAzureShowOutput): any;
export declare class StorageIntegrationAzureShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationAzureShowOutput | undefined;
    set internalValue(value: StorageIntegrationAzureShowOutput | undefined);
    get category(): string;
    get comment(): string;
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
    get storageType(): string;
}
export declare class StorageIntegrationAzureShowOutputList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationAzureShowOutputOutputReference;
}
export interface StorageIntegrationAzureTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure#create StorageIntegrationAzure#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure#delete StorageIntegrationAzure#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure#read StorageIntegrationAzure#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure#update StorageIntegrationAzure#update}
    */
    readonly update?: string;
}
export declare function storageIntegrationAzureTimeoutsToTerraform(struct?: StorageIntegrationAzureTimeouts | cdktn.IResolvable): any;
export declare function storageIntegrationAzureTimeoutsToHclTerraform(struct?: StorageIntegrationAzureTimeouts | cdktn.IResolvable): any;
export declare class StorageIntegrationAzureTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageIntegrationAzureTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: StorageIntegrationAzureTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure snowflake_storage_integration_azure}
*/
export declare class StorageIntegrationAzure extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_storage_integration_azure";
    /**
    * Generates CDKTN code for importing a StorageIntegrationAzure resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StorageIntegrationAzure to import
    * @param importFromId The id of the existing StorageIntegrationAzure that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StorageIntegrationAzure to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/storage_integration_azure snowflake_storage_integration_azure} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StorageIntegrationAzureConfig
    */
    constructor(scope: Construct, id: string, config: StorageIntegrationAzureConfig);
    private _azureTenantId?;
    get azureTenantId(): string;
    set azureTenantId(value: string);
    get azureTenantIdInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): StorageIntegrationAzureDescribeOutputList;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _showOutput;
    get showOutput(): StorageIntegrationAzureShowOutputList;
    private _storageAllowedLocations?;
    get storageAllowedLocations(): string[];
    set storageAllowedLocations(value: string[]);
    get storageAllowedLocationsInput(): string[] | undefined;
    private _storageBlockedLocations?;
    get storageBlockedLocations(): string[];
    set storageBlockedLocations(value: string[]);
    resetStorageBlockedLocations(): void;
    get storageBlockedLocationsInput(): string[] | undefined;
    private _usePrivatelinkEndpoint?;
    get usePrivatelinkEndpoint(): string;
    set usePrivatelinkEndpoint(value: string);
    resetUsePrivatelinkEndpoint(): void;
    get usePrivatelinkEndpointInput(): string | undefined;
    private _timeouts;
    get timeouts(): StorageIntegrationAzureTimeoutsOutputReference;
    putTimeouts(value: StorageIntegrationAzureTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | StorageIntegrationAzureTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
