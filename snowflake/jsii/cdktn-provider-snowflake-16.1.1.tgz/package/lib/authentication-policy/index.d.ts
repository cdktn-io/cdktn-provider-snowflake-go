/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AuthenticationPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * A list of authentication methods that are allowed during login. Valid values are (case-insensitive): `ALL` | `SAML` | `PASSWORD` | `OAUTH` | `KEYPAIR` | `PROGRAMMATIC_ACCESS_TOKEN` | `WORKLOAD_IDENTITY`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#authentication_methods AuthenticationPolicy#authentication_methods}
    */
    readonly authenticationMethods?: string[];
    /**
    * A list of clients that can authenticate with Snowflake. If a client tries to connect, and the client is not one of the valid `client_types`, then the login attempt fails. Valid values are (case-insensitive): `ALL` | `SNOWFLAKE_UI` | `DRIVERS` | `SNOWSQL` | `SNOWFLAKE_CLI`. The `client_types` property of an authentication policy is a best effort method to block user logins based on specific clients. It should not be used as the sole control to establish a security boundary.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#client_types AuthenticationPolicy#client_types}
    */
    readonly clientTypes?: string[];
    /**
    * Specifies a comment for the authentication policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#comment AuthenticationPolicy#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the authentication policy. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#database AuthenticationPolicy#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#id AuthenticationPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A list of authentication methods that enforce multi-factor authentication (MFA) during login. Authentication methods not listed in this parameter do not prompt for multi-factor authentication. Allowed values are `ALL` | `SAML` | `PASSWORD`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#mfa_authentication_methods AuthenticationPolicy#mfa_authentication_methods}
    */
    readonly mfaAuthenticationMethods?: string[];
    /**
    * Determines whether a user must enroll in multi-factor authentication. Valid values are (case-insensitive): `REQUIRED` | `REQUIRED_PASSWORD_ONLY` | `OPTIONAL`. When REQUIRED is specified, Enforces users to enroll in MFA. If this value is used, then the `client_types` parameter must include `snowflake_ui`, because Snowsight is the only place users can enroll in multi-factor authentication (MFA). Note that when you set this value to OPTIONAL, and your account setup forces users to enroll in MFA, then Snowflake may set quietly this value to `REQUIRED_PASSWORD_ONLY`, which may cause permadiff. In this case, you may want to adjust this field value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#mfa_enrollment AuthenticationPolicy#mfa_enrollment}
    */
    readonly mfaEnrollment?: string;
    /**
    * Specifies the identifier for the authentication policy. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#name AuthenticationPolicy#name}
    */
    readonly name: string;
    /**
    * The schema in which to create the authentication policy. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#schema AuthenticationPolicy#schema}
    */
    readonly schema: string;
    /**
    * A list of security integrations the authentication policy is associated with. This parameter has no effect when `saml` or `oauth` are not in the `authentication_methods` list. All values in the `security_integrations` list must be compatible with the values in the `authentication_methods` list. For example, if `security_integrations` contains a SAML security integration, and `authentication_methods` contains OAUTH, then you cannot create the authentication policy. To allow all security integrations use `ALL` as parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#security_integrations AuthenticationPolicy#security_integrations}
    */
    readonly securityIntegrations?: string[];
    /**
    * mfa_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#mfa_policy AuthenticationPolicy#mfa_policy}
    */
    readonly mfaPolicy?: AuthenticationPolicyMfaPolicy;
    /**
    * pat_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#pat_policy AuthenticationPolicy#pat_policy}
    */
    readonly patPolicy?: AuthenticationPolicyPatPolicy;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#timeouts AuthenticationPolicy#timeouts}
    */
    readonly timeouts?: AuthenticationPolicyTimeouts;
    /**
    * workload_identity_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#workload_identity_policy AuthenticationPolicy#workload_identity_policy}
    */
    readonly workloadIdentityPolicy?: AuthenticationPolicyWorkloadIdentityPolicy;
}
export interface AuthenticationPolicyDescribeOutput {
}
export declare function authenticationPolicyDescribeOutputToTerraform(struct?: AuthenticationPolicyDescribeOutput): any;
export declare function authenticationPolicyDescribeOutputToHclTerraform(struct?: AuthenticationPolicyDescribeOutput): any;
export declare class AuthenticationPolicyDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AuthenticationPolicyDescribeOutput | undefined;
    set internalValue(value: AuthenticationPolicyDescribeOutput | undefined);
    get authenticationMethods(): string;
    get clientTypes(): string;
    get comment(): string;
    get mfaEnrollment(): string;
    get mfaPolicy(): string;
    get name(): string;
    get owner(): string;
    get patPolicy(): string;
    get securityIntegrations(): string;
    get workloadIdentityPolicy(): string;
}
export declare class AuthenticationPolicyDescribeOutputList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AuthenticationPolicyDescribeOutputOutputReference;
}
export interface AuthenticationPolicyShowOutput {
}
export declare function authenticationPolicyShowOutputToTerraform(struct?: AuthenticationPolicyShowOutput): any;
export declare function authenticationPolicyShowOutputToHclTerraform(struct?: AuthenticationPolicyShowOutput): any;
export declare class AuthenticationPolicyShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AuthenticationPolicyShowOutput | undefined;
    set internalValue(value: AuthenticationPolicyShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get kind(): string;
    get name(): string;
    get options(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get schemaName(): string;
}
export declare class AuthenticationPolicyShowOutputList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AuthenticationPolicyShowOutputOutputReference;
}
export interface AuthenticationPolicyMfaPolicy {
    /**
    * Specifies the allowed methods for the MFA policy. Valid values are: `ALL` | `PASSKEY` | `TOTP` | `DUO`. These values are case-sensitive due to Terraform limitations (it's a nested field). Prefer using uppercased values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#allowed_methods AuthenticationPolicy#allowed_methods}
    */
    readonly allowedMethods?: string[];
    /**
    * Determines whether multi-factor authentication (MFA) is enforced on external authentication. Valid values are (case-insensitive): `ALL` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#enforce_mfa_on_external_authentication AuthenticationPolicy#enforce_mfa_on_external_authentication}
    */
    readonly enforceMfaOnExternalAuthentication?: string;
}
export declare function authenticationPolicyMfaPolicyToTerraform(struct?: AuthenticationPolicyMfaPolicyOutputReference | AuthenticationPolicyMfaPolicy): any;
export declare function authenticationPolicyMfaPolicyToHclTerraform(struct?: AuthenticationPolicyMfaPolicyOutputReference | AuthenticationPolicyMfaPolicy): any;
export declare class AuthenticationPolicyMfaPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AuthenticationPolicyMfaPolicy | undefined;
    set internalValue(value: AuthenticationPolicyMfaPolicy | undefined);
    private _allowedMethods?;
    get allowedMethods(): string[];
    set allowedMethods(value: string[]);
    resetAllowedMethods(): void;
    get allowedMethodsInput(): string[] | undefined;
    private _enforceMfaOnExternalAuthentication?;
    get enforceMfaOnExternalAuthentication(): string;
    set enforceMfaOnExternalAuthentication(value: string);
    resetEnforceMfaOnExternalAuthentication(): void;
    get enforceMfaOnExternalAuthenticationInput(): string | undefined;
}
export interface AuthenticationPolicyPatPolicy {
    /**
    * Specifies the default expiration time (in days) for a programmatic access token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#default_expiry_in_days AuthenticationPolicy#default_expiry_in_days}
    */
    readonly defaultExpiryInDays?: number;
    /**
    * Specifies the maximum number of days that can be set for the expiration time for a programmatic access token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#max_expiry_in_days AuthenticationPolicy#max_expiry_in_days}
    */
    readonly maxExpiryInDays?: number;
    /**
    * Specifies the network policy evaluation for the PAT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#network_policy_evaluation AuthenticationPolicy#network_policy_evaluation}
    */
    readonly networkPolicyEvaluation?: string;
}
export declare function authenticationPolicyPatPolicyToTerraform(struct?: AuthenticationPolicyPatPolicyOutputReference | AuthenticationPolicyPatPolicy): any;
export declare function authenticationPolicyPatPolicyToHclTerraform(struct?: AuthenticationPolicyPatPolicyOutputReference | AuthenticationPolicyPatPolicy): any;
export declare class AuthenticationPolicyPatPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AuthenticationPolicyPatPolicy | undefined;
    set internalValue(value: AuthenticationPolicyPatPolicy | undefined);
    private _defaultExpiryInDays?;
    get defaultExpiryInDays(): number;
    set defaultExpiryInDays(value: number);
    resetDefaultExpiryInDays(): void;
    get defaultExpiryInDaysInput(): number | undefined;
    private _maxExpiryInDays?;
    get maxExpiryInDays(): number;
    set maxExpiryInDays(value: number);
    resetMaxExpiryInDays(): void;
    get maxExpiryInDaysInput(): number | undefined;
    private _networkPolicyEvaluation?;
    get networkPolicyEvaluation(): string;
    set networkPolicyEvaluation(value: string);
    resetNetworkPolicyEvaluation(): void;
    get networkPolicyEvaluationInput(): string | undefined;
}
export interface AuthenticationPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#create AuthenticationPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#delete AuthenticationPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#read AuthenticationPolicy#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#update AuthenticationPolicy#update}
    */
    readonly update?: string;
}
export declare function authenticationPolicyTimeoutsToTerraform(struct?: AuthenticationPolicyTimeouts | cdktn.IResolvable): any;
export declare function authenticationPolicyTimeoutsToHclTerraform(struct?: AuthenticationPolicyTimeouts | cdktn.IResolvable): any;
export declare class AuthenticationPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AuthenticationPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AuthenticationPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface AuthenticationPolicyWorkloadIdentityPolicy {
    /**
    * Specifies the list of AWS account IDs allowed by the authentication policy during workload identity authentication of type `AWS`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#allowed_aws_accounts AuthenticationPolicy#allowed_aws_accounts}
    */
    readonly allowedAwsAccounts?: string[];
    /**
    * Specifies the list of Azure Entra ID issuers allowed by the authentication policy during workload identity authentication of type `AZURE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#allowed_azure_issuers AuthenticationPolicy#allowed_azure_issuers}
    */
    readonly allowedAzureIssuers?: string[];
    /**
    * Specifies the list of OIDC issuers allowed by the authentication policy during workload identity authentication of type `OIDC`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#allowed_oidc_issuers AuthenticationPolicy#allowed_oidc_issuers}
    */
    readonly allowedOidcIssuers?: string[];
    /**
    * Specifies the allowed providers for the workload identity policy. Valid values are: `ALL` | `AWS` | `AZURE` | `GCP` | `OIDC`. These values are case-sensitive due to Terraform limitations (it's a nested field). Prefer using uppercased values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#allowed_providers AuthenticationPolicy#allowed_providers}
    */
    readonly allowedProviders?: string[];
}
export declare function authenticationPolicyWorkloadIdentityPolicyToTerraform(struct?: AuthenticationPolicyWorkloadIdentityPolicyOutputReference | AuthenticationPolicyWorkloadIdentityPolicy): any;
export declare function authenticationPolicyWorkloadIdentityPolicyToHclTerraform(struct?: AuthenticationPolicyWorkloadIdentityPolicyOutputReference | AuthenticationPolicyWorkloadIdentityPolicy): any;
export declare class AuthenticationPolicyWorkloadIdentityPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AuthenticationPolicyWorkloadIdentityPolicy | undefined;
    set internalValue(value: AuthenticationPolicyWorkloadIdentityPolicy | undefined);
    private _allowedAwsAccounts?;
    get allowedAwsAccounts(): string[];
    set allowedAwsAccounts(value: string[]);
    resetAllowedAwsAccounts(): void;
    get allowedAwsAccountsInput(): string[] | undefined;
    private _allowedAzureIssuers?;
    get allowedAzureIssuers(): string[];
    set allowedAzureIssuers(value: string[]);
    resetAllowedAzureIssuers(): void;
    get allowedAzureIssuersInput(): string[] | undefined;
    private _allowedOidcIssuers?;
    get allowedOidcIssuers(): string[];
    set allowedOidcIssuers(value: string[]);
    resetAllowedOidcIssuers(): void;
    get allowedOidcIssuersInput(): string[] | undefined;
    private _allowedProviders?;
    get allowedProviders(): string[];
    set allowedProviders(value: string[]);
    resetAllowedProviders(): void;
    get allowedProvidersInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy snowflake_authentication_policy}
*/
export declare class AuthenticationPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_authentication_policy";
    /**
    * Generates CDKTN code for importing a AuthenticationPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuthenticationPolicy to import
    * @param importFromId The id of the existing AuthenticationPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuthenticationPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.1/docs/resources/authentication_policy snowflake_authentication_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuthenticationPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AuthenticationPolicyConfig);
    private _authenticationMethods?;
    get authenticationMethods(): string[];
    set authenticationMethods(value: string[]);
    resetAuthenticationMethods(): void;
    get authenticationMethodsInput(): string[] | undefined;
    private _clientTypes?;
    get clientTypes(): string[];
    set clientTypes(value: string[]);
    resetClientTypes(): void;
    get clientTypesInput(): string[] | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): AuthenticationPolicyDescribeOutputList;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _mfaAuthenticationMethods?;
    get mfaAuthenticationMethods(): string[];
    set mfaAuthenticationMethods(value: string[]);
    resetMfaAuthenticationMethods(): void;
    get mfaAuthenticationMethodsInput(): string[] | undefined;
    private _mfaEnrollment?;
    get mfaEnrollment(): string;
    set mfaEnrollment(value: string);
    resetMfaEnrollment(): void;
    get mfaEnrollmentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _securityIntegrations?;
    get securityIntegrations(): string[];
    set securityIntegrations(value: string[]);
    resetSecurityIntegrations(): void;
    get securityIntegrationsInput(): string[] | undefined;
    private _showOutput;
    get showOutput(): AuthenticationPolicyShowOutputList;
    private _mfaPolicy;
    get mfaPolicy(): AuthenticationPolicyMfaPolicyOutputReference;
    putMfaPolicy(value: AuthenticationPolicyMfaPolicy): void;
    resetMfaPolicy(): void;
    get mfaPolicyInput(): AuthenticationPolicyMfaPolicy | undefined;
    private _patPolicy;
    get patPolicy(): AuthenticationPolicyPatPolicyOutputReference;
    putPatPolicy(value: AuthenticationPolicyPatPolicy): void;
    resetPatPolicy(): void;
    get patPolicyInput(): AuthenticationPolicyPatPolicy | undefined;
    private _timeouts;
    get timeouts(): AuthenticationPolicyTimeoutsOutputReference;
    putTimeouts(value: AuthenticationPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AuthenticationPolicyTimeouts | undefined;
    private _workloadIdentityPolicy;
    get workloadIdentityPolicy(): AuthenticationPolicyWorkloadIdentityPolicyOutputReference;
    putWorkloadIdentityPolicy(value: AuthenticationPolicyWorkloadIdentityPolicy): void;
    resetWorkloadIdentityPolicy(): void;
    get workloadIdentityPolicyInput(): AuthenticationPolicyWorkloadIdentityPolicy | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
