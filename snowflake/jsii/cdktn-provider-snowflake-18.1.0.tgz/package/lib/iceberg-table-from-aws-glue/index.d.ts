/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IcebergTableFromAwsGlueConfig extends cdktn.TerraformMetaArguments {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether Snowflake should periodically refresh the Iceberg table metadata from the AWS Glue catalog. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#auto_refresh IcebergTableFromAwsGlue#auto_refresh}
    */
    readonly autoRefresh?: string;
    /**
    * Specifies the identifier for the catalog integration to use for the Iceberg table. If not specified, the account-level default is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#catalog IcebergTableFromAwsGlue#catalog}
    */
    readonly catalog?: string;
    /**
    * Specifies the namespace (or database) in the AWS Glue catalog that the table belongs to. If not specified, the catalog integration's default namespace is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#catalog_namespace IcebergTableFromAwsGlue#catalog_namespace}
    */
    readonly catalogNamespace?: string;
    /**
    * Specifies the name of the table as it appears in the AWS Glue catalog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#catalog_table_name IcebergTableFromAwsGlue#catalog_table_name}
    */
    readonly catalogTableName: string;
    /**
    * Specifies a comment for the Iceberg table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#comment IcebergTableFromAwsGlue#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the Iceberg table. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#database IcebergTableFromAwsGlue#database}
    */
    readonly database: string;
    /**
    * Specifies the identifier for the external volume where the Iceberg table stores its metadata files and data in Parquet format. If not specified, the account-level default is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#external_volume IcebergTableFromAwsGlue#external_volume}
    */
    readonly externalVolume?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#id IcebergTableFromAwsGlue#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the Iceberg table; must be unique for the schema in which the Iceberg table is created. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#name IcebergTableFromAwsGlue#name}
    */
    readonly name: string;
    /**
    * Specifies whether to replace invalid UTF-8 characters with the Unicode replacement character (`�`) in query results for an Iceberg table. For more information, check [REPLACE_INVALID_CHARACTERS docs](https://docs.snowflake.com/en/sql-reference/parameters#replace-invalid-characters).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#replace_invalid_characters IcebergTableFromAwsGlue#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: boolean | cdktn.IResolvable;
    /**
    * The schema in which to create the Iceberg table. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#schema IcebergTableFromAwsGlue#schema}
    */
    readonly schema: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#timeouts IcebergTableFromAwsGlue#timeouts}
    */
    readonly timeouts?: IcebergTableFromAwsGlueTimeouts;
}
export interface IcebergTableFromAwsGlueDescribeOutput {
}
export declare function icebergTableFromAwsGlueDescribeOutputToTerraform(struct?: IcebergTableFromAwsGlueDescribeOutput): any;
export declare function icebergTableFromAwsGlueDescribeOutputToHclTerraform(struct?: IcebergTableFromAwsGlueDescribeOutput): any;
export declare class IcebergTableFromAwsGlueDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromAwsGlueDescribeOutput | undefined;
    set internalValue(value: IcebergTableFromAwsGlueDescribeOutput | undefined);
    get check(): string;
    get comment(): string;
    get default(): string;
    get expression(): string;
    get isNullable(): cdktn.IResolvable;
    get kind(): string;
    get name(): string;
    get nameMapping(): string;
    get policyName(): string;
    get primaryKey(): cdktn.IResolvable;
    get privacyDomain(): string;
    get sourceIcebergType(): string;
    get type(): string;
    get uniqueKey(): cdktn.IResolvable;
    get writeDefault(): string;
}
export declare class IcebergTableFromAwsGlueDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromAwsGlueDescribeOutputOutputReference;
}
export interface IcebergTableFromAwsGlueParametersCatalog {
}
export declare function icebergTableFromAwsGlueParametersCatalogToTerraform(struct?: IcebergTableFromAwsGlueParametersCatalog): any;
export declare function icebergTableFromAwsGlueParametersCatalogToHclTerraform(struct?: IcebergTableFromAwsGlueParametersCatalog): any;
export declare class IcebergTableFromAwsGlueParametersCatalogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromAwsGlueParametersCatalog | undefined;
    set internalValue(value: IcebergTableFromAwsGlueParametersCatalog | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromAwsGlueParametersCatalogList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromAwsGlueParametersCatalogOutputReference;
}
export interface IcebergTableFromAwsGlueParametersExternalVolume {
}
export declare function icebergTableFromAwsGlueParametersExternalVolumeToTerraform(struct?: IcebergTableFromAwsGlueParametersExternalVolume): any;
export declare function icebergTableFromAwsGlueParametersExternalVolumeToHclTerraform(struct?: IcebergTableFromAwsGlueParametersExternalVolume): any;
export declare class IcebergTableFromAwsGlueParametersExternalVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromAwsGlueParametersExternalVolume | undefined;
    set internalValue(value: IcebergTableFromAwsGlueParametersExternalVolume | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromAwsGlueParametersExternalVolumeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromAwsGlueParametersExternalVolumeOutputReference;
}
export interface IcebergTableFromAwsGlueParametersReplaceInvalidCharacters {
}
export declare function icebergTableFromAwsGlueParametersReplaceInvalidCharactersToTerraform(struct?: IcebergTableFromAwsGlueParametersReplaceInvalidCharacters): any;
export declare function icebergTableFromAwsGlueParametersReplaceInvalidCharactersToHclTerraform(struct?: IcebergTableFromAwsGlueParametersReplaceInvalidCharacters): any;
export declare class IcebergTableFromAwsGlueParametersReplaceInvalidCharactersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromAwsGlueParametersReplaceInvalidCharacters | undefined;
    set internalValue(value: IcebergTableFromAwsGlueParametersReplaceInvalidCharacters | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromAwsGlueParametersReplaceInvalidCharactersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromAwsGlueParametersReplaceInvalidCharactersOutputReference;
}
export interface IcebergTableFromAwsGlueParameters {
}
export declare function icebergTableFromAwsGlueParametersToTerraform(struct?: IcebergTableFromAwsGlueParameters): any;
export declare function icebergTableFromAwsGlueParametersToHclTerraform(struct?: IcebergTableFromAwsGlueParameters): any;
export declare class IcebergTableFromAwsGlueParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromAwsGlueParameters | undefined;
    set internalValue(value: IcebergTableFromAwsGlueParameters | undefined);
    private _catalog;
    get catalog(): IcebergTableFromAwsGlueParametersCatalogList;
    private _externalVolume;
    get externalVolume(): IcebergTableFromAwsGlueParametersExternalVolumeList;
    private _replaceInvalidCharacters;
    get replaceInvalidCharacters(): IcebergTableFromAwsGlueParametersReplaceInvalidCharactersList;
}
export declare class IcebergTableFromAwsGlueParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromAwsGlueParametersOutputReference;
}
export interface IcebergTableFromAwsGlueShowOutputAutoRefreshStatus {
}
export declare function icebergTableFromAwsGlueShowOutputAutoRefreshStatusToTerraform(struct?: IcebergTableFromAwsGlueShowOutputAutoRefreshStatus): any;
export declare function icebergTableFromAwsGlueShowOutputAutoRefreshStatusToHclTerraform(struct?: IcebergTableFromAwsGlueShowOutputAutoRefreshStatus): any;
export declare class IcebergTableFromAwsGlueShowOutputAutoRefreshStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromAwsGlueShowOutputAutoRefreshStatus | undefined;
    set internalValue(value: IcebergTableFromAwsGlueShowOutputAutoRefreshStatus | undefined);
    get currentSnapshotId(): number;
    get executionState(): string;
    get lastSnapshotTime(): string;
    get lastUpdatedTime(): string;
    get pendingSnapshotCount(): number;
}
export declare class IcebergTableFromAwsGlueShowOutputAutoRefreshStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromAwsGlueShowOutputAutoRefreshStatusOutputReference;
}
export interface IcebergTableFromAwsGlueShowOutputPartitionSpecsFields {
}
export declare function icebergTableFromAwsGlueShowOutputPartitionSpecsFieldsToTerraform(struct?: IcebergTableFromAwsGlueShowOutputPartitionSpecsFields): any;
export declare function icebergTableFromAwsGlueShowOutputPartitionSpecsFieldsToHclTerraform(struct?: IcebergTableFromAwsGlueShowOutputPartitionSpecsFields): any;
export declare class IcebergTableFromAwsGlueShowOutputPartitionSpecsFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromAwsGlueShowOutputPartitionSpecsFields | undefined;
    set internalValue(value: IcebergTableFromAwsGlueShowOutputPartitionSpecsFields | undefined);
    get fieldId(): number;
    get name(): string;
    get sourceId(): number;
    get transform(): string;
}
export declare class IcebergTableFromAwsGlueShowOutputPartitionSpecsFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromAwsGlueShowOutputPartitionSpecsFieldsOutputReference;
}
export interface IcebergTableFromAwsGlueShowOutputPartitionSpecs {
}
export declare function icebergTableFromAwsGlueShowOutputPartitionSpecsToTerraform(struct?: IcebergTableFromAwsGlueShowOutputPartitionSpecs): any;
export declare function icebergTableFromAwsGlueShowOutputPartitionSpecsToHclTerraform(struct?: IcebergTableFromAwsGlueShowOutputPartitionSpecs): any;
export declare class IcebergTableFromAwsGlueShowOutputPartitionSpecsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromAwsGlueShowOutputPartitionSpecs | undefined;
    set internalValue(value: IcebergTableFromAwsGlueShowOutputPartitionSpecs | undefined);
    private _fields;
    get fields(): IcebergTableFromAwsGlueShowOutputPartitionSpecsFieldsList;
    get specId(): number;
}
export declare class IcebergTableFromAwsGlueShowOutputPartitionSpecsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromAwsGlueShowOutputPartitionSpecsOutputReference;
}
export interface IcebergTableFromAwsGlueShowOutput {
}
export declare function icebergTableFromAwsGlueShowOutputToTerraform(struct?: IcebergTableFromAwsGlueShowOutput): any;
export declare function icebergTableFromAwsGlueShowOutputToHclTerraform(struct?: IcebergTableFromAwsGlueShowOutput): any;
export declare class IcebergTableFromAwsGlueShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromAwsGlueShowOutput | undefined;
    set internalValue(value: IcebergTableFromAwsGlueShowOutput | undefined);
    private _autoRefreshStatus;
    get autoRefreshStatus(): IcebergTableFromAwsGlueShowOutputAutoRefreshStatusList;
    get baseLocation(): string;
    get canWriteMetadata(): cdktn.IResolvable;
    get catalogName(): string;
    get catalogNamespace(): string;
    get catalogSyncName(): string;
    get catalogTableName(): string;
    get comment(): string;
    get createdOn(): string;
    get currentPartitionSpecId(): number;
    get databaseName(): string;
    get externalVolumeName(): string;
    get icebergTableFormatVersion(): number;
    get icebergTableType(): string;
    get name(): string;
    get nameMapping(): string;
    get owner(): string;
    get ownerRoleType(): string;
    private _partitionSpecs;
    get partitionSpecs(): IcebergTableFromAwsGlueShowOutputPartitionSpecsList;
    get schemaName(): string;
}
export declare class IcebergTableFromAwsGlueShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromAwsGlueShowOutputOutputReference;
}
export interface IcebergTableFromAwsGlueTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#create IcebergTableFromAwsGlue#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#delete IcebergTableFromAwsGlue#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#read IcebergTableFromAwsGlue#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#update IcebergTableFromAwsGlue#update}
    */
    readonly update?: string;
}
export declare function icebergTableFromAwsGlueTimeoutsToTerraform(struct?: IcebergTableFromAwsGlueTimeouts | cdktn.IResolvable): any;
export declare function icebergTableFromAwsGlueTimeoutsToHclTerraform(struct?: IcebergTableFromAwsGlueTimeouts | cdktn.IResolvable): any;
export declare class IcebergTableFromAwsGlueTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IcebergTableFromAwsGlueTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: IcebergTableFromAwsGlueTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue snowflake_iceberg_table_from_aws_glue}
*/
export declare class IcebergTableFromAwsGlue extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_iceberg_table_from_aws_glue";
    /**
    * Generates CDKTN code for importing a IcebergTableFromAwsGlue resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IcebergTableFromAwsGlue to import
    * @param importFromId The id of the existing IcebergTableFromAwsGlue that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IcebergTableFromAwsGlue to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_aws_glue snowflake_iceberg_table_from_aws_glue} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IcebergTableFromAwsGlueConfig
    */
    constructor(scope: Construct, id: string, config: IcebergTableFromAwsGlueConfig);
    private _autoRefresh?;
    get autoRefresh(): string;
    set autoRefresh(value: string);
    resetAutoRefresh(): void;
    get autoRefreshInput(): string | undefined;
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _catalogNamespace?;
    get catalogNamespace(): string;
    set catalogNamespace(value: string);
    resetCatalogNamespace(): void;
    get catalogNamespaceInput(): string | undefined;
    private _catalogTableName?;
    get catalogTableName(): string;
    set catalogTableName(value: string);
    get catalogTableNameInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): IcebergTableFromAwsGlueDescribeOutputList;
    private _externalVolume?;
    get externalVolume(): string;
    set externalVolume(value: string);
    resetExternalVolume(): void;
    get externalVolumeInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): IcebergTableFromAwsGlueParametersList;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): boolean | cdktn.IResolvable;
    set replaceInvalidCharacters(value: boolean | cdktn.IResolvable);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): boolean | cdktn.IResolvable | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): IcebergTableFromAwsGlueShowOutputList;
    private _timeouts;
    get timeouts(): IcebergTableFromAwsGlueTimeoutsOutputReference;
    putTimeouts(value: IcebergTableFromAwsGlueTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | IcebergTableFromAwsGlueTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
