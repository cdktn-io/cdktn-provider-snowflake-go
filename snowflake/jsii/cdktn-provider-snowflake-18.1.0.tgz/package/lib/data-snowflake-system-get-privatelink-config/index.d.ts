/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeSystemGetPrivatelinkConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/system_get_privatelink_config#id DataSnowflakeSystemGetPrivatelinkConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/system_get_privatelink_config snowflake_system_get_privatelink_config}
*/
export declare class DataSnowflakeSystemGetPrivatelinkConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_system_get_privatelink_config";
    /**
    * Generates CDKTN code for importing a DataSnowflakeSystemGetPrivatelinkConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeSystemGetPrivatelinkConfig to import
    * @param importFromId The id of the existing DataSnowflakeSystemGetPrivatelinkConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/system_get_privatelink_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeSystemGetPrivatelinkConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/system_get_privatelink_config snowflake_system_get_privatelink_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeSystemGetPrivatelinkConfigConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeSystemGetPrivatelinkConfigConfig);
    get accountName(): string;
    get accountUrl(): string;
    get appServicePrivatelinkUrl(): string;
    get awsVpceId(): string;
    get azurePlsId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get internalStage(): string;
    get ocspUrl(): string;
    get privatelinkAccountPrincipal(): string;
    get privatelinkConnectionOcspUrls(): string;
    get privatelinkConnectionUrls(): string;
    get privatelinkDashedUrlsForDuo(): string;
    get privatelinkGcpServiceAttachment(): string;
    get privatelinkSnowflakeManagedStorageVolumeFs(): string;
    get privatelinkSnowflakeManagedStorageVolumeNfs(): string;
    get regionlessAccountUrl(): string;
    get regionlessPrivatelinkOcspUrl(): string;
    get regionlessSnowsightUrl(): string;
    get snowsightUrl(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
