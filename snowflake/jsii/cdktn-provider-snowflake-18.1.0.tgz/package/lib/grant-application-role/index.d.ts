/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GrantApplicationRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The fully qualified name of the application on which application role will be granted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_application_role#application_name GrantApplicationRole#application_name}
    */
    readonly applicationName?: string;
    /**
    * Specifies the identifier for the application role to grant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_application_role#application_role_name GrantApplicationRole#application_role_name}
    */
    readonly applicationRoleName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_application_role#id GrantApplicationRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The fully qualified name of the account role on which application role will be granted. For more information about this resource, see [docs](./account_role).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_application_role#parent_account_role_name GrantApplicationRole#parent_account_role_name}
    */
    readonly parentAccountRoleName?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_application_role#timeouts GrantApplicationRole#timeouts}
    */
    readonly timeouts?: GrantApplicationRoleTimeouts;
}
export interface GrantApplicationRoleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_application_role#create GrantApplicationRole#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_application_role#delete GrantApplicationRole#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_application_role#read GrantApplicationRole#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_application_role#update GrantApplicationRole#update}
    */
    readonly update?: string;
}
export declare function grantApplicationRoleTimeoutsToTerraform(struct?: GrantApplicationRoleTimeouts | cdktn.IResolvable): any;
export declare function grantApplicationRoleTimeoutsToHclTerraform(struct?: GrantApplicationRoleTimeouts | cdktn.IResolvable): any;
export declare class GrantApplicationRoleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GrantApplicationRoleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: GrantApplicationRoleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_application_role snowflake_grant_application_role}
*/
export declare class GrantApplicationRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_grant_application_role";
    /**
    * Generates CDKTN code for importing a GrantApplicationRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GrantApplicationRole to import
    * @param importFromId The id of the existing GrantApplicationRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_application_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GrantApplicationRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_application_role snowflake_grant_application_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GrantApplicationRoleConfig
    */
    constructor(scope: Construct, id: string, config: GrantApplicationRoleConfig);
    private _applicationName?;
    get applicationName(): string;
    set applicationName(value: string);
    resetApplicationName(): void;
    get applicationNameInput(): string | undefined;
    private _applicationRoleName?;
    get applicationRoleName(): string;
    set applicationRoleName(value: string);
    get applicationRoleNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _parentAccountRoleName?;
    get parentAccountRoleName(): string;
    set parentAccountRoleName(value: string);
    resetParentAccountRoleName(): void;
    get parentAccountRoleNameInput(): string | undefined;
    private _timeouts;
    get timeouts(): GrantApplicationRoleTimeoutsOutputReference;
    putTimeouts(value: GrantApplicationRoleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | GrantApplicationRoleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
