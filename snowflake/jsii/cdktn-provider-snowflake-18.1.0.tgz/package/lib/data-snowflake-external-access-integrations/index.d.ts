/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeExternalAccessIntegrationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/external_access_integrations#id DataSnowflakeExternalAccessIntegrations#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/external_access_integrations#like DataSnowflakeExternalAccessIntegrations#like}
    */
    readonly like?: string;
    /**
    * (Default: `true`) Runs DESC EXTERNAL ACCESS INTEGRATION for each integration returned by SHOW EXTERNAL ACCESS INTEGRATIONS. The output of describe is saved to the describe_output field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/external_access_integrations#with_describe DataSnowflakeExternalAccessIntegrations#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
}
export interface DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsDescribeOutput {
}
export declare function dataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsDescribeOutputToTerraform(struct?: DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsDescribeOutput): any;
export declare function dataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsDescribeOutputToHclTerraform(struct?: DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsDescribeOutput): any;
export declare class DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsDescribeOutput | undefined);
    get allowedApiAuthenticationIntegrations(): string[];
    get allowedAuthenticationSecrets(): string[];
    get allowedNetworkRules(): string[];
    get comment(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
}
export declare class DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsDescribeOutputOutputReference;
}
export interface DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsShowOutput {
}
export declare function dataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsShowOutputToTerraform(struct?: DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsShowOutput): any;
export declare function dataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsShowOutputToHclTerraform(struct?: DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsShowOutput): any;
export declare class DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsShowOutput | undefined;
    set internalValue(value: DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsShowOutput | undefined);
    get category(): string;
    get comment(): string;
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
    get type(): string;
}
export declare class DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsShowOutputOutputReference;
}
export interface DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrations {
}
export declare function dataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsToTerraform(struct?: DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrations): any;
export declare function dataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsToHclTerraform(struct?: DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrations): any;
export declare class DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrations | undefined;
    set internalValue(value: DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrations | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsShowOutputList;
}
export declare class DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/external_access_integrations snowflake_external_access_integrations}
*/
export declare class DataSnowflakeExternalAccessIntegrations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_external_access_integrations";
    /**
    * Generates CDKTN code for importing a DataSnowflakeExternalAccessIntegrations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeExternalAccessIntegrations to import
    * @param importFromId The id of the existing DataSnowflakeExternalAccessIntegrations that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/external_access_integrations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeExternalAccessIntegrations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/external_access_integrations snowflake_external_access_integrations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeExternalAccessIntegrationsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeExternalAccessIntegrationsConfig);
    private _externalAccessIntegrations;
    get externalAccessIntegrations(): DataSnowflakeExternalAccessIntegrationsExternalAccessIntegrationsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
