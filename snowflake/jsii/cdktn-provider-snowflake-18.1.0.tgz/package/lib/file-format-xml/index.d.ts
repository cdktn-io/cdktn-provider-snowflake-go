/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FileFormatXmlConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the file format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#comment FileFormatXml#comment}
    */
    readonly comment?: string;
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BZ2` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#compression FileFormatXml#compression}
    */
    readonly compression?: string;
    /**
    * The database in which to create the file format. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#database FileFormatXml#database}
    */
    readonly database: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether the XML parser disables automatic conversion of numeric and Boolean values from text to native representation. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#disable_auto_convert FileFormatXml#disable_auto_convert}
    */
    readonly disableAutoConvert?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#id FileFormatXml#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#ignore_utf8_errors FileFormatXml#ignore_utf8_errors}
    */
    readonly ignoreUtf8Errors?: string;
    /**
    * Specifies the identifier for the file format; must be unique for the database and schema in which the file format is created. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#name FileFormatXml#name}
    */
    readonly name: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether the XML parser preserves leading and trailing spaces in element content. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#preserve_space FileFormatXml#preserve_space}
    */
    readonly preserveSpace?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#replace_invalid_characters FileFormatXml#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * The schema in which to create the file format. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#schema FileFormatXml#schema}
    */
    readonly schema: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#skip_byte_order_mark FileFormatXml#skip_byte_order_mark}
    */
    readonly skipByteOrderMark?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether the XML parser strips out the outer XML element, exposing 2nd level elements as separate documents. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#strip_outer_element FileFormatXml#strip_outer_element}
    */
    readonly stripOuterElement?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#timeouts FileFormatXml#timeouts}
    */
    readonly timeouts?: FileFormatXmlTimeouts;
}
export interface FileFormatXmlDescribeOutput {
}
export declare function fileFormatXmlDescribeOutputToTerraform(struct?: FileFormatXmlDescribeOutput): any;
export declare function fileFormatXmlDescribeOutputToHclTerraform(struct?: FileFormatXmlDescribeOutput): any;
export declare class FileFormatXmlDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FileFormatXmlDescribeOutput | undefined;
    set internalValue(value: FileFormatXmlDescribeOutput | undefined);
    get compression(): string;
    get disableAutoConvert(): cdktn.IResolvable;
    get id(): string;
    get ignoreUtf8Errors(): cdktn.IResolvable;
    get preserveSpace(): cdktn.IResolvable;
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get stripOuterElement(): cdktn.IResolvable;
    get type(): string;
}
export declare class FileFormatXmlDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FileFormatXmlDescribeOutputOutputReference;
}
export interface FileFormatXmlShowOutput {
}
export declare function fileFormatXmlShowOutputToTerraform(struct?: FileFormatXmlShowOutput): any;
export declare function fileFormatXmlShowOutputToHclTerraform(struct?: FileFormatXmlShowOutput): any;
export declare class FileFormatXmlShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FileFormatXmlShowOutput | undefined;
    set internalValue(value: FileFormatXmlShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get formatOptions(): string;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get schemaName(): string;
    get type(): string;
}
export declare class FileFormatXmlShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FileFormatXmlShowOutputOutputReference;
}
export interface FileFormatXmlTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#create FileFormatXml#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#delete FileFormatXml#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#read FileFormatXml#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#update FileFormatXml#update}
    */
    readonly update?: string;
}
export declare function fileFormatXmlTimeoutsToTerraform(struct?: FileFormatXmlTimeouts | cdktn.IResolvable): any;
export declare function fileFormatXmlTimeoutsToHclTerraform(struct?: FileFormatXmlTimeouts | cdktn.IResolvable): any;
export declare class FileFormatXmlTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FileFormatXmlTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: FileFormatXmlTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml snowflake_file_format_xml}
*/
export declare class FileFormatXml extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_file_format_xml";
    /**
    * Generates CDKTN code for importing a FileFormatXml resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FileFormatXml to import
    * @param importFromId The id of the existing FileFormatXml that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FileFormatXml to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/file_format_xml snowflake_file_format_xml} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FileFormatXmlConfig
    */
    constructor(scope: Construct, id: string, config: FileFormatXmlConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): FileFormatXmlDescribeOutputList;
    private _disableAutoConvert?;
    get disableAutoConvert(): string;
    set disableAutoConvert(value: string);
    resetDisableAutoConvert(): void;
    get disableAutoConvertInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreUtf8Errors?;
    get ignoreUtf8Errors(): string;
    set ignoreUtf8Errors(value: string);
    resetIgnoreUtf8Errors(): void;
    get ignoreUtf8ErrorsInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _preserveSpace?;
    get preserveSpace(): string;
    set preserveSpace(value: string);
    resetPreserveSpace(): void;
    get preserveSpaceInput(): string | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): FileFormatXmlShowOutputList;
    private _skipByteOrderMark?;
    get skipByteOrderMark(): string;
    set skipByteOrderMark(value: string);
    resetSkipByteOrderMark(): void;
    get skipByteOrderMarkInput(): string | undefined;
    private _stripOuterElement?;
    get stripOuterElement(): string;
    set stripOuterElement(value: string);
    resetStripOuterElement(): void;
    get stripOuterElementInput(): string | undefined;
    get type(): string;
    private _timeouts;
    get timeouts(): FileFormatXmlTimeoutsOutputReference;
    putTimeouts(value: FileFormatXmlTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | FileFormatXmlTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
