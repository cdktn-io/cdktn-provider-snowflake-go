/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CatalogIntegrationOpenCatalogConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the default Open Catalog namespace for all Iceberg tables that you associate with the catalog integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#catalog_namespace CatalogIntegrationOpenCatalog#catalog_namespace}
    */
    readonly catalogNamespace?: string;
    /**
    * (Default: ``) Specifies a comment for the catalog integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#comment CatalogIntegrationOpenCatalog#comment}
    */
    readonly comment?: string;
    /**
    * Specifies whether the catalog integration is available for use for Iceberg tables. `true` allows users to create new Iceberg tables that reference this integration. Existing Iceberg tables that reference this integration function normally. `false` prevents users from creating new Iceberg tables that reference this integration. Existing Iceberg tables that reference this integration cannot access the catalog in the table definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#enabled CatalogIntegrationOpenCatalog#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#id CatalogIntegrationOpenCatalog#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier (i.e. name) of the catalog integration; must be unique in your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#name CatalogIntegrationOpenCatalog#name}
    */
    readonly name: string;
    /**
    * Specifies the number of seconds to wait between attempts to poll the external Iceberg catalog for metadata updates for automated refresh. For Delta-based tables, specifies the number of seconds to wait between attempts to poll your external cloud storage for new metadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#refresh_interval_seconds CatalogIntegrationOpenCatalog#refresh_interval_seconds}
    */
    readonly refreshIntervalSeconds?: number;
    /**
    * rest_authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#rest_authentication CatalogIntegrationOpenCatalog#rest_authentication}
    */
    readonly restAuthentication: CatalogIntegrationOpenCatalogRestAuthentication;
    /**
    * rest_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#rest_config CatalogIntegrationOpenCatalog#rest_config}
    */
    readonly restConfig: CatalogIntegrationOpenCatalogRestConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#timeouts CatalogIntegrationOpenCatalog#timeouts}
    */
    readonly timeouts?: CatalogIntegrationOpenCatalogTimeouts;
}
export interface CatalogIntegrationOpenCatalogDescribeOutputRestAuthentication {
}
export declare function catalogIntegrationOpenCatalogDescribeOutputRestAuthenticationToTerraform(struct?: CatalogIntegrationOpenCatalogDescribeOutputRestAuthentication): any;
export declare function catalogIntegrationOpenCatalogDescribeOutputRestAuthenticationToHclTerraform(struct?: CatalogIntegrationOpenCatalogDescribeOutputRestAuthentication): any;
export declare class CatalogIntegrationOpenCatalogDescribeOutputRestAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CatalogIntegrationOpenCatalogDescribeOutputRestAuthentication | undefined;
    set internalValue(value: CatalogIntegrationOpenCatalogDescribeOutputRestAuthentication | undefined);
    get oauthAllowedScopes(): string[];
    get oauthClientId(): string;
    get oauthTokenUri(): string;
}
export declare class CatalogIntegrationOpenCatalogDescribeOutputRestAuthenticationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CatalogIntegrationOpenCatalogDescribeOutputRestAuthenticationOutputReference;
}
export interface CatalogIntegrationOpenCatalogDescribeOutputRestConfig {
}
export declare function catalogIntegrationOpenCatalogDescribeOutputRestConfigToTerraform(struct?: CatalogIntegrationOpenCatalogDescribeOutputRestConfig): any;
export declare function catalogIntegrationOpenCatalogDescribeOutputRestConfigToHclTerraform(struct?: CatalogIntegrationOpenCatalogDescribeOutputRestConfig): any;
export declare class CatalogIntegrationOpenCatalogDescribeOutputRestConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CatalogIntegrationOpenCatalogDescribeOutputRestConfig | undefined;
    set internalValue(value: CatalogIntegrationOpenCatalogDescribeOutputRestConfig | undefined);
    get accessDelegationMode(): string;
    get catalogApiType(): string;
    get catalogName(): string;
    get catalogUri(): string;
}
export declare class CatalogIntegrationOpenCatalogDescribeOutputRestConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CatalogIntegrationOpenCatalogDescribeOutputRestConfigOutputReference;
}
export interface CatalogIntegrationOpenCatalogDescribeOutput {
}
export declare function catalogIntegrationOpenCatalogDescribeOutputToTerraform(struct?: CatalogIntegrationOpenCatalogDescribeOutput): any;
export declare function catalogIntegrationOpenCatalogDescribeOutputToHclTerraform(struct?: CatalogIntegrationOpenCatalogDescribeOutput): any;
export declare class CatalogIntegrationOpenCatalogDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CatalogIntegrationOpenCatalogDescribeOutput | undefined;
    set internalValue(value: CatalogIntegrationOpenCatalogDescribeOutput | undefined);
    get catalogNamespace(): string;
    get catalogSource(): string;
    get comment(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get refreshIntervalSeconds(): number;
    private _restAuthentication;
    get restAuthentication(): CatalogIntegrationOpenCatalogDescribeOutputRestAuthenticationList;
    private _restConfig;
    get restConfig(): CatalogIntegrationOpenCatalogDescribeOutputRestConfigList;
    get tableFormat(): string;
}
export declare class CatalogIntegrationOpenCatalogDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CatalogIntegrationOpenCatalogDescribeOutputOutputReference;
}
export interface CatalogIntegrationOpenCatalogShowOutput {
}
export declare function catalogIntegrationOpenCatalogShowOutputToTerraform(struct?: CatalogIntegrationOpenCatalogShowOutput): any;
export declare function catalogIntegrationOpenCatalogShowOutputToHclTerraform(struct?: CatalogIntegrationOpenCatalogShowOutput): any;
export declare class CatalogIntegrationOpenCatalogShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CatalogIntegrationOpenCatalogShowOutput | undefined;
    set internalValue(value: CatalogIntegrationOpenCatalogShowOutput | undefined);
    get category(): string;
    get comment(): string;
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
    get type(): string;
}
export declare class CatalogIntegrationOpenCatalogShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CatalogIntegrationOpenCatalogShowOutputOutputReference;
}
export interface CatalogIntegrationOpenCatalogRestAuthentication {
    /**
    * Specifies one or more scopes for the OAuth token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#oauth_allowed_scopes CatalogIntegrationOpenCatalog#oauth_allowed_scopes}
    */
    readonly oauthAllowedScopes: string[];
    /**
    * Specifies the client ID of the OAuth2 credential associated with your Open Catalog service connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#oauth_client_id CatalogIntegrationOpenCatalog#oauth_client_id}
    */
    readonly oauthClientId: string;
    /**
    * Specifies the secret of the OAuth2 credential associated with your Open Catalog service connection. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#oauth_client_secret CatalogIntegrationOpenCatalog#oauth_client_secret}
    */
    readonly oauthClientSecret: string;
    /**
    * Specifies URL for the third-party identity provider. If not specified, Snowflake assumes the remote catalog provider is the identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#oauth_token_uri CatalogIntegrationOpenCatalog#oauth_token_uri}
    */
    readonly oauthTokenUri?: string;
}
export declare function catalogIntegrationOpenCatalogRestAuthenticationToTerraform(struct?: CatalogIntegrationOpenCatalogRestAuthenticationOutputReference | CatalogIntegrationOpenCatalogRestAuthentication): any;
export declare function catalogIntegrationOpenCatalogRestAuthenticationToHclTerraform(struct?: CatalogIntegrationOpenCatalogRestAuthenticationOutputReference | CatalogIntegrationOpenCatalogRestAuthentication): any;
export declare class CatalogIntegrationOpenCatalogRestAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogIntegrationOpenCatalogRestAuthentication | undefined;
    set internalValue(value: CatalogIntegrationOpenCatalogRestAuthentication | undefined);
    private _oauthAllowedScopes?;
    get oauthAllowedScopes(): string[];
    set oauthAllowedScopes(value: string[]);
    get oauthAllowedScopesInput(): string[] | undefined;
    private _oauthClientId?;
    get oauthClientId(): string;
    set oauthClientId(value: string);
    get oauthClientIdInput(): string | undefined;
    private _oauthClientSecret?;
    get oauthClientSecret(): string;
    set oauthClientSecret(value: string);
    get oauthClientSecretInput(): string | undefined;
    private _oauthTokenUri?;
    get oauthTokenUri(): string;
    set oauthTokenUri(value: string);
    resetOauthTokenUri(): void;
    get oauthTokenUriInput(): string | undefined;
}
export interface CatalogIntegrationOpenCatalogRestConfig {
    /**
    * Specifies the access delegation mode for accessing Iceberg table files in your external cloud storage. Valid values are (case-insensitive): `VENDED_CREDENTIALS` | `EXTERNAL_VOLUME_CREDENTIALS`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#access_delegation_mode CatalogIntegrationOpenCatalog#access_delegation_mode}
    */
    readonly accessDelegationMode?: string;
    /**
    * Specifies how Snowflake connects to Open Catalog. Valid values are (case-insensitive): `PUBLIC` | `PRIVATE` | `AWS_API_GATEWAY` | `AWS_PRIVATE_API_GATEWAY` | `AWS_GLUE` | `AWS_PRIVATE_GLUE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#catalog_api_type CatalogIntegrationOpenCatalog#catalog_api_type}
    */
    readonly catalogApiType?: string;
    /**
    * Specifies the name of the catalog to use in Open Catalog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#catalog_name CatalogIntegrationOpenCatalog#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Specifies Open Catalog account URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#catalog_uri CatalogIntegrationOpenCatalog#catalog_uri}
    */
    readonly catalogUri: string;
}
export declare function catalogIntegrationOpenCatalogRestConfigToTerraform(struct?: CatalogIntegrationOpenCatalogRestConfigOutputReference | CatalogIntegrationOpenCatalogRestConfig): any;
export declare function catalogIntegrationOpenCatalogRestConfigToHclTerraform(struct?: CatalogIntegrationOpenCatalogRestConfigOutputReference | CatalogIntegrationOpenCatalogRestConfig): any;
export declare class CatalogIntegrationOpenCatalogRestConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogIntegrationOpenCatalogRestConfig | undefined;
    set internalValue(value: CatalogIntegrationOpenCatalogRestConfig | undefined);
    private _accessDelegationMode?;
    get accessDelegationMode(): string;
    set accessDelegationMode(value: string);
    resetAccessDelegationMode(): void;
    get accessDelegationModeInput(): string | undefined;
    private _catalogApiType?;
    get catalogApiType(): string;
    set catalogApiType(value: string);
    resetCatalogApiType(): void;
    get catalogApiTypeInput(): string | undefined;
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _catalogUri?;
    get catalogUri(): string;
    set catalogUri(value: string);
    get catalogUriInput(): string | undefined;
}
export interface CatalogIntegrationOpenCatalogTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#create CatalogIntegrationOpenCatalog#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#delete CatalogIntegrationOpenCatalog#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#read CatalogIntegrationOpenCatalog#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#update CatalogIntegrationOpenCatalog#update}
    */
    readonly update?: string;
}
export declare function catalogIntegrationOpenCatalogTimeoutsToTerraform(struct?: CatalogIntegrationOpenCatalogTimeouts | cdktn.IResolvable): any;
export declare function catalogIntegrationOpenCatalogTimeoutsToHclTerraform(struct?: CatalogIntegrationOpenCatalogTimeouts | cdktn.IResolvable): any;
export declare class CatalogIntegrationOpenCatalogTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogIntegrationOpenCatalogTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CatalogIntegrationOpenCatalogTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog snowflake_catalog_integration_open_catalog}
*/
export declare class CatalogIntegrationOpenCatalog extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_catalog_integration_open_catalog";
    /**
    * Generates CDKTN code for importing a CatalogIntegrationOpenCatalog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CatalogIntegrationOpenCatalog to import
    * @param importFromId The id of the existing CatalogIntegrationOpenCatalog that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CatalogIntegrationOpenCatalog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/catalog_integration_open_catalog snowflake_catalog_integration_open_catalog} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CatalogIntegrationOpenCatalogConfig
    */
    constructor(scope: Construct, id: string, config: CatalogIntegrationOpenCatalogConfig);
    private _catalogNamespace?;
    get catalogNamespace(): string;
    set catalogNamespace(value: string);
    resetCatalogNamespace(): void;
    get catalogNamespaceInput(): string | undefined;
    get catalogSource(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): CatalogIntegrationOpenCatalogDescribeOutputList;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _refreshIntervalSeconds?;
    get refreshIntervalSeconds(): number;
    set refreshIntervalSeconds(value: number);
    resetRefreshIntervalSeconds(): void;
    get refreshIntervalSecondsInput(): number | undefined;
    private _showOutput;
    get showOutput(): CatalogIntegrationOpenCatalogShowOutputList;
    private _restAuthentication;
    get restAuthentication(): CatalogIntegrationOpenCatalogRestAuthenticationOutputReference;
    putRestAuthentication(value: CatalogIntegrationOpenCatalogRestAuthentication): void;
    get restAuthenticationInput(): CatalogIntegrationOpenCatalogRestAuthentication | undefined;
    private _restConfig;
    get restConfig(): CatalogIntegrationOpenCatalogRestConfigOutputReference;
    putRestConfig(value: CatalogIntegrationOpenCatalogRestConfig): void;
    get restConfigInput(): CatalogIntegrationOpenCatalogRestConfig | undefined;
    private _timeouts;
    get timeouts(): CatalogIntegrationOpenCatalogTimeoutsOutputReference;
    putTimeouts(value: CatalogIntegrationOpenCatalogTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CatalogIntegrationOpenCatalogTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
