/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeStorageIntegrationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/storage_integrations#id DataSnowflakeStorageIntegrations#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/storage_integrations#like DataSnowflakeStorageIntegrations#like}
    */
    readonly like?: string;
    /**
    * (Default: `true`) Runs DESC STORAGE INTEGRATION for each storage integration returned by SHOW STORAGE INTEGRATIONS. The output of describe is saved to the description field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/storage_integrations#with_describe DataSnowflakeStorageIntegrations#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
}
export interface DataSnowflakeStorageIntegrationsStorageIntegrationsDescribeOutput {
}
export declare function dataSnowflakeStorageIntegrationsStorageIntegrationsDescribeOutputToTerraform(struct?: DataSnowflakeStorageIntegrationsStorageIntegrationsDescribeOutput): any;
export declare function dataSnowflakeStorageIntegrationsStorageIntegrationsDescribeOutputToHclTerraform(struct?: DataSnowflakeStorageIntegrationsStorageIntegrationsDescribeOutput): any;
export declare class DataSnowflakeStorageIntegrationsStorageIntegrationsDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStorageIntegrationsStorageIntegrationsDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeStorageIntegrationsStorageIntegrationsDescribeOutput | undefined);
    get allowedLocations(): string[];
    get blockedLocations(): string[];
    get comment(): string;
    get consentUrl(): string;
    get enabled(): cdktn.IResolvable;
    get externalId(): string;
    get iamUserArn(): string;
    get id(): string;
    get multiTenantAppName(): string;
    get objectAcl(): string;
    get provider(): string;
    get roleArn(): string;
    get serviceAccount(): string;
    get tenantId(): string;
    get usePrivatelinkEndpoint(): cdktn.IResolvable;
}
export declare class DataSnowflakeStorageIntegrationsStorageIntegrationsDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStorageIntegrationsStorageIntegrationsDescribeOutputOutputReference;
}
export interface DataSnowflakeStorageIntegrationsStorageIntegrationsShowOutput {
}
export declare function dataSnowflakeStorageIntegrationsStorageIntegrationsShowOutputToTerraform(struct?: DataSnowflakeStorageIntegrationsStorageIntegrationsShowOutput): any;
export declare function dataSnowflakeStorageIntegrationsStorageIntegrationsShowOutputToHclTerraform(struct?: DataSnowflakeStorageIntegrationsStorageIntegrationsShowOutput): any;
export declare class DataSnowflakeStorageIntegrationsStorageIntegrationsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStorageIntegrationsStorageIntegrationsShowOutput | undefined;
    set internalValue(value: DataSnowflakeStorageIntegrationsStorageIntegrationsShowOutput | undefined);
    get category(): string;
    get comment(): string;
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
    get storageType(): string;
}
export declare class DataSnowflakeStorageIntegrationsStorageIntegrationsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStorageIntegrationsStorageIntegrationsShowOutputOutputReference;
}
export interface DataSnowflakeStorageIntegrationsStorageIntegrations {
}
export declare function dataSnowflakeStorageIntegrationsStorageIntegrationsToTerraform(struct?: DataSnowflakeStorageIntegrationsStorageIntegrations): any;
export declare function dataSnowflakeStorageIntegrationsStorageIntegrationsToHclTerraform(struct?: DataSnowflakeStorageIntegrationsStorageIntegrations): any;
export declare class DataSnowflakeStorageIntegrationsStorageIntegrationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStorageIntegrationsStorageIntegrations | undefined;
    set internalValue(value: DataSnowflakeStorageIntegrationsStorageIntegrations | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeStorageIntegrationsStorageIntegrationsDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeStorageIntegrationsStorageIntegrationsShowOutputList;
}
export declare class DataSnowflakeStorageIntegrationsStorageIntegrationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStorageIntegrationsStorageIntegrationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/storage_integrations snowflake_storage_integrations}
*/
export declare class DataSnowflakeStorageIntegrations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_storage_integrations";
    /**
    * Generates CDKTN code for importing a DataSnowflakeStorageIntegrations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeStorageIntegrations to import
    * @param importFromId The id of the existing DataSnowflakeStorageIntegrations that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/storage_integrations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeStorageIntegrations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/storage_integrations snowflake_storage_integrations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeStorageIntegrationsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeStorageIntegrationsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _storageIntegrations;
    get storageIntegrations(): DataSnowflakeStorageIntegrationsStorageIntegrationsList;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
