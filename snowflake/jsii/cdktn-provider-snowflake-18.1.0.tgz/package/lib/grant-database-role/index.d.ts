/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GrantDatabaseRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The fully qualified name of the database role which will be granted to share or parent role. For more information about this resource, see [docs](./database_role).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_database_role#database_role_name GrantDatabaseRole#database_role_name}
    */
    readonly databaseRoleName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_database_role#id GrantDatabaseRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The fully qualified name of the parent database role which will create a parent-child relationship between the roles. For more information about this resource, see [docs](./database_role).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_database_role#parent_database_role_name GrantDatabaseRole#parent_database_role_name}
    */
    readonly parentDatabaseRoleName?: string;
    /**
    * The fully qualified name of the parent account role which will create a parent-child relationship between the roles. For more information about this resource, see [docs](./account_role).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_database_role#parent_role_name GrantDatabaseRole#parent_role_name}
    */
    readonly parentRoleName?: string;
    /**
    * The fully qualified name of the share on which privileges will be granted. For more information about this resource, see [docs](./share).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_database_role#share_name GrantDatabaseRole#share_name}
    */
    readonly shareName?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_database_role#timeouts GrantDatabaseRole#timeouts}
    */
    readonly timeouts?: GrantDatabaseRoleTimeouts;
}
export interface GrantDatabaseRoleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_database_role#create GrantDatabaseRole#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_database_role#delete GrantDatabaseRole#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_database_role#read GrantDatabaseRole#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_database_role#update GrantDatabaseRole#update}
    */
    readonly update?: string;
}
export declare function grantDatabaseRoleTimeoutsToTerraform(struct?: GrantDatabaseRoleTimeouts | cdktn.IResolvable): any;
export declare function grantDatabaseRoleTimeoutsToHclTerraform(struct?: GrantDatabaseRoleTimeouts | cdktn.IResolvable): any;
export declare class GrantDatabaseRoleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GrantDatabaseRoleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: GrantDatabaseRoleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_database_role snowflake_grant_database_role}
*/
export declare class GrantDatabaseRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_grant_database_role";
    /**
    * Generates CDKTN code for importing a GrantDatabaseRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GrantDatabaseRole to import
    * @param importFromId The id of the existing GrantDatabaseRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_database_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GrantDatabaseRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/grant_database_role snowflake_grant_database_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GrantDatabaseRoleConfig
    */
    constructor(scope: Construct, id: string, config: GrantDatabaseRoleConfig);
    private _databaseRoleName?;
    get databaseRoleName(): string;
    set databaseRoleName(value: string);
    get databaseRoleNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _parentDatabaseRoleName?;
    get parentDatabaseRoleName(): string;
    set parentDatabaseRoleName(value: string);
    resetParentDatabaseRoleName(): void;
    get parentDatabaseRoleNameInput(): string | undefined;
    private _parentRoleName?;
    get parentRoleName(): string;
    set parentRoleName(value: string);
    resetParentRoleName(): void;
    get parentRoleNameInput(): string | undefined;
    private _shareName?;
    get shareName(): string;
    set shareName(value: string);
    resetShareName(): void;
    get shareNameInput(): string | undefined;
    private _timeouts;
    get timeouts(): GrantDatabaseRoleTimeoutsOutputReference;
    putTimeouts(value: GrantDatabaseRoleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | GrantDatabaseRoleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
