/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StageExternalGcsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#comment StageExternalGcs#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the stage. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#database StageExternalGcs#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#id StageExternalGcs#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the stage; must be unique for the database and schema in which the stage is created. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#name StageExternalGcs#name}
    */
    readonly name: string;
    /**
    * The schema in which to create the stage. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#schema StageExternalGcs#schema}
    */
    readonly schema: string;
    /**
    * Specifies the name of the storage integration used to delegate authentication responsibility to a Snowflake identity. GCS stages require a storage integration. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#storage_integration StageExternalGcs#storage_integration}
    */
    readonly storageIntegration: string;
    /**
    * Specifies the URL for the GCS bucket (e.g., 'gcs://bucket/path/').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#url StageExternalGcs#url}
    */
    readonly url: string;
    /**
    * directory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#directory StageExternalGcs#directory}
    */
    readonly directory?: StageExternalGcsDirectory;
    /**
    * encryption block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#encryption StageExternalGcs#encryption}
    */
    readonly encryption?: StageExternalGcsEncryption;
    /**
    * file_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#file_format StageExternalGcs#file_format}
    */
    readonly fileFormat?: StageExternalGcsFileFormat;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#timeouts StageExternalGcs#timeouts}
    */
    readonly timeouts?: StageExternalGcsTimeouts;
}
export interface StageExternalGcsDescribeOutputDirectoryTable {
}
export declare function stageExternalGcsDescribeOutputDirectoryTableToTerraform(struct?: StageExternalGcsDescribeOutputDirectoryTable): any;
export declare function stageExternalGcsDescribeOutputDirectoryTableToHclTerraform(struct?: StageExternalGcsDescribeOutputDirectoryTable): any;
export declare class StageExternalGcsDescribeOutputDirectoryTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalGcsDescribeOutputDirectoryTable | undefined;
    set internalValue(value: StageExternalGcsDescribeOutputDirectoryTable | undefined);
    get autoRefresh(): cdktn.IResolvable;
    get enable(): cdktn.IResolvable;
    get lastRefreshedOn(): string;
}
export declare class StageExternalGcsDescribeOutputDirectoryTableList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalGcsDescribeOutputDirectoryTableOutputReference;
}
export interface StageExternalGcsDescribeOutputFileFormatAvro {
}
export declare function stageExternalGcsDescribeOutputFileFormatAvroToTerraform(struct?: StageExternalGcsDescribeOutputFileFormatAvro): any;
export declare function stageExternalGcsDescribeOutputFileFormatAvroToHclTerraform(struct?: StageExternalGcsDescribeOutputFileFormatAvro): any;
export declare class StageExternalGcsDescribeOutputFileFormatAvroOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalGcsDescribeOutputFileFormatAvro | undefined;
    set internalValue(value: StageExternalGcsDescribeOutputFileFormatAvro | undefined);
    get compression(): string;
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageExternalGcsDescribeOutputFileFormatAvroList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalGcsDescribeOutputFileFormatAvroOutputReference;
}
export interface StageExternalGcsDescribeOutputFileFormatCsv {
}
export declare function stageExternalGcsDescribeOutputFileFormatCsvToTerraform(struct?: StageExternalGcsDescribeOutputFileFormatCsv): any;
export declare function stageExternalGcsDescribeOutputFileFormatCsvToHclTerraform(struct?: StageExternalGcsDescribeOutputFileFormatCsv): any;
export declare class StageExternalGcsDescribeOutputFileFormatCsvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalGcsDescribeOutputFileFormatCsv | undefined;
    set internalValue(value: StageExternalGcsDescribeOutputFileFormatCsv | undefined);
    get binaryFormat(): string;
    get compression(): string;
    get dateFormat(): string;
    get emptyFieldAsNull(): cdktn.IResolvable;
    get encoding(): string;
    get errorOnColumnCountMismatch(): cdktn.IResolvable;
    get escape(): string;
    get escapeUnenclosedField(): string;
    get fieldDelimiter(): string;
    get fieldOptionallyEnclosedBy(): string;
    get fileExtension(): string;
    get multiLine(): cdktn.IResolvable;
    get nullIf(): string[];
    get parseHeader(): cdktn.IResolvable;
    get recordDelimiter(): string;
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipBlankLines(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get skipHeader(): number;
    get timeFormat(): string;
    get timestampFormat(): string;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
    get validateUtf8(): cdktn.IResolvable;
}
export declare class StageExternalGcsDescribeOutputFileFormatCsvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalGcsDescribeOutputFileFormatCsvOutputReference;
}
export interface StageExternalGcsDescribeOutputFileFormatJson {
}
export declare function stageExternalGcsDescribeOutputFileFormatJsonToTerraform(struct?: StageExternalGcsDescribeOutputFileFormatJson): any;
export declare function stageExternalGcsDescribeOutputFileFormatJsonToHclTerraform(struct?: StageExternalGcsDescribeOutputFileFormatJson): any;
export declare class StageExternalGcsDescribeOutputFileFormatJsonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalGcsDescribeOutputFileFormatJson | undefined;
    set internalValue(value: StageExternalGcsDescribeOutputFileFormatJson | undefined);
    get allowDuplicate(): cdktn.IResolvable;
    get binaryFormat(): string;
    get compression(): string;
    get dateFormat(): string;
    get enableOctal(): cdktn.IResolvable;
    get fileExtension(): string;
    get ignoreUtf8Errors(): cdktn.IResolvable;
    get multiLine(): cdktn.IResolvable;
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get stripNullValues(): cdktn.IResolvable;
    get stripOuterArray(): cdktn.IResolvable;
    get timeFormat(): string;
    get timestampFormat(): string;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageExternalGcsDescribeOutputFileFormatJsonList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalGcsDescribeOutputFileFormatJsonOutputReference;
}
export interface StageExternalGcsDescribeOutputFileFormatOrc {
}
export declare function stageExternalGcsDescribeOutputFileFormatOrcToTerraform(struct?: StageExternalGcsDescribeOutputFileFormatOrc): any;
export declare function stageExternalGcsDescribeOutputFileFormatOrcToHclTerraform(struct?: StageExternalGcsDescribeOutputFileFormatOrc): any;
export declare class StageExternalGcsDescribeOutputFileFormatOrcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalGcsDescribeOutputFileFormatOrc | undefined;
    set internalValue(value: StageExternalGcsDescribeOutputFileFormatOrc | undefined);
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageExternalGcsDescribeOutputFileFormatOrcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalGcsDescribeOutputFileFormatOrcOutputReference;
}
export interface StageExternalGcsDescribeOutputFileFormatParquet {
}
export declare function stageExternalGcsDescribeOutputFileFormatParquetToTerraform(struct?: StageExternalGcsDescribeOutputFileFormatParquet): any;
export declare function stageExternalGcsDescribeOutputFileFormatParquetToHclTerraform(struct?: StageExternalGcsDescribeOutputFileFormatParquet): any;
export declare class StageExternalGcsDescribeOutputFileFormatParquetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalGcsDescribeOutputFileFormatParquet | undefined;
    set internalValue(value: StageExternalGcsDescribeOutputFileFormatParquet | undefined);
    get binaryAsText(): cdktn.IResolvable;
    get compression(): string;
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
    get useLogicalType(): cdktn.IResolvable;
    get useVectorizedScanner(): cdktn.IResolvable;
}
export declare class StageExternalGcsDescribeOutputFileFormatParquetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalGcsDescribeOutputFileFormatParquetOutputReference;
}
export interface StageExternalGcsDescribeOutputFileFormatXml {
}
export declare function stageExternalGcsDescribeOutputFileFormatXmlToTerraform(struct?: StageExternalGcsDescribeOutputFileFormatXml): any;
export declare function stageExternalGcsDescribeOutputFileFormatXmlToHclTerraform(struct?: StageExternalGcsDescribeOutputFileFormatXml): any;
export declare class StageExternalGcsDescribeOutputFileFormatXmlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalGcsDescribeOutputFileFormatXml | undefined;
    set internalValue(value: StageExternalGcsDescribeOutputFileFormatXml | undefined);
    get compression(): string;
    get disableAutoConvert(): cdktn.IResolvable;
    get ignoreUtf8Errors(): cdktn.IResolvable;
    get preserveSpace(): cdktn.IResolvable;
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get stripOuterElement(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageExternalGcsDescribeOutputFileFormatXmlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalGcsDescribeOutputFileFormatXmlOutputReference;
}
export interface StageExternalGcsDescribeOutputFileFormat {
}
export declare function stageExternalGcsDescribeOutputFileFormatToTerraform(struct?: StageExternalGcsDescribeOutputFileFormat): any;
export declare function stageExternalGcsDescribeOutputFileFormatToHclTerraform(struct?: StageExternalGcsDescribeOutputFileFormat): any;
export declare class StageExternalGcsDescribeOutputFileFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalGcsDescribeOutputFileFormat | undefined;
    set internalValue(value: StageExternalGcsDescribeOutputFileFormat | undefined);
    private _avro;
    get avro(): StageExternalGcsDescribeOutputFileFormatAvroList;
    private _csv;
    get csv(): StageExternalGcsDescribeOutputFileFormatCsvList;
    get formatName(): string;
    private _json;
    get json(): StageExternalGcsDescribeOutputFileFormatJsonList;
    private _orc;
    get orc(): StageExternalGcsDescribeOutputFileFormatOrcList;
    private _parquet;
    get parquet(): StageExternalGcsDescribeOutputFileFormatParquetList;
    private _xml;
    get xml(): StageExternalGcsDescribeOutputFileFormatXmlList;
}
export declare class StageExternalGcsDescribeOutputFileFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalGcsDescribeOutputFileFormatOutputReference;
}
export interface StageExternalGcsDescribeOutput {
}
export declare function stageExternalGcsDescribeOutputToTerraform(struct?: StageExternalGcsDescribeOutput): any;
export declare function stageExternalGcsDescribeOutputToHclTerraform(struct?: StageExternalGcsDescribeOutput): any;
export declare class StageExternalGcsDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalGcsDescribeOutput | undefined;
    set internalValue(value: StageExternalGcsDescribeOutput | undefined);
    private _directoryTable;
    get directoryTable(): StageExternalGcsDescribeOutputDirectoryTableList;
    private _fileFormat;
    get fileFormat(): StageExternalGcsDescribeOutputFileFormatList;
}
export declare class StageExternalGcsDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalGcsDescribeOutputOutputReference;
}
export interface StageExternalGcsShowOutput {
}
export declare function stageExternalGcsShowOutputToTerraform(struct?: StageExternalGcsShowOutput): any;
export declare function stageExternalGcsShowOutputToHclTerraform(struct?: StageExternalGcsShowOutput): any;
export declare class StageExternalGcsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalGcsShowOutput | undefined;
    set internalValue(value: StageExternalGcsShowOutput | undefined);
    get cloud(): string;
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get directoryEnabled(): cdktn.IResolvable;
    get endpoint(): string;
    get hasCredentials(): cdktn.IResolvable;
    get hasEncryptionKey(): cdktn.IResolvable;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get region(): string;
    get schemaName(): string;
    get storageIntegration(): string;
    get type(): string;
    get url(): string;
}
export declare class StageExternalGcsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalGcsShowOutputOutputReference;
}
export interface StageExternalGcsDirectory {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether Snowflake should enable triggering automatic refreshes of the directory table metadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#auto_refresh StageExternalGcs#auto_refresh}
    */
    readonly autoRefresh?: string;
    /**
    * Specifies whether to enable a directory table on the external stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#enable StageExternalGcs#enable}
    */
    readonly enable: boolean | cdktn.IResolvable;
    /**
    * Specifies the name of the notification integration used to automatically refresh the directory table metadata. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#notification_integration StageExternalGcs#notification_integration}
    */
    readonly notificationIntegration?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether to automatically refresh the directory table metadata once, immediately after the stage is created.This field is used only when creating the object. Changes on this field are ignored after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#refresh_on_create StageExternalGcs#refresh_on_create}
    */
    readonly refreshOnCreate?: string;
}
export declare function stageExternalGcsDirectoryToTerraform(struct?: StageExternalGcsDirectoryOutputReference | StageExternalGcsDirectory): any;
export declare function stageExternalGcsDirectoryToHclTerraform(struct?: StageExternalGcsDirectoryOutputReference | StageExternalGcsDirectory): any;
export declare class StageExternalGcsDirectoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalGcsDirectory | undefined;
    set internalValue(value: StageExternalGcsDirectory | undefined);
    private _autoRefresh?;
    get autoRefresh(): string;
    set autoRefresh(value: string);
    resetAutoRefresh(): void;
    get autoRefreshInput(): string | undefined;
    private _enable?;
    get enable(): boolean | cdktn.IResolvable;
    set enable(value: boolean | cdktn.IResolvable);
    get enableInput(): boolean | cdktn.IResolvable | undefined;
    private _notificationIntegration?;
    get notificationIntegration(): string;
    set notificationIntegration(value: string);
    resetNotificationIntegration(): void;
    get notificationIntegrationInput(): string | undefined;
    private _refreshOnCreate?;
    get refreshOnCreate(): string;
    set refreshOnCreate(value: string);
    resetRefreshOnCreate(): void;
    get refreshOnCreateInput(): string | undefined;
}
export interface StageExternalGcsEncryptionGcsSseKms {
    /**
    * Specifies the KMS-managed key ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#kms_key_id StageExternalGcs#kms_key_id}
    */
    readonly kmsKeyId?: string;
}
export declare function stageExternalGcsEncryptionGcsSseKmsToTerraform(struct?: StageExternalGcsEncryptionGcsSseKmsOutputReference | StageExternalGcsEncryptionGcsSseKms): any;
export declare function stageExternalGcsEncryptionGcsSseKmsToHclTerraform(struct?: StageExternalGcsEncryptionGcsSseKmsOutputReference | StageExternalGcsEncryptionGcsSseKms): any;
export declare class StageExternalGcsEncryptionGcsSseKmsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalGcsEncryptionGcsSseKms | undefined;
    set internalValue(value: StageExternalGcsEncryptionGcsSseKms | undefined);
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
}
export interface StageExternalGcsEncryptionNone {
}
export declare function stageExternalGcsEncryptionNoneToTerraform(struct?: StageExternalGcsEncryptionNoneOutputReference | StageExternalGcsEncryptionNone): any;
export declare function stageExternalGcsEncryptionNoneToHclTerraform(struct?: StageExternalGcsEncryptionNoneOutputReference | StageExternalGcsEncryptionNone): any;
export declare class StageExternalGcsEncryptionNoneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalGcsEncryptionNone | undefined;
    set internalValue(value: StageExternalGcsEncryptionNone | undefined);
}
export interface StageExternalGcsEncryption {
    /**
    * gcs_sse_kms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#gcs_sse_kms StageExternalGcs#gcs_sse_kms}
    */
    readonly gcsSseKms?: StageExternalGcsEncryptionGcsSseKms;
    /**
    * none block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#none StageExternalGcs#none}
    */
    readonly none?: StageExternalGcsEncryptionNone;
}
export declare function stageExternalGcsEncryptionToTerraform(struct?: StageExternalGcsEncryptionOutputReference | StageExternalGcsEncryption): any;
export declare function stageExternalGcsEncryptionToHclTerraform(struct?: StageExternalGcsEncryptionOutputReference | StageExternalGcsEncryption): any;
export declare class StageExternalGcsEncryptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalGcsEncryption | undefined;
    set internalValue(value: StageExternalGcsEncryption | undefined);
    private _gcsSseKms;
    get gcsSseKms(): StageExternalGcsEncryptionGcsSseKmsOutputReference;
    putGcsSseKms(value: StageExternalGcsEncryptionGcsSseKms): void;
    resetGcsSseKms(): void;
    get gcsSseKmsInput(): StageExternalGcsEncryptionGcsSseKms | undefined;
    private _none;
    get none(): StageExternalGcsEncryptionNoneOutputReference;
    putNone(value: StageExternalGcsEncryptionNone): void;
    resetNone(): void;
    get noneInput(): StageExternalGcsEncryptionNone | undefined;
}
export interface StageExternalGcsFileFormatAvro {
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
    */
    readonly compression?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageExternalGcsFileFormatAvroToTerraform(struct?: StageExternalGcsFileFormatAvroOutputReference | StageExternalGcsFileFormatAvro): any;
export declare function stageExternalGcsFileFormatAvroToHclTerraform(struct?: StageExternalGcsFileFormatAvroOutputReference | StageExternalGcsFileFormatAvro): any;
export declare class StageExternalGcsFileFormatAvroOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalGcsFileFormatAvro | undefined;
    set internalValue(value: StageExternalGcsFileFormatAvro | undefined);
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageExternalGcsFileFormatCsv {
    /**
    * Defines the encoding format for binary input or output. Valid values: `HEX` | `BASE64` | `UTF8`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#binary_format StageExternalGcs#binary_format}
    */
    readonly binaryFormat?: string;
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BZ2` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
    */
    readonly compression?: string;
    /**
    * Defines the format of date values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#date_format StageExternalGcs#date_format}
    */
    readonly dateFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to insert SQL NULL for empty fields in an input file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#empty_field_as_null StageExternalGcs#empty_field_as_null}
    */
    readonly emptyFieldAsNull?: string;
    /**
    * Specifies the character set of the source data when loading data into a table. Valid values: `BIG5` | `EUCJP` | `EUCKR` | `GB18030` | `IBM420` | `IBM424` | `ISO2022CN` | `ISO2022JP` | `ISO2022KR` | `ISO88591` | `ISO88592` | `ISO88595` | `ISO88596` | `ISO88597` | `ISO88598` | `ISO88599` | `ISO885915` | `KOI8R` | `SHIFTJIS` | `UTF8` | `UTF16` | `UTF16BE` | `UTF16LE` | `UTF32` | `UTF32BE` | `UTF32LE` | `WINDOWS1250` | `WINDOWS1251` | `WINDOWS1252` | `WINDOWS1253` | `WINDOWS1254` | `WINDOWS1255` | `WINDOWS1256`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#encoding StageExternalGcs#encoding}
    */
    readonly encoding?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to generate a parsing error if the number of delimited columns in an input file does not match the number of columns in the corresponding table. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#error_on_column_count_mismatch StageExternalGcs#error_on_column_count_mismatch}
    */
    readonly errorOnColumnCountMismatch?: string;
    /**
    * Single character string used as the escape character for field values. Use `NONE` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#escape StageExternalGcs#escape}
    */
    readonly escape?: string;
    /**
    * Single character string used as the escape character for unenclosed field values only. Use `NONE` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#escape_unenclosed_field StageExternalGcs#escape_unenclosed_field}
    */
    readonly escapeUnenclosedField?: string;
    /**
    * One or more singlebyte or multibyte characters that separate fields in an input file. Use `NONE` to specify no delimiter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#field_delimiter StageExternalGcs#field_delimiter}
    */
    readonly fieldDelimiter?: string;
    /**
    * Character used to enclose strings. Use `NONE` to specify no enclosure character.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#field_optionally_enclosed_by StageExternalGcs#field_optionally_enclosed_by}
    */
    readonly fieldOptionallyEnclosedBy?: string;
    /**
    * Specifies the extension for files unloaded to a stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#file_extension StageExternalGcs#file_extension}
    */
    readonly fileExtension?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to parse CSV files containing multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#multi_line StageExternalGcs#multi_line}
    */
    readonly multiLine?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to use the first row headers in the data files to determine column names. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#parse_header StageExternalGcs#parse_header}
    */
    readonly parseHeader?: string;
    /**
    * One or more singlebyte or multibyte characters that separate records in an input file. Use `NONE` to specify no delimiter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#record_delimiter StageExternalGcs#record_delimiter}
    */
    readonly recordDelimiter?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies to skip any blank lines encountered in the data files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#skip_blank_lines StageExternalGcs#skip_blank_lines}
    */
    readonly skipBlankLines?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#skip_byte_order_mark StageExternalGcs#skip_byte_order_mark}
    */
    readonly skipByteOrderMark?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`-1`)) Number of lines at the start of the file to skip.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#skip_header StageExternalGcs#skip_header}
    */
    readonly skipHeader?: number;
    /**
    * Defines the format of time values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#time_format StageExternalGcs#time_format}
    */
    readonly timeFormat?: string;
    /**
    * Defines the format of timestamp values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#timestamp_format StageExternalGcs#timestamp_format}
    */
    readonly timestampFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageExternalGcsFileFormatCsvToTerraform(struct?: StageExternalGcsFileFormatCsvOutputReference | StageExternalGcsFileFormatCsv): any;
export declare function stageExternalGcsFileFormatCsvToHclTerraform(struct?: StageExternalGcsFileFormatCsvOutputReference | StageExternalGcsFileFormatCsv): any;
export declare class StageExternalGcsFileFormatCsvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalGcsFileFormatCsv | undefined;
    set internalValue(value: StageExternalGcsFileFormatCsv | undefined);
    private _binaryFormat?;
    get binaryFormat(): string;
    set binaryFormat(value: string);
    resetBinaryFormat(): void;
    get binaryFormatInput(): string | undefined;
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _dateFormat?;
    get dateFormat(): string;
    set dateFormat(value: string);
    resetDateFormat(): void;
    get dateFormatInput(): string | undefined;
    private _emptyFieldAsNull?;
    get emptyFieldAsNull(): string;
    set emptyFieldAsNull(value: string);
    resetEmptyFieldAsNull(): void;
    get emptyFieldAsNullInput(): string | undefined;
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    resetEncoding(): void;
    get encodingInput(): string | undefined;
    private _errorOnColumnCountMismatch?;
    get errorOnColumnCountMismatch(): string;
    set errorOnColumnCountMismatch(value: string);
    resetErrorOnColumnCountMismatch(): void;
    get errorOnColumnCountMismatchInput(): string | undefined;
    private _escape?;
    get escape(): string;
    set escape(value: string);
    resetEscape(): void;
    get escapeInput(): string | undefined;
    private _escapeUnenclosedField?;
    get escapeUnenclosedField(): string;
    set escapeUnenclosedField(value: string);
    resetEscapeUnenclosedField(): void;
    get escapeUnenclosedFieldInput(): string | undefined;
    private _fieldDelimiter?;
    get fieldDelimiter(): string;
    set fieldDelimiter(value: string);
    resetFieldDelimiter(): void;
    get fieldDelimiterInput(): string | undefined;
    private _fieldOptionallyEnclosedBy?;
    get fieldOptionallyEnclosedBy(): string;
    set fieldOptionallyEnclosedBy(value: string);
    resetFieldOptionallyEnclosedBy(): void;
    get fieldOptionallyEnclosedByInput(): string | undefined;
    private _fileExtension?;
    get fileExtension(): string;
    set fileExtension(value: string);
    resetFileExtension(): void;
    get fileExtensionInput(): string | undefined;
    private _multiLine?;
    get multiLine(): string;
    set multiLine(value: string);
    resetMultiLine(): void;
    get multiLineInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _parseHeader?;
    get parseHeader(): string;
    set parseHeader(value: string);
    resetParseHeader(): void;
    get parseHeaderInput(): string | undefined;
    private _recordDelimiter?;
    get recordDelimiter(): string;
    set recordDelimiter(value: string);
    resetRecordDelimiter(): void;
    get recordDelimiterInput(): string | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _skipBlankLines?;
    get skipBlankLines(): string;
    set skipBlankLines(value: string);
    resetSkipBlankLines(): void;
    get skipBlankLinesInput(): string | undefined;
    private _skipByteOrderMark?;
    get skipByteOrderMark(): string;
    set skipByteOrderMark(value: string);
    resetSkipByteOrderMark(): void;
    get skipByteOrderMarkInput(): string | undefined;
    private _skipHeader?;
    get skipHeader(): number;
    set skipHeader(value: number);
    resetSkipHeader(): void;
    get skipHeaderInput(): number | undefined;
    private _timeFormat?;
    get timeFormat(): string;
    set timeFormat(value: string);
    resetTimeFormat(): void;
    get timeFormatInput(): string | undefined;
    private _timestampFormat?;
    get timestampFormat(): string;
    set timestampFormat(value: string);
    resetTimestampFormat(): void;
    get timestampFormatInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageExternalGcsFileFormatJson {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to allow duplicate object field names (only the last one will be preserved). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#allow_duplicate StageExternalGcs#allow_duplicate}
    */
    readonly allowDuplicate?: string;
    /**
    * Defines the encoding format for binary input or output. Valid values: `HEX` | `BASE64` | `UTF8`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#binary_format StageExternalGcs#binary_format}
    */
    readonly binaryFormat?: string;
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BZ2` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
    */
    readonly compression?: string;
    /**
    * Defines the format of date values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#date_format StageExternalGcs#date_format}
    */
    readonly dateFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that enables parsing of octal numbers. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#enable_octal StageExternalGcs#enable_octal}
    */
    readonly enableOctal?: string;
    /**
    * Specifies the extension for files unloaded to a stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#file_extension StageExternalGcs#file_extension}
    */
    readonly fileExtension?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#ignore_utf8_errors StageExternalGcs#ignore_utf8_errors}
    */
    readonly ignoreUtf8Errors?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to allow multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#multi_line StageExternalGcs#multi_line}
    */
    readonly multiLine?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#skip_byte_order_mark StageExternalGcs#skip_byte_order_mark}
    */
    readonly skipByteOrderMark?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that instructs the JSON parser to remove object fields or array elements containing null values. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#strip_null_values StageExternalGcs#strip_null_values}
    */
    readonly stripNullValues?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that instructs the JSON parser to remove outer brackets. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#strip_outer_array StageExternalGcs#strip_outer_array}
    */
    readonly stripOuterArray?: string;
    /**
    * Defines the format of time values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#time_format StageExternalGcs#time_format}
    */
    readonly timeFormat?: string;
    /**
    * Defines the format of timestamp values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#timestamp_format StageExternalGcs#timestamp_format}
    */
    readonly timestampFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageExternalGcsFileFormatJsonToTerraform(struct?: StageExternalGcsFileFormatJsonOutputReference | StageExternalGcsFileFormatJson): any;
export declare function stageExternalGcsFileFormatJsonToHclTerraform(struct?: StageExternalGcsFileFormatJsonOutputReference | StageExternalGcsFileFormatJson): any;
export declare class StageExternalGcsFileFormatJsonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalGcsFileFormatJson | undefined;
    set internalValue(value: StageExternalGcsFileFormatJson | undefined);
    private _allowDuplicate?;
    get allowDuplicate(): string;
    set allowDuplicate(value: string);
    resetAllowDuplicate(): void;
    get allowDuplicateInput(): string | undefined;
    private _binaryFormat?;
    get binaryFormat(): string;
    set binaryFormat(value: string);
    resetBinaryFormat(): void;
    get binaryFormatInput(): string | undefined;
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _dateFormat?;
    get dateFormat(): string;
    set dateFormat(value: string);
    resetDateFormat(): void;
    get dateFormatInput(): string | undefined;
    private _enableOctal?;
    get enableOctal(): string;
    set enableOctal(value: string);
    resetEnableOctal(): void;
    get enableOctalInput(): string | undefined;
    private _fileExtension?;
    get fileExtension(): string;
    set fileExtension(value: string);
    resetFileExtension(): void;
    get fileExtensionInput(): string | undefined;
    private _ignoreUtf8Errors?;
    get ignoreUtf8Errors(): string;
    set ignoreUtf8Errors(value: string);
    resetIgnoreUtf8Errors(): void;
    get ignoreUtf8ErrorsInput(): string | undefined;
    private _multiLine?;
    get multiLine(): string;
    set multiLine(value: string);
    resetMultiLine(): void;
    get multiLineInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _skipByteOrderMark?;
    get skipByteOrderMark(): string;
    set skipByteOrderMark(value: string);
    resetSkipByteOrderMark(): void;
    get skipByteOrderMarkInput(): string | undefined;
    private _stripNullValues?;
    get stripNullValues(): string;
    set stripNullValues(value: string);
    resetStripNullValues(): void;
    get stripNullValuesInput(): string | undefined;
    private _stripOuterArray?;
    get stripOuterArray(): string;
    set stripOuterArray(value: string);
    resetStripOuterArray(): void;
    get stripOuterArrayInput(): string | undefined;
    private _timeFormat?;
    get timeFormat(): string;
    set timeFormat(value: string);
    resetTimeFormat(): void;
    get timeFormatInput(): string | undefined;
    private _timestampFormat?;
    get timestampFormat(): string;
    set timestampFormat(value: string);
    resetTimestampFormat(): void;
    get timestampFormatInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageExternalGcsFileFormatOrc {
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageExternalGcsFileFormatOrcToTerraform(struct?: StageExternalGcsFileFormatOrcOutputReference | StageExternalGcsFileFormatOrc): any;
export declare function stageExternalGcsFileFormatOrcToHclTerraform(struct?: StageExternalGcsFileFormatOrcOutputReference | StageExternalGcsFileFormatOrc): any;
export declare class StageExternalGcsFileFormatOrcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalGcsFileFormatOrc | undefined;
    set internalValue(value: StageExternalGcsFileFormatOrc | undefined);
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageExternalGcsFileFormatParquet {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to interpret columns with no defined logical data type as UTF-8 text. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#binary_as_text StageExternalGcs#binary_as_text}
    */
    readonly binaryAsText?: string;
    /**
    * Specifies the compression format. Valid values: `AUTO` | `LZO` | `SNAPPY` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
    */
    readonly compression?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#null_if StageExternalGcs#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#trim_space StageExternalGcs#trim_space}
    */
    readonly trimSpace?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to use Parquet logical types when loading data. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#use_logical_type StageExternalGcs#use_logical_type}
    */
    readonly useLogicalType?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to use a vectorized scanner for loading Parquet files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#use_vectorized_scanner StageExternalGcs#use_vectorized_scanner}
    */
    readonly useVectorizedScanner?: string;
}
export declare function stageExternalGcsFileFormatParquetToTerraform(struct?: StageExternalGcsFileFormatParquetOutputReference | StageExternalGcsFileFormatParquet): any;
export declare function stageExternalGcsFileFormatParquetToHclTerraform(struct?: StageExternalGcsFileFormatParquetOutputReference | StageExternalGcsFileFormatParquet): any;
export declare class StageExternalGcsFileFormatParquetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalGcsFileFormatParquet | undefined;
    set internalValue(value: StageExternalGcsFileFormatParquet | undefined);
    private _binaryAsText?;
    get binaryAsText(): string;
    set binaryAsText(value: string);
    resetBinaryAsText(): void;
    get binaryAsTextInput(): string | undefined;
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
    private _useLogicalType?;
    get useLogicalType(): string;
    set useLogicalType(value: string);
    resetUseLogicalType(): void;
    get useLogicalTypeInput(): string | undefined;
    private _useVectorizedScanner?;
    get useVectorizedScanner(): string;
    set useVectorizedScanner(value: string);
    resetUseVectorizedScanner(): void;
    get useVectorizedScannerInput(): string | undefined;
}
export interface StageExternalGcsFileFormatXml {
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BZ2` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#compression StageExternalGcs#compression}
    */
    readonly compression?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether the XML parser disables automatic conversion of numeric and Boolean values from text to native representation. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#disable_auto_convert StageExternalGcs#disable_auto_convert}
    */
    readonly disableAutoConvert?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#ignore_utf8_errors StageExternalGcs#ignore_utf8_errors}
    */
    readonly ignoreUtf8Errors?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether the XML parser preserves leading and trailing spaces in element content. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#preserve_space StageExternalGcs#preserve_space}
    */
    readonly preserveSpace?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#replace_invalid_characters StageExternalGcs#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#skip_byte_order_mark StageExternalGcs#skip_byte_order_mark}
    */
    readonly skipByteOrderMark?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether the XML parser strips out the outer XML element, exposing 2nd level elements as separate documents. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#strip_outer_element StageExternalGcs#strip_outer_element}
    */
    readonly stripOuterElement?: string;
}
export declare function stageExternalGcsFileFormatXmlToTerraform(struct?: StageExternalGcsFileFormatXmlOutputReference | StageExternalGcsFileFormatXml): any;
export declare function stageExternalGcsFileFormatXmlToHclTerraform(struct?: StageExternalGcsFileFormatXmlOutputReference | StageExternalGcsFileFormatXml): any;
export declare class StageExternalGcsFileFormatXmlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalGcsFileFormatXml | undefined;
    set internalValue(value: StageExternalGcsFileFormatXml | undefined);
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _disableAutoConvert?;
    get disableAutoConvert(): string;
    set disableAutoConvert(value: string);
    resetDisableAutoConvert(): void;
    get disableAutoConvertInput(): string | undefined;
    private _ignoreUtf8Errors?;
    get ignoreUtf8Errors(): string;
    set ignoreUtf8Errors(value: string);
    resetIgnoreUtf8Errors(): void;
    get ignoreUtf8ErrorsInput(): string | undefined;
    private _preserveSpace?;
    get preserveSpace(): string;
    set preserveSpace(value: string);
    resetPreserveSpace(): void;
    get preserveSpaceInput(): string | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _skipByteOrderMark?;
    get skipByteOrderMark(): string;
    set skipByteOrderMark(value: string);
    resetSkipByteOrderMark(): void;
    get skipByteOrderMarkInput(): string | undefined;
    private _stripOuterElement?;
    get stripOuterElement(): string;
    set stripOuterElement(value: string);
    resetStripOuterElement(): void;
    get stripOuterElementInput(): string | undefined;
}
export interface StageExternalGcsFileFormat {
    /**
    * Fully qualified name of the file format (e.g., 'database.schema.format_name').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#format_name StageExternalGcs#format_name}
    */
    readonly formatName?: string;
    /**
    * avro block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#avro StageExternalGcs#avro}
    */
    readonly avro?: StageExternalGcsFileFormatAvro;
    /**
    * csv block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#csv StageExternalGcs#csv}
    */
    readonly csv?: StageExternalGcsFileFormatCsv;
    /**
    * json block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#json StageExternalGcs#json}
    */
    readonly json?: StageExternalGcsFileFormatJson;
    /**
    * orc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#orc StageExternalGcs#orc}
    */
    readonly orc?: StageExternalGcsFileFormatOrc;
    /**
    * parquet block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#parquet StageExternalGcs#parquet}
    */
    readonly parquet?: StageExternalGcsFileFormatParquet;
    /**
    * xml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#xml StageExternalGcs#xml}
    */
    readonly xml?: StageExternalGcsFileFormatXml;
}
export declare function stageExternalGcsFileFormatToTerraform(struct?: StageExternalGcsFileFormatOutputReference | StageExternalGcsFileFormat): any;
export declare function stageExternalGcsFileFormatToHclTerraform(struct?: StageExternalGcsFileFormatOutputReference | StageExternalGcsFileFormat): any;
export declare class StageExternalGcsFileFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalGcsFileFormat | undefined;
    set internalValue(value: StageExternalGcsFileFormat | undefined);
    private _formatName?;
    get formatName(): string;
    set formatName(value: string);
    resetFormatName(): void;
    get formatNameInput(): string | undefined;
    private _avro;
    get avro(): StageExternalGcsFileFormatAvroOutputReference;
    putAvro(value: StageExternalGcsFileFormatAvro): void;
    resetAvro(): void;
    get avroInput(): StageExternalGcsFileFormatAvro | undefined;
    private _csv;
    get csv(): StageExternalGcsFileFormatCsvOutputReference;
    putCsv(value: StageExternalGcsFileFormatCsv): void;
    resetCsv(): void;
    get csvInput(): StageExternalGcsFileFormatCsv | undefined;
    private _json;
    get json(): StageExternalGcsFileFormatJsonOutputReference;
    putJson(value: StageExternalGcsFileFormatJson): void;
    resetJson(): void;
    get jsonInput(): StageExternalGcsFileFormatJson | undefined;
    private _orc;
    get orc(): StageExternalGcsFileFormatOrcOutputReference;
    putOrc(value: StageExternalGcsFileFormatOrc): void;
    resetOrc(): void;
    get orcInput(): StageExternalGcsFileFormatOrc | undefined;
    private _parquet;
    get parquet(): StageExternalGcsFileFormatParquetOutputReference;
    putParquet(value: StageExternalGcsFileFormatParquet): void;
    resetParquet(): void;
    get parquetInput(): StageExternalGcsFileFormatParquet | undefined;
    private _xml;
    get xml(): StageExternalGcsFileFormatXmlOutputReference;
    putXml(value: StageExternalGcsFileFormatXml): void;
    resetXml(): void;
    get xmlInput(): StageExternalGcsFileFormatXml | undefined;
}
export interface StageExternalGcsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#create StageExternalGcs#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#delete StageExternalGcs#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#read StageExternalGcs#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#update StageExternalGcs#update}
    */
    readonly update?: string;
}
export declare function stageExternalGcsTimeoutsToTerraform(struct?: StageExternalGcsTimeouts | cdktn.IResolvable): any;
export declare function stageExternalGcsTimeoutsToHclTerraform(struct?: StageExternalGcsTimeouts | cdktn.IResolvable): any;
export declare class StageExternalGcsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalGcsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: StageExternalGcsTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs snowflake_stage_external_gcs}
*/
export declare class StageExternalGcs extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_stage_external_gcs";
    /**
    * Generates CDKTN code for importing a StageExternalGcs resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StageExternalGcs to import
    * @param importFromId The id of the existing StageExternalGcs that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StageExternalGcs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/stage_external_gcs snowflake_stage_external_gcs} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StageExternalGcsConfig
    */
    constructor(scope: Construct, id: string, config: StageExternalGcsConfig);
    get cloud(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): StageExternalGcsDescribeOutputList;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): StageExternalGcsShowOutputList;
    get stageType(): string;
    private _storageIntegration?;
    get storageIntegration(): string;
    set storageIntegration(value: string);
    get storageIntegrationInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _directory;
    get directory(): StageExternalGcsDirectoryOutputReference;
    putDirectory(value: StageExternalGcsDirectory): void;
    resetDirectory(): void;
    get directoryInput(): StageExternalGcsDirectory | undefined;
    private _encryption;
    get encryption(): StageExternalGcsEncryptionOutputReference;
    putEncryption(value: StageExternalGcsEncryption): void;
    resetEncryption(): void;
    get encryptionInput(): StageExternalGcsEncryption | undefined;
    private _fileFormat;
    get fileFormat(): StageExternalGcsFileFormatOutputReference;
    putFileFormat(value: StageExternalGcsFileFormat): void;
    resetFileFormat(): void;
    get fileFormatInput(): StageExternalGcsFileFormat | undefined;
    private _timeouts;
    get timeouts(): StageExternalGcsTimeoutsOutputReference;
    putTimeouts(value: StageExternalGcsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | StageExternalGcsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
