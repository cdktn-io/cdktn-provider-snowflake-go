/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CortexAgentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the Cortex agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#comment CortexAgent#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the Cortex agent. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#database CortexAgent#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#id CortexAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the Cortex agent. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#name CortexAgent#name}
    */
    readonly name: string;
    /**
    * The schema in which to create the Cortex agent. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#schema CortexAgent#schema}
    */
    readonly schema: string;
    /**
    * Specifies a YAML object containing the settings for the Cortex agent. The provider wraps it in `$$` by default, so be aware of that while referencing the argument in the spec definition. Using `$$` in this field is disallowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#specification CortexAgent#specification}
    */
    readonly specification: string;
    /**
    * profile block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#profile CortexAgent#profile}
    */
    readonly profile?: CortexAgentProfile;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#timeouts CortexAgent#timeouts}
    */
    readonly timeouts?: CortexAgentTimeouts;
}
export interface CortexAgentDescribeOutputProfile {
}
export declare function cortexAgentDescribeOutputProfileToTerraform(struct?: CortexAgentDescribeOutputProfile): any;
export declare function cortexAgentDescribeOutputProfileToHclTerraform(struct?: CortexAgentDescribeOutputProfile): any;
export declare class CortexAgentDescribeOutputProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CortexAgentDescribeOutputProfile | undefined;
    set internalValue(value: CortexAgentDescribeOutputProfile | undefined);
    get avatar(): string;
    get color(): string;
    get displayName(): string;
}
export declare class CortexAgentDescribeOutputProfileList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CortexAgentDescribeOutputProfileOutputReference;
}
export interface CortexAgentDescribeOutput {
}
export declare function cortexAgentDescribeOutputToTerraform(struct?: CortexAgentDescribeOutput): any;
export declare function cortexAgentDescribeOutputToHclTerraform(struct?: CortexAgentDescribeOutput): any;
export declare class CortexAgentDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CortexAgentDescribeOutput | undefined;
    set internalValue(value: CortexAgentDescribeOutput | undefined);
    get agentSpec(): string;
    get aliases(): string;
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get defaultVersionName(): string;
    get name(): string;
    get owner(): string;
    private _profile;
    get profile(): CortexAgentDescribeOutputProfileList;
    get schemaName(): string;
    get versions(): string;
}
export declare class CortexAgentDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CortexAgentDescribeOutputOutputReference;
}
export interface CortexAgentShowOutputProfile {
}
export declare function cortexAgentShowOutputProfileToTerraform(struct?: CortexAgentShowOutputProfile): any;
export declare function cortexAgentShowOutputProfileToHclTerraform(struct?: CortexAgentShowOutputProfile): any;
export declare class CortexAgentShowOutputProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CortexAgentShowOutputProfile | undefined;
    set internalValue(value: CortexAgentShowOutputProfile | undefined);
    get avatar(): string;
    get color(): string;
    get displayName(): string;
}
export declare class CortexAgentShowOutputProfileList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CortexAgentShowOutputProfileOutputReference;
}
export interface CortexAgentShowOutput {
}
export declare function cortexAgentShowOutputToTerraform(struct?: CortexAgentShowOutput): any;
export declare function cortexAgentShowOutputToHclTerraform(struct?: CortexAgentShowOutput): any;
export declare class CortexAgentShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CortexAgentShowOutput | undefined;
    set internalValue(value: CortexAgentShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get name(): string;
    get owner(): string;
    private _profile;
    get profile(): CortexAgentShowOutputProfileList;
    get schemaName(): string;
}
export declare class CortexAgentShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CortexAgentShowOutputOutputReference;
}
export interface CortexAgentProfile {
    /**
    * Specifies an avatar image file name or identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#avatar CortexAgent#avatar}
    */
    readonly avatar?: string;
    /**
    * Specifies a color theme for the Cortex agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#color CortexAgent#color}
    */
    readonly color?: string;
    /**
    * Specifies a display name for the Cortex agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#display_name CortexAgent#display_name}
    */
    readonly displayName?: string;
}
export declare function cortexAgentProfileToTerraform(struct?: CortexAgentProfileOutputReference | CortexAgentProfile): any;
export declare function cortexAgentProfileToHclTerraform(struct?: CortexAgentProfileOutputReference | CortexAgentProfile): any;
export declare class CortexAgentProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CortexAgentProfile | undefined;
    set internalValue(value: CortexAgentProfile | undefined);
    private _avatar?;
    get avatar(): string;
    set avatar(value: string);
    resetAvatar(): void;
    get avatarInput(): string | undefined;
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
}
export interface CortexAgentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#create CortexAgent#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#delete CortexAgent#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#read CortexAgent#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#update CortexAgent#update}
    */
    readonly update?: string;
}
export declare function cortexAgentTimeoutsToTerraform(struct?: CortexAgentTimeouts | cdktn.IResolvable): any;
export declare function cortexAgentTimeoutsToHclTerraform(struct?: CortexAgentTimeouts | cdktn.IResolvable): any;
export declare class CortexAgentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CortexAgentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CortexAgentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent snowflake_cortex_agent}
*/
export declare class CortexAgent extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_cortex_agent";
    /**
    * Generates CDKTN code for importing a CortexAgent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CortexAgent to import
    * @param importFromId The id of the existing CortexAgent that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CortexAgent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/cortex_agent snowflake_cortex_agent} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CortexAgentConfig
    */
    constructor(scope: Construct, id: string, config: CortexAgentConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): CortexAgentDescribeOutputList;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): CortexAgentShowOutputList;
    private _specification?;
    get specification(): string;
    set specification(value: string);
    get specificationInput(): string | undefined;
    private _profile;
    get profile(): CortexAgentProfileOutputReference;
    putProfile(value: CortexAgentProfile): void;
    resetProfile(): void;
    get profileInput(): CortexAgentProfile | undefined;
    private _timeouts;
    get timeouts(): CortexAgentTimeoutsOutputReference;
    putTimeouts(value: CortexAgentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CortexAgentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
