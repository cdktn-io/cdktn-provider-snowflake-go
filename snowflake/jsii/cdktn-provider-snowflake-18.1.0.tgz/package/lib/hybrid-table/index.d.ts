/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface HybridTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the hybrid table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#comment HybridTable#comment}
    */
    readonly comment?: string;
    /**
    * Specifies the retention period for the hybrid table so that Time Travel actions can be performed on historical data. For more information, check [DATA_RETENTION_TIME_IN_DAYS docs](https://docs.snowflake.com/en/sql-reference/parameters#data-retention-time-in-days).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#data_retention_time_in_days HybridTable#data_retention_time_in_days}
    */
    readonly dataRetentionTimeInDays?: number;
    /**
    * The database in which to create the hybrid table. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#database HybridTable#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#id HybridTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Object parameter that specifies the maximum number of days for which Snowflake can extend the data retention period for the hybrid table to prevent streams on it from becoming stale. For more information, check [MAX_DATA_EXTENSION_TIME_IN_DAYS docs](https://docs.snowflake.com/en/sql-reference/parameters#max-data-extension-time-in-days).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#max_data_extension_time_in_days HybridTable#max_data_extension_time_in_days}
    */
    readonly maxDataExtensionTimeInDays?: number;
    /**
    * Specifies the identifier for the hybrid table. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#name HybridTable#name}
    */
    readonly name: string;
    /**
    * The schema in which to create the hybrid table. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#schema HybridTable#schema}
    */
    readonly schema: string;
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#column HybridTable#column}
    */
    readonly column: HybridTableColumn[] | cdktn.IResolvable;
    /**
    * foreign_key_constraint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#foreign_key_constraint HybridTable#foreign_key_constraint}
    */
    readonly foreignKeyConstraint?: HybridTableForeignKeyConstraint[] | cdktn.IResolvable;
    /**
    * index block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#index HybridTable#index}
    */
    readonly index?: HybridTableIndex[] | cdktn.IResolvable;
    /**
    * primary_key_constraint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#primary_key_constraint HybridTable#primary_key_constraint}
    */
    readonly primaryKeyConstraint: HybridTablePrimaryKeyConstraint;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#timeouts HybridTable#timeouts}
    */
    readonly timeouts?: HybridTableTimeouts;
    /**
    * unique_constraint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#unique_constraint HybridTable#unique_constraint}
    */
    readonly uniqueConstraint?: HybridTableUniqueConstraint[] | cdktn.IResolvable;
}
export interface HybridTableDescribeOutput {
}
export declare function hybridTableDescribeOutputToTerraform(struct?: HybridTableDescribeOutput): any;
export declare function hybridTableDescribeOutputToHclTerraform(struct?: HybridTableDescribeOutput): any;
export declare class HybridTableDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HybridTableDescribeOutput | undefined;
    set internalValue(value: HybridTableDescribeOutput | undefined);
    get check(): string;
    get collation(): string;
    get comment(): string;
    get default(): string;
    get expression(): string;
    get isNullable(): cdktn.IResolvable;
    get kind(): string;
    get name(): string;
    get policyName(): string;
    get primaryKey(): cdktn.IResolvable;
    get privacyDomain(): string;
    get schemaEvolutionRecord(): string;
    get type(): string;
    get uniqueKey(): cdktn.IResolvable;
}
export declare class HybridTableDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HybridTableDescribeOutputOutputReference;
}
export interface HybridTableShowKeysOutput {
}
export declare function hybridTableShowKeysOutputToTerraform(struct?: HybridTableShowKeysOutput): any;
export declare function hybridTableShowKeysOutputToHclTerraform(struct?: HybridTableShowKeysOutput): any;
export declare class HybridTableShowKeysOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HybridTableShowKeysOutput | undefined;
    set internalValue(value: HybridTableShowKeysOutput | undefined);
    get columns(): string[];
    get deleteRule(): string;
    get kind(): string;
    get name(): string;
    get referencedColumns(): string[];
    get referencedTable(): string;
    get updateRule(): string;
}
export declare class HybridTableShowKeysOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HybridTableShowKeysOutputOutputReference;
}
export interface HybridTableShowOutput {
}
export declare function hybridTableShowOutputToTerraform(struct?: HybridTableShowOutput): any;
export declare function hybridTableShowOutputToHclTerraform(struct?: HybridTableShowOutput): any;
export declare class HybridTableShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HybridTableShowOutput | undefined;
    set internalValue(value: HybridTableShowOutput | undefined);
    get bytes(): number;
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get rows(): number;
    get schemaName(): string;
}
export declare class HybridTableShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HybridTableShowOutputOutputReference;
}
export interface HybridTableColumnDefault {
    /**
    * A constant default value for the column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#constant HybridTable#constant}
    */
    readonly constant?: string;
    /**
    * A SQL expression default value for the column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#expression HybridTable#expression}
    */
    readonly expression?: string;
    /**
    * The default sequence for the column (uses NEXTVAL).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#sequence HybridTable#sequence}
    */
    readonly sequence?: string;
}
export declare function hybridTableColumnDefaultToTerraform(struct?: HybridTableColumnDefaultOutputReference | HybridTableColumnDefault): any;
export declare function hybridTableColumnDefaultToHclTerraform(struct?: HybridTableColumnDefaultOutputReference | HybridTableColumnDefault): any;
export declare class HybridTableColumnDefaultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HybridTableColumnDefault | undefined;
    set internalValue(value: HybridTableColumnDefault | undefined);
    private _constant?;
    get constant(): string;
    set constant(value: string);
    resetConstant(): void;
    get constantInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _sequence?;
    get sequence(): string;
    set sequence(value: string);
    resetSequence(): void;
    get sequenceInput(): string | undefined;
}
export interface HybridTableColumn {
    /**
    * Column collation specification, e.g. en-ci. Case-insensitive (en-ci and EN-CI are treated as equal).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#collate HybridTable#collate}
    */
    readonly collate?: string;
    /**
    * Column-level comment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#comment HybridTable#comment}
    */
    readonly comment?: string;
    /**
    * Column name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#name HybridTable#name}
    */
    readonly name: string;
    /**
    * Whether to restrict the column to NOT NULL values. Changing this on an existing column forces recreation. Primary key columns must set this to true because NOT NULL is implied by the primary key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#not_null HybridTable#not_null}
    */
    readonly notNull?: boolean | cdktn.IResolvable;
    /**
    * Column type. See [Snowflake data types](https://docs.snowflake.com/en/sql-reference-data-types) for supported values. Example: VARCHAR(256), NUMBER(38,0).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#type HybridTable#type}
    */
    readonly type: string;
    /**
    * default block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#default HybridTable#default}
    */
    readonly default?: HybridTableColumnDefault;
}
export declare function hybridTableColumnToTerraform(struct?: HybridTableColumn | cdktn.IResolvable): any;
export declare function hybridTableColumnToHclTerraform(struct?: HybridTableColumn | cdktn.IResolvable): any;
export declare class HybridTableColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HybridTableColumn | cdktn.IResolvable | undefined;
    set internalValue(value: HybridTableColumn | cdktn.IResolvable | undefined);
    private _collate?;
    get collate(): string;
    set collate(value: string);
    resetCollate(): void;
    get collateInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _notNull?;
    get notNull(): boolean | cdktn.IResolvable;
    set notNull(value: boolean | cdktn.IResolvable);
    resetNotNull(): void;
    get notNullInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _default;
    get default(): HybridTableColumnDefaultOutputReference;
    putDefault(value: HybridTableColumnDefault): void;
    resetDefault(): void;
    get defaultInput(): HybridTableColumnDefault | undefined;
}
export declare class HybridTableColumnList extends cdktn.ComplexList {
    internalValue?: HybridTableColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HybridTableColumnOutputReference;
}
export interface HybridTableForeignKeyConstraint {
    /**
    * The local column(s) the foreign key is defined on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#columns HybridTable#columns}
    */
    readonly columns: string[];
    /**
    * Name of the constraint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#name HybridTable#name}
    */
    readonly name?: string;
    /**
    * The column(s) in the referenced table that the foreign key references.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#ref_columns HybridTable#ref_columns}
    */
    readonly refColumns: string[];
    /**
    * The table that the foreign key references.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#table_name HybridTable#table_name}
    */
    readonly tableName: string;
}
export declare function hybridTableForeignKeyConstraintToTerraform(struct?: HybridTableForeignKeyConstraint | cdktn.IResolvable): any;
export declare function hybridTableForeignKeyConstraintToHclTerraform(struct?: HybridTableForeignKeyConstraint | cdktn.IResolvable): any;
export declare class HybridTableForeignKeyConstraintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HybridTableForeignKeyConstraint | cdktn.IResolvable | undefined;
    set internalValue(value: HybridTableForeignKeyConstraint | cdktn.IResolvable | undefined);
    private _columns?;
    get columns(): string[];
    set columns(value: string[]);
    get columnsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _refColumns?;
    get refColumns(): string[];
    set refColumns(value: string[]);
    get refColumnsInput(): string[] | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export declare class HybridTableForeignKeyConstraintList extends cdktn.ComplexList {
    internalValue?: HybridTableForeignKeyConstraint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HybridTableForeignKeyConstraintOutputReference;
}
export interface HybridTableIndex {
    /**
    * Index key columns, in order. Order is semantically meaningful.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#columns HybridTable#columns}
    */
    readonly columns: string[];
    /**
    * Columns included in the index payload via INCLUDE (...). Order carries no meaning.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#include_columns HybridTable#include_columns}
    */
    readonly includeColumns?: string[];
    /**
    * Name of the secondary index.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#name HybridTable#name}
    */
    readonly name: string;
}
export declare function hybridTableIndexToTerraform(struct?: HybridTableIndex | cdktn.IResolvable): any;
export declare function hybridTableIndexToHclTerraform(struct?: HybridTableIndex | cdktn.IResolvable): any;
export declare class HybridTableIndexOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HybridTableIndex | cdktn.IResolvable | undefined;
    set internalValue(value: HybridTableIndex | cdktn.IResolvable | undefined);
    private _columns?;
    get columns(): string[];
    set columns(value: string[]);
    get columnsInput(): string[] | undefined;
    private _includeColumns?;
    get includeColumns(): string[];
    set includeColumns(value: string[]);
    resetIncludeColumns(): void;
    get includeColumnsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class HybridTableIndexList extends cdktn.ComplexList {
    internalValue?: HybridTableIndex[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HybridTableIndexOutputReference;
}
export interface HybridTablePrimaryKeyConstraint {
    /**
    * The column(s) the constraint applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#columns HybridTable#columns}
    */
    readonly columns: string[];
    /**
    * Name of the constraint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#name HybridTable#name}
    */
    readonly name?: string;
}
export declare function hybridTablePrimaryKeyConstraintToTerraform(struct?: HybridTablePrimaryKeyConstraintOutputReference | HybridTablePrimaryKeyConstraint): any;
export declare function hybridTablePrimaryKeyConstraintToHclTerraform(struct?: HybridTablePrimaryKeyConstraintOutputReference | HybridTablePrimaryKeyConstraint): any;
export declare class HybridTablePrimaryKeyConstraintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HybridTablePrimaryKeyConstraint | undefined;
    set internalValue(value: HybridTablePrimaryKeyConstraint | undefined);
    private _columns?;
    get columns(): string[];
    set columns(value: string[]);
    get columnsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface HybridTableTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#create HybridTable#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#delete HybridTable#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#read HybridTable#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#update HybridTable#update}
    */
    readonly update?: string;
}
export declare function hybridTableTimeoutsToTerraform(struct?: HybridTableTimeouts | cdktn.IResolvable): any;
export declare function hybridTableTimeoutsToHclTerraform(struct?: HybridTableTimeouts | cdktn.IResolvable): any;
export declare class HybridTableTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): HybridTableTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: HybridTableTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface HybridTableUniqueConstraint {
    /**
    * The column(s) the constraint applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#columns HybridTable#columns}
    */
    readonly columns: string[];
    /**
    * Name of the constraint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#name HybridTable#name}
    */
    readonly name?: string;
}
export declare function hybridTableUniqueConstraintToTerraform(struct?: HybridTableUniqueConstraint | cdktn.IResolvable): any;
export declare function hybridTableUniqueConstraintToHclTerraform(struct?: HybridTableUniqueConstraint | cdktn.IResolvable): any;
export declare class HybridTableUniqueConstraintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): HybridTableUniqueConstraint | cdktn.IResolvable | undefined;
    set internalValue(value: HybridTableUniqueConstraint | cdktn.IResolvable | undefined);
    private _columns?;
    get columns(): string[];
    set columns(value: string[]);
    get columnsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class HybridTableUniqueConstraintList extends cdktn.ComplexList {
    internalValue?: HybridTableUniqueConstraint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): HybridTableUniqueConstraintOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table snowflake_hybrid_table}
*/
export declare class HybridTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_hybrid_table";
    /**
    * Generates CDKTN code for importing a HybridTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the HybridTable to import
    * @param importFromId The id of the existing HybridTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the HybridTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/hybrid_table snowflake_hybrid_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options HybridTableConfig
    */
    constructor(scope: Construct, id: string, config: HybridTableConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _dataRetentionTimeInDays?;
    get dataRetentionTimeInDays(): number;
    set dataRetentionTimeInDays(value: number);
    resetDataRetentionTimeInDays(): void;
    get dataRetentionTimeInDaysInput(): number | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): HybridTableDescribeOutputList;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxDataExtensionTimeInDays?;
    get maxDataExtensionTimeInDays(): number;
    set maxDataExtensionTimeInDays(value: number);
    resetMaxDataExtensionTimeInDays(): void;
    get maxDataExtensionTimeInDaysInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showKeysOutput;
    get showKeysOutput(): HybridTableShowKeysOutputList;
    private _showOutput;
    get showOutput(): HybridTableShowOutputList;
    private _column;
    get column(): HybridTableColumnList;
    putColumn(value: HybridTableColumn[] | cdktn.IResolvable): void;
    get columnInput(): cdktn.IResolvable | HybridTableColumn[] | undefined;
    private _foreignKeyConstraint;
    get foreignKeyConstraint(): HybridTableForeignKeyConstraintList;
    putForeignKeyConstraint(value: HybridTableForeignKeyConstraint[] | cdktn.IResolvable): void;
    resetForeignKeyConstraint(): void;
    get foreignKeyConstraintInput(): cdktn.IResolvable | HybridTableForeignKeyConstraint[] | undefined;
    private _index;
    get index(): HybridTableIndexList;
    putIndex(value: HybridTableIndex[] | cdktn.IResolvable): void;
    resetIndex(): void;
    get indexInput(): cdktn.IResolvable | HybridTableIndex[] | undefined;
    private _primaryKeyConstraint;
    get primaryKeyConstraint(): HybridTablePrimaryKeyConstraintOutputReference;
    putPrimaryKeyConstraint(value: HybridTablePrimaryKeyConstraint): void;
    get primaryKeyConstraintInput(): HybridTablePrimaryKeyConstraint | undefined;
    private _timeouts;
    get timeouts(): HybridTableTimeoutsOutputReference;
    putTimeouts(value: HybridTableTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | HybridTableTimeouts | undefined;
    private _uniqueConstraint;
    get uniqueConstraint(): HybridTableUniqueConstraintList;
    putUniqueConstraint(value: HybridTableUniqueConstraint[] | cdktn.IResolvable): void;
    resetUniqueConstraint(): void;
    get uniqueConstraintInput(): cdktn.IResolvable | HybridTableUniqueConstraint[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
