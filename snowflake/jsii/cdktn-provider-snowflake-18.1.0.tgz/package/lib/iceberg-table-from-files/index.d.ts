/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IcebergTableFromFilesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the identifier for the catalog integration to use for the Iceberg table. If not specified, the account-level default is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files#catalog IcebergTableFromFiles#catalog}
    */
    readonly catalog?: string;
    /**
    * Specifies a comment for the Iceberg table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files#comment IcebergTableFromFiles#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the Iceberg table. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files#database IcebergTableFromFiles#database}
    */
    readonly database: string;
    /**
    * Specifies the identifier for the external volume where the Iceberg table stores its metadata files and data in Parquet format. If not specified, the account-level default is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files#external_volume IcebergTableFromFiles#external_volume}
    */
    readonly externalVolume?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files#id IcebergTableFromFiles#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the relative path of the Iceberg metadata file in the external volume. Cannot be changed after creation. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files#metadata_file_path IcebergTableFromFiles#metadata_file_path}
    */
    readonly metadataFilePath: string;
    /**
    * Specifies the identifier for the Iceberg table; must be unique for the schema in which the Iceberg table is created. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files#name IcebergTableFromFiles#name}
    */
    readonly name: string;
    /**
    * Specifies whether to replace invalid UTF-8 characters with the Unicode replacement character (`�`) in query results for an Iceberg table. For more information, check [REPLACE_INVALID_CHARACTERS docs](https://docs.snowflake.com/en/sql-reference/parameters#replace-invalid-characters).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files#replace_invalid_characters IcebergTableFromFiles#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: boolean | cdktn.IResolvable;
    /**
    * The schema in which to create the Iceberg table. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files#schema IcebergTableFromFiles#schema}
    */
    readonly schema: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files#timeouts IcebergTableFromFiles#timeouts}
    */
    readonly timeouts?: IcebergTableFromFilesTimeouts;
}
export interface IcebergTableFromFilesDescribeOutput {
}
export declare function icebergTableFromFilesDescribeOutputToTerraform(struct?: IcebergTableFromFilesDescribeOutput): any;
export declare function icebergTableFromFilesDescribeOutputToHclTerraform(struct?: IcebergTableFromFilesDescribeOutput): any;
export declare class IcebergTableFromFilesDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromFilesDescribeOutput | undefined;
    set internalValue(value: IcebergTableFromFilesDescribeOutput | undefined);
    get check(): string;
    get comment(): string;
    get default(): string;
    get expression(): string;
    get isNullable(): cdktn.IResolvable;
    get kind(): string;
    get name(): string;
    get nameMapping(): string;
    get policyName(): string;
    get primaryKey(): cdktn.IResolvable;
    get privacyDomain(): string;
    get sourceIcebergType(): string;
    get type(): string;
    get uniqueKey(): cdktn.IResolvable;
    get writeDefault(): string;
}
export declare class IcebergTableFromFilesDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromFilesDescribeOutputOutputReference;
}
export interface IcebergTableFromFilesParametersCatalog {
}
export declare function icebergTableFromFilesParametersCatalogToTerraform(struct?: IcebergTableFromFilesParametersCatalog): any;
export declare function icebergTableFromFilesParametersCatalogToHclTerraform(struct?: IcebergTableFromFilesParametersCatalog): any;
export declare class IcebergTableFromFilesParametersCatalogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromFilesParametersCatalog | undefined;
    set internalValue(value: IcebergTableFromFilesParametersCatalog | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromFilesParametersCatalogList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromFilesParametersCatalogOutputReference;
}
export interface IcebergTableFromFilesParametersExternalVolume {
}
export declare function icebergTableFromFilesParametersExternalVolumeToTerraform(struct?: IcebergTableFromFilesParametersExternalVolume): any;
export declare function icebergTableFromFilesParametersExternalVolumeToHclTerraform(struct?: IcebergTableFromFilesParametersExternalVolume): any;
export declare class IcebergTableFromFilesParametersExternalVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromFilesParametersExternalVolume | undefined;
    set internalValue(value: IcebergTableFromFilesParametersExternalVolume | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromFilesParametersExternalVolumeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromFilesParametersExternalVolumeOutputReference;
}
export interface IcebergTableFromFilesParametersReplaceInvalidCharacters {
}
export declare function icebergTableFromFilesParametersReplaceInvalidCharactersToTerraform(struct?: IcebergTableFromFilesParametersReplaceInvalidCharacters): any;
export declare function icebergTableFromFilesParametersReplaceInvalidCharactersToHclTerraform(struct?: IcebergTableFromFilesParametersReplaceInvalidCharacters): any;
export declare class IcebergTableFromFilesParametersReplaceInvalidCharactersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromFilesParametersReplaceInvalidCharacters | undefined;
    set internalValue(value: IcebergTableFromFilesParametersReplaceInvalidCharacters | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromFilesParametersReplaceInvalidCharactersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromFilesParametersReplaceInvalidCharactersOutputReference;
}
export interface IcebergTableFromFilesParameters {
}
export declare function icebergTableFromFilesParametersToTerraform(struct?: IcebergTableFromFilesParameters): any;
export declare function icebergTableFromFilesParametersToHclTerraform(struct?: IcebergTableFromFilesParameters): any;
export declare class IcebergTableFromFilesParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromFilesParameters | undefined;
    set internalValue(value: IcebergTableFromFilesParameters | undefined);
    private _catalog;
    get catalog(): IcebergTableFromFilesParametersCatalogList;
    private _externalVolume;
    get externalVolume(): IcebergTableFromFilesParametersExternalVolumeList;
    private _replaceInvalidCharacters;
    get replaceInvalidCharacters(): IcebergTableFromFilesParametersReplaceInvalidCharactersList;
}
export declare class IcebergTableFromFilesParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromFilesParametersOutputReference;
}
export interface IcebergTableFromFilesShowOutputAutoRefreshStatus {
}
export declare function icebergTableFromFilesShowOutputAutoRefreshStatusToTerraform(struct?: IcebergTableFromFilesShowOutputAutoRefreshStatus): any;
export declare function icebergTableFromFilesShowOutputAutoRefreshStatusToHclTerraform(struct?: IcebergTableFromFilesShowOutputAutoRefreshStatus): any;
export declare class IcebergTableFromFilesShowOutputAutoRefreshStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromFilesShowOutputAutoRefreshStatus | undefined;
    set internalValue(value: IcebergTableFromFilesShowOutputAutoRefreshStatus | undefined);
    get currentSnapshotId(): number;
    get executionState(): string;
    get lastSnapshotTime(): string;
    get lastUpdatedTime(): string;
    get pendingSnapshotCount(): number;
}
export declare class IcebergTableFromFilesShowOutputAutoRefreshStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromFilesShowOutputAutoRefreshStatusOutputReference;
}
export interface IcebergTableFromFilesShowOutputPartitionSpecsFields {
}
export declare function icebergTableFromFilesShowOutputPartitionSpecsFieldsToTerraform(struct?: IcebergTableFromFilesShowOutputPartitionSpecsFields): any;
export declare function icebergTableFromFilesShowOutputPartitionSpecsFieldsToHclTerraform(struct?: IcebergTableFromFilesShowOutputPartitionSpecsFields): any;
export declare class IcebergTableFromFilesShowOutputPartitionSpecsFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromFilesShowOutputPartitionSpecsFields | undefined;
    set internalValue(value: IcebergTableFromFilesShowOutputPartitionSpecsFields | undefined);
    get fieldId(): number;
    get name(): string;
    get sourceId(): number;
    get transform(): string;
}
export declare class IcebergTableFromFilesShowOutputPartitionSpecsFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromFilesShowOutputPartitionSpecsFieldsOutputReference;
}
export interface IcebergTableFromFilesShowOutputPartitionSpecs {
}
export declare function icebergTableFromFilesShowOutputPartitionSpecsToTerraform(struct?: IcebergTableFromFilesShowOutputPartitionSpecs): any;
export declare function icebergTableFromFilesShowOutputPartitionSpecsToHclTerraform(struct?: IcebergTableFromFilesShowOutputPartitionSpecs): any;
export declare class IcebergTableFromFilesShowOutputPartitionSpecsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromFilesShowOutputPartitionSpecs | undefined;
    set internalValue(value: IcebergTableFromFilesShowOutputPartitionSpecs | undefined);
    private _fields;
    get fields(): IcebergTableFromFilesShowOutputPartitionSpecsFieldsList;
    get specId(): number;
}
export declare class IcebergTableFromFilesShowOutputPartitionSpecsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromFilesShowOutputPartitionSpecsOutputReference;
}
export interface IcebergTableFromFilesShowOutput {
}
export declare function icebergTableFromFilesShowOutputToTerraform(struct?: IcebergTableFromFilesShowOutput): any;
export declare function icebergTableFromFilesShowOutputToHclTerraform(struct?: IcebergTableFromFilesShowOutput): any;
export declare class IcebergTableFromFilesShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromFilesShowOutput | undefined;
    set internalValue(value: IcebergTableFromFilesShowOutput | undefined);
    private _autoRefreshStatus;
    get autoRefreshStatus(): IcebergTableFromFilesShowOutputAutoRefreshStatusList;
    get baseLocation(): string;
    get canWriteMetadata(): cdktn.IResolvable;
    get catalogName(): string;
    get catalogNamespace(): string;
    get catalogSyncName(): string;
    get catalogTableName(): string;
    get comment(): string;
    get createdOn(): string;
    get currentPartitionSpecId(): number;
    get databaseName(): string;
    get externalVolumeName(): string;
    get icebergTableFormatVersion(): number;
    get icebergTableType(): string;
    get name(): string;
    get nameMapping(): string;
    get owner(): string;
    get ownerRoleType(): string;
    private _partitionSpecs;
    get partitionSpecs(): IcebergTableFromFilesShowOutputPartitionSpecsList;
    get schemaName(): string;
}
export declare class IcebergTableFromFilesShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromFilesShowOutputOutputReference;
}
export interface IcebergTableFromFilesTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files#create IcebergTableFromFiles#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files#delete IcebergTableFromFiles#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files#read IcebergTableFromFiles#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files#update IcebergTableFromFiles#update}
    */
    readonly update?: string;
}
export declare function icebergTableFromFilesTimeoutsToTerraform(struct?: IcebergTableFromFilesTimeouts | cdktn.IResolvable): any;
export declare function icebergTableFromFilesTimeoutsToHclTerraform(struct?: IcebergTableFromFilesTimeouts | cdktn.IResolvable): any;
export declare class IcebergTableFromFilesTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IcebergTableFromFilesTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: IcebergTableFromFilesTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files snowflake_iceberg_table_from_files}
*/
export declare class IcebergTableFromFiles extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_iceberg_table_from_files";
    /**
    * Generates CDKTN code for importing a IcebergTableFromFiles resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IcebergTableFromFiles to import
    * @param importFromId The id of the existing IcebergTableFromFiles that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IcebergTableFromFiles to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_files snowflake_iceberg_table_from_files} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IcebergTableFromFilesConfig
    */
    constructor(scope: Construct, id: string, config: IcebergTableFromFilesConfig);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): IcebergTableFromFilesDescribeOutputList;
    private _externalVolume?;
    get externalVolume(): string;
    set externalVolume(value: string);
    resetExternalVolume(): void;
    get externalVolumeInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadataFilePath?;
    get metadataFilePath(): string;
    set metadataFilePath(value: string);
    get metadataFilePathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): IcebergTableFromFilesParametersList;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): boolean | cdktn.IResolvable;
    set replaceInvalidCharacters(value: boolean | cdktn.IResolvable);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): boolean | cdktn.IResolvable | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): IcebergTableFromFilesShowOutputList;
    private _timeouts;
    get timeouts(): IcebergTableFromFilesTimeoutsOutputReference;
    putTimeouts(value: IcebergTableFromFilesTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | IcebergTableFromFilesTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
