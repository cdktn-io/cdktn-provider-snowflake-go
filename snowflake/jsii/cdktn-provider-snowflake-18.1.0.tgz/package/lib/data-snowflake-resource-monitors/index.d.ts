/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeResourceMonitorsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/resource_monitors#id DataSnowflakeResourceMonitors#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/resource_monitors#like DataSnowflakeResourceMonitors#like}
    */
    readonly like?: string;
}
export interface DataSnowflakeResourceMonitorsResourceMonitorsShowOutput {
}
export declare function dataSnowflakeResourceMonitorsResourceMonitorsShowOutputToTerraform(struct?: DataSnowflakeResourceMonitorsResourceMonitorsShowOutput): any;
export declare function dataSnowflakeResourceMonitorsResourceMonitorsShowOutputToHclTerraform(struct?: DataSnowflakeResourceMonitorsResourceMonitorsShowOutput): any;
export declare class DataSnowflakeResourceMonitorsResourceMonitorsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeResourceMonitorsResourceMonitorsShowOutput | undefined;
    set internalValue(value: DataSnowflakeResourceMonitorsResourceMonitorsShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get creditQuota(): number;
    get endTime(): string;
    get frequency(): string;
    get level(): string;
    get name(): string;
    get owner(): string;
    get remainingCredits(): number;
    get startTime(): string;
    get suspendAt(): number;
    get suspendImmediateAt(): number;
    get usedCredits(): number;
}
export declare class DataSnowflakeResourceMonitorsResourceMonitorsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeResourceMonitorsResourceMonitorsShowOutputOutputReference;
}
export interface DataSnowflakeResourceMonitorsResourceMonitors {
}
export declare function dataSnowflakeResourceMonitorsResourceMonitorsToTerraform(struct?: DataSnowflakeResourceMonitorsResourceMonitors): any;
export declare function dataSnowflakeResourceMonitorsResourceMonitorsToHclTerraform(struct?: DataSnowflakeResourceMonitorsResourceMonitors): any;
export declare class DataSnowflakeResourceMonitorsResourceMonitorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeResourceMonitorsResourceMonitors | undefined;
    set internalValue(value: DataSnowflakeResourceMonitorsResourceMonitors | undefined);
    private _showOutput;
    get showOutput(): DataSnowflakeResourceMonitorsResourceMonitorsShowOutputList;
}
export declare class DataSnowflakeResourceMonitorsResourceMonitorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeResourceMonitorsResourceMonitorsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/resource_monitors snowflake_resource_monitors}
*/
export declare class DataSnowflakeResourceMonitors extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_resource_monitors";
    /**
    * Generates CDKTN code for importing a DataSnowflakeResourceMonitors resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeResourceMonitors to import
    * @param importFromId The id of the existing DataSnowflakeResourceMonitors that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/resource_monitors#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeResourceMonitors to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/data-sources/resource_monitors snowflake_resource_monitors} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeResourceMonitorsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeResourceMonitorsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _resourceMonitors;
    get resourceMonitors(): DataSnowflakeResourceMonitorsResourceMonitorsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
