/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TagConfig extends cdktn.TerraformMetaArguments {
    /**
    * Set of allowed values for the tag (unordered). When specified, only these values can be assigned. When the `TAGS_ALLOW_EMPTY_ALLOWED_VALUES` experiment is enabled, removing this field from the configuration reverts the tag to accepting any value. Conflicts with `no_allowed_values` and `ordered_allowed_values`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#allowed_values Tag#allowed_values}
    */
    readonly allowedValues?: string[];
    /**
    * Specifies a comment for the tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#comment Tag#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the tag. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#database Tag#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#id Tag#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Set of masking policies for the tag. A tag can support one masking policy for each data type. If masking policies are assigned to the tag, before dropping the tag, the provider automatically unassigns them. For more information about this resource, see [docs](./masking_policy).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#masking_policies Tag#masking_policies}
    */
    readonly maskingPolicies?: string[];
    /**
    * Specifies the identifier for the tag; must be unique for the database in which the tag is created. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#name Tag#name}
    */
    readonly name: string;
    /**
    * When set to true, the tag explicitly disallows any value from being assigned. This is different from omitting `allowed_values`, which means any value is accepted. Available only when the `TAGS_ALLOW_EMPTY_ALLOWED_VALUES` experiment is enabled. Conflicts with `allowed_values` and `ordered_allowed_values`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#no_allowed_values Tag#no_allowed_values}
    */
    readonly noAllowedValues?: boolean | cdktn.IResolvable;
    /**
    * Ordered list of allowed values for the tag. The order is preserved in Snowflake and is significant when `on_conflict.allowed_values_sequence` is used — the first matching value in the sequence wins. Use this instead of `allowed_values` when order matters. Conflicts with `allowed_values` and `no_allowed_values`. Note: transitioning from `allowed_values` to `ordered_allowed_values` always plans an update-in-place for this field, even when the configured order already matches the order stored in Snowflake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#ordered_allowed_values Tag#ordered_allowed_values}
    */
    readonly orderedAllowedValues?: string[];
    /**
    * Specifies that the tag will be automatically propagated from source objects to target objects. See more about tag propagation in the [official documentation](https://docs.snowflake.com/en/user-guide/object-tagging/propagation). Valid options are: `NONE` | `ON_DEPENDENCY` | `ON_DATA_MOVEMENT` | `ON_DEPENDENCY_AND_DATA_MOVEMENT`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#propagate Tag#propagate}
    */
    readonly propagate?: string;
    /**
    * The schema in which to create the tag. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#schema Tag#schema}
    */
    readonly schema: string;
    /**
    * on_conflict block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#on_conflict Tag#on_conflict}
    */
    readonly onConflict?: TagOnConflict;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#timeouts Tag#timeouts}
    */
    readonly timeouts?: TagTimeouts;
}
export interface TagShowOutput {
}
export declare function tagShowOutputToTerraform(struct?: TagShowOutput): any;
export declare function tagShowOutputToHclTerraform(struct?: TagShowOutput): any;
export declare class TagShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TagShowOutput | undefined;
    set internalValue(value: TagShowOutput | undefined);
    get allowedValues(): string[];
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get name(): string;
    get onConflict(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get propagate(): string;
    get schemaName(): string;
}
export declare class TagShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TagShowOutputOutputReference;
}
export interface TagOnConflict {
    /**
    * The order of the values in the ALLOWED_VALUES property of the tag determines which value is used when there is a conflict.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#allowed_values_sequence Tag#allowed_values_sequence}
    */
    readonly allowedValuesSequence?: boolean | cdktn.IResolvable;
    /**
    * Whenever there is a conflict, the value of tag is set to custom_value. If `allowed_values` are set, the value set in this field should be one of the values in the `allowed_values` list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#custom_value Tag#custom_value}
    */
    readonly customValue?: string;
}
export declare function tagOnConflictToTerraform(struct?: TagOnConflictOutputReference | TagOnConflict): any;
export declare function tagOnConflictToHclTerraform(struct?: TagOnConflictOutputReference | TagOnConflict): any;
export declare class TagOnConflictOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TagOnConflict | undefined;
    set internalValue(value: TagOnConflict | undefined);
    private _allowedValuesSequence?;
    get allowedValuesSequence(): boolean | cdktn.IResolvable;
    set allowedValuesSequence(value: boolean | cdktn.IResolvable);
    resetAllowedValuesSequence(): void;
    get allowedValuesSequenceInput(): boolean | cdktn.IResolvable | undefined;
    private _customValue?;
    get customValue(): string;
    set customValue(value: string);
    resetCustomValue(): void;
    get customValueInput(): string | undefined;
}
export interface TagTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#create Tag#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#delete Tag#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#read Tag#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#update Tag#update}
    */
    readonly update?: string;
}
export declare function tagTimeoutsToTerraform(struct?: TagTimeouts | cdktn.IResolvable): any;
export declare function tagTimeoutsToHclTerraform(struct?: TagTimeouts | cdktn.IResolvable): any;
export declare class TagTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TagTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: TagTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag snowflake_tag}
*/
export declare class Tag extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_tag";
    /**
    * Generates CDKTN code for importing a Tag resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Tag to import
    * @param importFromId The id of the existing Tag that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Tag to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/tag snowflake_tag} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TagConfig
    */
    constructor(scope: Construct, id: string, config: TagConfig);
    private _allowedValues?;
    get allowedValues(): string[];
    set allowedValues(value: string[]);
    resetAllowedValues(): void;
    get allowedValuesInput(): string[] | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maskingPolicies?;
    get maskingPolicies(): string[];
    set maskingPolicies(value: string[]);
    resetMaskingPolicies(): void;
    get maskingPoliciesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _noAllowedValues?;
    get noAllowedValues(): boolean | cdktn.IResolvable;
    set noAllowedValues(value: boolean | cdktn.IResolvable);
    resetNoAllowedValues(): void;
    get noAllowedValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _orderedAllowedValues?;
    get orderedAllowedValues(): string[];
    set orderedAllowedValues(value: string[]);
    resetOrderedAllowedValues(): void;
    get orderedAllowedValuesInput(): string[] | undefined;
    private _propagate?;
    get propagate(): string;
    set propagate(value: string);
    resetPropagate(): void;
    get propagateInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): TagShowOutputList;
    private _onConflict;
    get onConflict(): TagOnConflictOutputReference;
    putOnConflict(value: TagOnConflict): void;
    resetOnConflict(): void;
    get onConflictInput(): TagOnConflict | undefined;
    private _timeouts;
    get timeouts(): TagTimeoutsOutputReference;
    putTimeouts(value: TagTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TagTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
