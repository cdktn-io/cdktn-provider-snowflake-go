/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApiIntegrationGitRepositoryOauth2Config extends cdktn.TerraformMetaArguments {
    /**
    * Explicitly limits external functions that use the integration to reference one or more HTTPS proxy service and remote service endpoints and resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#api_allowed_prefixes ApiIntegrationGitRepositoryOauth2#api_allowed_prefixes}
    */
    readonly apiAllowedPrefixes: string[];
    /**
    * Lists the endpoints and resources in the HTTPS proxy service that are not allowed to be called from Snowflake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#api_blocked_prefixes ApiIntegrationGitRepositoryOauth2#api_blocked_prefixes}
    */
    readonly apiBlockedPrefixes?: string[];
    /**
    * Specifies a comment for the integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#comment ApiIntegrationGitRepositoryOauth2#comment}
    */
    readonly comment?: string;
    /**
    * Specifies whether this API integration is enabled or disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#enabled ApiIntegrationGitRepositoryOauth2#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#id ApiIntegrationGitRepositoryOauth2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier (i.e. name) for the integration. This value must be unique in your account. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#name ApiIntegrationGitRepositoryOauth2#name}
    */
    readonly name: string;
    /**
    * Specifies the validity period (in seconds) for the OAuth 2.0 access token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#oauth_access_token_validity ApiIntegrationGitRepositoryOauth2#oauth_access_token_validity}
    */
    readonly oauthAccessTokenValidity?: number;
    /**
    * Specifies a list of scopes to use when making a request from the OAuth by a role with USAGE on the integration. Valid values are (case-insensitive): `read_api` | `read_repository` | `write_repository`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#oauth_allowed_scopes ApiIntegrationGitRepositoryOauth2#oauth_allowed_scopes}
    */
    readonly oauthAllowedScopes?: string[];
    /**
    * The OAuth 2.0 authorization endpoint for the Git repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#oauth_authorization_endpoint ApiIntegrationGitRepositoryOauth2#oauth_authorization_endpoint}
    */
    readonly oauthAuthorizationEndpoint: string;
    /**
    * The client ID for the OAuth 2.0 application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#oauth_client_id ApiIntegrationGitRepositoryOauth2#oauth_client_id}
    */
    readonly oauthClientId: string;
    /**
    * The client secret for the OAuth 2.0 application. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#oauth_client_secret ApiIntegrationGitRepositoryOauth2#oauth_client_secret}
    */
    readonly oauthClientSecret: string;
    /**
    * Specifies the validity period (in seconds) for the OAuth 2.0 refresh token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#oauth_refresh_token_validity ApiIntegrationGitRepositoryOauth2#oauth_refresh_token_validity}
    */
    readonly oauthRefreshTokenValidity?: number;
    /**
    * The OAuth 2.0 token endpoint for the Git repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#oauth_token_endpoint ApiIntegrationGitRepositoryOauth2#oauth_token_endpoint}
    */
    readonly oauthTokenEndpoint: string;
    /**
    * Specifies the username to authenticate with the Git repository using OAuth 2.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#oauth_username ApiIntegrationGitRepositoryOauth2#oauth_username}
    */
    readonly oauthUsername?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#timeouts ApiIntegrationGitRepositoryOauth2#timeouts}
    */
    readonly timeouts?: ApiIntegrationGitRepositoryOauth2Timeouts;
}
export interface ApiIntegrationGitRepositoryOauth2DescribeOutput {
}
export declare function apiIntegrationGitRepositoryOauth2DescribeOutputToTerraform(struct?: ApiIntegrationGitRepositoryOauth2DescribeOutput): any;
export declare function apiIntegrationGitRepositoryOauth2DescribeOutputToHclTerraform(struct?: ApiIntegrationGitRepositoryOauth2DescribeOutput): any;
export declare class ApiIntegrationGitRepositoryOauth2DescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiIntegrationGitRepositoryOauth2DescribeOutput | undefined;
    set internalValue(value: ApiIntegrationGitRepositoryOauth2DescribeOutput | undefined);
    get allowedPrefixes(): string[];
    get blockedPrefixes(): string[];
    get comment(): string;
    get enabled(): cdktn.IResolvable;
    get oauthAccessTokenValidity(): number;
    get oauthAllowedScopes(): string[];
    get oauthAuthorizationEndpoint(): string;
    get oauthClientId(): string;
    get oauthRefreshTokenValidity(): number;
    get oauthTokenEndpoint(): string;
    get oauthUsername(): string;
    get userAuthType(): string;
}
export declare class ApiIntegrationGitRepositoryOauth2DescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiIntegrationGitRepositoryOauth2DescribeOutputOutputReference;
}
export interface ApiIntegrationGitRepositoryOauth2ShowOutput {
}
export declare function apiIntegrationGitRepositoryOauth2ShowOutputToTerraform(struct?: ApiIntegrationGitRepositoryOauth2ShowOutput): any;
export declare function apiIntegrationGitRepositoryOauth2ShowOutputToHclTerraform(struct?: ApiIntegrationGitRepositoryOauth2ShowOutput): any;
export declare class ApiIntegrationGitRepositoryOauth2ShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiIntegrationGitRepositoryOauth2ShowOutput | undefined;
    set internalValue(value: ApiIntegrationGitRepositoryOauth2ShowOutput | undefined);
    get apiType(): string;
    get category(): string;
    get comment(): string;
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
}
export declare class ApiIntegrationGitRepositoryOauth2ShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiIntegrationGitRepositoryOauth2ShowOutputOutputReference;
}
export interface ApiIntegrationGitRepositoryOauth2Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#create ApiIntegrationGitRepositoryOauth2#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#delete ApiIntegrationGitRepositoryOauth2#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#read ApiIntegrationGitRepositoryOauth2#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#update ApiIntegrationGitRepositoryOauth2#update}
    */
    readonly update?: string;
}
export declare function apiIntegrationGitRepositoryOauth2TimeoutsToTerraform(struct?: ApiIntegrationGitRepositoryOauth2Timeouts | cdktn.IResolvable): any;
export declare function apiIntegrationGitRepositoryOauth2TimeoutsToHclTerraform(struct?: ApiIntegrationGitRepositoryOauth2Timeouts | cdktn.IResolvable): any;
export declare class ApiIntegrationGitRepositoryOauth2TimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiIntegrationGitRepositoryOauth2Timeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApiIntegrationGitRepositoryOauth2Timeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2 snowflake_api_integration_git_repository_oauth2}
*/
export declare class ApiIntegrationGitRepositoryOauth2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_api_integration_git_repository_oauth2";
    /**
    * Generates CDKTN code for importing a ApiIntegrationGitRepositoryOauth2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApiIntegrationGitRepositoryOauth2 to import
    * @param importFromId The id of the existing ApiIntegrationGitRepositoryOauth2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApiIntegrationGitRepositoryOauth2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/api_integration_git_repository_oauth2 snowflake_api_integration_git_repository_oauth2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApiIntegrationGitRepositoryOauth2Config
    */
    constructor(scope: Construct, id: string, config: ApiIntegrationGitRepositoryOauth2Config);
    private _apiAllowedPrefixes?;
    get apiAllowedPrefixes(): string[];
    set apiAllowedPrefixes(value: string[]);
    get apiAllowedPrefixesInput(): string[] | undefined;
    private _apiBlockedPrefixes?;
    get apiBlockedPrefixes(): string[];
    set apiBlockedPrefixes(value: string[]);
    resetApiBlockedPrefixes(): void;
    get apiBlockedPrefixesInput(): string[] | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): ApiIntegrationGitRepositoryOauth2DescribeOutputList;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _oauthAccessTokenValidity?;
    get oauthAccessTokenValidity(): number;
    set oauthAccessTokenValidity(value: number);
    resetOauthAccessTokenValidity(): void;
    get oauthAccessTokenValidityInput(): number | undefined;
    private _oauthAllowedScopes?;
    get oauthAllowedScopes(): string[];
    set oauthAllowedScopes(value: string[]);
    resetOauthAllowedScopes(): void;
    get oauthAllowedScopesInput(): string[] | undefined;
    private _oauthAuthorizationEndpoint?;
    get oauthAuthorizationEndpoint(): string;
    set oauthAuthorizationEndpoint(value: string);
    get oauthAuthorizationEndpointInput(): string | undefined;
    private _oauthClientId?;
    get oauthClientId(): string;
    set oauthClientId(value: string);
    get oauthClientIdInput(): string | undefined;
    private _oauthClientSecret?;
    get oauthClientSecret(): string;
    set oauthClientSecret(value: string);
    get oauthClientSecretInput(): string | undefined;
    private _oauthRefreshTokenValidity?;
    get oauthRefreshTokenValidity(): number;
    set oauthRefreshTokenValidity(value: number);
    resetOauthRefreshTokenValidity(): void;
    get oauthRefreshTokenValidityInput(): number | undefined;
    private _oauthTokenEndpoint?;
    get oauthTokenEndpoint(): string;
    set oauthTokenEndpoint(value: string);
    get oauthTokenEndpointInput(): string | undefined;
    private _oauthUsername?;
    get oauthUsername(): string;
    set oauthUsername(value: string);
    resetOauthUsername(): void;
    get oauthUsernameInput(): string | undefined;
    private _showOutput;
    get showOutput(): ApiIntegrationGitRepositoryOauth2ShowOutputList;
    private _timeouts;
    get timeouts(): ApiIntegrationGitRepositoryOauth2TimeoutsOutputReference;
    putTimeouts(value: ApiIntegrationGitRepositoryOauth2Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApiIntegrationGitRepositoryOauth2Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
