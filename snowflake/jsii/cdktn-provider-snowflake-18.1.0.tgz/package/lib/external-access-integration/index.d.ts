/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ExternalAccessIntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the network rules for external locations reachable through this integration. At least one is required. Only egress network rules may be specified. For more information about this resource, see [docs](./network_rule).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#allowed_network_rules ExternalAccessIntegration#allowed_network_rules}
    */
    readonly allowedNetworkRules: string[];
    /**
    * Specifies a comment for the external access integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#comment ExternalAccessIntegration#comment}
    */
    readonly comment?: string;
    /**
    * Specifies whether the integration is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#enabled ExternalAccessIntegration#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#id ExternalAccessIntegration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the external access integration. Changing this value recreates the integration. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#name ExternalAccessIntegration#name}
    */
    readonly name: string;
    /**
    * allowed_api_authentication_integrations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#allowed_api_authentication_integrations ExternalAccessIntegration#allowed_api_authentication_integrations}
    */
    readonly allowedApiAuthenticationIntegrations?: ExternalAccessIntegrationAllowedApiAuthenticationIntegrations;
    /**
    * allowed_authentication_secrets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#allowed_authentication_secrets ExternalAccessIntegration#allowed_authentication_secrets}
    */
    readonly allowedAuthenticationSecrets?: ExternalAccessIntegrationAllowedAuthenticationSecrets;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#timeouts ExternalAccessIntegration#timeouts}
    */
    readonly timeouts?: ExternalAccessIntegrationTimeouts;
}
export interface ExternalAccessIntegrationDescribeOutput {
}
export declare function externalAccessIntegrationDescribeOutputToTerraform(struct?: ExternalAccessIntegrationDescribeOutput): any;
export declare function externalAccessIntegrationDescribeOutputToHclTerraform(struct?: ExternalAccessIntegrationDescribeOutput): any;
export declare class ExternalAccessIntegrationDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ExternalAccessIntegrationDescribeOutput | undefined;
    set internalValue(value: ExternalAccessIntegrationDescribeOutput | undefined);
    get allowedApiAuthenticationIntegrations(): string[];
    get allowedAuthenticationSecrets(): string[];
    get allowedNetworkRules(): string[];
    get comment(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
}
export declare class ExternalAccessIntegrationDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ExternalAccessIntegrationDescribeOutputOutputReference;
}
export interface ExternalAccessIntegrationShowOutput {
}
export declare function externalAccessIntegrationShowOutputToTerraform(struct?: ExternalAccessIntegrationShowOutput): any;
export declare function externalAccessIntegrationShowOutputToHclTerraform(struct?: ExternalAccessIntegrationShowOutput): any;
export declare class ExternalAccessIntegrationShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ExternalAccessIntegrationShowOutput | undefined;
    set internalValue(value: ExternalAccessIntegrationShowOutput | undefined);
    get category(): string;
    get comment(): string;
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
    get type(): string;
}
export declare class ExternalAccessIntegrationShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ExternalAccessIntegrationShowOutputOutputReference;
}
export interface ExternalAccessIntegrationAllowedApiAuthenticationIntegrations {
    /**
    * Specifies the API authentication integrations allowed for authenticating to external locations. Conflicts with `none`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#integrations ExternalAccessIntegration#integrations}
    */
    readonly integrations?: string[];
    /**
    * When true, no API authentication integrations are allowed. Conflicts with `integrations`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#none ExternalAccessIntegration#none}
    */
    readonly none?: boolean | cdktn.IResolvable;
}
export declare function externalAccessIntegrationAllowedApiAuthenticationIntegrationsToTerraform(struct?: ExternalAccessIntegrationAllowedApiAuthenticationIntegrationsOutputReference | ExternalAccessIntegrationAllowedApiAuthenticationIntegrations): any;
export declare function externalAccessIntegrationAllowedApiAuthenticationIntegrationsToHclTerraform(struct?: ExternalAccessIntegrationAllowedApiAuthenticationIntegrationsOutputReference | ExternalAccessIntegrationAllowedApiAuthenticationIntegrations): any;
export declare class ExternalAccessIntegrationAllowedApiAuthenticationIntegrationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalAccessIntegrationAllowedApiAuthenticationIntegrations | undefined;
    set internalValue(value: ExternalAccessIntegrationAllowedApiAuthenticationIntegrations | undefined);
    private _integrations?;
    get integrations(): string[];
    set integrations(value: string[]);
    resetIntegrations(): void;
    get integrationsInput(): string[] | undefined;
    private _none?;
    get none(): boolean | cdktn.IResolvable;
    set none(value: boolean | cdktn.IResolvable);
    resetNone(): void;
    get noneInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ExternalAccessIntegrationAllowedAuthenticationSecrets {
    /**
    * When true, all secrets in the account are allowed for authentication. Conflicts with `none` and `secrets`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#all ExternalAccessIntegration#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * When true, no secrets are allowed for authentication. Conflicts with `all` and `secrets`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#none ExternalAccessIntegration#none}
    */
    readonly none?: boolean | cdktn.IResolvable;
    /**
    * Specifies the fully qualified identifiers of secrets allowed for authentication. Conflicts with `none` and `all`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#secrets ExternalAccessIntegration#secrets}
    */
    readonly secrets?: string[];
}
export declare function externalAccessIntegrationAllowedAuthenticationSecretsToTerraform(struct?: ExternalAccessIntegrationAllowedAuthenticationSecretsOutputReference | ExternalAccessIntegrationAllowedAuthenticationSecrets): any;
export declare function externalAccessIntegrationAllowedAuthenticationSecretsToHclTerraform(struct?: ExternalAccessIntegrationAllowedAuthenticationSecretsOutputReference | ExternalAccessIntegrationAllowedAuthenticationSecrets): any;
export declare class ExternalAccessIntegrationAllowedAuthenticationSecretsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalAccessIntegrationAllowedAuthenticationSecrets | undefined;
    set internalValue(value: ExternalAccessIntegrationAllowedAuthenticationSecrets | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _none?;
    get none(): boolean | cdktn.IResolvable;
    set none(value: boolean | cdktn.IResolvable);
    resetNone(): void;
    get noneInput(): boolean | cdktn.IResolvable | undefined;
    private _secrets?;
    get secrets(): string[];
    set secrets(value: string[]);
    resetSecrets(): void;
    get secretsInput(): string[] | undefined;
}
export interface ExternalAccessIntegrationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#create ExternalAccessIntegration#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#delete ExternalAccessIntegration#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#read ExternalAccessIntegration#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#update ExternalAccessIntegration#update}
    */
    readonly update?: string;
}
export declare function externalAccessIntegrationTimeoutsToTerraform(struct?: ExternalAccessIntegrationTimeouts | cdktn.IResolvable): any;
export declare function externalAccessIntegrationTimeoutsToHclTerraform(struct?: ExternalAccessIntegrationTimeouts | cdktn.IResolvable): any;
export declare class ExternalAccessIntegrationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalAccessIntegrationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ExternalAccessIntegrationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration snowflake_external_access_integration}
*/
export declare class ExternalAccessIntegration extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_external_access_integration";
    /**
    * Generates CDKTN code for importing a ExternalAccessIntegration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ExternalAccessIntegration to import
    * @param importFromId The id of the existing ExternalAccessIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ExternalAccessIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/external_access_integration snowflake_external_access_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ExternalAccessIntegrationConfig
    */
    constructor(scope: Construct, id: string, config: ExternalAccessIntegrationConfig);
    private _allowedNetworkRules?;
    get allowedNetworkRules(): string[];
    set allowedNetworkRules(value: string[]);
    get allowedNetworkRulesInput(): string[] | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): ExternalAccessIntegrationDescribeOutputList;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _showOutput;
    get showOutput(): ExternalAccessIntegrationShowOutputList;
    private _allowedApiAuthenticationIntegrations;
    get allowedApiAuthenticationIntegrations(): ExternalAccessIntegrationAllowedApiAuthenticationIntegrationsOutputReference;
    putAllowedApiAuthenticationIntegrations(value: ExternalAccessIntegrationAllowedApiAuthenticationIntegrations): void;
    resetAllowedApiAuthenticationIntegrations(): void;
    get allowedApiAuthenticationIntegrationsInput(): ExternalAccessIntegrationAllowedApiAuthenticationIntegrations | undefined;
    private _allowedAuthenticationSecrets;
    get allowedAuthenticationSecrets(): ExternalAccessIntegrationAllowedAuthenticationSecretsOutputReference;
    putAllowedAuthenticationSecrets(value: ExternalAccessIntegrationAllowedAuthenticationSecrets): void;
    resetAllowedAuthenticationSecrets(): void;
    get allowedAuthenticationSecretsInput(): ExternalAccessIntegrationAllowedAuthenticationSecrets | undefined;
    private _timeouts;
    get timeouts(): ExternalAccessIntegrationTimeoutsOutputReference;
    putTimeouts(value: ExternalAccessIntegrationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ExternalAccessIntegrationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
