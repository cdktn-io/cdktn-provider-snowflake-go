/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IcebergTableFromRestConfig extends cdktn.TerraformMetaArguments {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether Snowflake should periodically refresh the Iceberg table metadata from the external catalog. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#auto_refresh IcebergTableFromRest#auto_refresh}
    */
    readonly autoRefresh?: string;
    /**
    * Specifies the identifier for the catalog integration to use for the Iceberg table. If not specified, the account-level default is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#catalog IcebergTableFromRest#catalog}
    */
    readonly catalog?: string;
    /**
    * Specifies the namespace (or database) in the external catalog that the table belongs to. If not specified, the catalog integration's default namespace is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#catalog_namespace IcebergTableFromRest#catalog_namespace}
    */
    readonly catalogNamespace?: string;
    /**
    * Specifies the name of the table as it appears in the external catalog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#catalog_table_name IcebergTableFromRest#catalog_table_name}
    */
    readonly catalogTableName: string;
    /**
    * Specifies a comment for the Iceberg table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#comment IcebergTableFromRest#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the Iceberg table. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#database IcebergTableFromRest#database}
    */
    readonly database: string;
    /**
    * Specifies whether merge-on-read is enabled for the Iceberg table. For more information, check [ENABLE_ICEBERG_MERGE_ON_READ docs](https://docs.snowflake.com/en/sql-reference/parameters#enable-iceberg-merge-on-read).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#enable_iceberg_merge_on_read IcebergTableFromRest#enable_iceberg_merge_on_read}
    */
    readonly enableIcebergMergeOnRead?: boolean | cdktn.IResolvable;
    /**
    * Specifies the identifier for the external volume where the Iceberg table stores its metadata files and data in Parquet format. If not specified, the account-level default is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#external_volume IcebergTableFromRest#external_volume}
    */
    readonly externalVolume?: string;
    /**
    * Specifies the merge-on-read behavior for the Iceberg table. Valid values are: [AUTO ENABLED DISABLED]. Cannot be changed after creation. For more information, check [ICEBERG_MERGE_ON_READ_BEHAVIOR docs](https://docs.snowflake.com/en/sql-reference/parameters#iceberg-merge-on-read-behavior).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#iceberg_merge_on_read_behavior IcebergTableFromRest#iceberg_merge_on_read_behavior}
    */
    readonly icebergMergeOnReadBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#id IcebergTableFromRest#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the Iceberg table; must be unique for the schema in which the Iceberg table is created. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#name IcebergTableFromRest#name}
    */
    readonly name: string;
    /**
    * Specifies the storage layout for the Iceberg table's Parquet files. Valid values are: [FLAT HIERARCHICAL]. Cannot be changed after creation. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#path_layout IcebergTableFromRest#path_layout}
    */
    readonly pathLayout?: string;
    /**
    * Specifies whether to replace invalid UTF-8 characters with the Unicode replacement character (`�`) in query results for an Iceberg table. For more information, check [REPLACE_INVALID_CHARACTERS docs](https://docs.snowflake.com/en/sql-reference/parameters#replace-invalid-characters).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#replace_invalid_characters IcebergTableFromRest#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: boolean | cdktn.IResolvable;
    /**
    * The schema in which to create the Iceberg table. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#schema IcebergTableFromRest#schema}
    */
    readonly schema: string;
    /**
    * Specifies the storage serialization policy for the Iceberg table. Valid values are: [COMPATIBLE OPTIMIZED]. Cannot be changed after creation. For more information, check [STORAGE_SERIALIZATION_POLICY docs](https://docs.snowflake.com/en/sql-reference/parameters#storage-serialization-policy).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#storage_serialization_policy IcebergTableFromRest#storage_serialization_policy}
    */
    readonly storageSerializationPolicy?: string;
    /**
    * Specifies the target file size (in bytes) used when writing the Iceberg table's Parquet files. Valid values are: [AUTO 16MB 32MB 64MB 128MB]. For more information, check [TARGET_FILE_SIZE docs](https://docs.snowflake.com/en/sql-reference/parameters#target-file-size).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#target_file_size IcebergTableFromRest#target_file_size}
    */
    readonly targetFileSize?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#timeouts IcebergTableFromRest#timeouts}
    */
    readonly timeouts?: IcebergTableFromRestTimeouts;
}
export interface IcebergTableFromRestDescribeOutput {
}
export declare function icebergTableFromRestDescribeOutputToTerraform(struct?: IcebergTableFromRestDescribeOutput): any;
export declare function icebergTableFromRestDescribeOutputToHclTerraform(struct?: IcebergTableFromRestDescribeOutput): any;
export declare class IcebergTableFromRestDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromRestDescribeOutput | undefined;
    set internalValue(value: IcebergTableFromRestDescribeOutput | undefined);
    get check(): string;
    get comment(): string;
    get default(): string;
    get expression(): string;
    get isNullable(): cdktn.IResolvable;
    get kind(): string;
    get name(): string;
    get nameMapping(): string;
    get policyName(): string;
    get primaryKey(): cdktn.IResolvable;
    get privacyDomain(): string;
    get sourceIcebergType(): string;
    get type(): string;
    get uniqueKey(): cdktn.IResolvable;
    get writeDefault(): string;
}
export declare class IcebergTableFromRestDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromRestDescribeOutputOutputReference;
}
export interface IcebergTableFromRestParametersCatalog {
}
export declare function icebergTableFromRestParametersCatalogToTerraform(struct?: IcebergTableFromRestParametersCatalog): any;
export declare function icebergTableFromRestParametersCatalogToHclTerraform(struct?: IcebergTableFromRestParametersCatalog): any;
export declare class IcebergTableFromRestParametersCatalogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromRestParametersCatalog | undefined;
    set internalValue(value: IcebergTableFromRestParametersCatalog | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromRestParametersCatalogList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromRestParametersCatalogOutputReference;
}
export interface IcebergTableFromRestParametersEnableIcebergMergeOnRead {
}
export declare function icebergTableFromRestParametersEnableIcebergMergeOnReadToTerraform(struct?: IcebergTableFromRestParametersEnableIcebergMergeOnRead): any;
export declare function icebergTableFromRestParametersEnableIcebergMergeOnReadToHclTerraform(struct?: IcebergTableFromRestParametersEnableIcebergMergeOnRead): any;
export declare class IcebergTableFromRestParametersEnableIcebergMergeOnReadOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromRestParametersEnableIcebergMergeOnRead | undefined;
    set internalValue(value: IcebergTableFromRestParametersEnableIcebergMergeOnRead | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromRestParametersEnableIcebergMergeOnReadList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromRestParametersEnableIcebergMergeOnReadOutputReference;
}
export interface IcebergTableFromRestParametersExternalVolume {
}
export declare function icebergTableFromRestParametersExternalVolumeToTerraform(struct?: IcebergTableFromRestParametersExternalVolume): any;
export declare function icebergTableFromRestParametersExternalVolumeToHclTerraform(struct?: IcebergTableFromRestParametersExternalVolume): any;
export declare class IcebergTableFromRestParametersExternalVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromRestParametersExternalVolume | undefined;
    set internalValue(value: IcebergTableFromRestParametersExternalVolume | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromRestParametersExternalVolumeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromRestParametersExternalVolumeOutputReference;
}
export interface IcebergTableFromRestParametersIcebergMergeOnReadBehavior {
}
export declare function icebergTableFromRestParametersIcebergMergeOnReadBehaviorToTerraform(struct?: IcebergTableFromRestParametersIcebergMergeOnReadBehavior): any;
export declare function icebergTableFromRestParametersIcebergMergeOnReadBehaviorToHclTerraform(struct?: IcebergTableFromRestParametersIcebergMergeOnReadBehavior): any;
export declare class IcebergTableFromRestParametersIcebergMergeOnReadBehaviorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromRestParametersIcebergMergeOnReadBehavior | undefined;
    set internalValue(value: IcebergTableFromRestParametersIcebergMergeOnReadBehavior | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromRestParametersIcebergMergeOnReadBehaviorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromRestParametersIcebergMergeOnReadBehaviorOutputReference;
}
export interface IcebergTableFromRestParametersReplaceInvalidCharacters {
}
export declare function icebergTableFromRestParametersReplaceInvalidCharactersToTerraform(struct?: IcebergTableFromRestParametersReplaceInvalidCharacters): any;
export declare function icebergTableFromRestParametersReplaceInvalidCharactersToHclTerraform(struct?: IcebergTableFromRestParametersReplaceInvalidCharacters): any;
export declare class IcebergTableFromRestParametersReplaceInvalidCharactersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromRestParametersReplaceInvalidCharacters | undefined;
    set internalValue(value: IcebergTableFromRestParametersReplaceInvalidCharacters | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromRestParametersReplaceInvalidCharactersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromRestParametersReplaceInvalidCharactersOutputReference;
}
export interface IcebergTableFromRestParametersStorageSerializationPolicy {
}
export declare function icebergTableFromRestParametersStorageSerializationPolicyToTerraform(struct?: IcebergTableFromRestParametersStorageSerializationPolicy): any;
export declare function icebergTableFromRestParametersStorageSerializationPolicyToHclTerraform(struct?: IcebergTableFromRestParametersStorageSerializationPolicy): any;
export declare class IcebergTableFromRestParametersStorageSerializationPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromRestParametersStorageSerializationPolicy | undefined;
    set internalValue(value: IcebergTableFromRestParametersStorageSerializationPolicy | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromRestParametersStorageSerializationPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromRestParametersStorageSerializationPolicyOutputReference;
}
export interface IcebergTableFromRestParametersTargetFileSize {
}
export declare function icebergTableFromRestParametersTargetFileSizeToTerraform(struct?: IcebergTableFromRestParametersTargetFileSize): any;
export declare function icebergTableFromRestParametersTargetFileSizeToHclTerraform(struct?: IcebergTableFromRestParametersTargetFileSize): any;
export declare class IcebergTableFromRestParametersTargetFileSizeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromRestParametersTargetFileSize | undefined;
    set internalValue(value: IcebergTableFromRestParametersTargetFileSize | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromRestParametersTargetFileSizeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromRestParametersTargetFileSizeOutputReference;
}
export interface IcebergTableFromRestParameters {
}
export declare function icebergTableFromRestParametersToTerraform(struct?: IcebergTableFromRestParameters): any;
export declare function icebergTableFromRestParametersToHclTerraform(struct?: IcebergTableFromRestParameters): any;
export declare class IcebergTableFromRestParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromRestParameters | undefined;
    set internalValue(value: IcebergTableFromRestParameters | undefined);
    private _catalog;
    get catalog(): IcebergTableFromRestParametersCatalogList;
    private _enableIcebergMergeOnRead;
    get enableIcebergMergeOnRead(): IcebergTableFromRestParametersEnableIcebergMergeOnReadList;
    private _externalVolume;
    get externalVolume(): IcebergTableFromRestParametersExternalVolumeList;
    private _icebergMergeOnReadBehavior;
    get icebergMergeOnReadBehavior(): IcebergTableFromRestParametersIcebergMergeOnReadBehaviorList;
    private _replaceInvalidCharacters;
    get replaceInvalidCharacters(): IcebergTableFromRestParametersReplaceInvalidCharactersList;
    private _storageSerializationPolicy;
    get storageSerializationPolicy(): IcebergTableFromRestParametersStorageSerializationPolicyList;
    private _targetFileSize;
    get targetFileSize(): IcebergTableFromRestParametersTargetFileSizeList;
}
export declare class IcebergTableFromRestParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromRestParametersOutputReference;
}
export interface IcebergTableFromRestShowOutputAutoRefreshStatus {
}
export declare function icebergTableFromRestShowOutputAutoRefreshStatusToTerraform(struct?: IcebergTableFromRestShowOutputAutoRefreshStatus): any;
export declare function icebergTableFromRestShowOutputAutoRefreshStatusToHclTerraform(struct?: IcebergTableFromRestShowOutputAutoRefreshStatus): any;
export declare class IcebergTableFromRestShowOutputAutoRefreshStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromRestShowOutputAutoRefreshStatus | undefined;
    set internalValue(value: IcebergTableFromRestShowOutputAutoRefreshStatus | undefined);
    get currentSnapshotId(): number;
    get executionState(): string;
    get lastSnapshotTime(): string;
    get lastUpdatedTime(): string;
    get pendingSnapshotCount(): number;
}
export declare class IcebergTableFromRestShowOutputAutoRefreshStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromRestShowOutputAutoRefreshStatusOutputReference;
}
export interface IcebergTableFromRestShowOutputPartitionSpecsFields {
}
export declare function icebergTableFromRestShowOutputPartitionSpecsFieldsToTerraform(struct?: IcebergTableFromRestShowOutputPartitionSpecsFields): any;
export declare function icebergTableFromRestShowOutputPartitionSpecsFieldsToHclTerraform(struct?: IcebergTableFromRestShowOutputPartitionSpecsFields): any;
export declare class IcebergTableFromRestShowOutputPartitionSpecsFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromRestShowOutputPartitionSpecsFields | undefined;
    set internalValue(value: IcebergTableFromRestShowOutputPartitionSpecsFields | undefined);
    get fieldId(): number;
    get name(): string;
    get sourceId(): number;
    get transform(): string;
}
export declare class IcebergTableFromRestShowOutputPartitionSpecsFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromRestShowOutputPartitionSpecsFieldsOutputReference;
}
export interface IcebergTableFromRestShowOutputPartitionSpecs {
}
export declare function icebergTableFromRestShowOutputPartitionSpecsToTerraform(struct?: IcebergTableFromRestShowOutputPartitionSpecs): any;
export declare function icebergTableFromRestShowOutputPartitionSpecsToHclTerraform(struct?: IcebergTableFromRestShowOutputPartitionSpecs): any;
export declare class IcebergTableFromRestShowOutputPartitionSpecsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromRestShowOutputPartitionSpecs | undefined;
    set internalValue(value: IcebergTableFromRestShowOutputPartitionSpecs | undefined);
    private _fields;
    get fields(): IcebergTableFromRestShowOutputPartitionSpecsFieldsList;
    get specId(): number;
}
export declare class IcebergTableFromRestShowOutputPartitionSpecsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromRestShowOutputPartitionSpecsOutputReference;
}
export interface IcebergTableFromRestShowOutput {
}
export declare function icebergTableFromRestShowOutputToTerraform(struct?: IcebergTableFromRestShowOutput): any;
export declare function icebergTableFromRestShowOutputToHclTerraform(struct?: IcebergTableFromRestShowOutput): any;
export declare class IcebergTableFromRestShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromRestShowOutput | undefined;
    set internalValue(value: IcebergTableFromRestShowOutput | undefined);
    private _autoRefreshStatus;
    get autoRefreshStatus(): IcebergTableFromRestShowOutputAutoRefreshStatusList;
    get baseLocation(): string;
    get canWriteMetadata(): cdktn.IResolvable;
    get catalogName(): string;
    get catalogNamespace(): string;
    get catalogSyncName(): string;
    get catalogTableName(): string;
    get comment(): string;
    get createdOn(): string;
    get currentPartitionSpecId(): number;
    get databaseName(): string;
    get externalVolumeName(): string;
    get icebergTableFormatVersion(): number;
    get icebergTableType(): string;
    get name(): string;
    get nameMapping(): string;
    get owner(): string;
    get ownerRoleType(): string;
    private _partitionSpecs;
    get partitionSpecs(): IcebergTableFromRestShowOutputPartitionSpecsList;
    get schemaName(): string;
}
export declare class IcebergTableFromRestShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromRestShowOutputOutputReference;
}
export interface IcebergTableFromRestTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#create IcebergTableFromRest#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#delete IcebergTableFromRest#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#read IcebergTableFromRest#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#update IcebergTableFromRest#update}
    */
    readonly update?: string;
}
export declare function icebergTableFromRestTimeoutsToTerraform(struct?: IcebergTableFromRestTimeouts | cdktn.IResolvable): any;
export declare function icebergTableFromRestTimeoutsToHclTerraform(struct?: IcebergTableFromRestTimeouts | cdktn.IResolvable): any;
export declare class IcebergTableFromRestTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IcebergTableFromRestTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: IcebergTableFromRestTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest snowflake_iceberg_table_from_rest}
*/
export declare class IcebergTableFromRest extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_iceberg_table_from_rest";
    /**
    * Generates CDKTN code for importing a IcebergTableFromRest resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IcebergTableFromRest to import
    * @param importFromId The id of the existing IcebergTableFromRest that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IcebergTableFromRest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.20.0/docs/resources/iceberg_table_from_rest snowflake_iceberg_table_from_rest} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IcebergTableFromRestConfig
    */
    constructor(scope: Construct, id: string, config: IcebergTableFromRestConfig);
    private _autoRefresh?;
    get autoRefresh(): string;
    set autoRefresh(value: string);
    resetAutoRefresh(): void;
    get autoRefreshInput(): string | undefined;
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _catalogNamespace?;
    get catalogNamespace(): string;
    set catalogNamespace(value: string);
    resetCatalogNamespace(): void;
    get catalogNamespaceInput(): string | undefined;
    private _catalogTableName?;
    get catalogTableName(): string;
    set catalogTableName(value: string);
    get catalogTableNameInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): IcebergTableFromRestDescribeOutputList;
    private _enableIcebergMergeOnRead?;
    get enableIcebergMergeOnRead(): boolean | cdktn.IResolvable;
    set enableIcebergMergeOnRead(value: boolean | cdktn.IResolvable);
    resetEnableIcebergMergeOnRead(): void;
    get enableIcebergMergeOnReadInput(): boolean | cdktn.IResolvable | undefined;
    private _externalVolume?;
    get externalVolume(): string;
    set externalVolume(value: string);
    resetExternalVolume(): void;
    get externalVolumeInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _icebergMergeOnReadBehavior?;
    get icebergMergeOnReadBehavior(): string;
    set icebergMergeOnReadBehavior(value: string);
    resetIcebergMergeOnReadBehavior(): void;
    get icebergMergeOnReadBehaviorInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): IcebergTableFromRestParametersList;
    private _pathLayout?;
    get pathLayout(): string;
    set pathLayout(value: string);
    resetPathLayout(): void;
    get pathLayoutInput(): string | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): boolean | cdktn.IResolvable;
    set replaceInvalidCharacters(value: boolean | cdktn.IResolvable);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): boolean | cdktn.IResolvable | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): IcebergTableFromRestShowOutputList;
    private _storageSerializationPolicy?;
    get storageSerializationPolicy(): string;
    set storageSerializationPolicy(value: string);
    resetStorageSerializationPolicy(): void;
    get storageSerializationPolicyInput(): string | undefined;
    private _targetFileSize?;
    get targetFileSize(): string;
    set targetFileSize(value: string);
    resetTargetFileSize(): void;
    get targetFileSizeInput(): string | undefined;
    private _timeouts;
    get timeouts(): IcebergTableFromRestTimeoutsOutputReference;
    putTimeouts(value: IcebergTableFromRestTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | IcebergTableFromRestTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
