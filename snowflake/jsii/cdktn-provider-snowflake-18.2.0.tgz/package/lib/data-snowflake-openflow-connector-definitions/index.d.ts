/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeOpenflowConnectorDefinitionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.21.0/docs/data-sources/openflow_connector_definitions#id DataSnowflakeOpenflowConnectorDefinitions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.21.0/docs/data-sources/openflow_connector_definitions#like DataSnowflakeOpenflowConnectorDefinitions#like}
    */
    readonly like?: string;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.21.0/docs/data-sources/openflow_connector_definitions#limit DataSnowflakeOpenflowConnectorDefinitions#limit}
    */
    readonly limit?: DataSnowflakeOpenflowConnectorDefinitionsLimit;
}
export interface DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsShowOutput {
}
export declare function dataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsShowOutputToTerraform(struct?: DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsShowOutput): any;
export declare function dataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsShowOutputToHclTerraform(struct?: DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsShowOutput): any;
export declare class DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsShowOutput | undefined;
    set internalValue(value: DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsShowOutput | undefined);
    get categories(): string[];
    get description(): string;
    get displayName(): string;
    get maxNodeCount(): number;
    get minRuntimeNodeType(): string;
    get name(): string;
    get provider(): string;
    get version(): string;
}
export declare class DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsShowOutputOutputReference;
}
export interface DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitions {
}
export declare function dataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsToTerraform(struct?: DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitions): any;
export declare function dataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsToHclTerraform(struct?: DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitions): any;
export declare class DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitions | undefined;
    set internalValue(value: DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitions | undefined);
    private _showOutput;
    get showOutput(): DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsShowOutputList;
}
export declare class DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsOutputReference;
}
export interface DataSnowflakeOpenflowConnectorDefinitionsLimit {
    /**
    * Specifies a **case-sensitive** pattern that is used to match object name. After the first match, the limit on the number of rows will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.21.0/docs/data-sources/openflow_connector_definitions#from DataSnowflakeOpenflowConnectorDefinitions#from}
    */
    readonly from?: string;
    /**
    * The maximum number of rows to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.21.0/docs/data-sources/openflow_connector_definitions#rows DataSnowflakeOpenflowConnectorDefinitions#rows}
    */
    readonly rows: number;
}
export declare function dataSnowflakeOpenflowConnectorDefinitionsLimitToTerraform(struct?: DataSnowflakeOpenflowConnectorDefinitionsLimitOutputReference | DataSnowflakeOpenflowConnectorDefinitionsLimit): any;
export declare function dataSnowflakeOpenflowConnectorDefinitionsLimitToHclTerraform(struct?: DataSnowflakeOpenflowConnectorDefinitionsLimitOutputReference | DataSnowflakeOpenflowConnectorDefinitionsLimit): any;
export declare class DataSnowflakeOpenflowConnectorDefinitionsLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeOpenflowConnectorDefinitionsLimit | undefined;
    set internalValue(value: DataSnowflakeOpenflowConnectorDefinitionsLimit | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _rows?;
    get rows(): number;
    set rows(value: number);
    get rowsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.21.0/docs/data-sources/openflow_connector_definitions snowflake_openflow_connector_definitions}
*/
export declare class DataSnowflakeOpenflowConnectorDefinitions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_openflow_connector_definitions";
    /**
    * Generates CDKTN code for importing a DataSnowflakeOpenflowConnectorDefinitions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeOpenflowConnectorDefinitions to import
    * @param importFromId The id of the existing DataSnowflakeOpenflowConnectorDefinitions that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.21.0/docs/data-sources/openflow_connector_definitions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeOpenflowConnectorDefinitions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.21.0/docs/data-sources/openflow_connector_definitions snowflake_openflow_connector_definitions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeOpenflowConnectorDefinitionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeOpenflowConnectorDefinitionsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _openflowConnectorDefinitions;
    get openflowConnectorDefinitions(): DataSnowflakeOpenflowConnectorDefinitionsOpenflowConnectorDefinitionsList;
    private _limit;
    get limit(): DataSnowflakeOpenflowConnectorDefinitionsLimitOutputReference;
    putLimit(value: DataSnowflakeOpenflowConnectorDefinitionsLimit): void;
    resetLimit(): void;
    get limitInput(): DataSnowflakeOpenflowConnectorDefinitionsLimit | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
