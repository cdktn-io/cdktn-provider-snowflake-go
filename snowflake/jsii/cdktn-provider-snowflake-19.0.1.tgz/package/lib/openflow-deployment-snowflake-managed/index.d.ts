/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OpenflowDeploymentSnowflakeManagedConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the Openflow deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_deployment_snowflake_managed#comment OpenflowDeploymentSnowflakeManaged#comment}
    */
    readonly comment?: string;
    /**
    * A free-text alias for the deployment. Shown in the Openflow UI in place of the deployment's identifier when set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_deployment_snowflake_managed#display_name OpenflowDeploymentSnowflakeManaged#display_name}
    */
    readonly displayName?: string;
    /**
    * Specifies the name of the event table for logging messages from stored procedures and UDFs contained by the object with which the event table is associated. Associating an event table with a database is available in [Enterprise Edition or higher](https://docs.snowflake.com/en/user-guide/intro-editions). For more information, check [EVENT_TABLE docs](https://docs.snowflake.com/en/sql-reference/parameters#event-table).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_deployment_snowflake_managed#event_table OpenflowDeploymentSnowflakeManaged#event_table}
    */
    readonly eventTable?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_deployment_snowflake_managed#id OpenflowDeploymentSnowflakeManaged#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the Openflow deployment; must be unique for the account. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_deployment_snowflake_managed#name OpenflowDeploymentSnowflakeManaged#name}
    */
    readonly name: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_deployment_snowflake_managed#timeouts OpenflowDeploymentSnowflakeManaged#timeouts}
    */
    readonly timeouts?: OpenflowDeploymentSnowflakeManagedTimeouts;
}
export interface OpenflowDeploymentSnowflakeManagedDescribeOutput {
}
export declare function openflowDeploymentSnowflakeManagedDescribeOutputToTerraform(struct?: OpenflowDeploymentSnowflakeManagedDescribeOutput): any;
export declare function openflowDeploymentSnowflakeManagedDescribeOutputToHclTerraform(struct?: OpenflowDeploymentSnowflakeManagedDescribeOutput): any;
export declare class OpenflowDeploymentSnowflakeManagedDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OpenflowDeploymentSnowflakeManagedDescribeOutput | undefined;
    set internalValue(value: OpenflowDeploymentSnowflakeManagedDescribeOutput | undefined);
    get comment(): string;
    get customIngressHostname(): string;
    get displayName(): string;
    get key(): string;
    get name(): string;
    get owner(): string;
    get status(): string;
    get type(): string;
    get usePrivateLink(): cdktn.IResolvable;
    get useUserAuthOverPrivateLink(): cdktn.IResolvable;
    get vpcType(): string;
}
export declare class OpenflowDeploymentSnowflakeManagedDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OpenflowDeploymentSnowflakeManagedDescribeOutputOutputReference;
}
export interface OpenflowDeploymentSnowflakeManagedParametersEventTable {
}
export declare function openflowDeploymentSnowflakeManagedParametersEventTableToTerraform(struct?: OpenflowDeploymentSnowflakeManagedParametersEventTable): any;
export declare function openflowDeploymentSnowflakeManagedParametersEventTableToHclTerraform(struct?: OpenflowDeploymentSnowflakeManagedParametersEventTable): any;
export declare class OpenflowDeploymentSnowflakeManagedParametersEventTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OpenflowDeploymentSnowflakeManagedParametersEventTable | undefined;
    set internalValue(value: OpenflowDeploymentSnowflakeManagedParametersEventTable | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class OpenflowDeploymentSnowflakeManagedParametersEventTableList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OpenflowDeploymentSnowflakeManagedParametersEventTableOutputReference;
}
export interface OpenflowDeploymentSnowflakeManagedParameters {
}
export declare function openflowDeploymentSnowflakeManagedParametersToTerraform(struct?: OpenflowDeploymentSnowflakeManagedParameters): any;
export declare function openflowDeploymentSnowflakeManagedParametersToHclTerraform(struct?: OpenflowDeploymentSnowflakeManagedParameters): any;
export declare class OpenflowDeploymentSnowflakeManagedParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OpenflowDeploymentSnowflakeManagedParameters | undefined;
    set internalValue(value: OpenflowDeploymentSnowflakeManagedParameters | undefined);
    private _eventTable;
    get eventTable(): OpenflowDeploymentSnowflakeManagedParametersEventTableList;
}
export declare class OpenflowDeploymentSnowflakeManagedParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OpenflowDeploymentSnowflakeManagedParametersOutputReference;
}
export interface OpenflowDeploymentSnowflakeManagedShowOutput {
}
export declare function openflowDeploymentSnowflakeManagedShowOutputToTerraform(struct?: OpenflowDeploymentSnowflakeManagedShowOutput): any;
export declare function openflowDeploymentSnowflakeManagedShowOutputToHclTerraform(struct?: OpenflowDeploymentSnowflakeManagedShowOutput): any;
export declare class OpenflowDeploymentSnowflakeManagedShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OpenflowDeploymentSnowflakeManagedShowOutput | undefined;
    set internalValue(value: OpenflowDeploymentSnowflakeManagedShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get customIngressHostname(): string;
    get displayName(): string;
    get key(): string;
    get name(): string;
    get owner(): string;
    get status(): string;
    get type(): string;
    get updatedOn(): string;
    get usePrivateLink(): cdktn.IResolvable;
    get useUserAuthOverPrivateLink(): cdktn.IResolvable;
    get vpcType(): string;
}
export declare class OpenflowDeploymentSnowflakeManagedShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OpenflowDeploymentSnowflakeManagedShowOutputOutputReference;
}
export interface OpenflowDeploymentSnowflakeManagedTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_deployment_snowflake_managed#create OpenflowDeploymentSnowflakeManaged#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_deployment_snowflake_managed#delete OpenflowDeploymentSnowflakeManaged#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_deployment_snowflake_managed#read OpenflowDeploymentSnowflakeManaged#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_deployment_snowflake_managed#update OpenflowDeploymentSnowflakeManaged#update}
    */
    readonly update?: string;
}
export declare function openflowDeploymentSnowflakeManagedTimeoutsToTerraform(struct?: OpenflowDeploymentSnowflakeManagedTimeouts | cdktn.IResolvable): any;
export declare function openflowDeploymentSnowflakeManagedTimeoutsToHclTerraform(struct?: OpenflowDeploymentSnowflakeManagedTimeouts | cdktn.IResolvable): any;
export declare class OpenflowDeploymentSnowflakeManagedTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OpenflowDeploymentSnowflakeManagedTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: OpenflowDeploymentSnowflakeManagedTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_deployment_snowflake_managed snowflake_openflow_deployment_snowflake_managed}
*/
export declare class OpenflowDeploymentSnowflakeManaged extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_openflow_deployment_snowflake_managed";
    /**
    * Generates CDKTN code for importing a OpenflowDeploymentSnowflakeManaged resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OpenflowDeploymentSnowflakeManaged to import
    * @param importFromId The id of the existing OpenflowDeploymentSnowflakeManaged that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_deployment_snowflake_managed#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OpenflowDeploymentSnowflakeManaged to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_deployment_snowflake_managed snowflake_openflow_deployment_snowflake_managed} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OpenflowDeploymentSnowflakeManagedConfig
    */
    constructor(scope: Construct, id: string, config: OpenflowDeploymentSnowflakeManagedConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): OpenflowDeploymentSnowflakeManagedDescribeOutputList;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _eventTable?;
    get eventTable(): string;
    set eventTable(value: string);
    resetEventTable(): void;
    get eventTableInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): OpenflowDeploymentSnowflakeManagedParametersList;
    private _showOutput;
    get showOutput(): OpenflowDeploymentSnowflakeManagedShowOutputList;
    get type(): string;
    private _timeouts;
    get timeouts(): OpenflowDeploymentSnowflakeManagedTimeoutsOutputReference;
    putTimeouts(value: OpenflowDeploymentSnowflakeManagedTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | OpenflowDeploymentSnowflakeManagedTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
