/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeOpenflowDeploymentsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_deployments#id DataSnowflakeOpenflowDeployments#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_deployments#like DataSnowflakeOpenflowDeployments#like}
    */
    readonly like?: string;
    /**
    * Filters the output with **case-sensitive** characters indicating the beginning of the object name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_deployments#starts_with DataSnowflakeOpenflowDeployments#starts_with}
    */
    readonly startsWith?: string;
    /**
    * (Default: `true`) Runs DESC OPENFLOW DEPLOYMENT for each deployment returned by SHOW OPENFLOW DEPLOYMENTS. The output of describe is saved to the description field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_deployments#with_describe DataSnowflakeOpenflowDeployments#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * (Default: `true`) Runs SHOW PARAMETERS IN OPENFLOW DEPLOYMENT for each deployment returned by SHOW OPENFLOW DEPLOYMENTS. The output is saved to the parameters field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_deployments#with_parameters DataSnowflakeOpenflowDeployments#with_parameters}
    */
    readonly withParameters?: boolean | cdktn.IResolvable;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_deployments#limit DataSnowflakeOpenflowDeployments#limit}
    */
    readonly limit?: DataSnowflakeOpenflowDeploymentsLimit;
}
export interface DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsDescribeOutput {
}
export declare function dataSnowflakeOpenflowDeploymentsOpenflowDeploymentsDescribeOutputToTerraform(struct?: DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsDescribeOutput): any;
export declare function dataSnowflakeOpenflowDeploymentsOpenflowDeploymentsDescribeOutputToHclTerraform(struct?: DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsDescribeOutput): any;
export declare class DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsDescribeOutput | undefined);
    get comment(): string;
    get customIngressHostname(): string;
    get displayName(): string;
    get key(): string;
    get name(): string;
    get owner(): string;
    get status(): string;
    get type(): string;
    get usePrivateLink(): cdktn.IResolvable;
    get useUserAuthOverPrivateLink(): cdktn.IResolvable;
    get vpcType(): string;
}
export declare class DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsDescribeOutputOutputReference;
}
export interface DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersEventTable {
}
export declare function dataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersEventTableToTerraform(struct?: DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersEventTable): any;
export declare function dataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersEventTableToHclTerraform(struct?: DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersEventTable): any;
export declare class DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersEventTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersEventTable | undefined;
    set internalValue(value: DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersEventTable | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersEventTableList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersEventTableOutputReference;
}
export interface DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParameters {
}
export declare function dataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersToTerraform(struct?: DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParameters): any;
export declare function dataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersToHclTerraform(struct?: DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParameters): any;
export declare class DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParameters | undefined;
    set internalValue(value: DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParameters | undefined);
    private _eventTable;
    get eventTable(): DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersEventTableList;
}
export declare class DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersOutputReference;
}
export interface DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsShowOutput {
}
export declare function dataSnowflakeOpenflowDeploymentsOpenflowDeploymentsShowOutputToTerraform(struct?: DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsShowOutput): any;
export declare function dataSnowflakeOpenflowDeploymentsOpenflowDeploymentsShowOutputToHclTerraform(struct?: DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsShowOutput): any;
export declare class DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsShowOutput | undefined;
    set internalValue(value: DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get customIngressHostname(): string;
    get displayName(): string;
    get key(): string;
    get name(): string;
    get owner(): string;
    get status(): string;
    get type(): string;
    get updatedOn(): string;
    get usePrivateLink(): cdktn.IResolvable;
    get useUserAuthOverPrivateLink(): cdktn.IResolvable;
    get vpcType(): string;
}
export declare class DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsShowOutputOutputReference;
}
export interface DataSnowflakeOpenflowDeploymentsOpenflowDeployments {
}
export declare function dataSnowflakeOpenflowDeploymentsOpenflowDeploymentsToTerraform(struct?: DataSnowflakeOpenflowDeploymentsOpenflowDeployments): any;
export declare function dataSnowflakeOpenflowDeploymentsOpenflowDeploymentsToHclTerraform(struct?: DataSnowflakeOpenflowDeploymentsOpenflowDeployments): any;
export declare class DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeOpenflowDeploymentsOpenflowDeployments | undefined;
    set internalValue(value: DataSnowflakeOpenflowDeploymentsOpenflowDeployments | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsDescribeOutputList;
    private _parameters;
    get parameters(): DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsParametersList;
    private _showOutput;
    get showOutput(): DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsShowOutputList;
}
export declare class DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsOutputReference;
}
export interface DataSnowflakeOpenflowDeploymentsLimit {
    /**
    * Specifies a **case-sensitive** pattern that is used to match object name. After the first match, the limit on the number of rows will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_deployments#from DataSnowflakeOpenflowDeployments#from}
    */
    readonly from?: string;
    /**
    * The maximum number of rows to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_deployments#rows DataSnowflakeOpenflowDeployments#rows}
    */
    readonly rows: number;
}
export declare function dataSnowflakeOpenflowDeploymentsLimitToTerraform(struct?: DataSnowflakeOpenflowDeploymentsLimitOutputReference | DataSnowflakeOpenflowDeploymentsLimit): any;
export declare function dataSnowflakeOpenflowDeploymentsLimitToHclTerraform(struct?: DataSnowflakeOpenflowDeploymentsLimitOutputReference | DataSnowflakeOpenflowDeploymentsLimit): any;
export declare class DataSnowflakeOpenflowDeploymentsLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeOpenflowDeploymentsLimit | undefined;
    set internalValue(value: DataSnowflakeOpenflowDeploymentsLimit | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _rows?;
    get rows(): number;
    set rows(value: number);
    get rowsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_deployments snowflake_openflow_deployments}
*/
export declare class DataSnowflakeOpenflowDeployments extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_openflow_deployments";
    /**
    * Generates CDKTN code for importing a DataSnowflakeOpenflowDeployments resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeOpenflowDeployments to import
    * @param importFromId The id of the existing DataSnowflakeOpenflowDeployments that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_deployments#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeOpenflowDeployments to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_deployments snowflake_openflow_deployments} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeOpenflowDeploymentsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeOpenflowDeploymentsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _openflowDeployments;
    get openflowDeployments(): DataSnowflakeOpenflowDeploymentsOpenflowDeploymentsList;
    private _startsWith?;
    get startsWith(): string;
    set startsWith(value: string);
    resetStartsWith(): void;
    get startsWithInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _withParameters?;
    get withParameters(): boolean | cdktn.IResolvable;
    set withParameters(value: boolean | cdktn.IResolvable);
    resetWithParameters(): void;
    get withParametersInput(): boolean | cdktn.IResolvable | undefined;
    private _limit;
    get limit(): DataSnowflakeOpenflowDeploymentsLimitOutputReference;
    putLimit(value: DataSnowflakeOpenflowDeploymentsLimit): void;
    resetLimit(): void;
    get limitInput(): DataSnowflakeOpenflowDeploymentsLimit | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
