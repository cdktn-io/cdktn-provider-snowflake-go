/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeHybridTablesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables#id DataSnowflakeHybridTables#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables#like DataSnowflakeHybridTables#like}
    */
    readonly like?: string;
    /**
    * Filters the output with **case-sensitive** characters indicating the beginning of the object name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables#starts_with DataSnowflakeHybridTables#starts_with}
    */
    readonly startsWith?: string;
    /**
    * (Default: `true`) Runs DESC TABLE for each hybrid table returned by SHOW HYBRID TABLES. The output of describe is saved to the describe_output field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables#with_describe DataSnowflakeHybridTables#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * (Default: `false`) Runs SHOW INDEXES for each hybrid table returned by SHOW HYBRID TABLES. The output is saved to the show_indexes field. By default this value is set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables#with_indexes DataSnowflakeHybridTables#with_indexes}
    */
    readonly withIndexes?: boolean | cdktn.IResolvable;
    /**
    * (Default: `false`) Runs SHOW PRIMARY KEYS, SHOW UNIQUE KEYS, and SHOW IMPORTED KEYS for each hybrid table returned by SHOW HYBRID TABLES. The merged constraints are saved to the show_keys_output field, grouped by constraint name and ordered by kind, then by column names. By default this value is set to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables#with_keys DataSnowflakeHybridTables#with_keys}
    */
    readonly withKeys?: boolean | cdktn.IResolvable;
    /**
    * (Default: `true`) Runs SHOW PARAMETERS FOR TABLE for each hybrid table returned by SHOW HYBRID TABLES. The output is saved to the parameters field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables#with_parameters DataSnowflakeHybridTables#with_parameters}
    */
    readonly withParameters?: boolean | cdktn.IResolvable;
    /**
    * in block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables#in DataSnowflakeHybridTables#in}
    */
    readonly in?: DataSnowflakeHybridTablesIn;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables#limit DataSnowflakeHybridTables#limit}
    */
    readonly limit?: DataSnowflakeHybridTablesLimit;
}
export interface DataSnowflakeHybridTablesHybridTablesDescribeOutput {
}
export declare function dataSnowflakeHybridTablesHybridTablesDescribeOutputToTerraform(struct?: DataSnowflakeHybridTablesHybridTablesDescribeOutput): any;
export declare function dataSnowflakeHybridTablesHybridTablesDescribeOutputToHclTerraform(struct?: DataSnowflakeHybridTablesHybridTablesDescribeOutput): any;
export declare class DataSnowflakeHybridTablesHybridTablesDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeHybridTablesHybridTablesDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeHybridTablesHybridTablesDescribeOutput | undefined);
    get check(): string;
    get collation(): string;
    get comment(): string;
    get default(): string;
    get expression(): string;
    get isNullable(): cdktn.IResolvable;
    get kind(): string;
    get name(): string;
    get policyName(): string;
    get primaryKey(): cdktn.IResolvable;
    get privacyDomain(): string;
    get schemaEvolutionRecord(): string;
    get type(): string;
    get uniqueKey(): cdktn.IResolvable;
}
export declare class DataSnowflakeHybridTablesHybridTablesDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeHybridTablesHybridTablesDescribeOutputOutputReference;
}
export interface DataSnowflakeHybridTablesHybridTablesParametersDataRetentionTimeInDays {
}
export declare function dataSnowflakeHybridTablesHybridTablesParametersDataRetentionTimeInDaysToTerraform(struct?: DataSnowflakeHybridTablesHybridTablesParametersDataRetentionTimeInDays): any;
export declare function dataSnowflakeHybridTablesHybridTablesParametersDataRetentionTimeInDaysToHclTerraform(struct?: DataSnowflakeHybridTablesHybridTablesParametersDataRetentionTimeInDays): any;
export declare class DataSnowflakeHybridTablesHybridTablesParametersDataRetentionTimeInDaysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeHybridTablesHybridTablesParametersDataRetentionTimeInDays | undefined;
    set internalValue(value: DataSnowflakeHybridTablesHybridTablesParametersDataRetentionTimeInDays | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeHybridTablesHybridTablesParametersDataRetentionTimeInDaysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeHybridTablesHybridTablesParametersDataRetentionTimeInDaysOutputReference;
}
export interface DataSnowflakeHybridTablesHybridTablesParametersMaxDataExtensionTimeInDays {
}
export declare function dataSnowflakeHybridTablesHybridTablesParametersMaxDataExtensionTimeInDaysToTerraform(struct?: DataSnowflakeHybridTablesHybridTablesParametersMaxDataExtensionTimeInDays): any;
export declare function dataSnowflakeHybridTablesHybridTablesParametersMaxDataExtensionTimeInDaysToHclTerraform(struct?: DataSnowflakeHybridTablesHybridTablesParametersMaxDataExtensionTimeInDays): any;
export declare class DataSnowflakeHybridTablesHybridTablesParametersMaxDataExtensionTimeInDaysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeHybridTablesHybridTablesParametersMaxDataExtensionTimeInDays | undefined;
    set internalValue(value: DataSnowflakeHybridTablesHybridTablesParametersMaxDataExtensionTimeInDays | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeHybridTablesHybridTablesParametersMaxDataExtensionTimeInDaysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeHybridTablesHybridTablesParametersMaxDataExtensionTimeInDaysOutputReference;
}
export interface DataSnowflakeHybridTablesHybridTablesParameters {
}
export declare function dataSnowflakeHybridTablesHybridTablesParametersToTerraform(struct?: DataSnowflakeHybridTablesHybridTablesParameters): any;
export declare function dataSnowflakeHybridTablesHybridTablesParametersToHclTerraform(struct?: DataSnowflakeHybridTablesHybridTablesParameters): any;
export declare class DataSnowflakeHybridTablesHybridTablesParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeHybridTablesHybridTablesParameters | undefined;
    set internalValue(value: DataSnowflakeHybridTablesHybridTablesParameters | undefined);
    private _dataRetentionTimeInDays;
    get dataRetentionTimeInDays(): DataSnowflakeHybridTablesHybridTablesParametersDataRetentionTimeInDaysList;
    private _maxDataExtensionTimeInDays;
    get maxDataExtensionTimeInDays(): DataSnowflakeHybridTablesHybridTablesParametersMaxDataExtensionTimeInDaysList;
}
export declare class DataSnowflakeHybridTablesHybridTablesParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeHybridTablesHybridTablesParametersOutputReference;
}
export interface DataSnowflakeHybridTablesHybridTablesShowIndexes {
}
export declare function dataSnowflakeHybridTablesHybridTablesShowIndexesToTerraform(struct?: DataSnowflakeHybridTablesHybridTablesShowIndexes): any;
export declare function dataSnowflakeHybridTablesHybridTablesShowIndexesToHclTerraform(struct?: DataSnowflakeHybridTablesHybridTablesShowIndexes): any;
export declare class DataSnowflakeHybridTablesHybridTablesShowIndexesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeHybridTablesHybridTablesShowIndexes | undefined;
    set internalValue(value: DataSnowflakeHybridTablesHybridTablesShowIndexes | undefined);
    get columns(): string;
    get createdOn(): string;
    get databaseName(): string;
    get includedColumns(): string;
    get isUnique(): cdktn.IResolvable;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get schemaName(): string;
    get tableName(): string;
}
export declare class DataSnowflakeHybridTablesHybridTablesShowIndexesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeHybridTablesHybridTablesShowIndexesOutputReference;
}
export interface DataSnowflakeHybridTablesHybridTablesShowKeysOutput {
}
export declare function dataSnowflakeHybridTablesHybridTablesShowKeysOutputToTerraform(struct?: DataSnowflakeHybridTablesHybridTablesShowKeysOutput): any;
export declare function dataSnowflakeHybridTablesHybridTablesShowKeysOutputToHclTerraform(struct?: DataSnowflakeHybridTablesHybridTablesShowKeysOutput): any;
export declare class DataSnowflakeHybridTablesHybridTablesShowKeysOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeHybridTablesHybridTablesShowKeysOutput | undefined;
    set internalValue(value: DataSnowflakeHybridTablesHybridTablesShowKeysOutput | undefined);
    get columns(): string[];
    get deleteRule(): string;
    get kind(): string;
    get name(): string;
    get referencedColumns(): string[];
    get referencedTable(): string;
    get updateRule(): string;
}
export declare class DataSnowflakeHybridTablesHybridTablesShowKeysOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeHybridTablesHybridTablesShowKeysOutputOutputReference;
}
export interface DataSnowflakeHybridTablesHybridTablesShowOutput {
}
export declare function dataSnowflakeHybridTablesHybridTablesShowOutputToTerraform(struct?: DataSnowflakeHybridTablesHybridTablesShowOutput): any;
export declare function dataSnowflakeHybridTablesHybridTablesShowOutputToHclTerraform(struct?: DataSnowflakeHybridTablesHybridTablesShowOutput): any;
export declare class DataSnowflakeHybridTablesHybridTablesShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeHybridTablesHybridTablesShowOutput | undefined;
    set internalValue(value: DataSnowflakeHybridTablesHybridTablesShowOutput | undefined);
    get bytes(): number;
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get rows(): number;
    get schemaName(): string;
}
export declare class DataSnowflakeHybridTablesHybridTablesShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeHybridTablesHybridTablesShowOutputOutputReference;
}
export interface DataSnowflakeHybridTablesHybridTables {
}
export declare function dataSnowflakeHybridTablesHybridTablesToTerraform(struct?: DataSnowflakeHybridTablesHybridTables): any;
export declare function dataSnowflakeHybridTablesHybridTablesToHclTerraform(struct?: DataSnowflakeHybridTablesHybridTables): any;
export declare class DataSnowflakeHybridTablesHybridTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeHybridTablesHybridTables | undefined;
    set internalValue(value: DataSnowflakeHybridTablesHybridTables | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeHybridTablesHybridTablesDescribeOutputList;
    private _parameters;
    get parameters(): DataSnowflakeHybridTablesHybridTablesParametersList;
    private _showIndexes;
    get showIndexes(): DataSnowflakeHybridTablesHybridTablesShowIndexesList;
    private _showKeysOutput;
    get showKeysOutput(): DataSnowflakeHybridTablesHybridTablesShowKeysOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeHybridTablesHybridTablesShowOutputList;
}
export declare class DataSnowflakeHybridTablesHybridTablesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeHybridTablesHybridTablesOutputReference;
}
export interface DataSnowflakeHybridTablesIn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables#account DataSnowflakeHybridTables#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the current database in use or for a specified database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables#database DataSnowflakeHybridTables#database}
    */
    readonly database?: string;
    /**
    * Returns records for the current schema in use or a specified schema. Use fully qualified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables#schema DataSnowflakeHybridTables#schema}
    */
    readonly schema?: string;
}
export declare function dataSnowflakeHybridTablesInToTerraform(struct?: DataSnowflakeHybridTablesInOutputReference | DataSnowflakeHybridTablesIn): any;
export declare function dataSnowflakeHybridTablesInToHclTerraform(struct?: DataSnowflakeHybridTablesInOutputReference | DataSnowflakeHybridTablesIn): any;
export declare class DataSnowflakeHybridTablesInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeHybridTablesIn | undefined;
    set internalValue(value: DataSnowflakeHybridTablesIn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export interface DataSnowflakeHybridTablesLimit {
    /**
    * Specifies a **case-sensitive** pattern that is used to match object name. After the first match, the limit on the number of rows will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables#from DataSnowflakeHybridTables#from}
    */
    readonly from?: string;
    /**
    * The maximum number of rows to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables#rows DataSnowflakeHybridTables#rows}
    */
    readonly rows: number;
}
export declare function dataSnowflakeHybridTablesLimitToTerraform(struct?: DataSnowflakeHybridTablesLimitOutputReference | DataSnowflakeHybridTablesLimit): any;
export declare function dataSnowflakeHybridTablesLimitToHclTerraform(struct?: DataSnowflakeHybridTablesLimitOutputReference | DataSnowflakeHybridTablesLimit): any;
export declare class DataSnowflakeHybridTablesLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeHybridTablesLimit | undefined;
    set internalValue(value: DataSnowflakeHybridTablesLimit | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _rows?;
    get rows(): number;
    set rows(value: number);
    get rowsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables snowflake_hybrid_tables}
*/
export declare class DataSnowflakeHybridTables extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_hybrid_tables";
    /**
    * Generates CDKTN code for importing a DataSnowflakeHybridTables resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeHybridTables to import
    * @param importFromId The id of the existing DataSnowflakeHybridTables that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeHybridTables to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/hybrid_tables snowflake_hybrid_tables} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeHybridTablesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeHybridTablesConfig);
    private _hybridTables;
    get hybridTables(): DataSnowflakeHybridTablesHybridTablesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _startsWith?;
    get startsWith(): string;
    set startsWith(value: string);
    resetStartsWith(): void;
    get startsWithInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _withIndexes?;
    get withIndexes(): boolean | cdktn.IResolvable;
    set withIndexes(value: boolean | cdktn.IResolvable);
    resetWithIndexes(): void;
    get withIndexesInput(): boolean | cdktn.IResolvable | undefined;
    private _withKeys?;
    get withKeys(): boolean | cdktn.IResolvable;
    set withKeys(value: boolean | cdktn.IResolvable);
    resetWithKeys(): void;
    get withKeysInput(): boolean | cdktn.IResolvable | undefined;
    private _withParameters?;
    get withParameters(): boolean | cdktn.IResolvable;
    set withParameters(value: boolean | cdktn.IResolvable);
    resetWithParameters(): void;
    get withParametersInput(): boolean | cdktn.IResolvable | undefined;
    private _in;
    get in(): DataSnowflakeHybridTablesInOutputReference;
    putIn(value: DataSnowflakeHybridTablesIn): void;
    resetIn(): void;
    get inInput(): DataSnowflakeHybridTablesIn | undefined;
    private _limit;
    get limit(): DataSnowflakeHybridTablesLimitOutputReference;
    putLimit(value: DataSnowflakeHybridTablesLimit): void;
    resetLimit(): void;
    get limitInput(): DataSnowflakeHybridTablesLimit | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
