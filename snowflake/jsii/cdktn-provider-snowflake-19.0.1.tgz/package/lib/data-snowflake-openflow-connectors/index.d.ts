/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeOpenflowConnectorsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_connectors#id DataSnowflakeOpenflowConnectors#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_connectors#like DataSnowflakeOpenflowConnectors#like}
    */
    readonly like?: string;
    /**
    * Filters the output with **case-sensitive** characters indicating the beginning of the object name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_connectors#starts_with DataSnowflakeOpenflowConnectors#starts_with}
    */
    readonly startsWith?: string;
    /**
    * (Default: `true`) Runs DESC OPENFLOW CONNECTOR for each connector returned by SHOW OPENFLOW CONNECTORS. The output of describe is saved to the description field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_connectors#with_describe DataSnowflakeOpenflowConnectors#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * in block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_connectors#in DataSnowflakeOpenflowConnectors#in}
    */
    readonly in?: DataSnowflakeOpenflowConnectorsIn;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_connectors#limit DataSnowflakeOpenflowConnectors#limit}
    */
    readonly limit?: DataSnowflakeOpenflowConnectorsLimit;
}
export interface DataSnowflakeOpenflowConnectorsOpenflowConnectorsDescribeOutput {
}
export declare function dataSnowflakeOpenflowConnectorsOpenflowConnectorsDescribeOutputToTerraform(struct?: DataSnowflakeOpenflowConnectorsOpenflowConnectorsDescribeOutput): any;
export declare function dataSnowflakeOpenflowConnectorsOpenflowConnectorsDescribeOutputToHclTerraform(struct?: DataSnowflakeOpenflowConnectorsOpenflowConnectorsDescribeOutput): any;
export declare class DataSnowflakeOpenflowConnectorsOpenflowConnectorsDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeOpenflowConnectorsOpenflowConnectorsDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeOpenflowConnectorsOpenflowConnectorsDescribeOutput | undefined);
    get comment(): string;
    get connectorDefinition(): string;
    get connectorUrl(): string;
    get defaultVersion(): string;
    get defaultVersionAlias(): string;
    get defaultVersionGitCommitHash(): string;
    get defaultVersionLocationUri(): string;
    get defaultVersionName(): string;
    get defaultVersionSourceLocationUri(): string;
    get displayName(): string;
    get lastVersionAlias(): string;
    get lastVersionGitCommitHash(): string;
    get lastVersionLocationUri(): string;
    get lastVersionName(): string;
    get lastVersionSourceLocationUri(): string;
    get liveVersionLocationUri(): string;
    get name(): string;
    get owner(): string;
    get runtime(): string;
    get status(): string;
}
export declare class DataSnowflakeOpenflowConnectorsOpenflowConnectorsDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeOpenflowConnectorsOpenflowConnectorsDescribeOutputOutputReference;
}
export interface DataSnowflakeOpenflowConnectorsOpenflowConnectorsShowOutput {
}
export declare function dataSnowflakeOpenflowConnectorsOpenflowConnectorsShowOutputToTerraform(struct?: DataSnowflakeOpenflowConnectorsOpenflowConnectorsShowOutput): any;
export declare function dataSnowflakeOpenflowConnectorsOpenflowConnectorsShowOutputToHclTerraform(struct?: DataSnowflakeOpenflowConnectorsOpenflowConnectorsShowOutput): any;
export declare class DataSnowflakeOpenflowConnectorsOpenflowConnectorsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeOpenflowConnectorsOpenflowConnectorsShowOutput | undefined;
    set internalValue(value: DataSnowflakeOpenflowConnectorsOpenflowConnectorsShowOutput | undefined);
    get comment(): string;
    get connectorDefinition(): string;
    get connectorUrl(): string;
    get createdOn(): string;
    get databaseName(): string;
    get defaultVersion(): string;
    get defaultVersionAlias(): string;
    get defaultVersionLocationUri(): string;
    get defaultVersionName(): string;
    get defaultVersionSourceLocationUri(): string;
    get displayName(): string;
    get liveVersionLocationUri(): string;
    get name(): string;
    get owner(): string;
    get runtime(): string;
    get schemaName(): string;
    get status(): string;
    get updatedOn(): string;
}
export declare class DataSnowflakeOpenflowConnectorsOpenflowConnectorsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeOpenflowConnectorsOpenflowConnectorsShowOutputOutputReference;
}
export interface DataSnowflakeOpenflowConnectorsOpenflowConnectors {
}
export declare function dataSnowflakeOpenflowConnectorsOpenflowConnectorsToTerraform(struct?: DataSnowflakeOpenflowConnectorsOpenflowConnectors): any;
export declare function dataSnowflakeOpenflowConnectorsOpenflowConnectorsToHclTerraform(struct?: DataSnowflakeOpenflowConnectorsOpenflowConnectors): any;
export declare class DataSnowflakeOpenflowConnectorsOpenflowConnectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeOpenflowConnectorsOpenflowConnectors | undefined;
    set internalValue(value: DataSnowflakeOpenflowConnectorsOpenflowConnectors | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeOpenflowConnectorsOpenflowConnectorsDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeOpenflowConnectorsOpenflowConnectorsShowOutputList;
}
export declare class DataSnowflakeOpenflowConnectorsOpenflowConnectorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeOpenflowConnectorsOpenflowConnectorsOutputReference;
}
export interface DataSnowflakeOpenflowConnectorsIn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_connectors#account DataSnowflakeOpenflowConnectors#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the current database in use or for a specified database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_connectors#database DataSnowflakeOpenflowConnectors#database}
    */
    readonly database?: string;
    /**
    * Returns records for the current schema in use or a specified schema. Use fully qualified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_connectors#schema DataSnowflakeOpenflowConnectors#schema}
    */
    readonly schema?: string;
}
export declare function dataSnowflakeOpenflowConnectorsInToTerraform(struct?: DataSnowflakeOpenflowConnectorsInOutputReference | DataSnowflakeOpenflowConnectorsIn): any;
export declare function dataSnowflakeOpenflowConnectorsInToHclTerraform(struct?: DataSnowflakeOpenflowConnectorsInOutputReference | DataSnowflakeOpenflowConnectorsIn): any;
export declare class DataSnowflakeOpenflowConnectorsInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeOpenflowConnectorsIn | undefined;
    set internalValue(value: DataSnowflakeOpenflowConnectorsIn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export interface DataSnowflakeOpenflowConnectorsLimit {
    /**
    * Specifies a **case-sensitive** pattern that is used to match object name. After the first match, the limit on the number of rows will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_connectors#from DataSnowflakeOpenflowConnectors#from}
    */
    readonly from?: string;
    /**
    * The maximum number of rows to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_connectors#rows DataSnowflakeOpenflowConnectors#rows}
    */
    readonly rows: number;
}
export declare function dataSnowflakeOpenflowConnectorsLimitToTerraform(struct?: DataSnowflakeOpenflowConnectorsLimitOutputReference | DataSnowflakeOpenflowConnectorsLimit): any;
export declare function dataSnowflakeOpenflowConnectorsLimitToHclTerraform(struct?: DataSnowflakeOpenflowConnectorsLimitOutputReference | DataSnowflakeOpenflowConnectorsLimit): any;
export declare class DataSnowflakeOpenflowConnectorsLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeOpenflowConnectorsLimit | undefined;
    set internalValue(value: DataSnowflakeOpenflowConnectorsLimit | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _rows?;
    get rows(): number;
    set rows(value: number);
    get rowsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_connectors snowflake_openflow_connectors}
*/
export declare class DataSnowflakeOpenflowConnectors extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_openflow_connectors";
    /**
    * Generates CDKTN code for importing a DataSnowflakeOpenflowConnectors resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeOpenflowConnectors to import
    * @param importFromId The id of the existing DataSnowflakeOpenflowConnectors that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_connectors#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeOpenflowConnectors to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/data-sources/openflow_connectors snowflake_openflow_connectors} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeOpenflowConnectorsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeOpenflowConnectorsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _openflowConnectors;
    get openflowConnectors(): DataSnowflakeOpenflowConnectorsOpenflowConnectorsList;
    private _startsWith?;
    get startsWith(): string;
    set startsWith(value: string);
    resetStartsWith(): void;
    get startsWithInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _in;
    get in(): DataSnowflakeOpenflowConnectorsInOutputReference;
    putIn(value: DataSnowflakeOpenflowConnectorsIn): void;
    resetIn(): void;
    get inInput(): DataSnowflakeOpenflowConnectorsIn | undefined;
    private _limit;
    get limit(): DataSnowflakeOpenflowConnectorsLimitOutputReference;
    putLimit(value: DataSnowflakeOpenflowConnectorsLimit): void;
    resetLimit(): void;
    get limitInput(): DataSnowflakeOpenflowConnectorsLimit | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
