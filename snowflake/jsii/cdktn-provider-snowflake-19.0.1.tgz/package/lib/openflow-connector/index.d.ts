/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OpenflowConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the Openflow connector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#comment OpenflowConnector#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the Openflow connector. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#database OpenflowConnector#database}
    */
    readonly database: string;
    /**
    * A free-text alias for the connector. Shown in the Openflow UI in place of the connector's identifier when set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#display_name OpenflowConnector#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#id OpenflowConnector#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the Openflow connector; must be unique for the schema in which the connector is created. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#name OpenflowConnector#name}
    */
    readonly name: string;
    /**
    * Specifies the fully qualified name of the Openflow runtime the connector runs in. The connector is created in the runtime's schema, so `database` and `schema` must match it. Snowflake has no ALTER for it, so changing it recreates the connector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#runtime OpenflowConnector#runtime}
    */
    readonly runtime: string;
    /**
    * The schema in which to create the Openflow connector. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#schema OpenflowConnector#schema}
    */
    readonly schema: string;
    /**
    * from block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#from OpenflowConnector#from}
    */
    readonly from: OpenflowConnectorFrom;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#timeouts OpenflowConnector#timeouts}
    */
    readonly timeouts?: OpenflowConnectorTimeouts;
}
export interface OpenflowConnectorDescribeOutput {
}
export declare function openflowConnectorDescribeOutputToTerraform(struct?: OpenflowConnectorDescribeOutput): any;
export declare function openflowConnectorDescribeOutputToHclTerraform(struct?: OpenflowConnectorDescribeOutput): any;
export declare class OpenflowConnectorDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OpenflowConnectorDescribeOutput | undefined;
    set internalValue(value: OpenflowConnectorDescribeOutput | undefined);
    get comment(): string;
    get connectorDefinition(): string;
    get connectorUrl(): string;
    get defaultVersion(): string;
    get defaultVersionAlias(): string;
    get defaultVersionGitCommitHash(): string;
    get defaultVersionLocationUri(): string;
    get defaultVersionName(): string;
    get defaultVersionSourceLocationUri(): string;
    get displayName(): string;
    get lastVersionAlias(): string;
    get lastVersionGitCommitHash(): string;
    get lastVersionLocationUri(): string;
    get lastVersionName(): string;
    get lastVersionSourceLocationUri(): string;
    get liveVersionLocationUri(): string;
    get name(): string;
    get owner(): string;
    get runtime(): string;
    get status(): string;
}
export declare class OpenflowConnectorDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OpenflowConnectorDescribeOutputOutputReference;
}
export interface OpenflowConnectorShowOutput {
}
export declare function openflowConnectorShowOutputToTerraform(struct?: OpenflowConnectorShowOutput): any;
export declare function openflowConnectorShowOutputToHclTerraform(struct?: OpenflowConnectorShowOutput): any;
export declare class OpenflowConnectorShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OpenflowConnectorShowOutput | undefined;
    set internalValue(value: OpenflowConnectorShowOutput | undefined);
    get comment(): string;
    get connectorDefinition(): string;
    get connectorUrl(): string;
    get createdOn(): string;
    get databaseName(): string;
    get defaultVersion(): string;
    get defaultVersionAlias(): string;
    get defaultVersionLocationUri(): string;
    get defaultVersionName(): string;
    get defaultVersionSourceLocationUri(): string;
    get displayName(): string;
    get liveVersionLocationUri(): string;
    get name(): string;
    get owner(): string;
    get runtime(): string;
    get schemaName(): string;
    get status(): string;
    get updatedOn(): string;
}
export declare class OpenflowConnectorShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OpenflowConnectorShowOutputOutputReference;
}
export interface OpenflowConnectorFrom {
    /**
    * Catalog definition ID for the connector type, for example `OPENFLOW_POSTGRES_CDC`. List the available IDs with the `snowflake_openflow_connector_definitions` data source. A connector created this way is a draft: it settles on STOPPED and stays there until a configuration version is committed, which this resource does not do.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#definition OpenflowConnector#definition}
    */
    readonly definition?: string;
    /**
    * Path to the bundle within the stage. The bundle's root is used when omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#path OpenflowConnector#path}
    */
    readonly path?: string;
    /**
    * Identifier of a stage holding a complete configuration bundle, which is how a connector arrives already configured and able to start without a commit. A git repository stage works here too.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#stage OpenflowConnector#stage}
    */
    readonly stage?: string;
}
export declare function openflowConnectorFromToTerraform(struct?: OpenflowConnectorFromOutputReference | OpenflowConnectorFrom): any;
export declare function openflowConnectorFromToHclTerraform(struct?: OpenflowConnectorFromOutputReference | OpenflowConnectorFrom): any;
export declare class OpenflowConnectorFromOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OpenflowConnectorFrom | undefined;
    set internalValue(value: OpenflowConnectorFrom | undefined);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    resetDefinition(): void;
    get definitionInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _stage?;
    get stage(): string;
    set stage(value: string);
    resetStage(): void;
    get stageInput(): string | undefined;
}
export interface OpenflowConnectorTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#create OpenflowConnector#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#delete OpenflowConnector#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#read OpenflowConnector#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#update OpenflowConnector#update}
    */
    readonly update?: string;
}
export declare function openflowConnectorTimeoutsToTerraform(struct?: OpenflowConnectorTimeouts | cdktn.IResolvable): any;
export declare function openflowConnectorTimeoutsToHclTerraform(struct?: OpenflowConnectorTimeouts | cdktn.IResolvable): any;
export declare class OpenflowConnectorTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OpenflowConnectorTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: OpenflowConnectorTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector snowflake_openflow_connector}
*/
export declare class OpenflowConnector extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_openflow_connector";
    /**
    * Generates CDKTN code for importing a OpenflowConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OpenflowConnector to import
    * @param importFromId The id of the existing OpenflowConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OpenflowConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.1/docs/resources/openflow_connector snowflake_openflow_connector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OpenflowConnectorConfig
    */
    constructor(scope: Construct, id: string, config: OpenflowConnectorConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): OpenflowConnectorDescribeOutputList;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _runtime?;
    get runtime(): string;
    set runtime(value: string);
    get runtimeInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): OpenflowConnectorShowOutputList;
    private _from;
    get from(): OpenflowConnectorFromOutputReference;
    putFrom(value: OpenflowConnectorFrom): void;
    get fromInput(): OpenflowConnectorFrom | undefined;
    private _timeouts;
    get timeouts(): OpenflowConnectorTimeoutsOutputReference;
    putTimeouts(value: OpenflowConnectorTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | OpenflowConnectorTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
