/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OpenflowDeploymentByocConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the Openflow deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc#comment OpenflowDeploymentByoc#comment}
    */
    readonly comment?: string;
    /**
    * Specifies a custom hostname for ingress into the deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc#custom_ingress_hostname OpenflowDeploymentByoc#custom_ingress_hostname}
    */
    readonly customIngressHostname?: string;
    /**
    * A free-text alias for the deployment. Shown in the Openflow UI in place of the deployment's identifier when set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc#display_name OpenflowDeploymentByoc#display_name}
    */
    readonly displayName?: string;
    /**
    * Specifies the name of the event table for logging messages from stored procedures and UDFs contained by the object with which the event table is associated. Associating an event table with a database is available in [Enterprise Edition or higher](https://docs.snowflake.com/en/user-guide/intro-editions). For more information, check [EVENT_TABLE docs](https://docs.snowflake.com/en/sql-reference/parameters#event-table).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc#event_table OpenflowDeploymentByoc#event_table}
    */
    readonly eventTable?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc#id OpenflowDeploymentByoc#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the Openflow deployment; must be unique for the account. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc#name OpenflowDeploymentByoc#name}
    */
    readonly name: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether the deployment is reached over private link. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc#use_private_link OpenflowDeploymentByoc#use_private_link}
    */
    readonly usePrivateLink?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether user authentication is performed over private link. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc#use_user_auth_over_privatelink OpenflowDeploymentByoc#use_user_auth_over_privatelink}
    */
    readonly useUserAuthOverPrivatelink?: string;
    /**
    * Specifies whether the deployment's VPC is created by Snowflake or supplied by you. Valid values are (case-insensitive): `MANAGED` | `PROVIDED`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc#vpc_type OpenflowDeploymentByoc#vpc_type}
    */
    readonly vpcType: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc#timeouts OpenflowDeploymentByoc#timeouts}
    */
    readonly timeouts?: OpenflowDeploymentByocTimeouts;
}
export interface OpenflowDeploymentByocDescribeOutput {
}
export declare function openflowDeploymentByocDescribeOutputToTerraform(struct?: OpenflowDeploymentByocDescribeOutput): any;
export declare function openflowDeploymentByocDescribeOutputToHclTerraform(struct?: OpenflowDeploymentByocDescribeOutput): any;
export declare class OpenflowDeploymentByocDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OpenflowDeploymentByocDescribeOutput | undefined;
    set internalValue(value: OpenflowDeploymentByocDescribeOutput | undefined);
    get comment(): string;
    get customIngressHostname(): string;
    get displayName(): string;
    get key(): string;
    get name(): string;
    get owner(): string;
    get status(): string;
    get type(): string;
    get usePrivateLink(): cdktn.IResolvable;
    get useUserAuthOverPrivateLink(): cdktn.IResolvable;
    get vpcType(): string;
}
export declare class OpenflowDeploymentByocDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OpenflowDeploymentByocDescribeOutputOutputReference;
}
export interface OpenflowDeploymentByocParametersEventTable {
}
export declare function openflowDeploymentByocParametersEventTableToTerraform(struct?: OpenflowDeploymentByocParametersEventTable): any;
export declare function openflowDeploymentByocParametersEventTableToHclTerraform(struct?: OpenflowDeploymentByocParametersEventTable): any;
export declare class OpenflowDeploymentByocParametersEventTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OpenflowDeploymentByocParametersEventTable | undefined;
    set internalValue(value: OpenflowDeploymentByocParametersEventTable | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class OpenflowDeploymentByocParametersEventTableList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OpenflowDeploymentByocParametersEventTableOutputReference;
}
export interface OpenflowDeploymentByocParameters {
}
export declare function openflowDeploymentByocParametersToTerraform(struct?: OpenflowDeploymentByocParameters): any;
export declare function openflowDeploymentByocParametersToHclTerraform(struct?: OpenflowDeploymentByocParameters): any;
export declare class OpenflowDeploymentByocParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OpenflowDeploymentByocParameters | undefined;
    set internalValue(value: OpenflowDeploymentByocParameters | undefined);
    private _eventTable;
    get eventTable(): OpenflowDeploymentByocParametersEventTableList;
}
export declare class OpenflowDeploymentByocParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OpenflowDeploymentByocParametersOutputReference;
}
export interface OpenflowDeploymentByocShowOutput {
}
export declare function openflowDeploymentByocShowOutputToTerraform(struct?: OpenflowDeploymentByocShowOutput): any;
export declare function openflowDeploymentByocShowOutputToHclTerraform(struct?: OpenflowDeploymentByocShowOutput): any;
export declare class OpenflowDeploymentByocShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OpenflowDeploymentByocShowOutput | undefined;
    set internalValue(value: OpenflowDeploymentByocShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get customIngressHostname(): string;
    get displayName(): string;
    get key(): string;
    get name(): string;
    get owner(): string;
    get status(): string;
    get type(): string;
    get updatedOn(): string;
    get usePrivateLink(): cdktn.IResolvable;
    get useUserAuthOverPrivateLink(): cdktn.IResolvable;
    get vpcType(): string;
}
export declare class OpenflowDeploymentByocShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OpenflowDeploymentByocShowOutputOutputReference;
}
export interface OpenflowDeploymentByocTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc#create OpenflowDeploymentByoc#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc#delete OpenflowDeploymentByoc#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc#read OpenflowDeploymentByoc#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc#update OpenflowDeploymentByoc#update}
    */
    readonly update?: string;
}
export declare function openflowDeploymentByocTimeoutsToTerraform(struct?: OpenflowDeploymentByocTimeouts | cdktn.IResolvable): any;
export declare function openflowDeploymentByocTimeoutsToHclTerraform(struct?: OpenflowDeploymentByocTimeouts | cdktn.IResolvable): any;
export declare class OpenflowDeploymentByocTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OpenflowDeploymentByocTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: OpenflowDeploymentByocTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc snowflake_openflow_deployment_byoc}
*/
export declare class OpenflowDeploymentByoc extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_openflow_deployment_byoc";
    /**
    * Generates CDKTN code for importing a OpenflowDeploymentByoc resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OpenflowDeploymentByoc to import
    * @param importFromId The id of the existing OpenflowDeploymentByoc that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OpenflowDeploymentByoc to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/resources/openflow_deployment_byoc snowflake_openflow_deployment_byoc} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OpenflowDeploymentByocConfig
    */
    constructor(scope: Construct, id: string, config: OpenflowDeploymentByocConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _customIngressHostname?;
    get customIngressHostname(): string;
    set customIngressHostname(value: string);
    resetCustomIngressHostname(): void;
    get customIngressHostnameInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): OpenflowDeploymentByocDescribeOutputList;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _eventTable?;
    get eventTable(): string;
    set eventTable(value: string);
    resetEventTable(): void;
    get eventTableInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): OpenflowDeploymentByocParametersList;
    private _showOutput;
    get showOutput(): OpenflowDeploymentByocShowOutputList;
    get type(): string;
    private _usePrivateLink?;
    get usePrivateLink(): string;
    set usePrivateLink(value: string);
    resetUsePrivateLink(): void;
    get usePrivateLinkInput(): string | undefined;
    private _useUserAuthOverPrivatelink?;
    get useUserAuthOverPrivatelink(): string;
    set useUserAuthOverPrivatelink(value: string);
    resetUseUserAuthOverPrivatelink(): void;
    get useUserAuthOverPrivatelinkInput(): string | undefined;
    private _vpcType?;
    get vpcType(): string;
    set vpcType(value: string);
    get vpcTypeInput(): string | undefined;
    private _timeouts;
    get timeouts(): OpenflowDeploymentByocTimeoutsOutputReference;
    putTimeouts(value: OpenflowDeploymentByocTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | OpenflowDeploymentByocTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
