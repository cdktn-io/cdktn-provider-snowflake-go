/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { DataSnowflakeAccountsAccountsParametersAbortDetachedQueryList, DataSnowflakeAccountsAccountsParametersActivePythonProfilerList, DataSnowflakeAccountsAccountsParametersAllowBindValuesAccessList, DataSnowflakeAccountsAccountsParametersAllowClientMfaCachingList, DataSnowflakeAccountsAccountsParametersAllowIdTokenList, DataSnowflakeAccountsAccountsParametersAllowedSpcsWorkloadTypesList, DataSnowflakeAccountsAccountsParametersAutocommitList, DataSnowflakeAccountsAccountsParametersBaseLocationPrefixList, DataSnowflakeAccountsAccountsParametersBinaryInputFormatList, DataSnowflakeAccountsAccountsParametersBinaryOutputFormatList, DataSnowflakeAccountsAccountsParametersCatalogList, DataSnowflakeAccountsAccountsParametersCatalogSyncList, DataSnowflakeAccountsAccountsParametersClientEnableLogInfoStatementParametersList, DataSnowflakeAccountsAccountsParametersClientEncryptionKeySizeList, DataSnowflakeAccountsAccountsParametersClientMemoryLimitList, DataSnowflakeAccountsAccountsParametersClientMetadataRequestUseConnectionCtxList, DataSnowflakeAccountsAccountsParametersClientMetadataUseSessionDatabaseList, DataSnowflakeAccountsAccountsParametersClientPrefetchThreadsList, DataSnowflakeAccountsAccountsParametersClientResultChunkSizeList, DataSnowflakeAccountsAccountsParametersClientResultColumnCaseInsensitiveList, DataSnowflakeAccountsAccountsParametersClientSessionKeepAliveList, DataSnowflakeAccountsAccountsParametersClientSessionKeepAliveHeartbeatFrequencyList, DataSnowflakeAccountsAccountsParametersClientTimestampTypeMappingList, DataSnowflakeAccountsAccountsParametersCortexCodeCliDailyEstCreditLimitPerUserList, DataSnowflakeAccountsAccountsParametersCortexCodeDesktopDailyEstCreditLimitPerUserList, DataSnowflakeAccountsAccountsParametersCortexCodeSnowsightDailyEstCreditLimitPerUserList, DataSnowflakeAccountsAccountsParametersCortexEnabledCrossRegionList, DataSnowflakeAccountsAccountsParametersCortexModelsAllowlistStructList, DataSnowflakeAccountsAccountsParametersCsvTimestampFormatList, DataSnowflakeAccountsAccountsParametersDataMetricScheduleList, DataSnowflakeAccountsAccountsParametersDataRetentionTimeInDaysList, DataSnowflakeAccountsAccountsParametersDateInputFormatList, DataSnowflakeAccountsAccountsParametersDateOutputFormatList, DataSnowflakeAccountsAccountsParametersDefaultDbtVersionList, DataSnowflakeAccountsAccountsParametersDefaultDdlCollationList, DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolCpuList, DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolGpuList, DataSnowflakeAccountsAccountsParametersDefaultNullOrderingList, DataSnowflakeAccountsAccountsParametersDefaultStreamlitComputePoolList, DataSnowflakeAccountsAccountsParametersDefaultStreamlitNotebookWarehouseList, DataSnowflakeAccountsAccountsParametersDisableUiDownloadButtonList, DataSnowflakeAccountsAccountsParametersDisableUserPrivilegeGrantsList, DataSnowflakeAccountsAccountsParametersDisallowedSpcsWorkloadTypesList, DataSnowflakeAccountsAccountsParametersEnableAutomaticSensitiveDataClassificationLogList, DataSnowflakeAccountsAccountsParametersEnableBudgetEventLoggingList, DataSnowflakeAccountsAccountsParametersEnableConsoleOutputList, DataSnowflakeAccountsAccountsParametersEnableCortexAnalystList, DataSnowflakeAccountsAccountsParametersEnableDataCompactionList, DataSnowflakeAccountsAccountsParametersEnableEgressCostOptimizerList, DataSnowflakeAccountsAccountsParametersEnableGetDdlUseDataTypeAliasList, DataSnowflakeAccountsAccountsParametersEnableIcebergMergeOnReadList, DataSnowflakeAccountsAccountsParametersEnableIdentifierFirstLoginList, DataSnowflakeAccountsAccountsParametersEnableInternalStagesPrivatelinkList, DataSnowflakeAccountsAccountsParametersEnableNotebookCreationInPersonalDbList, DataSnowflakeAccountsAccountsParametersEnablePerAccountAppServicePrivatelinkUrlList, DataSnowflakeAccountsAccountsParametersEnablePersonalDatabaseList, DataSnowflakeAccountsAccountsParametersEnableSpcsBlockStorageSnowflakeFullEncryptionEnforcementList, DataSnowflakeAccountsAccountsParametersEnableTagPropagationEventLoggingList, DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForImageRepositoryList, DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForSpcsBlockStorageList, DataSnowflakeAccountsAccountsParametersEnableUnhandledExceptionsReportingList, DataSnowflakeAccountsAccountsParametersEnableUnloadPhysicalTypeOptimizationList, DataSnowflakeAccountsAccountsParametersEnableUnredactedQuerySyntaxErrorList, DataSnowflakeAccountsAccountsParametersEnableUnredactedSecureObjectErrorList, DataSnowflakeAccountsAccountsParametersEnforceNetworkRulesForInternalStagesList, DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicMergeList, DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicUpdateList, DataSnowflakeAccountsAccountsParametersEventTableList, DataSnowflakeAccountsAccountsParametersExternalOauthAddPrivilegedRolesToBlockedListStructList, DataSnowflakeAccountsAccountsParametersExternalVolumeList, DataSnowflakeAccountsAccountsParametersGeographyOutputFormatList, DataSnowflakeAccountsAccountsParametersGeometryOutputFormatList, DataSnowflakeAccountsAccountsParametersHybridTableLockTimeoutList, DataSnowflakeAccountsAccountsParametersIcebergVersionDefaultList, DataSnowflakeAccountsAccountsParametersInitialReplicationSizeLimitInTbList, DataSnowflakeAccountsAccountsParametersJdbcTreatDecimalAsIntList, DataSnowflakeAccountsAccountsParametersJdbcTreatTimestampNtzAsUtcList, DataSnowflakeAccountsAccountsParametersJdbcUseSessionTimezoneList, DataSnowflakeAccountsAccountsParametersJsTreatIntegerAsBigintList, DataSnowflakeAccountsAccountsParametersJsonIndentList, DataSnowflakeAccountsAccountsParametersListingAutoFulfillmentReplicationRefreshScheduleList, DataSnowflakeAccountsAccountsParametersLockTimeoutList, DataSnowflakeAccountsAccountsParametersLogEventLevelList, DataSnowflakeAccountsAccountsParametersLogLevelList, DataSnowflakeAccountsAccountsParametersMaxConcurrencyLevelList, DataSnowflakeAccountsAccountsParametersMaxDataExtensionTimeInDaysList, DataSnowflakeAccountsAccountsParametersMetricLevelList, DataSnowflakeAccountsAccountsParametersMinDataRetentionTimeInDaysList, DataSnowflakeAccountsAccountsParametersMultiStatementCountList, DataSnowflakeAccountsAccountsParametersNetworkPolicyList, DataSnowflakeAccountsAccountsParametersNoorderSequenceAsDefaultList, DataSnowflakeAccountsAccountsParametersOauthAddPrivilegedRolesToBlockedListStructList, DataSnowflakeAccountsAccountsParametersOdbcTreatDecimalAsIntList, DataSnowflakeAccountsAccountsParametersPeriodicDataRekeyingList, DataSnowflakeAccountsAccountsParametersPipeExecutionPausedList, DataSnowflakeAccountsAccountsParametersPreventLoadFromInlineUrlList, DataSnowflakeAccountsAccountsParametersPreventUnloadToInlineUrlList, DataSnowflakeAccountsAccountsParametersPreventUnloadToInternalStagesList, DataSnowflakeAccountsAccountsParametersPythonProfilerModulesList, DataSnowflakeAccountsAccountsParametersPythonProfilerTargetStageList } from './structs0';
export interface DataSnowflakeAccountsAccountsParametersQueryTag {
}
export declare function dataSnowflakeAccountsAccountsParametersQueryTagToTerraform(struct?: DataSnowflakeAccountsAccountsParametersQueryTag): any;
export declare function dataSnowflakeAccountsAccountsParametersQueryTagToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersQueryTag): any;
export declare class DataSnowflakeAccountsAccountsParametersQueryTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersQueryTag | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersQueryTag | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersQueryTagList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersQueryTagOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersQuotedIdentifiersIgnoreCase {
}
export declare function dataSnowflakeAccountsAccountsParametersQuotedIdentifiersIgnoreCaseToTerraform(struct?: DataSnowflakeAccountsAccountsParametersQuotedIdentifiersIgnoreCase): any;
export declare function dataSnowflakeAccountsAccountsParametersQuotedIdentifiersIgnoreCaseToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersQuotedIdentifiersIgnoreCase): any;
export declare class DataSnowflakeAccountsAccountsParametersQuotedIdentifiersIgnoreCaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersQuotedIdentifiersIgnoreCase | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersQuotedIdentifiersIgnoreCase | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersQuotedIdentifiersIgnoreCaseList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersQuotedIdentifiersIgnoreCaseOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersReadConsistencyMode {
}
export declare function dataSnowflakeAccountsAccountsParametersReadConsistencyModeToTerraform(struct?: DataSnowflakeAccountsAccountsParametersReadConsistencyMode): any;
export declare function dataSnowflakeAccountsAccountsParametersReadConsistencyModeToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersReadConsistencyMode): any;
export declare class DataSnowflakeAccountsAccountsParametersReadConsistencyModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersReadConsistencyMode | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersReadConsistencyMode | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersReadConsistencyModeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersReadConsistencyModeOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersReplaceInvalidCharacters {
}
export declare function dataSnowflakeAccountsAccountsParametersReplaceInvalidCharactersToTerraform(struct?: DataSnowflakeAccountsAccountsParametersReplaceInvalidCharacters): any;
export declare function dataSnowflakeAccountsAccountsParametersReplaceInvalidCharactersToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersReplaceInvalidCharacters): any;
export declare class DataSnowflakeAccountsAccountsParametersReplaceInvalidCharactersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersReplaceInvalidCharacters | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersReplaceInvalidCharacters | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersReplaceInvalidCharactersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersReplaceInvalidCharactersOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageCreation {
}
export declare function dataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageCreationToTerraform(struct?: DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageCreation): any;
export declare function dataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageCreationToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageCreation): any;
export declare class DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageCreationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageCreation | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageCreation | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageCreationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageCreationOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageOperation {
}
export declare function dataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageOperationToTerraform(struct?: DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageOperation): any;
export declare function dataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageOperationToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageOperation): any;
export declare class DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageOperationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageOperation | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageOperation | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageOperationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageOperationOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersRowTimestampDefault {
}
export declare function dataSnowflakeAccountsAccountsParametersRowTimestampDefaultToTerraform(struct?: DataSnowflakeAccountsAccountsParametersRowTimestampDefault): any;
export declare function dataSnowflakeAccountsAccountsParametersRowTimestampDefaultToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersRowTimestampDefault): any;
export declare class DataSnowflakeAccountsAccountsParametersRowTimestampDefaultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersRowTimestampDefault | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersRowTimestampDefault | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersRowTimestampDefaultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersRowTimestampDefaultOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersRowsPerResultset {
}
export declare function dataSnowflakeAccountsAccountsParametersRowsPerResultsetToTerraform(struct?: DataSnowflakeAccountsAccountsParametersRowsPerResultset): any;
export declare function dataSnowflakeAccountsAccountsParametersRowsPerResultsetToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersRowsPerResultset): any;
export declare class DataSnowflakeAccountsAccountsParametersRowsPerResultsetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersRowsPerResultset | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersRowsPerResultset | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersRowsPerResultsetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersRowsPerResultsetOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersS3StageVpceDnsName {
}
export declare function dataSnowflakeAccountsAccountsParametersS3StageVpceDnsNameToTerraform(struct?: DataSnowflakeAccountsAccountsParametersS3StageVpceDnsName): any;
export declare function dataSnowflakeAccountsAccountsParametersS3StageVpceDnsNameToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersS3StageVpceDnsName): any;
export declare class DataSnowflakeAccountsAccountsParametersS3StageVpceDnsNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersS3StageVpceDnsName | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersS3StageVpceDnsName | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersS3StageVpceDnsNameList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersS3StageVpceDnsNameOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersSearchPath {
}
export declare function dataSnowflakeAccountsAccountsParametersSearchPathToTerraform(struct?: DataSnowflakeAccountsAccountsParametersSearchPath): any;
export declare function dataSnowflakeAccountsAccountsParametersSearchPathToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersSearchPath): any;
export declare class DataSnowflakeAccountsAccountsParametersSearchPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersSearchPath | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersSearchPath | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersSearchPathList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersSearchPathOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersServerlessTaskMaxStatementSize {
}
export declare function dataSnowflakeAccountsAccountsParametersServerlessTaskMaxStatementSizeToTerraform(struct?: DataSnowflakeAccountsAccountsParametersServerlessTaskMaxStatementSize): any;
export declare function dataSnowflakeAccountsAccountsParametersServerlessTaskMaxStatementSizeToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersServerlessTaskMaxStatementSize): any;
export declare class DataSnowflakeAccountsAccountsParametersServerlessTaskMaxStatementSizeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersServerlessTaskMaxStatementSize | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersServerlessTaskMaxStatementSize | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersServerlessTaskMaxStatementSizeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersServerlessTaskMaxStatementSizeOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersServerlessTaskMinStatementSize {
}
export declare function dataSnowflakeAccountsAccountsParametersServerlessTaskMinStatementSizeToTerraform(struct?: DataSnowflakeAccountsAccountsParametersServerlessTaskMinStatementSize): any;
export declare function dataSnowflakeAccountsAccountsParametersServerlessTaskMinStatementSizeToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersServerlessTaskMinStatementSize): any;
export declare class DataSnowflakeAccountsAccountsParametersServerlessTaskMinStatementSizeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersServerlessTaskMinStatementSize | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersServerlessTaskMinStatementSize | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersServerlessTaskMinStatementSizeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersServerlessTaskMinStatementSizeOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersShareRestrictions {
}
export declare function dataSnowflakeAccountsAccountsParametersShareRestrictionsToTerraform(struct?: DataSnowflakeAccountsAccountsParametersShareRestrictions): any;
export declare function dataSnowflakeAccountsAccountsParametersShareRestrictionsToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersShareRestrictions): any;
export declare class DataSnowflakeAccountsAccountsParametersShareRestrictionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersShareRestrictions | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersShareRestrictions | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersShareRestrictionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersShareRestrictionsOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersSimulatedDataSharingConsumer {
}
export declare function dataSnowflakeAccountsAccountsParametersSimulatedDataSharingConsumerToTerraform(struct?: DataSnowflakeAccountsAccountsParametersSimulatedDataSharingConsumer): any;
export declare function dataSnowflakeAccountsAccountsParametersSimulatedDataSharingConsumerToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersSimulatedDataSharingConsumer): any;
export declare class DataSnowflakeAccountsAccountsParametersSimulatedDataSharingConsumerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersSimulatedDataSharingConsumer | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersSimulatedDataSharingConsumer | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersSimulatedDataSharingConsumerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersSimulatedDataSharingConsumerOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersSqlTraceQueryText {
}
export declare function dataSnowflakeAccountsAccountsParametersSqlTraceQueryTextToTerraform(struct?: DataSnowflakeAccountsAccountsParametersSqlTraceQueryText): any;
export declare function dataSnowflakeAccountsAccountsParametersSqlTraceQueryTextToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersSqlTraceQueryText): any;
export declare class DataSnowflakeAccountsAccountsParametersSqlTraceQueryTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersSqlTraceQueryText | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersSqlTraceQueryText | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersSqlTraceQueryTextList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersSqlTraceQueryTextOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersSsoLoginPage {
}
export declare function dataSnowflakeAccountsAccountsParametersSsoLoginPageToTerraform(struct?: DataSnowflakeAccountsAccountsParametersSsoLoginPage): any;
export declare function dataSnowflakeAccountsAccountsParametersSsoLoginPageToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersSsoLoginPage): any;
export declare class DataSnowflakeAccountsAccountsParametersSsoLoginPageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersSsoLoginPage | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersSsoLoginPage | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersSsoLoginPageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersSsoLoginPageOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersStatementQueuedTimeoutInSeconds {
}
export declare function dataSnowflakeAccountsAccountsParametersStatementQueuedTimeoutInSecondsToTerraform(struct?: DataSnowflakeAccountsAccountsParametersStatementQueuedTimeoutInSeconds): any;
export declare function dataSnowflakeAccountsAccountsParametersStatementQueuedTimeoutInSecondsToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersStatementQueuedTimeoutInSeconds): any;
export declare class DataSnowflakeAccountsAccountsParametersStatementQueuedTimeoutInSecondsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersStatementQueuedTimeoutInSeconds | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersStatementQueuedTimeoutInSeconds | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersStatementQueuedTimeoutInSecondsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersStatementQueuedTimeoutInSecondsOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersStatementTimeoutInSeconds {
}
export declare function dataSnowflakeAccountsAccountsParametersStatementTimeoutInSecondsToTerraform(struct?: DataSnowflakeAccountsAccountsParametersStatementTimeoutInSeconds): any;
export declare function dataSnowflakeAccountsAccountsParametersStatementTimeoutInSecondsToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersStatementTimeoutInSeconds): any;
export declare class DataSnowflakeAccountsAccountsParametersStatementTimeoutInSecondsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersStatementTimeoutInSeconds | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersStatementTimeoutInSeconds | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersStatementTimeoutInSecondsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersStatementTimeoutInSecondsOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersStorageSerializationPolicy {
}
export declare function dataSnowflakeAccountsAccountsParametersStorageSerializationPolicyToTerraform(struct?: DataSnowflakeAccountsAccountsParametersStorageSerializationPolicy): any;
export declare function dataSnowflakeAccountsAccountsParametersStorageSerializationPolicyToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersStorageSerializationPolicy): any;
export declare class DataSnowflakeAccountsAccountsParametersStorageSerializationPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersStorageSerializationPolicy | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersStorageSerializationPolicy | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersStorageSerializationPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersStorageSerializationPolicyOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersStrictJsonOutput {
}
export declare function dataSnowflakeAccountsAccountsParametersStrictJsonOutputToTerraform(struct?: DataSnowflakeAccountsAccountsParametersStrictJsonOutput): any;
export declare function dataSnowflakeAccountsAccountsParametersStrictJsonOutputToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersStrictJsonOutput): any;
export declare class DataSnowflakeAccountsAccountsParametersStrictJsonOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersStrictJsonOutput | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersStrictJsonOutput | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersStrictJsonOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersStrictJsonOutputOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersSuspendTaskAfterNumFailures {
}
export declare function dataSnowflakeAccountsAccountsParametersSuspendTaskAfterNumFailuresToTerraform(struct?: DataSnowflakeAccountsAccountsParametersSuspendTaskAfterNumFailures): any;
export declare function dataSnowflakeAccountsAccountsParametersSuspendTaskAfterNumFailuresToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersSuspendTaskAfterNumFailures): any;
export declare class DataSnowflakeAccountsAccountsParametersSuspendTaskAfterNumFailuresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersSuspendTaskAfterNumFailures | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersSuspendTaskAfterNumFailures | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersSuspendTaskAfterNumFailuresList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersSuspendTaskAfterNumFailuresOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersTaskAutoRetryAttempts {
}
export declare function dataSnowflakeAccountsAccountsParametersTaskAutoRetryAttemptsToTerraform(struct?: DataSnowflakeAccountsAccountsParametersTaskAutoRetryAttempts): any;
export declare function dataSnowflakeAccountsAccountsParametersTaskAutoRetryAttemptsToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersTaskAutoRetryAttempts): any;
export declare class DataSnowflakeAccountsAccountsParametersTaskAutoRetryAttemptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersTaskAutoRetryAttempts | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersTaskAutoRetryAttempts | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersTaskAutoRetryAttemptsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersTaskAutoRetryAttemptsOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersTimeInputFormat {
}
export declare function dataSnowflakeAccountsAccountsParametersTimeInputFormatToTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimeInputFormat): any;
export declare function dataSnowflakeAccountsAccountsParametersTimeInputFormatToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimeInputFormat): any;
export declare class DataSnowflakeAccountsAccountsParametersTimeInputFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersTimeInputFormat | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersTimeInputFormat | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersTimeInputFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersTimeInputFormatOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersTimeOutputFormat {
}
export declare function dataSnowflakeAccountsAccountsParametersTimeOutputFormatToTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimeOutputFormat): any;
export declare function dataSnowflakeAccountsAccountsParametersTimeOutputFormatToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimeOutputFormat): any;
export declare class DataSnowflakeAccountsAccountsParametersTimeOutputFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersTimeOutputFormat | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersTimeOutputFormat | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersTimeOutputFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersTimeOutputFormatOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersTimestampDayIsAlways24H {
}
export declare function dataSnowflakeAccountsAccountsParametersTimestampDayIsAlways24HToTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimestampDayIsAlways24H): any;
export declare function dataSnowflakeAccountsAccountsParametersTimestampDayIsAlways24HToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimestampDayIsAlways24H): any;
export declare class DataSnowflakeAccountsAccountsParametersTimestampDayIsAlways24HOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersTimestampDayIsAlways24H | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersTimestampDayIsAlways24H | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersTimestampDayIsAlways24HList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersTimestampDayIsAlways24HOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersTimestampInputFormat {
}
export declare function dataSnowflakeAccountsAccountsParametersTimestampInputFormatToTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimestampInputFormat): any;
export declare function dataSnowflakeAccountsAccountsParametersTimestampInputFormatToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimestampInputFormat): any;
export declare class DataSnowflakeAccountsAccountsParametersTimestampInputFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersTimestampInputFormat | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersTimestampInputFormat | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersTimestampInputFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersTimestampInputFormatOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersTimestampLtzOutputFormat {
}
export declare function dataSnowflakeAccountsAccountsParametersTimestampLtzOutputFormatToTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimestampLtzOutputFormat): any;
export declare function dataSnowflakeAccountsAccountsParametersTimestampLtzOutputFormatToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimestampLtzOutputFormat): any;
export declare class DataSnowflakeAccountsAccountsParametersTimestampLtzOutputFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersTimestampLtzOutputFormat | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersTimestampLtzOutputFormat | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersTimestampLtzOutputFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersTimestampLtzOutputFormatOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersTimestampNtzOutputFormat {
}
export declare function dataSnowflakeAccountsAccountsParametersTimestampNtzOutputFormatToTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimestampNtzOutputFormat): any;
export declare function dataSnowflakeAccountsAccountsParametersTimestampNtzOutputFormatToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimestampNtzOutputFormat): any;
export declare class DataSnowflakeAccountsAccountsParametersTimestampNtzOutputFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersTimestampNtzOutputFormat | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersTimestampNtzOutputFormat | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersTimestampNtzOutputFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersTimestampNtzOutputFormatOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersTimestampOutputFormat {
}
export declare function dataSnowflakeAccountsAccountsParametersTimestampOutputFormatToTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimestampOutputFormat): any;
export declare function dataSnowflakeAccountsAccountsParametersTimestampOutputFormatToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimestampOutputFormat): any;
export declare class DataSnowflakeAccountsAccountsParametersTimestampOutputFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersTimestampOutputFormat | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersTimestampOutputFormat | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersTimestampOutputFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersTimestampOutputFormatOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersTimestampTypeMapping {
}
export declare function dataSnowflakeAccountsAccountsParametersTimestampTypeMappingToTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimestampTypeMapping): any;
export declare function dataSnowflakeAccountsAccountsParametersTimestampTypeMappingToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimestampTypeMapping): any;
export declare class DataSnowflakeAccountsAccountsParametersTimestampTypeMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersTimestampTypeMapping | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersTimestampTypeMapping | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersTimestampTypeMappingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersTimestampTypeMappingOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersTimestampTzOutputFormat {
}
export declare function dataSnowflakeAccountsAccountsParametersTimestampTzOutputFormatToTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimestampTzOutputFormat): any;
export declare function dataSnowflakeAccountsAccountsParametersTimestampTzOutputFormatToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimestampTzOutputFormat): any;
export declare class DataSnowflakeAccountsAccountsParametersTimestampTzOutputFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersTimestampTzOutputFormat | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersTimestampTzOutputFormat | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersTimestampTzOutputFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersTimestampTzOutputFormatOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersTimezone {
}
export declare function dataSnowflakeAccountsAccountsParametersTimezoneToTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimezone): any;
export declare function dataSnowflakeAccountsAccountsParametersTimezoneToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersTimezone): any;
export declare class DataSnowflakeAccountsAccountsParametersTimezoneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersTimezone | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersTimezone | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersTimezoneList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersTimezoneOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersTraceLevel {
}
export declare function dataSnowflakeAccountsAccountsParametersTraceLevelToTerraform(struct?: DataSnowflakeAccountsAccountsParametersTraceLevel): any;
export declare function dataSnowflakeAccountsAccountsParametersTraceLevelToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersTraceLevel): any;
export declare class DataSnowflakeAccountsAccountsParametersTraceLevelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersTraceLevel | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersTraceLevel | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersTraceLevelList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersTraceLevelOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersTransactionAbortOnError {
}
export declare function dataSnowflakeAccountsAccountsParametersTransactionAbortOnErrorToTerraform(struct?: DataSnowflakeAccountsAccountsParametersTransactionAbortOnError): any;
export declare function dataSnowflakeAccountsAccountsParametersTransactionAbortOnErrorToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersTransactionAbortOnError): any;
export declare class DataSnowflakeAccountsAccountsParametersTransactionAbortOnErrorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersTransactionAbortOnError | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersTransactionAbortOnError | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersTransactionAbortOnErrorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersTransactionAbortOnErrorOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersTransactionDefaultIsolationLevel {
}
export declare function dataSnowflakeAccountsAccountsParametersTransactionDefaultIsolationLevelToTerraform(struct?: DataSnowflakeAccountsAccountsParametersTransactionDefaultIsolationLevel): any;
export declare function dataSnowflakeAccountsAccountsParametersTransactionDefaultIsolationLevelToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersTransactionDefaultIsolationLevel): any;
export declare class DataSnowflakeAccountsAccountsParametersTransactionDefaultIsolationLevelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersTransactionDefaultIsolationLevel | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersTransactionDefaultIsolationLevel | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersTransactionDefaultIsolationLevelList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersTransactionDefaultIsolationLevelOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersTwoDigitCenturyStart {
}
export declare function dataSnowflakeAccountsAccountsParametersTwoDigitCenturyStartToTerraform(struct?: DataSnowflakeAccountsAccountsParametersTwoDigitCenturyStart): any;
export declare function dataSnowflakeAccountsAccountsParametersTwoDigitCenturyStartToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersTwoDigitCenturyStart): any;
export declare class DataSnowflakeAccountsAccountsParametersTwoDigitCenturyStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersTwoDigitCenturyStart | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersTwoDigitCenturyStart | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersTwoDigitCenturyStartList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersTwoDigitCenturyStartOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersUnsupportedDdlAction {
}
export declare function dataSnowflakeAccountsAccountsParametersUnsupportedDdlActionToTerraform(struct?: DataSnowflakeAccountsAccountsParametersUnsupportedDdlAction): any;
export declare function dataSnowflakeAccountsAccountsParametersUnsupportedDdlActionToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersUnsupportedDdlAction): any;
export declare class DataSnowflakeAccountsAccountsParametersUnsupportedDdlActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersUnsupportedDdlAction | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersUnsupportedDdlAction | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersUnsupportedDdlActionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersUnsupportedDdlActionOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersUseCachedResult {
}
export declare function dataSnowflakeAccountsAccountsParametersUseCachedResultToTerraform(struct?: DataSnowflakeAccountsAccountsParametersUseCachedResult): any;
export declare function dataSnowflakeAccountsAccountsParametersUseCachedResultToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersUseCachedResult): any;
export declare class DataSnowflakeAccountsAccountsParametersUseCachedResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersUseCachedResult | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersUseCachedResult | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersUseCachedResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersUseCachedResultOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersUseWorkspacesForSql {
}
export declare function dataSnowflakeAccountsAccountsParametersUseWorkspacesForSqlToTerraform(struct?: DataSnowflakeAccountsAccountsParametersUseWorkspacesForSql): any;
export declare function dataSnowflakeAccountsAccountsParametersUseWorkspacesForSqlToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersUseWorkspacesForSql): any;
export declare class DataSnowflakeAccountsAccountsParametersUseWorkspacesForSqlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersUseWorkspacesForSql | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersUseWorkspacesForSql | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersUseWorkspacesForSqlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersUseWorkspacesForSqlOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersUserTaskManagedInitialWarehouseSize {
}
export declare function dataSnowflakeAccountsAccountsParametersUserTaskManagedInitialWarehouseSizeToTerraform(struct?: DataSnowflakeAccountsAccountsParametersUserTaskManagedInitialWarehouseSize): any;
export declare function dataSnowflakeAccountsAccountsParametersUserTaskManagedInitialWarehouseSizeToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersUserTaskManagedInitialWarehouseSize): any;
export declare class DataSnowflakeAccountsAccountsParametersUserTaskManagedInitialWarehouseSizeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersUserTaskManagedInitialWarehouseSize | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersUserTaskManagedInitialWarehouseSize | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersUserTaskManagedInitialWarehouseSizeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersUserTaskManagedInitialWarehouseSizeOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersUserTaskMinimumTriggerIntervalInSeconds {
}
export declare function dataSnowflakeAccountsAccountsParametersUserTaskMinimumTriggerIntervalInSecondsToTerraform(struct?: DataSnowflakeAccountsAccountsParametersUserTaskMinimumTriggerIntervalInSeconds): any;
export declare function dataSnowflakeAccountsAccountsParametersUserTaskMinimumTriggerIntervalInSecondsToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersUserTaskMinimumTriggerIntervalInSeconds): any;
export declare class DataSnowflakeAccountsAccountsParametersUserTaskMinimumTriggerIntervalInSecondsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersUserTaskMinimumTriggerIntervalInSeconds | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersUserTaskMinimumTriggerIntervalInSeconds | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersUserTaskMinimumTriggerIntervalInSecondsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersUserTaskMinimumTriggerIntervalInSecondsOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersUserTaskTimeoutMs {
}
export declare function dataSnowflakeAccountsAccountsParametersUserTaskTimeoutMsToTerraform(struct?: DataSnowflakeAccountsAccountsParametersUserTaskTimeoutMs): any;
export declare function dataSnowflakeAccountsAccountsParametersUserTaskTimeoutMsToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersUserTaskTimeoutMs): any;
export declare class DataSnowflakeAccountsAccountsParametersUserTaskTimeoutMsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersUserTaskTimeoutMs | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersUserTaskTimeoutMs | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersUserTaskTimeoutMsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersUserTaskTimeoutMsOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersWeekOfYearPolicy {
}
export declare function dataSnowflakeAccountsAccountsParametersWeekOfYearPolicyToTerraform(struct?: DataSnowflakeAccountsAccountsParametersWeekOfYearPolicy): any;
export declare function dataSnowflakeAccountsAccountsParametersWeekOfYearPolicyToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersWeekOfYearPolicy): any;
export declare class DataSnowflakeAccountsAccountsParametersWeekOfYearPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersWeekOfYearPolicy | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersWeekOfYearPolicy | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersWeekOfYearPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersWeekOfYearPolicyOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersWeekStart {
}
export declare function dataSnowflakeAccountsAccountsParametersWeekStartToTerraform(struct?: DataSnowflakeAccountsAccountsParametersWeekStart): any;
export declare function dataSnowflakeAccountsAccountsParametersWeekStartToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersWeekStart): any;
export declare class DataSnowflakeAccountsAccountsParametersWeekStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersWeekStart | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersWeekStart | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersWeekStartList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersWeekStartOutputReference;
}
export interface DataSnowflakeAccountsAccountsParameters {
}
export declare function dataSnowflakeAccountsAccountsParametersToTerraform(struct?: DataSnowflakeAccountsAccountsParameters): any;
export declare function dataSnowflakeAccountsAccountsParametersToHclTerraform(struct?: DataSnowflakeAccountsAccountsParameters): any;
export declare class DataSnowflakeAccountsAccountsParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParameters | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParameters | undefined);
    private _abortDetachedQuery;
    get abortDetachedQuery(): DataSnowflakeAccountsAccountsParametersAbortDetachedQueryList;
    private _activePythonProfiler;
    get activePythonProfiler(): DataSnowflakeAccountsAccountsParametersActivePythonProfilerList;
    private _allowBindValuesAccess;
    get allowBindValuesAccess(): DataSnowflakeAccountsAccountsParametersAllowBindValuesAccessList;
    private _allowClientMfaCaching;
    get allowClientMfaCaching(): DataSnowflakeAccountsAccountsParametersAllowClientMfaCachingList;
    private _allowIdToken;
    get allowIdToken(): DataSnowflakeAccountsAccountsParametersAllowIdTokenList;
    private _allowedSpcsWorkloadTypes;
    get allowedSpcsWorkloadTypes(): DataSnowflakeAccountsAccountsParametersAllowedSpcsWorkloadTypesList;
    private _autocommit;
    get autocommit(): DataSnowflakeAccountsAccountsParametersAutocommitList;
    private _baseLocationPrefix;
    get baseLocationPrefix(): DataSnowflakeAccountsAccountsParametersBaseLocationPrefixList;
    private _binaryInputFormat;
    get binaryInputFormat(): DataSnowflakeAccountsAccountsParametersBinaryInputFormatList;
    private _binaryOutputFormat;
    get binaryOutputFormat(): DataSnowflakeAccountsAccountsParametersBinaryOutputFormatList;
    private _catalog;
    get catalog(): DataSnowflakeAccountsAccountsParametersCatalogList;
    private _catalogSync;
    get catalogSync(): DataSnowflakeAccountsAccountsParametersCatalogSyncList;
    private _clientEnableLogInfoStatementParameters;
    get clientEnableLogInfoStatementParameters(): DataSnowflakeAccountsAccountsParametersClientEnableLogInfoStatementParametersList;
    private _clientEncryptionKeySize;
    get clientEncryptionKeySize(): DataSnowflakeAccountsAccountsParametersClientEncryptionKeySizeList;
    private _clientMemoryLimit;
    get clientMemoryLimit(): DataSnowflakeAccountsAccountsParametersClientMemoryLimitList;
    private _clientMetadataRequestUseConnectionCtx;
    get clientMetadataRequestUseConnectionCtx(): DataSnowflakeAccountsAccountsParametersClientMetadataRequestUseConnectionCtxList;
    private _clientMetadataUseSessionDatabase;
    get clientMetadataUseSessionDatabase(): DataSnowflakeAccountsAccountsParametersClientMetadataUseSessionDatabaseList;
    private _clientPrefetchThreads;
    get clientPrefetchThreads(): DataSnowflakeAccountsAccountsParametersClientPrefetchThreadsList;
    private _clientResultChunkSize;
    get clientResultChunkSize(): DataSnowflakeAccountsAccountsParametersClientResultChunkSizeList;
    private _clientResultColumnCaseInsensitive;
    get clientResultColumnCaseInsensitive(): DataSnowflakeAccountsAccountsParametersClientResultColumnCaseInsensitiveList;
    private _clientSessionKeepAlive;
    get clientSessionKeepAlive(): DataSnowflakeAccountsAccountsParametersClientSessionKeepAliveList;
    private _clientSessionKeepAliveHeartbeatFrequency;
    get clientSessionKeepAliveHeartbeatFrequency(): DataSnowflakeAccountsAccountsParametersClientSessionKeepAliveHeartbeatFrequencyList;
    private _clientTimestampTypeMapping;
    get clientTimestampTypeMapping(): DataSnowflakeAccountsAccountsParametersClientTimestampTypeMappingList;
    private _cortexCodeCliDailyEstCreditLimitPerUser;
    get cortexCodeCliDailyEstCreditLimitPerUser(): DataSnowflakeAccountsAccountsParametersCortexCodeCliDailyEstCreditLimitPerUserList;
    private _cortexCodeDesktopDailyEstCreditLimitPerUser;
    get cortexCodeDesktopDailyEstCreditLimitPerUser(): DataSnowflakeAccountsAccountsParametersCortexCodeDesktopDailyEstCreditLimitPerUserList;
    private _cortexCodeSnowsightDailyEstCreditLimitPerUser;
    get cortexCodeSnowsightDailyEstCreditLimitPerUser(): DataSnowflakeAccountsAccountsParametersCortexCodeSnowsightDailyEstCreditLimitPerUserList;
    private _cortexEnabledCrossRegion;
    get cortexEnabledCrossRegion(): DataSnowflakeAccountsAccountsParametersCortexEnabledCrossRegionList;
    private _cortexModelsAllowlist;
    get cortexModelsAllowlist(): DataSnowflakeAccountsAccountsParametersCortexModelsAllowlistStructList;
    private _csvTimestampFormat;
    get csvTimestampFormat(): DataSnowflakeAccountsAccountsParametersCsvTimestampFormatList;
    private _dataMetricSchedule;
    get dataMetricSchedule(): DataSnowflakeAccountsAccountsParametersDataMetricScheduleList;
    private _dataRetentionTimeInDays;
    get dataRetentionTimeInDays(): DataSnowflakeAccountsAccountsParametersDataRetentionTimeInDaysList;
    private _dateInputFormat;
    get dateInputFormat(): DataSnowflakeAccountsAccountsParametersDateInputFormatList;
    private _dateOutputFormat;
    get dateOutputFormat(): DataSnowflakeAccountsAccountsParametersDateOutputFormatList;
    private _defaultDbtVersion;
    get defaultDbtVersion(): DataSnowflakeAccountsAccountsParametersDefaultDbtVersionList;
    private _defaultDdlCollation;
    get defaultDdlCollation(): DataSnowflakeAccountsAccountsParametersDefaultDdlCollationList;
    private _defaultNotebookComputePoolCpu;
    get defaultNotebookComputePoolCpu(): DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolCpuList;
    private _defaultNotebookComputePoolGpu;
    get defaultNotebookComputePoolGpu(): DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolGpuList;
    private _defaultNullOrdering;
    get defaultNullOrdering(): DataSnowflakeAccountsAccountsParametersDefaultNullOrderingList;
    private _defaultStreamlitComputePool;
    get defaultStreamlitComputePool(): DataSnowflakeAccountsAccountsParametersDefaultStreamlitComputePoolList;
    private _defaultStreamlitNotebookWarehouse;
    get defaultStreamlitNotebookWarehouse(): DataSnowflakeAccountsAccountsParametersDefaultStreamlitNotebookWarehouseList;
    private _disableUiDownloadButton;
    get disableUiDownloadButton(): DataSnowflakeAccountsAccountsParametersDisableUiDownloadButtonList;
    private _disableUserPrivilegeGrants;
    get disableUserPrivilegeGrants(): DataSnowflakeAccountsAccountsParametersDisableUserPrivilegeGrantsList;
    private _disallowedSpcsWorkloadTypes;
    get disallowedSpcsWorkloadTypes(): DataSnowflakeAccountsAccountsParametersDisallowedSpcsWorkloadTypesList;
    private _enableAutomaticSensitiveDataClassificationLog;
    get enableAutomaticSensitiveDataClassificationLog(): DataSnowflakeAccountsAccountsParametersEnableAutomaticSensitiveDataClassificationLogList;
    private _enableBudgetEventLogging;
    get enableBudgetEventLogging(): DataSnowflakeAccountsAccountsParametersEnableBudgetEventLoggingList;
    private _enableConsoleOutput;
    get enableConsoleOutput(): DataSnowflakeAccountsAccountsParametersEnableConsoleOutputList;
    private _enableCortexAnalyst;
    get enableCortexAnalyst(): DataSnowflakeAccountsAccountsParametersEnableCortexAnalystList;
    private _enableDataCompaction;
    get enableDataCompaction(): DataSnowflakeAccountsAccountsParametersEnableDataCompactionList;
    private _enableEgressCostOptimizer;
    get enableEgressCostOptimizer(): DataSnowflakeAccountsAccountsParametersEnableEgressCostOptimizerList;
    private _enableGetDdlUseDataTypeAlias;
    get enableGetDdlUseDataTypeAlias(): DataSnowflakeAccountsAccountsParametersEnableGetDdlUseDataTypeAliasList;
    private _enableIcebergMergeOnRead;
    get enableIcebergMergeOnRead(): DataSnowflakeAccountsAccountsParametersEnableIcebergMergeOnReadList;
    private _enableIdentifierFirstLogin;
    get enableIdentifierFirstLogin(): DataSnowflakeAccountsAccountsParametersEnableIdentifierFirstLoginList;
    private _enableInternalStagesPrivatelink;
    get enableInternalStagesPrivatelink(): DataSnowflakeAccountsAccountsParametersEnableInternalStagesPrivatelinkList;
    private _enableNotebookCreationInPersonalDb;
    get enableNotebookCreationInPersonalDb(): DataSnowflakeAccountsAccountsParametersEnableNotebookCreationInPersonalDbList;
    private _enablePerAccountAppServicePrivatelinkUrl;
    get enablePerAccountAppServicePrivatelinkUrl(): DataSnowflakeAccountsAccountsParametersEnablePerAccountAppServicePrivatelinkUrlList;
    private _enablePersonalDatabase;
    get enablePersonalDatabase(): DataSnowflakeAccountsAccountsParametersEnablePersonalDatabaseList;
    private _enableSpcsBlockStorageSnowflakeFullEncryptionEnforcement;
    get enableSpcsBlockStorageSnowflakeFullEncryptionEnforcement(): DataSnowflakeAccountsAccountsParametersEnableSpcsBlockStorageSnowflakeFullEncryptionEnforcementList;
    private _enableTagPropagationEventLogging;
    get enableTagPropagationEventLogging(): DataSnowflakeAccountsAccountsParametersEnableTagPropagationEventLoggingList;
    private _enableTriSecretAndRekeyOptOutForImageRepository;
    get enableTriSecretAndRekeyOptOutForImageRepository(): DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForImageRepositoryList;
    private _enableTriSecretAndRekeyOptOutForSpcsBlockStorage;
    get enableTriSecretAndRekeyOptOutForSpcsBlockStorage(): DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForSpcsBlockStorageList;
    private _enableUnhandledExceptionsReporting;
    get enableUnhandledExceptionsReporting(): DataSnowflakeAccountsAccountsParametersEnableUnhandledExceptionsReportingList;
    private _enableUnloadPhysicalTypeOptimization;
    get enableUnloadPhysicalTypeOptimization(): DataSnowflakeAccountsAccountsParametersEnableUnloadPhysicalTypeOptimizationList;
    private _enableUnredactedQuerySyntaxError;
    get enableUnredactedQuerySyntaxError(): DataSnowflakeAccountsAccountsParametersEnableUnredactedQuerySyntaxErrorList;
    private _enableUnredactedSecureObjectError;
    get enableUnredactedSecureObjectError(): DataSnowflakeAccountsAccountsParametersEnableUnredactedSecureObjectErrorList;
    private _enforceNetworkRulesForInternalStages;
    get enforceNetworkRulesForInternalStages(): DataSnowflakeAccountsAccountsParametersEnforceNetworkRulesForInternalStagesList;
    private _errorOnNondeterministicMerge;
    get errorOnNondeterministicMerge(): DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicMergeList;
    private _errorOnNondeterministicUpdate;
    get errorOnNondeterministicUpdate(): DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicUpdateList;
    private _eventTable;
    get eventTable(): DataSnowflakeAccountsAccountsParametersEventTableList;
    private _externalOauthAddPrivilegedRolesToBlockedList;
    get externalOauthAddPrivilegedRolesToBlockedList(): DataSnowflakeAccountsAccountsParametersExternalOauthAddPrivilegedRolesToBlockedListStructList;
    private _externalVolume;
    get externalVolume(): DataSnowflakeAccountsAccountsParametersExternalVolumeList;
    private _geographyOutputFormat;
    get geographyOutputFormat(): DataSnowflakeAccountsAccountsParametersGeographyOutputFormatList;
    private _geometryOutputFormat;
    get geometryOutputFormat(): DataSnowflakeAccountsAccountsParametersGeometryOutputFormatList;
    private _hybridTableLockTimeout;
    get hybridTableLockTimeout(): DataSnowflakeAccountsAccountsParametersHybridTableLockTimeoutList;
    private _icebergVersionDefault;
    get icebergVersionDefault(): DataSnowflakeAccountsAccountsParametersIcebergVersionDefaultList;
    private _initialReplicationSizeLimitInTb;
    get initialReplicationSizeLimitInTb(): DataSnowflakeAccountsAccountsParametersInitialReplicationSizeLimitInTbList;
    private _jdbcTreatDecimalAsInt;
    get jdbcTreatDecimalAsInt(): DataSnowflakeAccountsAccountsParametersJdbcTreatDecimalAsIntList;
    private _jdbcTreatTimestampNtzAsUtc;
    get jdbcTreatTimestampNtzAsUtc(): DataSnowflakeAccountsAccountsParametersJdbcTreatTimestampNtzAsUtcList;
    private _jdbcUseSessionTimezone;
    get jdbcUseSessionTimezone(): DataSnowflakeAccountsAccountsParametersJdbcUseSessionTimezoneList;
    private _jsTreatIntegerAsBigint;
    get jsTreatIntegerAsBigint(): DataSnowflakeAccountsAccountsParametersJsTreatIntegerAsBigintList;
    private _jsonIndent;
    get jsonIndent(): DataSnowflakeAccountsAccountsParametersJsonIndentList;
    private _listingAutoFulfillmentReplicationRefreshSchedule;
    get listingAutoFulfillmentReplicationRefreshSchedule(): DataSnowflakeAccountsAccountsParametersListingAutoFulfillmentReplicationRefreshScheduleList;
    private _lockTimeout;
    get lockTimeout(): DataSnowflakeAccountsAccountsParametersLockTimeoutList;
    private _logEventLevel;
    get logEventLevel(): DataSnowflakeAccountsAccountsParametersLogEventLevelList;
    private _logLevel;
    get logLevel(): DataSnowflakeAccountsAccountsParametersLogLevelList;
    private _maxConcurrencyLevel;
    get maxConcurrencyLevel(): DataSnowflakeAccountsAccountsParametersMaxConcurrencyLevelList;
    private _maxDataExtensionTimeInDays;
    get maxDataExtensionTimeInDays(): DataSnowflakeAccountsAccountsParametersMaxDataExtensionTimeInDaysList;
    private _metricLevel;
    get metricLevel(): DataSnowflakeAccountsAccountsParametersMetricLevelList;
    private _minDataRetentionTimeInDays;
    get minDataRetentionTimeInDays(): DataSnowflakeAccountsAccountsParametersMinDataRetentionTimeInDaysList;
    private _multiStatementCount;
    get multiStatementCount(): DataSnowflakeAccountsAccountsParametersMultiStatementCountList;
    private _networkPolicy;
    get networkPolicy(): DataSnowflakeAccountsAccountsParametersNetworkPolicyList;
    private _noorderSequenceAsDefault;
    get noorderSequenceAsDefault(): DataSnowflakeAccountsAccountsParametersNoorderSequenceAsDefaultList;
    private _oauthAddPrivilegedRolesToBlockedList;
    get oauthAddPrivilegedRolesToBlockedList(): DataSnowflakeAccountsAccountsParametersOauthAddPrivilegedRolesToBlockedListStructList;
    private _odbcTreatDecimalAsInt;
    get odbcTreatDecimalAsInt(): DataSnowflakeAccountsAccountsParametersOdbcTreatDecimalAsIntList;
    private _periodicDataRekeying;
    get periodicDataRekeying(): DataSnowflakeAccountsAccountsParametersPeriodicDataRekeyingList;
    private _pipeExecutionPaused;
    get pipeExecutionPaused(): DataSnowflakeAccountsAccountsParametersPipeExecutionPausedList;
    private _preventLoadFromInlineUrl;
    get preventLoadFromInlineUrl(): DataSnowflakeAccountsAccountsParametersPreventLoadFromInlineUrlList;
    private _preventUnloadToInlineUrl;
    get preventUnloadToInlineUrl(): DataSnowflakeAccountsAccountsParametersPreventUnloadToInlineUrlList;
    private _preventUnloadToInternalStages;
    get preventUnloadToInternalStages(): DataSnowflakeAccountsAccountsParametersPreventUnloadToInternalStagesList;
    private _pythonProfilerModules;
    get pythonProfilerModules(): DataSnowflakeAccountsAccountsParametersPythonProfilerModulesList;
    private _pythonProfilerTargetStage;
    get pythonProfilerTargetStage(): DataSnowflakeAccountsAccountsParametersPythonProfilerTargetStageList;
    private _queryTag;
    get queryTag(): DataSnowflakeAccountsAccountsParametersQueryTagList;
    private _quotedIdentifiersIgnoreCase;
    get quotedIdentifiersIgnoreCase(): DataSnowflakeAccountsAccountsParametersQuotedIdentifiersIgnoreCaseList;
    private _readConsistencyMode;
    get readConsistencyMode(): DataSnowflakeAccountsAccountsParametersReadConsistencyModeList;
    private _replaceInvalidCharacters;
    get replaceInvalidCharacters(): DataSnowflakeAccountsAccountsParametersReplaceInvalidCharactersList;
    private _requireStorageIntegrationForStageCreation;
    get requireStorageIntegrationForStageCreation(): DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageCreationList;
    private _requireStorageIntegrationForStageOperation;
    get requireStorageIntegrationForStageOperation(): DataSnowflakeAccountsAccountsParametersRequireStorageIntegrationForStageOperationList;
    private _rowTimestampDefault;
    get rowTimestampDefault(): DataSnowflakeAccountsAccountsParametersRowTimestampDefaultList;
    private _rowsPerResultset;
    get rowsPerResultset(): DataSnowflakeAccountsAccountsParametersRowsPerResultsetList;
    private _s3StageVpceDnsName;
    get s3StageVpceDnsName(): DataSnowflakeAccountsAccountsParametersS3StageVpceDnsNameList;
    private _searchPath;
    get searchPath(): DataSnowflakeAccountsAccountsParametersSearchPathList;
    private _serverlessTaskMaxStatementSize;
    get serverlessTaskMaxStatementSize(): DataSnowflakeAccountsAccountsParametersServerlessTaskMaxStatementSizeList;
    private _serverlessTaskMinStatementSize;
    get serverlessTaskMinStatementSize(): DataSnowflakeAccountsAccountsParametersServerlessTaskMinStatementSizeList;
    private _shareRestrictions;
    get shareRestrictions(): DataSnowflakeAccountsAccountsParametersShareRestrictionsList;
    private _simulatedDataSharingConsumer;
    get simulatedDataSharingConsumer(): DataSnowflakeAccountsAccountsParametersSimulatedDataSharingConsumerList;
    private _sqlTraceQueryText;
    get sqlTraceQueryText(): DataSnowflakeAccountsAccountsParametersSqlTraceQueryTextList;
    private _ssoLoginPage;
    get ssoLoginPage(): DataSnowflakeAccountsAccountsParametersSsoLoginPageList;
    private _statementQueuedTimeoutInSeconds;
    get statementQueuedTimeoutInSeconds(): DataSnowflakeAccountsAccountsParametersStatementQueuedTimeoutInSecondsList;
    private _statementTimeoutInSeconds;
    get statementTimeoutInSeconds(): DataSnowflakeAccountsAccountsParametersStatementTimeoutInSecondsList;
    private _storageSerializationPolicy;
    get storageSerializationPolicy(): DataSnowflakeAccountsAccountsParametersStorageSerializationPolicyList;
    private _strictJsonOutput;
    get strictJsonOutput(): DataSnowflakeAccountsAccountsParametersStrictJsonOutputList;
    private _suspendTaskAfterNumFailures;
    get suspendTaskAfterNumFailures(): DataSnowflakeAccountsAccountsParametersSuspendTaskAfterNumFailuresList;
    private _taskAutoRetryAttempts;
    get taskAutoRetryAttempts(): DataSnowflakeAccountsAccountsParametersTaskAutoRetryAttemptsList;
    private _timeInputFormat;
    get timeInputFormat(): DataSnowflakeAccountsAccountsParametersTimeInputFormatList;
    private _timeOutputFormat;
    get timeOutputFormat(): DataSnowflakeAccountsAccountsParametersTimeOutputFormatList;
    private _timestampDayIsAlways24H;
    get timestampDayIsAlways24H(): DataSnowflakeAccountsAccountsParametersTimestampDayIsAlways24HList;
    private _timestampInputFormat;
    get timestampInputFormat(): DataSnowflakeAccountsAccountsParametersTimestampInputFormatList;
    private _timestampLtzOutputFormat;
    get timestampLtzOutputFormat(): DataSnowflakeAccountsAccountsParametersTimestampLtzOutputFormatList;
    private _timestampNtzOutputFormat;
    get timestampNtzOutputFormat(): DataSnowflakeAccountsAccountsParametersTimestampNtzOutputFormatList;
    private _timestampOutputFormat;
    get timestampOutputFormat(): DataSnowflakeAccountsAccountsParametersTimestampOutputFormatList;
    private _timestampTypeMapping;
    get timestampTypeMapping(): DataSnowflakeAccountsAccountsParametersTimestampTypeMappingList;
    private _timestampTzOutputFormat;
    get timestampTzOutputFormat(): DataSnowflakeAccountsAccountsParametersTimestampTzOutputFormatList;
    private _timezone;
    get timezone(): DataSnowflakeAccountsAccountsParametersTimezoneList;
    private _traceLevel;
    get traceLevel(): DataSnowflakeAccountsAccountsParametersTraceLevelList;
    private _transactionAbortOnError;
    get transactionAbortOnError(): DataSnowflakeAccountsAccountsParametersTransactionAbortOnErrorList;
    private _transactionDefaultIsolationLevel;
    get transactionDefaultIsolationLevel(): DataSnowflakeAccountsAccountsParametersTransactionDefaultIsolationLevelList;
    private _twoDigitCenturyStart;
    get twoDigitCenturyStart(): DataSnowflakeAccountsAccountsParametersTwoDigitCenturyStartList;
    private _unsupportedDdlAction;
    get unsupportedDdlAction(): DataSnowflakeAccountsAccountsParametersUnsupportedDdlActionList;
    private _useCachedResult;
    get useCachedResult(): DataSnowflakeAccountsAccountsParametersUseCachedResultList;
    private _useWorkspacesForSql;
    get useWorkspacesForSql(): DataSnowflakeAccountsAccountsParametersUseWorkspacesForSqlList;
    private _userTaskManagedInitialWarehouseSize;
    get userTaskManagedInitialWarehouseSize(): DataSnowflakeAccountsAccountsParametersUserTaskManagedInitialWarehouseSizeList;
    private _userTaskMinimumTriggerIntervalInSeconds;
    get userTaskMinimumTriggerIntervalInSeconds(): DataSnowflakeAccountsAccountsParametersUserTaskMinimumTriggerIntervalInSecondsList;
    private _userTaskTimeoutMs;
    get userTaskTimeoutMs(): DataSnowflakeAccountsAccountsParametersUserTaskTimeoutMsList;
    private _weekOfYearPolicy;
    get weekOfYearPolicy(): DataSnowflakeAccountsAccountsParametersWeekOfYearPolicyList;
    private _weekStart;
    get weekStart(): DataSnowflakeAccountsAccountsParametersWeekStartList;
}
export declare class DataSnowflakeAccountsAccountsParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersOutputReference;
}
export interface DataSnowflakeAccountsAccountsShowOutput {
}
export declare function dataSnowflakeAccountsAccountsShowOutputToTerraform(struct?: DataSnowflakeAccountsAccountsShowOutput): any;
export declare function dataSnowflakeAccountsAccountsShowOutputToHclTerraform(struct?: DataSnowflakeAccountsAccountsShowOutput): any;
export declare class DataSnowflakeAccountsAccountsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsShowOutput | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsShowOutput | undefined);
    get accountLocator(): string;
    get accountLocatorUrl(): string;
    get accountName(): string;
    get accountOldUrlLastUsed(): string;
    get accountOldUrlSavedOn(): string;
    get accountUrl(): string;
    get comment(): string;
    get consumptionBillingEntityName(): string;
    get createdOn(): string;
    get droppedOn(): string;
    get edition(): string;
    get isEventsAccount(): cdktn.IResolvable;
    get isOrgAdmin(): cdktn.IResolvable;
    get isOrganizationAccount(): cdktn.IResolvable;
    get managedAccounts(): number;
    get marketplaceConsumerBillingEntityName(): string;
    get marketplaceProviderBillingEntityName(): string;
    get movedOn(): string;
    get movedToOrganization(): string;
    get oldAccountUrl(): string;
    get organizationName(): string;
    get organizationOldUrl(): string;
    get organizationOldUrlLastUsed(): string;
    get organizationOldUrlSavedOn(): string;
    get organizationUrlExpirationOn(): string;
    get regionGroup(): string;
    get restoredOn(): string;
    get scheduledDeletionTime(): string;
    get snowflakeRegion(): string;
}
export declare class DataSnowflakeAccountsAccountsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsShowOutputOutputReference;
}
export interface DataSnowflakeAccountsAccounts {
}
export declare function dataSnowflakeAccountsAccountsToTerraform(struct?: DataSnowflakeAccountsAccounts): any;
export declare function dataSnowflakeAccountsAccountsToHclTerraform(struct?: DataSnowflakeAccountsAccounts): any;
export declare class DataSnowflakeAccountsAccountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccounts | undefined;
    set internalValue(value: DataSnowflakeAccountsAccounts | undefined);
    private _parameters;
    get parameters(): DataSnowflakeAccountsAccountsParametersList;
    private _showOutput;
    get showOutput(): DataSnowflakeAccountsAccountsShowOutputList;
}
export declare class DataSnowflakeAccountsAccountsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsOutputReference;
}
