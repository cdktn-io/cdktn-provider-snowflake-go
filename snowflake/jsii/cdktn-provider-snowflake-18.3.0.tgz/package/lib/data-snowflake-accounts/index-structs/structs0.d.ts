/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
export interface DataSnowflakeAccountsAccountsParametersAbortDetachedQuery {
}
export declare function dataSnowflakeAccountsAccountsParametersAbortDetachedQueryToTerraform(struct?: DataSnowflakeAccountsAccountsParametersAbortDetachedQuery): any;
export declare function dataSnowflakeAccountsAccountsParametersAbortDetachedQueryToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersAbortDetachedQuery): any;
export declare class DataSnowflakeAccountsAccountsParametersAbortDetachedQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersAbortDetachedQuery | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersAbortDetachedQuery | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersAbortDetachedQueryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersAbortDetachedQueryOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersActivePythonProfiler {
}
export declare function dataSnowflakeAccountsAccountsParametersActivePythonProfilerToTerraform(struct?: DataSnowflakeAccountsAccountsParametersActivePythonProfiler): any;
export declare function dataSnowflakeAccountsAccountsParametersActivePythonProfilerToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersActivePythonProfiler): any;
export declare class DataSnowflakeAccountsAccountsParametersActivePythonProfilerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersActivePythonProfiler | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersActivePythonProfiler | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersActivePythonProfilerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersActivePythonProfilerOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersAllowBindValuesAccess {
}
export declare function dataSnowflakeAccountsAccountsParametersAllowBindValuesAccessToTerraform(struct?: DataSnowflakeAccountsAccountsParametersAllowBindValuesAccess): any;
export declare function dataSnowflakeAccountsAccountsParametersAllowBindValuesAccessToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersAllowBindValuesAccess): any;
export declare class DataSnowflakeAccountsAccountsParametersAllowBindValuesAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersAllowBindValuesAccess | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersAllowBindValuesAccess | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersAllowBindValuesAccessList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersAllowBindValuesAccessOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersAllowClientMfaCaching {
}
export declare function dataSnowflakeAccountsAccountsParametersAllowClientMfaCachingToTerraform(struct?: DataSnowflakeAccountsAccountsParametersAllowClientMfaCaching): any;
export declare function dataSnowflakeAccountsAccountsParametersAllowClientMfaCachingToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersAllowClientMfaCaching): any;
export declare class DataSnowflakeAccountsAccountsParametersAllowClientMfaCachingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersAllowClientMfaCaching | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersAllowClientMfaCaching | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersAllowClientMfaCachingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersAllowClientMfaCachingOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersAllowIdToken {
}
export declare function dataSnowflakeAccountsAccountsParametersAllowIdTokenToTerraform(struct?: DataSnowflakeAccountsAccountsParametersAllowIdToken): any;
export declare function dataSnowflakeAccountsAccountsParametersAllowIdTokenToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersAllowIdToken): any;
export declare class DataSnowflakeAccountsAccountsParametersAllowIdTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersAllowIdToken | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersAllowIdToken | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersAllowIdTokenList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersAllowIdTokenOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersAllowedSpcsWorkloadTypes {
}
export declare function dataSnowflakeAccountsAccountsParametersAllowedSpcsWorkloadTypesToTerraform(struct?: DataSnowflakeAccountsAccountsParametersAllowedSpcsWorkloadTypes): any;
export declare function dataSnowflakeAccountsAccountsParametersAllowedSpcsWorkloadTypesToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersAllowedSpcsWorkloadTypes): any;
export declare class DataSnowflakeAccountsAccountsParametersAllowedSpcsWorkloadTypesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersAllowedSpcsWorkloadTypes | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersAllowedSpcsWorkloadTypes | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersAllowedSpcsWorkloadTypesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersAllowedSpcsWorkloadTypesOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersAutocommit {
}
export declare function dataSnowflakeAccountsAccountsParametersAutocommitToTerraform(struct?: DataSnowflakeAccountsAccountsParametersAutocommit): any;
export declare function dataSnowflakeAccountsAccountsParametersAutocommitToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersAutocommit): any;
export declare class DataSnowflakeAccountsAccountsParametersAutocommitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersAutocommit | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersAutocommit | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersAutocommitList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersAutocommitOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersBaseLocationPrefix {
}
export declare function dataSnowflakeAccountsAccountsParametersBaseLocationPrefixToTerraform(struct?: DataSnowflakeAccountsAccountsParametersBaseLocationPrefix): any;
export declare function dataSnowflakeAccountsAccountsParametersBaseLocationPrefixToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersBaseLocationPrefix): any;
export declare class DataSnowflakeAccountsAccountsParametersBaseLocationPrefixOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersBaseLocationPrefix | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersBaseLocationPrefix | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersBaseLocationPrefixList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersBaseLocationPrefixOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersBinaryInputFormat {
}
export declare function dataSnowflakeAccountsAccountsParametersBinaryInputFormatToTerraform(struct?: DataSnowflakeAccountsAccountsParametersBinaryInputFormat): any;
export declare function dataSnowflakeAccountsAccountsParametersBinaryInputFormatToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersBinaryInputFormat): any;
export declare class DataSnowflakeAccountsAccountsParametersBinaryInputFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersBinaryInputFormat | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersBinaryInputFormat | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersBinaryInputFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersBinaryInputFormatOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersBinaryOutputFormat {
}
export declare function dataSnowflakeAccountsAccountsParametersBinaryOutputFormatToTerraform(struct?: DataSnowflakeAccountsAccountsParametersBinaryOutputFormat): any;
export declare function dataSnowflakeAccountsAccountsParametersBinaryOutputFormatToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersBinaryOutputFormat): any;
export declare class DataSnowflakeAccountsAccountsParametersBinaryOutputFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersBinaryOutputFormat | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersBinaryOutputFormat | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersBinaryOutputFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersBinaryOutputFormatOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersCatalog {
}
export declare function dataSnowflakeAccountsAccountsParametersCatalogToTerraform(struct?: DataSnowflakeAccountsAccountsParametersCatalog): any;
export declare function dataSnowflakeAccountsAccountsParametersCatalogToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersCatalog): any;
export declare class DataSnowflakeAccountsAccountsParametersCatalogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersCatalog | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersCatalog | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersCatalogList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersCatalogOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersCatalogSync {
}
export declare function dataSnowflakeAccountsAccountsParametersCatalogSyncToTerraform(struct?: DataSnowflakeAccountsAccountsParametersCatalogSync): any;
export declare function dataSnowflakeAccountsAccountsParametersCatalogSyncToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersCatalogSync): any;
export declare class DataSnowflakeAccountsAccountsParametersCatalogSyncOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersCatalogSync | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersCatalogSync | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersCatalogSyncList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersCatalogSyncOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersClientEnableLogInfoStatementParameters {
}
export declare function dataSnowflakeAccountsAccountsParametersClientEnableLogInfoStatementParametersToTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientEnableLogInfoStatementParameters): any;
export declare function dataSnowflakeAccountsAccountsParametersClientEnableLogInfoStatementParametersToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientEnableLogInfoStatementParameters): any;
export declare class DataSnowflakeAccountsAccountsParametersClientEnableLogInfoStatementParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersClientEnableLogInfoStatementParameters | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersClientEnableLogInfoStatementParameters | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersClientEnableLogInfoStatementParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersClientEnableLogInfoStatementParametersOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersClientEncryptionKeySize {
}
export declare function dataSnowflakeAccountsAccountsParametersClientEncryptionKeySizeToTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientEncryptionKeySize): any;
export declare function dataSnowflakeAccountsAccountsParametersClientEncryptionKeySizeToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientEncryptionKeySize): any;
export declare class DataSnowflakeAccountsAccountsParametersClientEncryptionKeySizeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersClientEncryptionKeySize | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersClientEncryptionKeySize | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersClientEncryptionKeySizeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersClientEncryptionKeySizeOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersClientMemoryLimit {
}
export declare function dataSnowflakeAccountsAccountsParametersClientMemoryLimitToTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientMemoryLimit): any;
export declare function dataSnowflakeAccountsAccountsParametersClientMemoryLimitToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientMemoryLimit): any;
export declare class DataSnowflakeAccountsAccountsParametersClientMemoryLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersClientMemoryLimit | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersClientMemoryLimit | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersClientMemoryLimitList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersClientMemoryLimitOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersClientMetadataRequestUseConnectionCtx {
}
export declare function dataSnowflakeAccountsAccountsParametersClientMetadataRequestUseConnectionCtxToTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientMetadataRequestUseConnectionCtx): any;
export declare function dataSnowflakeAccountsAccountsParametersClientMetadataRequestUseConnectionCtxToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientMetadataRequestUseConnectionCtx): any;
export declare class DataSnowflakeAccountsAccountsParametersClientMetadataRequestUseConnectionCtxOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersClientMetadataRequestUseConnectionCtx | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersClientMetadataRequestUseConnectionCtx | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersClientMetadataRequestUseConnectionCtxList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersClientMetadataRequestUseConnectionCtxOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersClientMetadataUseSessionDatabase {
}
export declare function dataSnowflakeAccountsAccountsParametersClientMetadataUseSessionDatabaseToTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientMetadataUseSessionDatabase): any;
export declare function dataSnowflakeAccountsAccountsParametersClientMetadataUseSessionDatabaseToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientMetadataUseSessionDatabase): any;
export declare class DataSnowflakeAccountsAccountsParametersClientMetadataUseSessionDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersClientMetadataUseSessionDatabase | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersClientMetadataUseSessionDatabase | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersClientMetadataUseSessionDatabaseList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersClientMetadataUseSessionDatabaseOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersClientPrefetchThreads {
}
export declare function dataSnowflakeAccountsAccountsParametersClientPrefetchThreadsToTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientPrefetchThreads): any;
export declare function dataSnowflakeAccountsAccountsParametersClientPrefetchThreadsToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientPrefetchThreads): any;
export declare class DataSnowflakeAccountsAccountsParametersClientPrefetchThreadsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersClientPrefetchThreads | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersClientPrefetchThreads | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersClientPrefetchThreadsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersClientPrefetchThreadsOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersClientResultChunkSize {
}
export declare function dataSnowflakeAccountsAccountsParametersClientResultChunkSizeToTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientResultChunkSize): any;
export declare function dataSnowflakeAccountsAccountsParametersClientResultChunkSizeToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientResultChunkSize): any;
export declare class DataSnowflakeAccountsAccountsParametersClientResultChunkSizeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersClientResultChunkSize | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersClientResultChunkSize | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersClientResultChunkSizeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersClientResultChunkSizeOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersClientResultColumnCaseInsensitive {
}
export declare function dataSnowflakeAccountsAccountsParametersClientResultColumnCaseInsensitiveToTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientResultColumnCaseInsensitive): any;
export declare function dataSnowflakeAccountsAccountsParametersClientResultColumnCaseInsensitiveToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientResultColumnCaseInsensitive): any;
export declare class DataSnowflakeAccountsAccountsParametersClientResultColumnCaseInsensitiveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersClientResultColumnCaseInsensitive | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersClientResultColumnCaseInsensitive | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersClientResultColumnCaseInsensitiveList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersClientResultColumnCaseInsensitiveOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersClientSessionKeepAlive {
}
export declare function dataSnowflakeAccountsAccountsParametersClientSessionKeepAliveToTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientSessionKeepAlive): any;
export declare function dataSnowflakeAccountsAccountsParametersClientSessionKeepAliveToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientSessionKeepAlive): any;
export declare class DataSnowflakeAccountsAccountsParametersClientSessionKeepAliveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersClientSessionKeepAlive | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersClientSessionKeepAlive | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersClientSessionKeepAliveList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersClientSessionKeepAliveOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersClientSessionKeepAliveHeartbeatFrequency {
}
export declare function dataSnowflakeAccountsAccountsParametersClientSessionKeepAliveHeartbeatFrequencyToTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientSessionKeepAliveHeartbeatFrequency): any;
export declare function dataSnowflakeAccountsAccountsParametersClientSessionKeepAliveHeartbeatFrequencyToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientSessionKeepAliveHeartbeatFrequency): any;
export declare class DataSnowflakeAccountsAccountsParametersClientSessionKeepAliveHeartbeatFrequencyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersClientSessionKeepAliveHeartbeatFrequency | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersClientSessionKeepAliveHeartbeatFrequency | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersClientSessionKeepAliveHeartbeatFrequencyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersClientSessionKeepAliveHeartbeatFrequencyOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersClientTimestampTypeMapping {
}
export declare function dataSnowflakeAccountsAccountsParametersClientTimestampTypeMappingToTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientTimestampTypeMapping): any;
export declare function dataSnowflakeAccountsAccountsParametersClientTimestampTypeMappingToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersClientTimestampTypeMapping): any;
export declare class DataSnowflakeAccountsAccountsParametersClientTimestampTypeMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersClientTimestampTypeMapping | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersClientTimestampTypeMapping | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersClientTimestampTypeMappingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersClientTimestampTypeMappingOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersCortexCodeCliDailyEstCreditLimitPerUser {
}
export declare function dataSnowflakeAccountsAccountsParametersCortexCodeCliDailyEstCreditLimitPerUserToTerraform(struct?: DataSnowflakeAccountsAccountsParametersCortexCodeCliDailyEstCreditLimitPerUser): any;
export declare function dataSnowflakeAccountsAccountsParametersCortexCodeCliDailyEstCreditLimitPerUserToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersCortexCodeCliDailyEstCreditLimitPerUser): any;
export declare class DataSnowflakeAccountsAccountsParametersCortexCodeCliDailyEstCreditLimitPerUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersCortexCodeCliDailyEstCreditLimitPerUser | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersCortexCodeCliDailyEstCreditLimitPerUser | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersCortexCodeCliDailyEstCreditLimitPerUserList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersCortexCodeCliDailyEstCreditLimitPerUserOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersCortexCodeDesktopDailyEstCreditLimitPerUser {
}
export declare function dataSnowflakeAccountsAccountsParametersCortexCodeDesktopDailyEstCreditLimitPerUserToTerraform(struct?: DataSnowflakeAccountsAccountsParametersCortexCodeDesktopDailyEstCreditLimitPerUser): any;
export declare function dataSnowflakeAccountsAccountsParametersCortexCodeDesktopDailyEstCreditLimitPerUserToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersCortexCodeDesktopDailyEstCreditLimitPerUser): any;
export declare class DataSnowflakeAccountsAccountsParametersCortexCodeDesktopDailyEstCreditLimitPerUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersCortexCodeDesktopDailyEstCreditLimitPerUser | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersCortexCodeDesktopDailyEstCreditLimitPerUser | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersCortexCodeDesktopDailyEstCreditLimitPerUserList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersCortexCodeDesktopDailyEstCreditLimitPerUserOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersCortexCodeSnowsightDailyEstCreditLimitPerUser {
}
export declare function dataSnowflakeAccountsAccountsParametersCortexCodeSnowsightDailyEstCreditLimitPerUserToTerraform(struct?: DataSnowflakeAccountsAccountsParametersCortexCodeSnowsightDailyEstCreditLimitPerUser): any;
export declare function dataSnowflakeAccountsAccountsParametersCortexCodeSnowsightDailyEstCreditLimitPerUserToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersCortexCodeSnowsightDailyEstCreditLimitPerUser): any;
export declare class DataSnowflakeAccountsAccountsParametersCortexCodeSnowsightDailyEstCreditLimitPerUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersCortexCodeSnowsightDailyEstCreditLimitPerUser | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersCortexCodeSnowsightDailyEstCreditLimitPerUser | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersCortexCodeSnowsightDailyEstCreditLimitPerUserList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersCortexCodeSnowsightDailyEstCreditLimitPerUserOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersCortexEnabledCrossRegion {
}
export declare function dataSnowflakeAccountsAccountsParametersCortexEnabledCrossRegionToTerraform(struct?: DataSnowflakeAccountsAccountsParametersCortexEnabledCrossRegion): any;
export declare function dataSnowflakeAccountsAccountsParametersCortexEnabledCrossRegionToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersCortexEnabledCrossRegion): any;
export declare class DataSnowflakeAccountsAccountsParametersCortexEnabledCrossRegionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersCortexEnabledCrossRegion | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersCortexEnabledCrossRegion | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersCortexEnabledCrossRegionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersCortexEnabledCrossRegionOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersCortexModelsAllowlistStruct {
}
export declare function dataSnowflakeAccountsAccountsParametersCortexModelsAllowlistStructToTerraform(struct?: DataSnowflakeAccountsAccountsParametersCortexModelsAllowlistStruct): any;
export declare function dataSnowflakeAccountsAccountsParametersCortexModelsAllowlistStructToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersCortexModelsAllowlistStruct): any;
export declare class DataSnowflakeAccountsAccountsParametersCortexModelsAllowlistStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersCortexModelsAllowlistStruct | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersCortexModelsAllowlistStruct | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersCortexModelsAllowlistStructList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersCortexModelsAllowlistStructOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersCsvTimestampFormat {
}
export declare function dataSnowflakeAccountsAccountsParametersCsvTimestampFormatToTerraform(struct?: DataSnowflakeAccountsAccountsParametersCsvTimestampFormat): any;
export declare function dataSnowflakeAccountsAccountsParametersCsvTimestampFormatToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersCsvTimestampFormat): any;
export declare class DataSnowflakeAccountsAccountsParametersCsvTimestampFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersCsvTimestampFormat | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersCsvTimestampFormat | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersCsvTimestampFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersCsvTimestampFormatOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersDataMetricSchedule {
}
export declare function dataSnowflakeAccountsAccountsParametersDataMetricScheduleToTerraform(struct?: DataSnowflakeAccountsAccountsParametersDataMetricSchedule): any;
export declare function dataSnowflakeAccountsAccountsParametersDataMetricScheduleToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersDataMetricSchedule): any;
export declare class DataSnowflakeAccountsAccountsParametersDataMetricScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersDataMetricSchedule | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersDataMetricSchedule | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersDataMetricScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersDataMetricScheduleOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersDataRetentionTimeInDays {
}
export declare function dataSnowflakeAccountsAccountsParametersDataRetentionTimeInDaysToTerraform(struct?: DataSnowflakeAccountsAccountsParametersDataRetentionTimeInDays): any;
export declare function dataSnowflakeAccountsAccountsParametersDataRetentionTimeInDaysToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersDataRetentionTimeInDays): any;
export declare class DataSnowflakeAccountsAccountsParametersDataRetentionTimeInDaysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersDataRetentionTimeInDays | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersDataRetentionTimeInDays | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersDataRetentionTimeInDaysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersDataRetentionTimeInDaysOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersDateInputFormat {
}
export declare function dataSnowflakeAccountsAccountsParametersDateInputFormatToTerraform(struct?: DataSnowflakeAccountsAccountsParametersDateInputFormat): any;
export declare function dataSnowflakeAccountsAccountsParametersDateInputFormatToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersDateInputFormat): any;
export declare class DataSnowflakeAccountsAccountsParametersDateInputFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersDateInputFormat | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersDateInputFormat | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersDateInputFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersDateInputFormatOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersDateOutputFormat {
}
export declare function dataSnowflakeAccountsAccountsParametersDateOutputFormatToTerraform(struct?: DataSnowflakeAccountsAccountsParametersDateOutputFormat): any;
export declare function dataSnowflakeAccountsAccountsParametersDateOutputFormatToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersDateOutputFormat): any;
export declare class DataSnowflakeAccountsAccountsParametersDateOutputFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersDateOutputFormat | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersDateOutputFormat | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersDateOutputFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersDateOutputFormatOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersDefaultDbtVersion {
}
export declare function dataSnowflakeAccountsAccountsParametersDefaultDbtVersionToTerraform(struct?: DataSnowflakeAccountsAccountsParametersDefaultDbtVersion): any;
export declare function dataSnowflakeAccountsAccountsParametersDefaultDbtVersionToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersDefaultDbtVersion): any;
export declare class DataSnowflakeAccountsAccountsParametersDefaultDbtVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersDefaultDbtVersion | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersDefaultDbtVersion | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersDefaultDbtVersionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersDefaultDbtVersionOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersDefaultDdlCollation {
}
export declare function dataSnowflakeAccountsAccountsParametersDefaultDdlCollationToTerraform(struct?: DataSnowflakeAccountsAccountsParametersDefaultDdlCollation): any;
export declare function dataSnowflakeAccountsAccountsParametersDefaultDdlCollationToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersDefaultDdlCollation): any;
export declare class DataSnowflakeAccountsAccountsParametersDefaultDdlCollationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersDefaultDdlCollation | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersDefaultDdlCollation | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersDefaultDdlCollationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersDefaultDdlCollationOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolCpu {
}
export declare function dataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolCpuToTerraform(struct?: DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolCpu): any;
export declare function dataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolCpuToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolCpu): any;
export declare class DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolCpuOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolCpu | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolCpu | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolCpuList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolCpuOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolGpu {
}
export declare function dataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolGpuToTerraform(struct?: DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolGpu): any;
export declare function dataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolGpuToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolGpu): any;
export declare class DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolGpuOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolGpu | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolGpu | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolGpuList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersDefaultNotebookComputePoolGpuOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersDefaultNullOrdering {
}
export declare function dataSnowflakeAccountsAccountsParametersDefaultNullOrderingToTerraform(struct?: DataSnowflakeAccountsAccountsParametersDefaultNullOrdering): any;
export declare function dataSnowflakeAccountsAccountsParametersDefaultNullOrderingToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersDefaultNullOrdering): any;
export declare class DataSnowflakeAccountsAccountsParametersDefaultNullOrderingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersDefaultNullOrdering | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersDefaultNullOrdering | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersDefaultNullOrderingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersDefaultNullOrderingOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersDefaultStreamlitComputePool {
}
export declare function dataSnowflakeAccountsAccountsParametersDefaultStreamlitComputePoolToTerraform(struct?: DataSnowflakeAccountsAccountsParametersDefaultStreamlitComputePool): any;
export declare function dataSnowflakeAccountsAccountsParametersDefaultStreamlitComputePoolToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersDefaultStreamlitComputePool): any;
export declare class DataSnowflakeAccountsAccountsParametersDefaultStreamlitComputePoolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersDefaultStreamlitComputePool | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersDefaultStreamlitComputePool | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersDefaultStreamlitComputePoolList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersDefaultStreamlitComputePoolOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersDefaultStreamlitNotebookWarehouse {
}
export declare function dataSnowflakeAccountsAccountsParametersDefaultStreamlitNotebookWarehouseToTerraform(struct?: DataSnowflakeAccountsAccountsParametersDefaultStreamlitNotebookWarehouse): any;
export declare function dataSnowflakeAccountsAccountsParametersDefaultStreamlitNotebookWarehouseToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersDefaultStreamlitNotebookWarehouse): any;
export declare class DataSnowflakeAccountsAccountsParametersDefaultStreamlitNotebookWarehouseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersDefaultStreamlitNotebookWarehouse | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersDefaultStreamlitNotebookWarehouse | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersDefaultStreamlitNotebookWarehouseList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersDefaultStreamlitNotebookWarehouseOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersDisableUiDownloadButton {
}
export declare function dataSnowflakeAccountsAccountsParametersDisableUiDownloadButtonToTerraform(struct?: DataSnowflakeAccountsAccountsParametersDisableUiDownloadButton): any;
export declare function dataSnowflakeAccountsAccountsParametersDisableUiDownloadButtonToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersDisableUiDownloadButton): any;
export declare class DataSnowflakeAccountsAccountsParametersDisableUiDownloadButtonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersDisableUiDownloadButton | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersDisableUiDownloadButton | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersDisableUiDownloadButtonList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersDisableUiDownloadButtonOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersDisableUserPrivilegeGrants {
}
export declare function dataSnowflakeAccountsAccountsParametersDisableUserPrivilegeGrantsToTerraform(struct?: DataSnowflakeAccountsAccountsParametersDisableUserPrivilegeGrants): any;
export declare function dataSnowflakeAccountsAccountsParametersDisableUserPrivilegeGrantsToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersDisableUserPrivilegeGrants): any;
export declare class DataSnowflakeAccountsAccountsParametersDisableUserPrivilegeGrantsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersDisableUserPrivilegeGrants | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersDisableUserPrivilegeGrants | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersDisableUserPrivilegeGrantsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersDisableUserPrivilegeGrantsOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersDisallowedSpcsWorkloadTypes {
}
export declare function dataSnowflakeAccountsAccountsParametersDisallowedSpcsWorkloadTypesToTerraform(struct?: DataSnowflakeAccountsAccountsParametersDisallowedSpcsWorkloadTypes): any;
export declare function dataSnowflakeAccountsAccountsParametersDisallowedSpcsWorkloadTypesToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersDisallowedSpcsWorkloadTypes): any;
export declare class DataSnowflakeAccountsAccountsParametersDisallowedSpcsWorkloadTypesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersDisallowedSpcsWorkloadTypes | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersDisallowedSpcsWorkloadTypes | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersDisallowedSpcsWorkloadTypesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersDisallowedSpcsWorkloadTypesOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableAutomaticSensitiveDataClassificationLog {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableAutomaticSensitiveDataClassificationLogToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableAutomaticSensitiveDataClassificationLog): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableAutomaticSensitiveDataClassificationLogToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableAutomaticSensitiveDataClassificationLog): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableAutomaticSensitiveDataClassificationLogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableAutomaticSensitiveDataClassificationLog | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableAutomaticSensitiveDataClassificationLog | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableAutomaticSensitiveDataClassificationLogList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableAutomaticSensitiveDataClassificationLogOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableBudgetEventLogging {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableBudgetEventLoggingToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableBudgetEventLogging): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableBudgetEventLoggingToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableBudgetEventLogging): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableBudgetEventLoggingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableBudgetEventLogging | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableBudgetEventLogging | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableBudgetEventLoggingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableBudgetEventLoggingOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableConsoleOutput {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableConsoleOutputToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableConsoleOutput): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableConsoleOutputToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableConsoleOutput): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableConsoleOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableConsoleOutput | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableConsoleOutput | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableConsoleOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableConsoleOutputOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableCortexAnalyst {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableCortexAnalystToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableCortexAnalyst): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableCortexAnalystToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableCortexAnalyst): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableCortexAnalystOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableCortexAnalyst | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableCortexAnalyst | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableCortexAnalystList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableCortexAnalystOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableDataCompaction {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableDataCompactionToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableDataCompaction): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableDataCompactionToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableDataCompaction): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableDataCompactionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableDataCompaction | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableDataCompaction | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableDataCompactionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableDataCompactionOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableEgressCostOptimizer {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableEgressCostOptimizerToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableEgressCostOptimizer): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableEgressCostOptimizerToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableEgressCostOptimizer): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableEgressCostOptimizerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableEgressCostOptimizer | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableEgressCostOptimizer | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableEgressCostOptimizerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableEgressCostOptimizerOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableGetDdlUseDataTypeAlias {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableGetDdlUseDataTypeAliasToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableGetDdlUseDataTypeAlias): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableGetDdlUseDataTypeAliasToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableGetDdlUseDataTypeAlias): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableGetDdlUseDataTypeAliasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableGetDdlUseDataTypeAlias | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableGetDdlUseDataTypeAlias | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableGetDdlUseDataTypeAliasList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableGetDdlUseDataTypeAliasOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableIcebergMergeOnRead {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableIcebergMergeOnReadToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableIcebergMergeOnRead): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableIcebergMergeOnReadToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableIcebergMergeOnRead): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableIcebergMergeOnReadOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableIcebergMergeOnRead | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableIcebergMergeOnRead | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableIcebergMergeOnReadList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableIcebergMergeOnReadOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableIdentifierFirstLogin {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableIdentifierFirstLoginToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableIdentifierFirstLogin): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableIdentifierFirstLoginToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableIdentifierFirstLogin): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableIdentifierFirstLoginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableIdentifierFirstLogin | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableIdentifierFirstLogin | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableIdentifierFirstLoginList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableIdentifierFirstLoginOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableInternalStagesPrivatelink {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableInternalStagesPrivatelinkToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableInternalStagesPrivatelink): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableInternalStagesPrivatelinkToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableInternalStagesPrivatelink): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableInternalStagesPrivatelinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableInternalStagesPrivatelink | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableInternalStagesPrivatelink | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableInternalStagesPrivatelinkList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableInternalStagesPrivatelinkOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableNotebookCreationInPersonalDb {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableNotebookCreationInPersonalDbToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableNotebookCreationInPersonalDb): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableNotebookCreationInPersonalDbToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableNotebookCreationInPersonalDb): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableNotebookCreationInPersonalDbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableNotebookCreationInPersonalDb | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableNotebookCreationInPersonalDb | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableNotebookCreationInPersonalDbList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableNotebookCreationInPersonalDbOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnablePerAccountAppServicePrivatelinkUrl {
}
export declare function dataSnowflakeAccountsAccountsParametersEnablePerAccountAppServicePrivatelinkUrlToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnablePerAccountAppServicePrivatelinkUrl): any;
export declare function dataSnowflakeAccountsAccountsParametersEnablePerAccountAppServicePrivatelinkUrlToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnablePerAccountAppServicePrivatelinkUrl): any;
export declare class DataSnowflakeAccountsAccountsParametersEnablePerAccountAppServicePrivatelinkUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnablePerAccountAppServicePrivatelinkUrl | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnablePerAccountAppServicePrivatelinkUrl | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnablePerAccountAppServicePrivatelinkUrlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnablePerAccountAppServicePrivatelinkUrlOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnablePersonalDatabase {
}
export declare function dataSnowflakeAccountsAccountsParametersEnablePersonalDatabaseToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnablePersonalDatabase): any;
export declare function dataSnowflakeAccountsAccountsParametersEnablePersonalDatabaseToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnablePersonalDatabase): any;
export declare class DataSnowflakeAccountsAccountsParametersEnablePersonalDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnablePersonalDatabase | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnablePersonalDatabase | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnablePersonalDatabaseList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnablePersonalDatabaseOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableSpcsBlockStorageSnowflakeFullEncryptionEnforcement {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableSpcsBlockStorageSnowflakeFullEncryptionEnforcementToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableSpcsBlockStorageSnowflakeFullEncryptionEnforcement): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableSpcsBlockStorageSnowflakeFullEncryptionEnforcementToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableSpcsBlockStorageSnowflakeFullEncryptionEnforcement): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableSpcsBlockStorageSnowflakeFullEncryptionEnforcementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableSpcsBlockStorageSnowflakeFullEncryptionEnforcement | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableSpcsBlockStorageSnowflakeFullEncryptionEnforcement | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableSpcsBlockStorageSnowflakeFullEncryptionEnforcementList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableSpcsBlockStorageSnowflakeFullEncryptionEnforcementOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableTagPropagationEventLogging {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableTagPropagationEventLoggingToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableTagPropagationEventLogging): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableTagPropagationEventLoggingToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableTagPropagationEventLogging): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableTagPropagationEventLoggingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableTagPropagationEventLogging | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableTagPropagationEventLogging | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableTagPropagationEventLoggingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableTagPropagationEventLoggingOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForImageRepository {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForImageRepositoryToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForImageRepository): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForImageRepositoryToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForImageRepository): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForImageRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForImageRepository | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForImageRepository | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForImageRepositoryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForImageRepositoryOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForSpcsBlockStorage {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForSpcsBlockStorageToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForSpcsBlockStorage): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForSpcsBlockStorageToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForSpcsBlockStorage): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForSpcsBlockStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForSpcsBlockStorage | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForSpcsBlockStorage | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForSpcsBlockStorageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableTriSecretAndRekeyOptOutForSpcsBlockStorageOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableUnhandledExceptionsReporting {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableUnhandledExceptionsReportingToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableUnhandledExceptionsReporting): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableUnhandledExceptionsReportingToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableUnhandledExceptionsReporting): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableUnhandledExceptionsReportingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableUnhandledExceptionsReporting | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableUnhandledExceptionsReporting | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableUnhandledExceptionsReportingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableUnhandledExceptionsReportingOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableUnloadPhysicalTypeOptimization {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableUnloadPhysicalTypeOptimizationToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableUnloadPhysicalTypeOptimization): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableUnloadPhysicalTypeOptimizationToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableUnloadPhysicalTypeOptimization): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableUnloadPhysicalTypeOptimizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableUnloadPhysicalTypeOptimization | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableUnloadPhysicalTypeOptimization | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableUnloadPhysicalTypeOptimizationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableUnloadPhysicalTypeOptimizationOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableUnredactedQuerySyntaxError {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableUnredactedQuerySyntaxErrorToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableUnredactedQuerySyntaxError): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableUnredactedQuerySyntaxErrorToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableUnredactedQuerySyntaxError): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableUnredactedQuerySyntaxErrorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableUnredactedQuerySyntaxError | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableUnredactedQuerySyntaxError | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableUnredactedQuerySyntaxErrorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableUnredactedQuerySyntaxErrorOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnableUnredactedSecureObjectError {
}
export declare function dataSnowflakeAccountsAccountsParametersEnableUnredactedSecureObjectErrorToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableUnredactedSecureObjectError): any;
export declare function dataSnowflakeAccountsAccountsParametersEnableUnredactedSecureObjectErrorToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnableUnredactedSecureObjectError): any;
export declare class DataSnowflakeAccountsAccountsParametersEnableUnredactedSecureObjectErrorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnableUnredactedSecureObjectError | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnableUnredactedSecureObjectError | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnableUnredactedSecureObjectErrorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnableUnredactedSecureObjectErrorOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEnforceNetworkRulesForInternalStages {
}
export declare function dataSnowflakeAccountsAccountsParametersEnforceNetworkRulesForInternalStagesToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnforceNetworkRulesForInternalStages): any;
export declare function dataSnowflakeAccountsAccountsParametersEnforceNetworkRulesForInternalStagesToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEnforceNetworkRulesForInternalStages): any;
export declare class DataSnowflakeAccountsAccountsParametersEnforceNetworkRulesForInternalStagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEnforceNetworkRulesForInternalStages | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEnforceNetworkRulesForInternalStages | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEnforceNetworkRulesForInternalStagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEnforceNetworkRulesForInternalStagesOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicMerge {
}
export declare function dataSnowflakeAccountsAccountsParametersErrorOnNondeterministicMergeToTerraform(struct?: DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicMerge): any;
export declare function dataSnowflakeAccountsAccountsParametersErrorOnNondeterministicMergeToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicMerge): any;
export declare class DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicMergeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicMerge | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicMerge | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicMergeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicMergeOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicUpdate {
}
export declare function dataSnowflakeAccountsAccountsParametersErrorOnNondeterministicUpdateToTerraform(struct?: DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicUpdate): any;
export declare function dataSnowflakeAccountsAccountsParametersErrorOnNondeterministicUpdateToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicUpdate): any;
export declare class DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicUpdateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicUpdate | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicUpdate | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicUpdateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersErrorOnNondeterministicUpdateOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersEventTable {
}
export declare function dataSnowflakeAccountsAccountsParametersEventTableToTerraform(struct?: DataSnowflakeAccountsAccountsParametersEventTable): any;
export declare function dataSnowflakeAccountsAccountsParametersEventTableToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersEventTable): any;
export declare class DataSnowflakeAccountsAccountsParametersEventTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersEventTable | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersEventTable | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersEventTableList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersEventTableOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersExternalOauthAddPrivilegedRolesToBlockedListStruct {
}
export declare function dataSnowflakeAccountsAccountsParametersExternalOauthAddPrivilegedRolesToBlockedListStructToTerraform(struct?: DataSnowflakeAccountsAccountsParametersExternalOauthAddPrivilegedRolesToBlockedListStruct): any;
export declare function dataSnowflakeAccountsAccountsParametersExternalOauthAddPrivilegedRolesToBlockedListStructToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersExternalOauthAddPrivilegedRolesToBlockedListStruct): any;
export declare class DataSnowflakeAccountsAccountsParametersExternalOauthAddPrivilegedRolesToBlockedListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersExternalOauthAddPrivilegedRolesToBlockedListStruct | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersExternalOauthAddPrivilegedRolesToBlockedListStruct | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersExternalOauthAddPrivilegedRolesToBlockedListStructList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersExternalOauthAddPrivilegedRolesToBlockedListStructOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersExternalVolume {
}
export declare function dataSnowflakeAccountsAccountsParametersExternalVolumeToTerraform(struct?: DataSnowflakeAccountsAccountsParametersExternalVolume): any;
export declare function dataSnowflakeAccountsAccountsParametersExternalVolumeToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersExternalVolume): any;
export declare class DataSnowflakeAccountsAccountsParametersExternalVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersExternalVolume | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersExternalVolume | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersExternalVolumeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersExternalVolumeOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersGeographyOutputFormat {
}
export declare function dataSnowflakeAccountsAccountsParametersGeographyOutputFormatToTerraform(struct?: DataSnowflakeAccountsAccountsParametersGeographyOutputFormat): any;
export declare function dataSnowflakeAccountsAccountsParametersGeographyOutputFormatToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersGeographyOutputFormat): any;
export declare class DataSnowflakeAccountsAccountsParametersGeographyOutputFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersGeographyOutputFormat | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersGeographyOutputFormat | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersGeographyOutputFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersGeographyOutputFormatOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersGeometryOutputFormat {
}
export declare function dataSnowflakeAccountsAccountsParametersGeometryOutputFormatToTerraform(struct?: DataSnowflakeAccountsAccountsParametersGeometryOutputFormat): any;
export declare function dataSnowflakeAccountsAccountsParametersGeometryOutputFormatToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersGeometryOutputFormat): any;
export declare class DataSnowflakeAccountsAccountsParametersGeometryOutputFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersGeometryOutputFormat | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersGeometryOutputFormat | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersGeometryOutputFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersGeometryOutputFormatOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersHybridTableLockTimeout {
}
export declare function dataSnowflakeAccountsAccountsParametersHybridTableLockTimeoutToTerraform(struct?: DataSnowflakeAccountsAccountsParametersHybridTableLockTimeout): any;
export declare function dataSnowflakeAccountsAccountsParametersHybridTableLockTimeoutToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersHybridTableLockTimeout): any;
export declare class DataSnowflakeAccountsAccountsParametersHybridTableLockTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersHybridTableLockTimeout | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersHybridTableLockTimeout | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersHybridTableLockTimeoutList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersHybridTableLockTimeoutOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersIcebergVersionDefault {
}
export declare function dataSnowflakeAccountsAccountsParametersIcebergVersionDefaultToTerraform(struct?: DataSnowflakeAccountsAccountsParametersIcebergVersionDefault): any;
export declare function dataSnowflakeAccountsAccountsParametersIcebergVersionDefaultToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersIcebergVersionDefault): any;
export declare class DataSnowflakeAccountsAccountsParametersIcebergVersionDefaultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersIcebergVersionDefault | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersIcebergVersionDefault | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersIcebergVersionDefaultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersIcebergVersionDefaultOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersInitialReplicationSizeLimitInTb {
}
export declare function dataSnowflakeAccountsAccountsParametersInitialReplicationSizeLimitInTbToTerraform(struct?: DataSnowflakeAccountsAccountsParametersInitialReplicationSizeLimitInTb): any;
export declare function dataSnowflakeAccountsAccountsParametersInitialReplicationSizeLimitInTbToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersInitialReplicationSizeLimitInTb): any;
export declare class DataSnowflakeAccountsAccountsParametersInitialReplicationSizeLimitInTbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersInitialReplicationSizeLimitInTb | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersInitialReplicationSizeLimitInTb | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersInitialReplicationSizeLimitInTbList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersInitialReplicationSizeLimitInTbOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersJdbcTreatDecimalAsInt {
}
export declare function dataSnowflakeAccountsAccountsParametersJdbcTreatDecimalAsIntToTerraform(struct?: DataSnowflakeAccountsAccountsParametersJdbcTreatDecimalAsInt): any;
export declare function dataSnowflakeAccountsAccountsParametersJdbcTreatDecimalAsIntToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersJdbcTreatDecimalAsInt): any;
export declare class DataSnowflakeAccountsAccountsParametersJdbcTreatDecimalAsIntOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersJdbcTreatDecimalAsInt | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersJdbcTreatDecimalAsInt | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersJdbcTreatDecimalAsIntList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersJdbcTreatDecimalAsIntOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersJdbcTreatTimestampNtzAsUtc {
}
export declare function dataSnowflakeAccountsAccountsParametersJdbcTreatTimestampNtzAsUtcToTerraform(struct?: DataSnowflakeAccountsAccountsParametersJdbcTreatTimestampNtzAsUtc): any;
export declare function dataSnowflakeAccountsAccountsParametersJdbcTreatTimestampNtzAsUtcToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersJdbcTreatTimestampNtzAsUtc): any;
export declare class DataSnowflakeAccountsAccountsParametersJdbcTreatTimestampNtzAsUtcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersJdbcTreatTimestampNtzAsUtc | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersJdbcTreatTimestampNtzAsUtc | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersJdbcTreatTimestampNtzAsUtcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersJdbcTreatTimestampNtzAsUtcOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersJdbcUseSessionTimezone {
}
export declare function dataSnowflakeAccountsAccountsParametersJdbcUseSessionTimezoneToTerraform(struct?: DataSnowflakeAccountsAccountsParametersJdbcUseSessionTimezone): any;
export declare function dataSnowflakeAccountsAccountsParametersJdbcUseSessionTimezoneToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersJdbcUseSessionTimezone): any;
export declare class DataSnowflakeAccountsAccountsParametersJdbcUseSessionTimezoneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersJdbcUseSessionTimezone | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersJdbcUseSessionTimezone | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersJdbcUseSessionTimezoneList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersJdbcUseSessionTimezoneOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersJsTreatIntegerAsBigint {
}
export declare function dataSnowflakeAccountsAccountsParametersJsTreatIntegerAsBigintToTerraform(struct?: DataSnowflakeAccountsAccountsParametersJsTreatIntegerAsBigint): any;
export declare function dataSnowflakeAccountsAccountsParametersJsTreatIntegerAsBigintToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersJsTreatIntegerAsBigint): any;
export declare class DataSnowflakeAccountsAccountsParametersJsTreatIntegerAsBigintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersJsTreatIntegerAsBigint | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersJsTreatIntegerAsBigint | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersJsTreatIntegerAsBigintList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersJsTreatIntegerAsBigintOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersJsonIndent {
}
export declare function dataSnowflakeAccountsAccountsParametersJsonIndentToTerraform(struct?: DataSnowflakeAccountsAccountsParametersJsonIndent): any;
export declare function dataSnowflakeAccountsAccountsParametersJsonIndentToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersJsonIndent): any;
export declare class DataSnowflakeAccountsAccountsParametersJsonIndentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersJsonIndent | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersJsonIndent | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersJsonIndentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersJsonIndentOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersListingAutoFulfillmentReplicationRefreshSchedule {
}
export declare function dataSnowflakeAccountsAccountsParametersListingAutoFulfillmentReplicationRefreshScheduleToTerraform(struct?: DataSnowflakeAccountsAccountsParametersListingAutoFulfillmentReplicationRefreshSchedule): any;
export declare function dataSnowflakeAccountsAccountsParametersListingAutoFulfillmentReplicationRefreshScheduleToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersListingAutoFulfillmentReplicationRefreshSchedule): any;
export declare class DataSnowflakeAccountsAccountsParametersListingAutoFulfillmentReplicationRefreshScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersListingAutoFulfillmentReplicationRefreshSchedule | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersListingAutoFulfillmentReplicationRefreshSchedule | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersListingAutoFulfillmentReplicationRefreshScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersListingAutoFulfillmentReplicationRefreshScheduleOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersLockTimeout {
}
export declare function dataSnowflakeAccountsAccountsParametersLockTimeoutToTerraform(struct?: DataSnowflakeAccountsAccountsParametersLockTimeout): any;
export declare function dataSnowflakeAccountsAccountsParametersLockTimeoutToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersLockTimeout): any;
export declare class DataSnowflakeAccountsAccountsParametersLockTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersLockTimeout | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersLockTimeout | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersLockTimeoutList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersLockTimeoutOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersLogEventLevel {
}
export declare function dataSnowflakeAccountsAccountsParametersLogEventLevelToTerraform(struct?: DataSnowflakeAccountsAccountsParametersLogEventLevel): any;
export declare function dataSnowflakeAccountsAccountsParametersLogEventLevelToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersLogEventLevel): any;
export declare class DataSnowflakeAccountsAccountsParametersLogEventLevelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersLogEventLevel | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersLogEventLevel | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersLogEventLevelList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersLogEventLevelOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersLogLevel {
}
export declare function dataSnowflakeAccountsAccountsParametersLogLevelToTerraform(struct?: DataSnowflakeAccountsAccountsParametersLogLevel): any;
export declare function dataSnowflakeAccountsAccountsParametersLogLevelToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersLogLevel): any;
export declare class DataSnowflakeAccountsAccountsParametersLogLevelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersLogLevel | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersLogLevel | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersLogLevelList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersLogLevelOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersMaxConcurrencyLevel {
}
export declare function dataSnowflakeAccountsAccountsParametersMaxConcurrencyLevelToTerraform(struct?: DataSnowflakeAccountsAccountsParametersMaxConcurrencyLevel): any;
export declare function dataSnowflakeAccountsAccountsParametersMaxConcurrencyLevelToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersMaxConcurrencyLevel): any;
export declare class DataSnowflakeAccountsAccountsParametersMaxConcurrencyLevelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersMaxConcurrencyLevel | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersMaxConcurrencyLevel | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersMaxConcurrencyLevelList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersMaxConcurrencyLevelOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersMaxDataExtensionTimeInDays {
}
export declare function dataSnowflakeAccountsAccountsParametersMaxDataExtensionTimeInDaysToTerraform(struct?: DataSnowflakeAccountsAccountsParametersMaxDataExtensionTimeInDays): any;
export declare function dataSnowflakeAccountsAccountsParametersMaxDataExtensionTimeInDaysToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersMaxDataExtensionTimeInDays): any;
export declare class DataSnowflakeAccountsAccountsParametersMaxDataExtensionTimeInDaysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersMaxDataExtensionTimeInDays | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersMaxDataExtensionTimeInDays | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersMaxDataExtensionTimeInDaysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersMaxDataExtensionTimeInDaysOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersMetricLevel {
}
export declare function dataSnowflakeAccountsAccountsParametersMetricLevelToTerraform(struct?: DataSnowflakeAccountsAccountsParametersMetricLevel): any;
export declare function dataSnowflakeAccountsAccountsParametersMetricLevelToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersMetricLevel): any;
export declare class DataSnowflakeAccountsAccountsParametersMetricLevelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersMetricLevel | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersMetricLevel | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersMetricLevelList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersMetricLevelOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersMinDataRetentionTimeInDays {
}
export declare function dataSnowflakeAccountsAccountsParametersMinDataRetentionTimeInDaysToTerraform(struct?: DataSnowflakeAccountsAccountsParametersMinDataRetentionTimeInDays): any;
export declare function dataSnowflakeAccountsAccountsParametersMinDataRetentionTimeInDaysToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersMinDataRetentionTimeInDays): any;
export declare class DataSnowflakeAccountsAccountsParametersMinDataRetentionTimeInDaysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersMinDataRetentionTimeInDays | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersMinDataRetentionTimeInDays | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersMinDataRetentionTimeInDaysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersMinDataRetentionTimeInDaysOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersMultiStatementCount {
}
export declare function dataSnowflakeAccountsAccountsParametersMultiStatementCountToTerraform(struct?: DataSnowflakeAccountsAccountsParametersMultiStatementCount): any;
export declare function dataSnowflakeAccountsAccountsParametersMultiStatementCountToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersMultiStatementCount): any;
export declare class DataSnowflakeAccountsAccountsParametersMultiStatementCountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersMultiStatementCount | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersMultiStatementCount | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersMultiStatementCountList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersMultiStatementCountOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersNetworkPolicy {
}
export declare function dataSnowflakeAccountsAccountsParametersNetworkPolicyToTerraform(struct?: DataSnowflakeAccountsAccountsParametersNetworkPolicy): any;
export declare function dataSnowflakeAccountsAccountsParametersNetworkPolicyToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersNetworkPolicy): any;
export declare class DataSnowflakeAccountsAccountsParametersNetworkPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersNetworkPolicy | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersNetworkPolicy | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersNetworkPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersNetworkPolicyOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersNoorderSequenceAsDefault {
}
export declare function dataSnowflakeAccountsAccountsParametersNoorderSequenceAsDefaultToTerraform(struct?: DataSnowflakeAccountsAccountsParametersNoorderSequenceAsDefault): any;
export declare function dataSnowflakeAccountsAccountsParametersNoorderSequenceAsDefaultToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersNoorderSequenceAsDefault): any;
export declare class DataSnowflakeAccountsAccountsParametersNoorderSequenceAsDefaultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersNoorderSequenceAsDefault | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersNoorderSequenceAsDefault | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersNoorderSequenceAsDefaultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersNoorderSequenceAsDefaultOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersOauthAddPrivilegedRolesToBlockedListStruct {
}
export declare function dataSnowflakeAccountsAccountsParametersOauthAddPrivilegedRolesToBlockedListStructToTerraform(struct?: DataSnowflakeAccountsAccountsParametersOauthAddPrivilegedRolesToBlockedListStruct): any;
export declare function dataSnowflakeAccountsAccountsParametersOauthAddPrivilegedRolesToBlockedListStructToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersOauthAddPrivilegedRolesToBlockedListStruct): any;
export declare class DataSnowflakeAccountsAccountsParametersOauthAddPrivilegedRolesToBlockedListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersOauthAddPrivilegedRolesToBlockedListStruct | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersOauthAddPrivilegedRolesToBlockedListStruct | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersOauthAddPrivilegedRolesToBlockedListStructList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersOauthAddPrivilegedRolesToBlockedListStructOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersOdbcTreatDecimalAsInt {
}
export declare function dataSnowflakeAccountsAccountsParametersOdbcTreatDecimalAsIntToTerraform(struct?: DataSnowflakeAccountsAccountsParametersOdbcTreatDecimalAsInt): any;
export declare function dataSnowflakeAccountsAccountsParametersOdbcTreatDecimalAsIntToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersOdbcTreatDecimalAsInt): any;
export declare class DataSnowflakeAccountsAccountsParametersOdbcTreatDecimalAsIntOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersOdbcTreatDecimalAsInt | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersOdbcTreatDecimalAsInt | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersOdbcTreatDecimalAsIntList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersOdbcTreatDecimalAsIntOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersPeriodicDataRekeying {
}
export declare function dataSnowflakeAccountsAccountsParametersPeriodicDataRekeyingToTerraform(struct?: DataSnowflakeAccountsAccountsParametersPeriodicDataRekeying): any;
export declare function dataSnowflakeAccountsAccountsParametersPeriodicDataRekeyingToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersPeriodicDataRekeying): any;
export declare class DataSnowflakeAccountsAccountsParametersPeriodicDataRekeyingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersPeriodicDataRekeying | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersPeriodicDataRekeying | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersPeriodicDataRekeyingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersPeriodicDataRekeyingOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersPipeExecutionPaused {
}
export declare function dataSnowflakeAccountsAccountsParametersPipeExecutionPausedToTerraform(struct?: DataSnowflakeAccountsAccountsParametersPipeExecutionPaused): any;
export declare function dataSnowflakeAccountsAccountsParametersPipeExecutionPausedToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersPipeExecutionPaused): any;
export declare class DataSnowflakeAccountsAccountsParametersPipeExecutionPausedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersPipeExecutionPaused | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersPipeExecutionPaused | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersPipeExecutionPausedList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersPipeExecutionPausedOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersPreventLoadFromInlineUrl {
}
export declare function dataSnowflakeAccountsAccountsParametersPreventLoadFromInlineUrlToTerraform(struct?: DataSnowflakeAccountsAccountsParametersPreventLoadFromInlineUrl): any;
export declare function dataSnowflakeAccountsAccountsParametersPreventLoadFromInlineUrlToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersPreventLoadFromInlineUrl): any;
export declare class DataSnowflakeAccountsAccountsParametersPreventLoadFromInlineUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersPreventLoadFromInlineUrl | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersPreventLoadFromInlineUrl | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersPreventLoadFromInlineUrlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersPreventLoadFromInlineUrlOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersPreventUnloadToInlineUrl {
}
export declare function dataSnowflakeAccountsAccountsParametersPreventUnloadToInlineUrlToTerraform(struct?: DataSnowflakeAccountsAccountsParametersPreventUnloadToInlineUrl): any;
export declare function dataSnowflakeAccountsAccountsParametersPreventUnloadToInlineUrlToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersPreventUnloadToInlineUrl): any;
export declare class DataSnowflakeAccountsAccountsParametersPreventUnloadToInlineUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersPreventUnloadToInlineUrl | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersPreventUnloadToInlineUrl | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersPreventUnloadToInlineUrlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersPreventUnloadToInlineUrlOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersPreventUnloadToInternalStages {
}
export declare function dataSnowflakeAccountsAccountsParametersPreventUnloadToInternalStagesToTerraform(struct?: DataSnowflakeAccountsAccountsParametersPreventUnloadToInternalStages): any;
export declare function dataSnowflakeAccountsAccountsParametersPreventUnloadToInternalStagesToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersPreventUnloadToInternalStages): any;
export declare class DataSnowflakeAccountsAccountsParametersPreventUnloadToInternalStagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersPreventUnloadToInternalStages | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersPreventUnloadToInternalStages | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersPreventUnloadToInternalStagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersPreventUnloadToInternalStagesOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersPythonProfilerModules {
}
export declare function dataSnowflakeAccountsAccountsParametersPythonProfilerModulesToTerraform(struct?: DataSnowflakeAccountsAccountsParametersPythonProfilerModules): any;
export declare function dataSnowflakeAccountsAccountsParametersPythonProfilerModulesToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersPythonProfilerModules): any;
export declare class DataSnowflakeAccountsAccountsParametersPythonProfilerModulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersPythonProfilerModules | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersPythonProfilerModules | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersPythonProfilerModulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersPythonProfilerModulesOutputReference;
}
export interface DataSnowflakeAccountsAccountsParametersPythonProfilerTargetStage {
}
export declare function dataSnowflakeAccountsAccountsParametersPythonProfilerTargetStageToTerraform(struct?: DataSnowflakeAccountsAccountsParametersPythonProfilerTargetStage): any;
export declare function dataSnowflakeAccountsAccountsParametersPythonProfilerTargetStageToHclTerraform(struct?: DataSnowflakeAccountsAccountsParametersPythonProfilerTargetStage): any;
export declare class DataSnowflakeAccountsAccountsParametersPythonProfilerTargetStageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsParametersPythonProfilerTargetStage | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsParametersPythonProfilerTargetStage | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeAccountsAccountsParametersPythonProfilerTargetStageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsParametersPythonProfilerTargetStageOutputReference;
}
