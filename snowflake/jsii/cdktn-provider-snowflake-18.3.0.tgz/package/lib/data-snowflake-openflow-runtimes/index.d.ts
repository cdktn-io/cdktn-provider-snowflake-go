/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeOpenflowRuntimesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/data-sources/openflow_runtimes#id DataSnowflakeOpenflowRuntimes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/data-sources/openflow_runtimes#like DataSnowflakeOpenflowRuntimes#like}
    */
    readonly like?: string;
    /**
    * Filters the output with **case-sensitive** characters indicating the beginning of the object name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/data-sources/openflow_runtimes#starts_with DataSnowflakeOpenflowRuntimes#starts_with}
    */
    readonly startsWith?: string;
    /**
    * (Default: `true`) Runs DESC OPENFLOW RUNTIME for each runtime returned by SHOW OPENFLOW RUNTIMES. The output of describe is saved to the description field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/data-sources/openflow_runtimes#with_describe DataSnowflakeOpenflowRuntimes#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * in block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/data-sources/openflow_runtimes#in DataSnowflakeOpenflowRuntimes#in}
    */
    readonly in?: DataSnowflakeOpenflowRuntimesIn;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/data-sources/openflow_runtimes#limit DataSnowflakeOpenflowRuntimes#limit}
    */
    readonly limit?: DataSnowflakeOpenflowRuntimesLimit;
}
export interface DataSnowflakeOpenflowRuntimesOpenflowRuntimesDescribeOutput {
}
export declare function dataSnowflakeOpenflowRuntimesOpenflowRuntimesDescribeOutputToTerraform(struct?: DataSnowflakeOpenflowRuntimesOpenflowRuntimesDescribeOutput): any;
export declare function dataSnowflakeOpenflowRuntimesOpenflowRuntimesDescribeOutputToHclTerraform(struct?: DataSnowflakeOpenflowRuntimesOpenflowRuntimesDescribeOutput): any;
export declare class DataSnowflakeOpenflowRuntimesOpenflowRuntimesDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeOpenflowRuntimesOpenflowRuntimesDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeOpenflowRuntimesOpenflowRuntimesDescribeOutput | undefined);
    get comment(): string;
    get deployment(): string;
    get displayName(): string;
    get executeAsRole(): string;
    get externalAccessIntegrations(): string[];
    get initiallySuspended(): cdktn.IResolvable;
    get key(): string;
    get maxNodes(): number;
    get minNodes(): number;
    get name(): string;
    get nodeType(): string;
    get nodeTypeTier(): string;
    get owner(): string;
    get serverUrl(): string;
    get status(): string;
}
export declare class DataSnowflakeOpenflowRuntimesOpenflowRuntimesDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeOpenflowRuntimesOpenflowRuntimesDescribeOutputOutputReference;
}
export interface DataSnowflakeOpenflowRuntimesOpenflowRuntimesShowOutput {
}
export declare function dataSnowflakeOpenflowRuntimesOpenflowRuntimesShowOutputToTerraform(struct?: DataSnowflakeOpenflowRuntimesOpenflowRuntimesShowOutput): any;
export declare function dataSnowflakeOpenflowRuntimesOpenflowRuntimesShowOutputToHclTerraform(struct?: DataSnowflakeOpenflowRuntimesOpenflowRuntimesShowOutput): any;
export declare class DataSnowflakeOpenflowRuntimesOpenflowRuntimesShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeOpenflowRuntimesOpenflowRuntimesShowOutput | undefined;
    set internalValue(value: DataSnowflakeOpenflowRuntimesOpenflowRuntimesShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get deployment(): string;
    get displayName(): string;
    get executeAsRole(): string;
    get externalAccessIntegrations(): string[];
    get initiallySuspended(): cdktn.IResolvable;
    get key(): string;
    get maxNodes(): number;
    get minNodes(): number;
    get name(): string;
    get nodeType(): string;
    get owner(): string;
    get schemaName(): string;
    get status(): string;
    get updatedOn(): string;
}
export declare class DataSnowflakeOpenflowRuntimesOpenflowRuntimesShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeOpenflowRuntimesOpenflowRuntimesShowOutputOutputReference;
}
export interface DataSnowflakeOpenflowRuntimesOpenflowRuntimes {
}
export declare function dataSnowflakeOpenflowRuntimesOpenflowRuntimesToTerraform(struct?: DataSnowflakeOpenflowRuntimesOpenflowRuntimes): any;
export declare function dataSnowflakeOpenflowRuntimesOpenflowRuntimesToHclTerraform(struct?: DataSnowflakeOpenflowRuntimesOpenflowRuntimes): any;
export declare class DataSnowflakeOpenflowRuntimesOpenflowRuntimesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeOpenflowRuntimesOpenflowRuntimes | undefined;
    set internalValue(value: DataSnowflakeOpenflowRuntimesOpenflowRuntimes | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeOpenflowRuntimesOpenflowRuntimesDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeOpenflowRuntimesOpenflowRuntimesShowOutputList;
}
export declare class DataSnowflakeOpenflowRuntimesOpenflowRuntimesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeOpenflowRuntimesOpenflowRuntimesOutputReference;
}
export interface DataSnowflakeOpenflowRuntimesIn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/data-sources/openflow_runtimes#account DataSnowflakeOpenflowRuntimes#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the current database in use or for a specified database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/data-sources/openflow_runtimes#database DataSnowflakeOpenflowRuntimes#database}
    */
    readonly database?: string;
    /**
    * Returns records for the current schema in use or a specified schema. Use fully qualified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/data-sources/openflow_runtimes#schema DataSnowflakeOpenflowRuntimes#schema}
    */
    readonly schema?: string;
}
export declare function dataSnowflakeOpenflowRuntimesInToTerraform(struct?: DataSnowflakeOpenflowRuntimesInOutputReference | DataSnowflakeOpenflowRuntimesIn): any;
export declare function dataSnowflakeOpenflowRuntimesInToHclTerraform(struct?: DataSnowflakeOpenflowRuntimesInOutputReference | DataSnowflakeOpenflowRuntimesIn): any;
export declare class DataSnowflakeOpenflowRuntimesInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeOpenflowRuntimesIn | undefined;
    set internalValue(value: DataSnowflakeOpenflowRuntimesIn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export interface DataSnowflakeOpenflowRuntimesLimit {
    /**
    * Specifies a **case-sensitive** pattern that is used to match object name. After the first match, the limit on the number of rows will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/data-sources/openflow_runtimes#from DataSnowflakeOpenflowRuntimes#from}
    */
    readonly from?: string;
    /**
    * The maximum number of rows to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/data-sources/openflow_runtimes#rows DataSnowflakeOpenflowRuntimes#rows}
    */
    readonly rows: number;
}
export declare function dataSnowflakeOpenflowRuntimesLimitToTerraform(struct?: DataSnowflakeOpenflowRuntimesLimitOutputReference | DataSnowflakeOpenflowRuntimesLimit): any;
export declare function dataSnowflakeOpenflowRuntimesLimitToHclTerraform(struct?: DataSnowflakeOpenflowRuntimesLimitOutputReference | DataSnowflakeOpenflowRuntimesLimit): any;
export declare class DataSnowflakeOpenflowRuntimesLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeOpenflowRuntimesLimit | undefined;
    set internalValue(value: DataSnowflakeOpenflowRuntimesLimit | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _rows?;
    get rows(): number;
    set rows(value: number);
    get rowsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/data-sources/openflow_runtimes snowflake_openflow_runtimes}
*/
export declare class DataSnowflakeOpenflowRuntimes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_openflow_runtimes";
    /**
    * Generates CDKTN code for importing a DataSnowflakeOpenflowRuntimes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeOpenflowRuntimes to import
    * @param importFromId The id of the existing DataSnowflakeOpenflowRuntimes that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/data-sources/openflow_runtimes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeOpenflowRuntimes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.22.0/docs/data-sources/openflow_runtimes snowflake_openflow_runtimes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeOpenflowRuntimesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeOpenflowRuntimesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _openflowRuntimes;
    get openflowRuntimes(): DataSnowflakeOpenflowRuntimesOpenflowRuntimesList;
    private _startsWith?;
    get startsWith(): string;
    set startsWith(value: string);
    resetStartsWith(): void;
    get startsWithInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _in;
    get in(): DataSnowflakeOpenflowRuntimesInOutputReference;
    putIn(value: DataSnowflakeOpenflowRuntimesIn): void;
    resetIn(): void;
    get inInput(): DataSnowflakeOpenflowRuntimesIn | undefined;
    private _limit;
    get limit(): DataSnowflakeOpenflowRuntimesLimitOutputReference;
    putLimit(value: DataSnowflakeOpenflowRuntimesLimit): void;
    resetLimit(): void;
    get limitInput(): DataSnowflakeOpenflowRuntimesLimit | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
