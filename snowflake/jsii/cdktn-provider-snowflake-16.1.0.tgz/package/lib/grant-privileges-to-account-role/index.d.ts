/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GrantPrivilegesToAccountRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The fully qualified name of the account role to which privileges will be granted. For more information about this resource, see [docs](./account_role).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#account_role_name GrantPrivilegesToAccountRole#account_role_name}
    */
    readonly accountRoleName: string;
    /**
    * (Default: `false`) Grant all privileges on the account role. When all privileges cannot be granted, the provider returns a warning, which is aligned with the Snowsight behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#all_privileges GrantPrivilegesToAccountRole#all_privileges}
    */
    readonly allPrivileges?: boolean | cdktn.IResolvable;
    /**
    * (Default: `false`) If true, the resource will always produce a “plan” and on “apply” it will re-grant defined privileges. It is supposed to be used only in “grant privileges on all X’s in database / schema Y” or “grant all privileges to X” scenarios to make sure that every new object in a given database / schema is granted by the account role and every new privilege is granted to the database role. Important note: this flag is not compliant with the Terraform assumptions of the config being eventually convergent (producing an empty plan).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#always_apply GrantPrivilegesToAccountRole#always_apply}
    */
    readonly alwaysApply?: boolean | cdktn.IResolvable;
    /**
    * (Default: ``) This is a helper field and should not be set. Its main purpose is to help to achieve the functionality described by the always_apply field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#always_apply_trigger GrantPrivilegesToAccountRole#always_apply_trigger}
    */
    readonly alwaysApplyTrigger?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#id GrantPrivilegesToAccountRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * (Default: `false`) If true, the privileges will be granted on the account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#on_account GrantPrivilegesToAccountRole#on_account}
    */
    readonly onAccount?: boolean | cdktn.IResolvable;
    /**
    * The privileges to grant on the account role. This field is case-sensitive; use only upper-case privileges.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#privileges GrantPrivilegesToAccountRole#privileges}
    */
    readonly privileges?: string[];
    /**
    * (Default: `false`) If true, the resource will revoke all privileges that are not explicitly defined in the config making it a central source of truth for the privileges granted on an object to an account role. If false, the resource will be only concerned with the privileges that are explicitly defined in the config. The potential privilege removals will be planned only after second `terraform apply` run, after setting the flag in resource configuration. This means, the flag update doesn't revoke immediately any externally granted privileges. This is a Terraform limitation, and two steps are needed to properly show the potential privilege changes (e.g., revoking privileges not specified in the configuration) in the plan. External privileges will be detected regardless of their grant option. The parameter can be only used when `GRANTS_STRICT_PRIVILEGE_MANAGEMENT` option is specified in provider block in the [`experimental_features_enabled`](https://registry.terraform.io/providers/snowflakedb/snowflake/latest/docs#experimental_features_enabled-1) field. Regular and future grants are treated separately, meaning, more resources need to be defined to control regular and future grants for a given object and role (and for a given database or schema they're defined in for future grants). See our [Strict privilege management](https://registry.terraform.io/providers/snowflakedb/snowflake/latest/docs/guides/strict_privilege_management) guide for more information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#strict_privilege_management GrantPrivilegesToAccountRole#strict_privilege_management}
    */
    readonly strictPrivilegeManagement?: boolean | cdktn.IResolvable;
    /**
    * (Default: `false`) Specifies whether the grantee can grant the privileges to other users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#with_grant_option GrantPrivilegesToAccountRole#with_grant_option}
    */
    readonly withGrantOption?: boolean | cdktn.IResolvable;
    /**
    * on_account_object block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#on_account_object GrantPrivilegesToAccountRole#on_account_object}
    */
    readonly onAccountObject?: GrantPrivilegesToAccountRoleOnAccountObject;
    /**
    * on_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#on_schema GrantPrivilegesToAccountRole#on_schema}
    */
    readonly onSchema?: GrantPrivilegesToAccountRoleOnSchema;
    /**
    * on_schema_object block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#on_schema_object GrantPrivilegesToAccountRole#on_schema_object}
    */
    readonly onSchemaObject?: GrantPrivilegesToAccountRoleOnSchemaObject;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#timeouts GrantPrivilegesToAccountRole#timeouts}
    */
    readonly timeouts?: GrantPrivilegesToAccountRoleTimeouts;
}
export interface GrantPrivilegesToAccountRoleOnAccountObject {
    /**
    * The fully qualified name of the object on which privileges will be granted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#object_name GrantPrivilegesToAccountRole#object_name}
    */
    readonly objectName: string;
    /**
    * The object type of the account object on which privileges will be granted. Valid values are: `USER` | `RESOURCE MONITOR` | `WAREHOUSE` | `COMPUTE POOL` | `DATABASE` | `INTEGRATION` | `CONNECTION` | `FAILOVER GROUP` | `REPLICATION GROUP` | `EXTERNAL VOLUME`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#object_type GrantPrivilegesToAccountRole#object_type}
    */
    readonly objectType: string;
}
export declare function grantPrivilegesToAccountRoleOnAccountObjectToTerraform(struct?: GrantPrivilegesToAccountRoleOnAccountObjectOutputReference | GrantPrivilegesToAccountRoleOnAccountObject): any;
export declare function grantPrivilegesToAccountRoleOnAccountObjectToHclTerraform(struct?: GrantPrivilegesToAccountRoleOnAccountObjectOutputReference | GrantPrivilegesToAccountRoleOnAccountObject): any;
export declare class GrantPrivilegesToAccountRoleOnAccountObjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GrantPrivilegesToAccountRoleOnAccountObject | undefined;
    set internalValue(value: GrantPrivilegesToAccountRoleOnAccountObject | undefined);
    private _objectName?;
    get objectName(): string;
    set objectName(value: string);
    get objectNameInput(): string | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    get objectTypeInput(): string | undefined;
}
export interface GrantPrivilegesToAccountRoleOnSchema {
    /**
    * The fully qualified name of the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#all_schemas_in_database GrantPrivilegesToAccountRole#all_schemas_in_database}
    */
    readonly allSchemasInDatabase?: string;
    /**
    * The fully qualified name of the database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#future_schemas_in_database GrantPrivilegesToAccountRole#future_schemas_in_database}
    */
    readonly futureSchemasInDatabase?: string;
    /**
    * The fully qualified name of the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#schema_name GrantPrivilegesToAccountRole#schema_name}
    */
    readonly schemaName?: string;
}
export declare function grantPrivilegesToAccountRoleOnSchemaToTerraform(struct?: GrantPrivilegesToAccountRoleOnSchemaOutputReference | GrantPrivilegesToAccountRoleOnSchema): any;
export declare function grantPrivilegesToAccountRoleOnSchemaToHclTerraform(struct?: GrantPrivilegesToAccountRoleOnSchemaOutputReference | GrantPrivilegesToAccountRoleOnSchema): any;
export declare class GrantPrivilegesToAccountRoleOnSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GrantPrivilegesToAccountRoleOnSchema | undefined;
    set internalValue(value: GrantPrivilegesToAccountRoleOnSchema | undefined);
    private _allSchemasInDatabase?;
    get allSchemasInDatabase(): string;
    set allSchemasInDatabase(value: string);
    resetAllSchemasInDatabase(): void;
    get allSchemasInDatabaseInput(): string | undefined;
    private _futureSchemasInDatabase?;
    get futureSchemasInDatabase(): string;
    set futureSchemasInDatabase(value: string);
    resetFutureSchemasInDatabase(): void;
    get futureSchemasInDatabaseInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
}
export interface GrantPrivilegesToAccountRoleOnSchemaObjectAll {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#in_database GrantPrivilegesToAccountRole#in_database}
    */
    readonly inDatabase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#in_schema GrantPrivilegesToAccountRole#in_schema}
    */
    readonly inSchema?: string;
    /**
    * The plural object type of the schema object on which privileges will be granted. Valid values are: AGENTS | AGGREGATION POLICIES | ALERTS | AUTHENTICATION POLICIES | CORTEX SEARCH SERVICES | DATA METRIC FUNCTIONS | DATASETS | DBT PROJECTS | DYNAMIC TABLES | EVENT TABLES | EXTERNAL TABLES | FILE FORMATS | FUNCTIONS | GIT REPOSITORIES | HYBRID TABLES | IMAGE REPOSITORIES | ICEBERG TABLES | MASKING POLICIES | MATERIALIZED VIEWS | MCP SERVERS | MODELS | MODEL MONITORS | NETWORK RULES | NOTEBOOKS | ONLINE FEATURE TABLES | PACKAGES POLICIES | PASSWORD POLICIES | PIPES | PRIVACY POLICIES | PROCEDURES | PROJECTION POLICIES | ROW ACCESS POLICIES | SECRETS | SEMANTIC VIEWS | SERVICES | SESSION POLICIES | SEQUENCES | SNAPSHOTS | SNAPSHOT POLICIES | SNAPSHOT SETS | STAGES | STREAMS | STREAMLITS | TABLES | TAGS | TASKS | VIEWS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#object_type_plural GrantPrivilegesToAccountRole#object_type_plural}
    */
    readonly objectTypePlural: string;
}
export declare function grantPrivilegesToAccountRoleOnSchemaObjectAllToTerraform(struct?: GrantPrivilegesToAccountRoleOnSchemaObjectAllOutputReference | GrantPrivilegesToAccountRoleOnSchemaObjectAll): any;
export declare function grantPrivilegesToAccountRoleOnSchemaObjectAllToHclTerraform(struct?: GrantPrivilegesToAccountRoleOnSchemaObjectAllOutputReference | GrantPrivilegesToAccountRoleOnSchemaObjectAll): any;
export declare class GrantPrivilegesToAccountRoleOnSchemaObjectAllOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GrantPrivilegesToAccountRoleOnSchemaObjectAll | undefined;
    set internalValue(value: GrantPrivilegesToAccountRoleOnSchemaObjectAll | undefined);
    private _inDatabase?;
    get inDatabase(): string;
    set inDatabase(value: string);
    resetInDatabase(): void;
    get inDatabaseInput(): string | undefined;
    private _inSchema?;
    get inSchema(): string;
    set inSchema(value: string);
    resetInSchema(): void;
    get inSchemaInput(): string | undefined;
    private _objectTypePlural?;
    get objectTypePlural(): string;
    set objectTypePlural(value: string);
    get objectTypePluralInput(): string | undefined;
}
export interface GrantPrivilegesToAccountRoleOnSchemaObjectFuture {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#in_database GrantPrivilegesToAccountRole#in_database}
    */
    readonly inDatabase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#in_schema GrantPrivilegesToAccountRole#in_schema}
    */
    readonly inSchema?: string;
    /**
    * The plural object type of the schema object on which privileges will be granted. Valid values are: AGENTS | ALERTS | AUTHENTICATION POLICIES | CORTEX SEARCH SERVICES | DATA METRIC FUNCTIONS | DATASETS | DBT PROJECTS | DYNAMIC TABLES | EVENT TABLES | EXTERNAL TABLES | FILE FORMATS | FUNCTIONS | GIT REPOSITORIES | HYBRID TABLES | ICEBERG TABLES | MATERIALIZED VIEWS | MCP SERVERS | MODELS | MODEL MONITORS | NETWORK RULES | NOTEBOOKS | ONLINE FEATURE TABLES | PASSWORD POLICIES | PIPES | PRIVACY POLICIES | PROCEDURES | SECRETS | SEMANTIC VIEWS | SERVICES | SEQUENCES | SNAPSHOT POLICIES | SNAPSHOT SETS | STAGES | STREAMS | STREAMLITS | TABLES | TASKS | VIEWS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#object_type_plural GrantPrivilegesToAccountRole#object_type_plural}
    */
    readonly objectTypePlural: string;
}
export declare function grantPrivilegesToAccountRoleOnSchemaObjectFutureToTerraform(struct?: GrantPrivilegesToAccountRoleOnSchemaObjectFutureOutputReference | GrantPrivilegesToAccountRoleOnSchemaObjectFuture): any;
export declare function grantPrivilegesToAccountRoleOnSchemaObjectFutureToHclTerraform(struct?: GrantPrivilegesToAccountRoleOnSchemaObjectFutureOutputReference | GrantPrivilegesToAccountRoleOnSchemaObjectFuture): any;
export declare class GrantPrivilegesToAccountRoleOnSchemaObjectFutureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GrantPrivilegesToAccountRoleOnSchemaObjectFuture | undefined;
    set internalValue(value: GrantPrivilegesToAccountRoleOnSchemaObjectFuture | undefined);
    private _inDatabase?;
    get inDatabase(): string;
    set inDatabase(value: string);
    resetInDatabase(): void;
    get inDatabaseInput(): string | undefined;
    private _inSchema?;
    get inSchema(): string;
    set inSchema(value: string);
    resetInSchema(): void;
    get inSchemaInput(): string | undefined;
    private _objectTypePlural?;
    get objectTypePlural(): string;
    set objectTypePlural(value: string);
    get objectTypePluralInput(): string | undefined;
}
export interface GrantPrivilegesToAccountRoleOnSchemaObject {
    /**
    * The fully qualified name of the object on which privileges will be granted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#object_name GrantPrivilegesToAccountRole#object_name}
    */
    readonly objectName?: string;
    /**
    * The object type of the schema object on which privileges will be granted. Valid values are: AGENT | AGGREGATION POLICY | ALERT | AUTHENTICATION POLICY | CORTEX SEARCH SERVICE | DATA METRIC FUNCTION | DATASET | DBT PROJECT | DYNAMIC TABLE | EVENT TABLE | EXPERIMENT | EXTERNAL TABLE | FILE FORMAT | FUNCTION | GATEWAY | GIT REPOSITORY | HYBRID TABLE | IMAGE REPOSITORY | ICEBERG TABLE | JOIN POLICY | MASKING POLICY | MATERIALIZED VIEW | MCP SERVER | MODEL | MODEL MONITOR | NETWORK RULE | NOTEBOOK | NOTEBOOK PROJECT | ONLINE FEATURE TABLE | PACKAGES POLICY | PASSWORD POLICY | PIPE | PRIVACY POLICY | PROCEDURE | PROJECTION POLICY | ROW ACCESS POLICY | SECRET | SEMANTIC VIEW | SERVICE | SESSION POLICY | SEQUENCE | SNAPSHOT | SNAPSHOT POLICY | SNAPSHOT SET | STAGE | STORAGE LIFECYCLE POLICY | STREAM | STREAMLIT | TABLE | TAG | TASK | VIEW | WORKSPACE
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#object_type GrantPrivilegesToAccountRole#object_type}
    */
    readonly objectType?: string;
    /**
    * all block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#all GrantPrivilegesToAccountRole#all}
    */
    readonly all?: GrantPrivilegesToAccountRoleOnSchemaObjectAll;
    /**
    * future block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#future GrantPrivilegesToAccountRole#future}
    */
    readonly future?: GrantPrivilegesToAccountRoleOnSchemaObjectFuture;
}
export declare function grantPrivilegesToAccountRoleOnSchemaObjectToTerraform(struct?: GrantPrivilegesToAccountRoleOnSchemaObjectOutputReference | GrantPrivilegesToAccountRoleOnSchemaObject): any;
export declare function grantPrivilegesToAccountRoleOnSchemaObjectToHclTerraform(struct?: GrantPrivilegesToAccountRoleOnSchemaObjectOutputReference | GrantPrivilegesToAccountRoleOnSchemaObject): any;
export declare class GrantPrivilegesToAccountRoleOnSchemaObjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GrantPrivilegesToAccountRoleOnSchemaObject | undefined;
    set internalValue(value: GrantPrivilegesToAccountRoleOnSchemaObject | undefined);
    private _objectName?;
    get objectName(): string;
    set objectName(value: string);
    resetObjectName(): void;
    get objectNameInput(): string | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    resetObjectType(): void;
    get objectTypeInput(): string | undefined;
    private _all;
    get all(): GrantPrivilegesToAccountRoleOnSchemaObjectAllOutputReference;
    putAll(value: GrantPrivilegesToAccountRoleOnSchemaObjectAll): void;
    resetAll(): void;
    get allInput(): GrantPrivilegesToAccountRoleOnSchemaObjectAll | undefined;
    private _future;
    get future(): GrantPrivilegesToAccountRoleOnSchemaObjectFutureOutputReference;
    putFuture(value: GrantPrivilegesToAccountRoleOnSchemaObjectFuture): void;
    resetFuture(): void;
    get futureInput(): GrantPrivilegesToAccountRoleOnSchemaObjectFuture | undefined;
}
export interface GrantPrivilegesToAccountRoleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#create GrantPrivilegesToAccountRole#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#delete GrantPrivilegesToAccountRole#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#read GrantPrivilegesToAccountRole#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#update GrantPrivilegesToAccountRole#update}
    */
    readonly update?: string;
}
export declare function grantPrivilegesToAccountRoleTimeoutsToTerraform(struct?: GrantPrivilegesToAccountRoleTimeouts | cdktn.IResolvable): any;
export declare function grantPrivilegesToAccountRoleTimeoutsToHclTerraform(struct?: GrantPrivilegesToAccountRoleTimeouts | cdktn.IResolvable): any;
export declare class GrantPrivilegesToAccountRoleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GrantPrivilegesToAccountRoleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: GrantPrivilegesToAccountRoleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role snowflake_grant_privileges_to_account_role}
*/
export declare class GrantPrivilegesToAccountRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_grant_privileges_to_account_role";
    /**
    * Generates CDKTN code for importing a GrantPrivilegesToAccountRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GrantPrivilegesToAccountRole to import
    * @param importFromId The id of the existing GrantPrivilegesToAccountRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GrantPrivilegesToAccountRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/grant_privileges_to_account_role snowflake_grant_privileges_to_account_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GrantPrivilegesToAccountRoleConfig
    */
    constructor(scope: Construct, id: string, config: GrantPrivilegesToAccountRoleConfig);
    private _accountRoleName?;
    get accountRoleName(): string;
    set accountRoleName(value: string);
    get accountRoleNameInput(): string | undefined;
    private _allPrivileges?;
    get allPrivileges(): boolean | cdktn.IResolvable;
    set allPrivileges(value: boolean | cdktn.IResolvable);
    resetAllPrivileges(): void;
    get allPrivilegesInput(): boolean | cdktn.IResolvable | undefined;
    private _alwaysApply?;
    get alwaysApply(): boolean | cdktn.IResolvable;
    set alwaysApply(value: boolean | cdktn.IResolvable);
    resetAlwaysApply(): void;
    get alwaysApplyInput(): boolean | cdktn.IResolvable | undefined;
    private _alwaysApplyTrigger?;
    get alwaysApplyTrigger(): string;
    set alwaysApplyTrigger(value: string);
    resetAlwaysApplyTrigger(): void;
    get alwaysApplyTriggerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _onAccount?;
    get onAccount(): boolean | cdktn.IResolvable;
    set onAccount(value: boolean | cdktn.IResolvable);
    resetOnAccount(): void;
    get onAccountInput(): boolean | cdktn.IResolvable | undefined;
    private _privileges?;
    get privileges(): string[];
    set privileges(value: string[]);
    resetPrivileges(): void;
    get privilegesInput(): string[] | undefined;
    private _strictPrivilegeManagement?;
    get strictPrivilegeManagement(): boolean | cdktn.IResolvable;
    set strictPrivilegeManagement(value: boolean | cdktn.IResolvable);
    resetStrictPrivilegeManagement(): void;
    get strictPrivilegeManagementInput(): boolean | cdktn.IResolvable | undefined;
    private _withGrantOption?;
    get withGrantOption(): boolean | cdktn.IResolvable;
    set withGrantOption(value: boolean | cdktn.IResolvable);
    resetWithGrantOption(): void;
    get withGrantOptionInput(): boolean | cdktn.IResolvable | undefined;
    private _onAccountObject;
    get onAccountObject(): GrantPrivilegesToAccountRoleOnAccountObjectOutputReference;
    putOnAccountObject(value: GrantPrivilegesToAccountRoleOnAccountObject): void;
    resetOnAccountObject(): void;
    get onAccountObjectInput(): GrantPrivilegesToAccountRoleOnAccountObject | undefined;
    private _onSchema;
    get onSchema(): GrantPrivilegesToAccountRoleOnSchemaOutputReference;
    putOnSchema(value: GrantPrivilegesToAccountRoleOnSchema): void;
    resetOnSchema(): void;
    get onSchemaInput(): GrantPrivilegesToAccountRoleOnSchema | undefined;
    private _onSchemaObject;
    get onSchemaObject(): GrantPrivilegesToAccountRoleOnSchemaObjectOutputReference;
    putOnSchemaObject(value: GrantPrivilegesToAccountRoleOnSchemaObject): void;
    resetOnSchemaObject(): void;
    get onSchemaObjectInput(): GrantPrivilegesToAccountRoleOnSchemaObject | undefined;
    private _timeouts;
    get timeouts(): GrantPrivilegesToAccountRoleTimeoutsOutputReference;
    putTimeouts(value: GrantPrivilegesToAccountRoleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | GrantPrivilegesToAccountRoleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
