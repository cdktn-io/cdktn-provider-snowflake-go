/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PasswordPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Adds a comment or overwrites an existing comment for the password policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#comment PasswordPolicy#comment}
    */
    readonly comment?: string;
    /**
    * The database this password policy belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#database PasswordPolicy#database}
    */
    readonly database: string;
    /**
    * (Default: `0`) Specifies the number of the most recent passwords that Snowflake stores. These stored passwords cannot be repeated when a user updates their password value. The current password value does not count towards the history. When you increase the history value, Snowflake saves the previous values. When you decrease the value, Snowflake saves the stored values up to that value that is set. For example, if the history value is 8 and you change the history value to 3, Snowflake stores the most recent 3 passwords and deletes the 5 older password values from the history. Default: 0 Max: 24
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#history PasswordPolicy#history}
    */
    readonly history?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#id PasswordPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * (Default: `false`) Prevent overwriting a previous password policy with the same name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#if_not_exists PasswordPolicy#if_not_exists}
    */
    readonly ifNotExists?: boolean | cdktn.IResolvable;
    /**
    * (Default: `15`) Specifies the number of minutes the user account will be locked after exhausting the designated number of password retries (i.e. PASSWORD_MAX_RETRIES). Supported range: 1 to 999, inclusive. Default: 15
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#lockout_time_mins PasswordPolicy#lockout_time_mins}
    */
    readonly lockoutTimeMins?: number;
    /**
    * (Default: `90`) Specifies the maximum number of days before the password must be changed. Supported range: 0 to 999, inclusive. A value of zero (i.e. 0) indicates that the password does not need to be changed. Snowflake does not recommend choosing this value for a default account-level password policy or for any user-level policy. Instead, choose a value that meets your internal security guidelines. Default: 90, which means the password must be changed every 90 days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#max_age_days PasswordPolicy#max_age_days}
    */
    readonly maxAgeDays?: number;
    /**
    * (Default: `256`) Specifies the maximum number of characters the password must contain. This number must be greater than or equal to the sum of PASSWORD_MIN_LENGTH, PASSWORD_MIN_UPPER_CASE_CHARS, and PASSWORD_MIN_LOWER_CASE_CHARS. Supported range: 8 to 256, inclusive. Default: 256
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#max_length PasswordPolicy#max_length}
    */
    readonly maxLength?: number;
    /**
    * (Default: `5`) Specifies the maximum number of attempts to enter a password before being locked out. Supported range: 1 to 10, inclusive. Default: 5
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#max_retries PasswordPolicy#max_retries}
    */
    readonly maxRetries?: number;
    /**
    * (Default: `0`) Specifies the number of days the user must wait before a recently changed password can be changed again. Supported range: 0 to 999, inclusive. Default: 0
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#min_age_days PasswordPolicy#min_age_days}
    */
    readonly minAgeDays?: number;
    /**
    * (Default: `8`) Specifies the minimum number of characters the password must contain. Supported range: 8 to 256, inclusive. Default: 8
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#min_length PasswordPolicy#min_length}
    */
    readonly minLength?: number;
    /**
    * (Default: `1`) Specifies the minimum number of lowercase characters the password must contain. Supported range: 0 to 256, inclusive. Default: 1
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#min_lower_case_chars PasswordPolicy#min_lower_case_chars}
    */
    readonly minLowerCaseChars?: number;
    /**
    * (Default: `1`) Specifies the minimum number of numeric characters the password must contain. Supported range: 0 to 256, inclusive. Default: 1
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#min_numeric_chars PasswordPolicy#min_numeric_chars}
    */
    readonly minNumericChars?: number;
    /**
    * (Default: `1`) Specifies the minimum number of special characters the password must contain. Supported range: 0 to 256, inclusive. Default: 1
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#min_special_chars PasswordPolicy#min_special_chars}
    */
    readonly minSpecialChars?: number;
    /**
    * (Default: `1`) Specifies the minimum number of uppercase characters the password must contain. Supported range: 0 to 256, inclusive. Default: 1
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#min_upper_case_chars PasswordPolicy#min_upper_case_chars}
    */
    readonly minUpperCaseChars?: number;
    /**
    * Identifier for the password policy; must be unique for your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#name PasswordPolicy#name}
    */
    readonly name: string;
    /**
    * (Default: `false`) Whether to override a previous password policy with the same name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#or_replace PasswordPolicy#or_replace}
    */
    readonly orReplace?: boolean | cdktn.IResolvable;
    /**
    * The schema this password policy belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#schema PasswordPolicy#schema}
    */
    readonly schema: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#timeouts PasswordPolicy#timeouts}
    */
    readonly timeouts?: PasswordPolicyTimeouts;
}
export interface PasswordPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#create PasswordPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#delete PasswordPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#read PasswordPolicy#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#update PasswordPolicy#update}
    */
    readonly update?: string;
}
export declare function passwordPolicyTimeoutsToTerraform(struct?: PasswordPolicyTimeouts | cdktn.IResolvable): any;
export declare function passwordPolicyTimeoutsToHclTerraform(struct?: PasswordPolicyTimeouts | cdktn.IResolvable): any;
export declare class PasswordPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PasswordPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: PasswordPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy snowflake_password_policy}
*/
export declare class PasswordPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_password_policy";
    /**
    * Generates CDKTN code for importing a PasswordPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PasswordPolicy to import
    * @param importFromId The id of the existing PasswordPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PasswordPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/password_policy snowflake_password_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PasswordPolicyConfig
    */
    constructor(scope: Construct, id: string, config: PasswordPolicyConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _history?;
    get history(): number;
    set history(value: number);
    resetHistory(): void;
    get historyInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ifNotExists?;
    get ifNotExists(): boolean | cdktn.IResolvable;
    set ifNotExists(value: boolean | cdktn.IResolvable);
    resetIfNotExists(): void;
    get ifNotExistsInput(): boolean | cdktn.IResolvable | undefined;
    private _lockoutTimeMins?;
    get lockoutTimeMins(): number;
    set lockoutTimeMins(value: number);
    resetLockoutTimeMins(): void;
    get lockoutTimeMinsInput(): number | undefined;
    private _maxAgeDays?;
    get maxAgeDays(): number;
    set maxAgeDays(value: number);
    resetMaxAgeDays(): void;
    get maxAgeDaysInput(): number | undefined;
    private _maxLength?;
    get maxLength(): number;
    set maxLength(value: number);
    resetMaxLength(): void;
    get maxLengthInput(): number | undefined;
    private _maxRetries?;
    get maxRetries(): number;
    set maxRetries(value: number);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
    private _minAgeDays?;
    get minAgeDays(): number;
    set minAgeDays(value: number);
    resetMinAgeDays(): void;
    get minAgeDaysInput(): number | undefined;
    private _minLength?;
    get minLength(): number;
    set minLength(value: number);
    resetMinLength(): void;
    get minLengthInput(): number | undefined;
    private _minLowerCaseChars?;
    get minLowerCaseChars(): number;
    set minLowerCaseChars(value: number);
    resetMinLowerCaseChars(): void;
    get minLowerCaseCharsInput(): number | undefined;
    private _minNumericChars?;
    get minNumericChars(): number;
    set minNumericChars(value: number);
    resetMinNumericChars(): void;
    get minNumericCharsInput(): number | undefined;
    private _minSpecialChars?;
    get minSpecialChars(): number;
    set minSpecialChars(value: number);
    resetMinSpecialChars(): void;
    get minSpecialCharsInput(): number | undefined;
    private _minUpperCaseChars?;
    get minUpperCaseChars(): number;
    set minUpperCaseChars(value: number);
    resetMinUpperCaseChars(): void;
    get minUpperCaseCharsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _orReplace?;
    get orReplace(): boolean | cdktn.IResolvable;
    set orReplace(value: boolean | cdktn.IResolvable);
    resetOrReplace(): void;
    get orReplaceInput(): boolean | cdktn.IResolvable | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _timeouts;
    get timeouts(): PasswordPolicyTimeoutsOutputReference;
    putTimeouts(value: PasswordPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | PasswordPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
