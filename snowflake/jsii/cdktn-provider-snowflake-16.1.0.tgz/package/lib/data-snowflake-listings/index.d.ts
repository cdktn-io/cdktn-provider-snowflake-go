/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeListingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/data-sources/listings#id DataSnowflakeListings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/data-sources/listings#like DataSnowflakeListings#like}
    */
    readonly like?: string;
    /**
    * Filters the output with **case-sensitive** characters indicating the beginning of the object name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/data-sources/listings#starts_with DataSnowflakeListings#starts_with}
    */
    readonly startsWith?: string;
    /**
    * (Default: `true`) Runs DESC LISTING for each listing returned by SHOW LISTINGS. The output of describe is saved to the description field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/data-sources/listings#with_describe DataSnowflakeListings#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/data-sources/listings#limit DataSnowflakeListings#limit}
    */
    readonly limit?: DataSnowflakeListingsLimit;
}
export interface DataSnowflakeListingsListingsDescribeOutput {
}
export declare function dataSnowflakeListingsListingsDescribeOutputToTerraform(struct?: DataSnowflakeListingsListingsDescribeOutput): any;
export declare function dataSnowflakeListingsListingsDescribeOutputToHclTerraform(struct?: DataSnowflakeListingsListingsDescribeOutput): any;
export declare class DataSnowflakeListingsListingsDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeListingsListingsDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeListingsListingsDescribeOutput | undefined);
    get applicationPackage(): string;
    get approverContact(): string;
    get businessNeeds(): string;
    get categories(): string;
    get comment(): string;
    get createdOn(): string;
    get customizedContactInfo(): string;
    get dataAttributes(): string;
    get dataDictionary(): string;
    get dataPreview(): string;
    get description(): string;
    get distribution(): string;
    get globalName(): string;
    get isApplication(): cdktn.IResolvable;
    get isByRequest(): cdktn.IResolvable;
    get isLimitedTrial(): cdktn.IResolvable;
    get isMonetized(): cdktn.IResolvable;
    get isMountlessQueryable(): cdktn.IResolvable;
    get isShare(): cdktn.IResolvable;
    get isTargeted(): cdktn.IResolvable;
    get lastCommittedVersionAlias(): string;
    get lastCommittedVersionName(): string;
    get lastCommittedVersionUri(): string;
    get legacyUniformListingLocators(): string;
    get limitedTrialPlan(): string;
    get listingTerms(): string;
    get liveVersionUri(): string;
    get manifestYaml(): string;
    get monetizationDisplayOrder(): string;
    get name(): string;
    get organizationProfileName(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get profile(): string;
    get publishedOn(): string;
    get publishedVersionAlias(): string;
    get publishedVersionName(): string;
    get publishedVersionUri(): string;
    get refreshSchedule(): string;
    get refreshType(): string;
    get regions(): string;
    get rejectionReason(): string;
    get requestApprovalType(): string;
    get resources(): string;
    get retriedOn(): string;
    get reviewState(): string;
    get revisions(): string;
    get scheduledDropTime(): string;
    get share(): string;
    get state(): string;
    get subtitle(): string;
    get supportContact(): string;
    get targetAccounts(): string;
    get title(): string;
    get trialDetails(): string;
    get uniformListingLocator(): string;
    get unpublishedByAdminReasons(): string;
    get updatedOn(): string;
    get usageExamples(): string;
}
export declare class DataSnowflakeListingsListingsDescribeOutputList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeListingsListingsDescribeOutputOutputReference;
}
export interface DataSnowflakeListingsListingsShowOutput {
}
export declare function dataSnowflakeListingsListingsShowOutputToTerraform(struct?: DataSnowflakeListingsListingsShowOutput): any;
export declare function dataSnowflakeListingsListingsShowOutputToHclTerraform(struct?: DataSnowflakeListingsListingsShowOutput): any;
export declare class DataSnowflakeListingsListingsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeListingsListingsShowOutput | undefined;
    set internalValue(value: DataSnowflakeListingsListingsShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get detailedTargetAccounts(): string;
    get distribution(): string;
    get globalName(): string;
    get isApplication(): cdktn.IResolvable;
    get isByRequest(): cdktn.IResolvable;
    get isLimitedTrial(): cdktn.IResolvable;
    get isMonetized(): cdktn.IResolvable;
    get isMountlessQueryable(): cdktn.IResolvable;
    get isTargeted(): cdktn.IResolvable;
    get name(): string;
    get organizationProfileName(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get profile(): string;
    get publishedOn(): string;
    get regions(): string;
    get rejectedOn(): string;
    get reviewState(): string;
    get state(): string;
    get subtitle(): string;
    get targetAccounts(): string;
    get title(): string;
    get uniformListingLocator(): string;
    get updatedOn(): string;
}
export declare class DataSnowflakeListingsListingsShowOutputList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeListingsListingsShowOutputOutputReference;
}
export interface DataSnowflakeListingsListings {
}
export declare function dataSnowflakeListingsListingsToTerraform(struct?: DataSnowflakeListingsListings): any;
export declare function dataSnowflakeListingsListingsToHclTerraform(struct?: DataSnowflakeListingsListings): any;
export declare class DataSnowflakeListingsListingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeListingsListings | undefined;
    set internalValue(value: DataSnowflakeListingsListings | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeListingsListingsDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeListingsListingsShowOutputList;
}
export declare class DataSnowflakeListingsListingsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeListingsListingsOutputReference;
}
export interface DataSnowflakeListingsLimit {
    /**
    * Specifies a **case-sensitive** pattern that is used to match object name. After the first match, the limit on the number of rows will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/data-sources/listings#from DataSnowflakeListings#from}
    */
    readonly from?: string;
    /**
    * The maximum number of rows to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/data-sources/listings#rows DataSnowflakeListings#rows}
    */
    readonly rows: number;
}
export declare function dataSnowflakeListingsLimitToTerraform(struct?: DataSnowflakeListingsLimitOutputReference | DataSnowflakeListingsLimit): any;
export declare function dataSnowflakeListingsLimitToHclTerraform(struct?: DataSnowflakeListingsLimitOutputReference | DataSnowflakeListingsLimit): any;
export declare class DataSnowflakeListingsLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeListingsLimit | undefined;
    set internalValue(value: DataSnowflakeListingsLimit | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _rows?;
    get rows(): number;
    set rows(value: number);
    get rowsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/data-sources/listings snowflake_listings}
*/
export declare class DataSnowflakeListings extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_listings";
    /**
    * Generates CDKTN code for importing a DataSnowflakeListings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeListings to import
    * @param importFromId The id of the existing DataSnowflakeListings that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/data-sources/listings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeListings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/data-sources/listings snowflake_listings} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeListingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeListingsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _listings;
    get listings(): DataSnowflakeListingsListingsList;
    private _startsWith?;
    get startsWith(): string;
    set startsWith(value: string);
    resetStartsWith(): void;
    get startsWithInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _limit;
    get limit(): DataSnowflakeListingsLimitOutputReference;
    putLimit(value: DataSnowflakeListingsLimit): void;
    resetLimit(): void;
    get limitInput(): DataSnowflakeListingsLimit | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
