/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StageInternalConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#comment StageInternal#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the stage. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#database StageInternal#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#id StageInternal#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the stage; must be unique for the database and schema in which the stage is created. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#name StageInternal#name}
    */
    readonly name: string;
    /**
    * The schema in which to create the stage. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#schema StageInternal#schema}
    */
    readonly schema: string;
    /**
    * directory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#directory StageInternal#directory}
    */
    readonly directory?: StageInternalDirectory;
    /**
    * encryption block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#encryption StageInternal#encryption}
    */
    readonly encryption?: StageInternalEncryption;
    /**
    * file_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#file_format StageInternal#file_format}
    */
    readonly fileFormat?: StageInternalFileFormat;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#timeouts StageInternal#timeouts}
    */
    readonly timeouts?: StageInternalTimeouts;
}
export interface StageInternalDescribeOutputDirectoryTable {
}
export declare function stageInternalDescribeOutputDirectoryTableToTerraform(struct?: StageInternalDescribeOutputDirectoryTable): any;
export declare function stageInternalDescribeOutputDirectoryTableToHclTerraform(struct?: StageInternalDescribeOutputDirectoryTable): any;
export declare class StageInternalDescribeOutputDirectoryTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageInternalDescribeOutputDirectoryTable | undefined;
    set internalValue(value: StageInternalDescribeOutputDirectoryTable | undefined);
    get autoRefresh(): cdktn.IResolvable;
    get enable(): cdktn.IResolvable;
    get lastRefreshedOn(): string;
}
export declare class StageInternalDescribeOutputDirectoryTableList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageInternalDescribeOutputDirectoryTableOutputReference;
}
export interface StageInternalDescribeOutputFileFormatAvro {
}
export declare function stageInternalDescribeOutputFileFormatAvroToTerraform(struct?: StageInternalDescribeOutputFileFormatAvro): any;
export declare function stageInternalDescribeOutputFileFormatAvroToHclTerraform(struct?: StageInternalDescribeOutputFileFormatAvro): any;
export declare class StageInternalDescribeOutputFileFormatAvroOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageInternalDescribeOutputFileFormatAvro | undefined;
    set internalValue(value: StageInternalDescribeOutputFileFormatAvro | undefined);
    get compression(): string;
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageInternalDescribeOutputFileFormatAvroList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageInternalDescribeOutputFileFormatAvroOutputReference;
}
export interface StageInternalDescribeOutputFileFormatCsv {
}
export declare function stageInternalDescribeOutputFileFormatCsvToTerraform(struct?: StageInternalDescribeOutputFileFormatCsv): any;
export declare function stageInternalDescribeOutputFileFormatCsvToHclTerraform(struct?: StageInternalDescribeOutputFileFormatCsv): any;
export declare class StageInternalDescribeOutputFileFormatCsvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageInternalDescribeOutputFileFormatCsv | undefined;
    set internalValue(value: StageInternalDescribeOutputFileFormatCsv | undefined);
    get binaryFormat(): string;
    get compression(): string;
    get dateFormat(): string;
    get emptyFieldAsNull(): cdktn.IResolvable;
    get encoding(): string;
    get errorOnColumnCountMismatch(): cdktn.IResolvable;
    get escape(): string;
    get escapeUnenclosedField(): string;
    get fieldDelimiter(): string;
    get fieldOptionallyEnclosedBy(): string;
    get fileExtension(): string;
    get multiLine(): cdktn.IResolvable;
    get nullIf(): string[];
    get parseHeader(): cdktn.IResolvable;
    get recordDelimiter(): string;
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipBlankLines(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get skipHeader(): number;
    get timeFormat(): string;
    get timestampFormat(): string;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
    get validateUtf8(): cdktn.IResolvable;
}
export declare class StageInternalDescribeOutputFileFormatCsvList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageInternalDescribeOutputFileFormatCsvOutputReference;
}
export interface StageInternalDescribeOutputFileFormatJson {
}
export declare function stageInternalDescribeOutputFileFormatJsonToTerraform(struct?: StageInternalDescribeOutputFileFormatJson): any;
export declare function stageInternalDescribeOutputFileFormatJsonToHclTerraform(struct?: StageInternalDescribeOutputFileFormatJson): any;
export declare class StageInternalDescribeOutputFileFormatJsonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageInternalDescribeOutputFileFormatJson | undefined;
    set internalValue(value: StageInternalDescribeOutputFileFormatJson | undefined);
    get allowDuplicate(): cdktn.IResolvable;
    get binaryFormat(): string;
    get compression(): string;
    get dateFormat(): string;
    get enableOctal(): cdktn.IResolvable;
    get fileExtension(): string;
    get ignoreUtf8Errors(): cdktn.IResolvable;
    get multiLine(): cdktn.IResolvable;
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get stripNullValues(): cdktn.IResolvable;
    get stripOuterArray(): cdktn.IResolvable;
    get timeFormat(): string;
    get timestampFormat(): string;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageInternalDescribeOutputFileFormatJsonList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageInternalDescribeOutputFileFormatJsonOutputReference;
}
export interface StageInternalDescribeOutputFileFormatOrc {
}
export declare function stageInternalDescribeOutputFileFormatOrcToTerraform(struct?: StageInternalDescribeOutputFileFormatOrc): any;
export declare function stageInternalDescribeOutputFileFormatOrcToHclTerraform(struct?: StageInternalDescribeOutputFileFormatOrc): any;
export declare class StageInternalDescribeOutputFileFormatOrcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageInternalDescribeOutputFileFormatOrc | undefined;
    set internalValue(value: StageInternalDescribeOutputFileFormatOrc | undefined);
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageInternalDescribeOutputFileFormatOrcList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageInternalDescribeOutputFileFormatOrcOutputReference;
}
export interface StageInternalDescribeOutputFileFormatParquet {
}
export declare function stageInternalDescribeOutputFileFormatParquetToTerraform(struct?: StageInternalDescribeOutputFileFormatParquet): any;
export declare function stageInternalDescribeOutputFileFormatParquetToHclTerraform(struct?: StageInternalDescribeOutputFileFormatParquet): any;
export declare class StageInternalDescribeOutputFileFormatParquetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageInternalDescribeOutputFileFormatParquet | undefined;
    set internalValue(value: StageInternalDescribeOutputFileFormatParquet | undefined);
    get binaryAsText(): cdktn.IResolvable;
    get compression(): string;
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
    get useLogicalType(): cdktn.IResolvable;
    get useVectorizedScanner(): cdktn.IResolvable;
}
export declare class StageInternalDescribeOutputFileFormatParquetList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageInternalDescribeOutputFileFormatParquetOutputReference;
}
export interface StageInternalDescribeOutputFileFormatXml {
}
export declare function stageInternalDescribeOutputFileFormatXmlToTerraform(struct?: StageInternalDescribeOutputFileFormatXml): any;
export declare function stageInternalDescribeOutputFileFormatXmlToHclTerraform(struct?: StageInternalDescribeOutputFileFormatXml): any;
export declare class StageInternalDescribeOutputFileFormatXmlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageInternalDescribeOutputFileFormatXml | undefined;
    set internalValue(value: StageInternalDescribeOutputFileFormatXml | undefined);
    get compression(): string;
    get disableAutoConvert(): cdktn.IResolvable;
    get ignoreUtf8Errors(): cdktn.IResolvable;
    get preserveSpace(): cdktn.IResolvable;
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get stripOuterElement(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageInternalDescribeOutputFileFormatXmlList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageInternalDescribeOutputFileFormatXmlOutputReference;
}
export interface StageInternalDescribeOutputFileFormat {
}
export declare function stageInternalDescribeOutputFileFormatToTerraform(struct?: StageInternalDescribeOutputFileFormat): any;
export declare function stageInternalDescribeOutputFileFormatToHclTerraform(struct?: StageInternalDescribeOutputFileFormat): any;
export declare class StageInternalDescribeOutputFileFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageInternalDescribeOutputFileFormat | undefined;
    set internalValue(value: StageInternalDescribeOutputFileFormat | undefined);
    private _avro;
    get avro(): StageInternalDescribeOutputFileFormatAvroList;
    private _csv;
    get csv(): StageInternalDescribeOutputFileFormatCsvList;
    get formatName(): string;
    private _json;
    get json(): StageInternalDescribeOutputFileFormatJsonList;
    private _orc;
    get orc(): StageInternalDescribeOutputFileFormatOrcList;
    private _parquet;
    get parquet(): StageInternalDescribeOutputFileFormatParquetList;
    private _xml;
    get xml(): StageInternalDescribeOutputFileFormatXmlList;
}
export declare class StageInternalDescribeOutputFileFormatList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageInternalDescribeOutputFileFormatOutputReference;
}
export interface StageInternalDescribeOutput {
}
export declare function stageInternalDescribeOutputToTerraform(struct?: StageInternalDescribeOutput): any;
export declare function stageInternalDescribeOutputToHclTerraform(struct?: StageInternalDescribeOutput): any;
export declare class StageInternalDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageInternalDescribeOutput | undefined;
    set internalValue(value: StageInternalDescribeOutput | undefined);
    private _directoryTable;
    get directoryTable(): StageInternalDescribeOutputDirectoryTableList;
    private _fileFormat;
    get fileFormat(): StageInternalDescribeOutputFileFormatList;
}
export declare class StageInternalDescribeOutputList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageInternalDescribeOutputOutputReference;
}
export interface StageInternalShowOutput {
}
export declare function stageInternalShowOutputToTerraform(struct?: StageInternalShowOutput): any;
export declare function stageInternalShowOutputToHclTerraform(struct?: StageInternalShowOutput): any;
export declare class StageInternalShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageInternalShowOutput | undefined;
    set internalValue(value: StageInternalShowOutput | undefined);
    get cloud(): string;
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get directoryEnabled(): cdktn.IResolvable;
    get endpoint(): string;
    get hasCredentials(): cdktn.IResolvable;
    get hasEncryptionKey(): cdktn.IResolvable;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get region(): string;
    get schemaName(): string;
    get storageIntegration(): string;
    get type(): string;
    get url(): string;
}
export declare class StageInternalShowOutputList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageInternalShowOutputOutputReference;
}
export interface StageInternalDirectory {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether Snowflake should automatically refresh the directory table metadata when new or updated data files are available on the internal named stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#auto_refresh StageInternal#auto_refresh}
    */
    readonly autoRefresh?: string;
    /**
    * Specifies whether to enable a directory table on the internal named stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#enable StageInternal#enable}
    */
    readonly enable: boolean | cdktn.IResolvable;
}
export declare function stageInternalDirectoryToTerraform(struct?: StageInternalDirectoryOutputReference | StageInternalDirectory): any;
export declare function stageInternalDirectoryToHclTerraform(struct?: StageInternalDirectoryOutputReference | StageInternalDirectory): any;
export declare class StageInternalDirectoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageInternalDirectory | undefined;
    set internalValue(value: StageInternalDirectory | undefined);
    private _autoRefresh?;
    get autoRefresh(): string;
    set autoRefresh(value: string);
    resetAutoRefresh(): void;
    get autoRefreshInput(): string | undefined;
    private _enable?;
    get enable(): boolean | cdktn.IResolvable;
    set enable(value: boolean | cdktn.IResolvable);
    get enableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface StageInternalEncryptionSnowflakeFull {
}
export declare function stageInternalEncryptionSnowflakeFullToTerraform(struct?: StageInternalEncryptionSnowflakeFullOutputReference | StageInternalEncryptionSnowflakeFull): any;
export declare function stageInternalEncryptionSnowflakeFullToHclTerraform(struct?: StageInternalEncryptionSnowflakeFullOutputReference | StageInternalEncryptionSnowflakeFull): any;
export declare class StageInternalEncryptionSnowflakeFullOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageInternalEncryptionSnowflakeFull | undefined;
    set internalValue(value: StageInternalEncryptionSnowflakeFull | undefined);
}
export interface StageInternalEncryptionSnowflakeSse {
}
export declare function stageInternalEncryptionSnowflakeSseToTerraform(struct?: StageInternalEncryptionSnowflakeSseOutputReference | StageInternalEncryptionSnowflakeSse): any;
export declare function stageInternalEncryptionSnowflakeSseToHclTerraform(struct?: StageInternalEncryptionSnowflakeSseOutputReference | StageInternalEncryptionSnowflakeSse): any;
export declare class StageInternalEncryptionSnowflakeSseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageInternalEncryptionSnowflakeSse | undefined;
    set internalValue(value: StageInternalEncryptionSnowflakeSse | undefined);
}
export interface StageInternalEncryption {
    /**
    * snowflake_full block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#snowflake_full StageInternal#snowflake_full}
    */
    readonly snowflakeFull?: StageInternalEncryptionSnowflakeFull;
    /**
    * snowflake_sse block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#snowflake_sse StageInternal#snowflake_sse}
    */
    readonly snowflakeSse?: StageInternalEncryptionSnowflakeSse;
}
export declare function stageInternalEncryptionToTerraform(struct?: StageInternalEncryptionOutputReference | StageInternalEncryption): any;
export declare function stageInternalEncryptionToHclTerraform(struct?: StageInternalEncryptionOutputReference | StageInternalEncryption): any;
export declare class StageInternalEncryptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageInternalEncryption | undefined;
    set internalValue(value: StageInternalEncryption | undefined);
    private _snowflakeFull;
    get snowflakeFull(): StageInternalEncryptionSnowflakeFullOutputReference;
    putSnowflakeFull(value: StageInternalEncryptionSnowflakeFull): void;
    resetSnowflakeFull(): void;
    get snowflakeFullInput(): StageInternalEncryptionSnowflakeFull | undefined;
    private _snowflakeSse;
    get snowflakeSse(): StageInternalEncryptionSnowflakeSseOutputReference;
    putSnowflakeSse(value: StageInternalEncryptionSnowflakeSse): void;
    resetSnowflakeSse(): void;
    get snowflakeSseInput(): StageInternalEncryptionSnowflakeSse | undefined;
}
export interface StageInternalFileFormatAvro {
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
    */
    readonly compression?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageInternalFileFormatAvroToTerraform(struct?: StageInternalFileFormatAvroOutputReference | StageInternalFileFormatAvro): any;
export declare function stageInternalFileFormatAvroToHclTerraform(struct?: StageInternalFileFormatAvroOutputReference | StageInternalFileFormatAvro): any;
export declare class StageInternalFileFormatAvroOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageInternalFileFormatAvro | undefined;
    set internalValue(value: StageInternalFileFormatAvro | undefined);
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageInternalFileFormatCsv {
    /**
    * Defines the encoding format for binary input or output. Valid values: `HEX` | `BASE64` | `UTF8`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#binary_format StageInternal#binary_format}
    */
    readonly binaryFormat?: string;
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BZ2` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
    */
    readonly compression?: string;
    /**
    * Defines the format of date values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#date_format StageInternal#date_format}
    */
    readonly dateFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to insert SQL NULL for empty fields in an input file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#empty_field_as_null StageInternal#empty_field_as_null}
    */
    readonly emptyFieldAsNull?: string;
    /**
    * Specifies the character set of the source data when loading data into a table. Valid values: `BIG5` | `EUCJP` | `EUCKR` | `GB18030` | `IBM420` | `IBM424` | `ISO2022CN` | `ISO2022JP` | `ISO2022KR` | `ISO88591` | `ISO88592` | `ISO88595` | `ISO88596` | `ISO88597` | `ISO88598` | `ISO88599` | `ISO885915` | `KOI8R` | `SHIFTJIS` | `UTF8` | `UTF16` | `UTF16BE` | `UTF16LE` | `UTF32` | `UTF32BE` | `UTF32LE` | `WINDOWS1250` | `WINDOWS1251` | `WINDOWS1252` | `WINDOWS1253` | `WINDOWS1254` | `WINDOWS1255` | `WINDOWS1256`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#encoding StageInternal#encoding}
    */
    readonly encoding?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to generate a parsing error if the number of delimited columns in an input file does not match the number of columns in the corresponding table. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#error_on_column_count_mismatch StageInternal#error_on_column_count_mismatch}
    */
    readonly errorOnColumnCountMismatch?: string;
    /**
    * Single character string used as the escape character for field values. Use `NONE` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#escape StageInternal#escape}
    */
    readonly escape?: string;
    /**
    * Single character string used as the escape character for unenclosed field values only. Use `NONE` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#escape_unenclosed_field StageInternal#escape_unenclosed_field}
    */
    readonly escapeUnenclosedField?: string;
    /**
    * One or more singlebyte or multibyte characters that separate fields in an input file. Use `NONE` to specify no delimiter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#field_delimiter StageInternal#field_delimiter}
    */
    readonly fieldDelimiter?: string;
    /**
    * Character used to enclose strings. Use `NONE` to specify no enclosure character.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#field_optionally_enclosed_by StageInternal#field_optionally_enclosed_by}
    */
    readonly fieldOptionallyEnclosedBy?: string;
    /**
    * Specifies the extension for files unloaded to a stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#file_extension StageInternal#file_extension}
    */
    readonly fileExtension?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to parse CSV files containing multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#multi_line StageInternal#multi_line}
    */
    readonly multiLine?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to use the first row headers in the data files to determine column names. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#parse_header StageInternal#parse_header}
    */
    readonly parseHeader?: string;
    /**
    * One or more singlebyte or multibyte characters that separate records in an input file. Use `NONE` to specify no delimiter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#record_delimiter StageInternal#record_delimiter}
    */
    readonly recordDelimiter?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies to skip any blank lines encountered in the data files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_blank_lines StageInternal#skip_blank_lines}
    */
    readonly skipBlankLines?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_byte_order_mark StageInternal#skip_byte_order_mark}
    */
    readonly skipByteOrderMark?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`-1`)) Number of lines at the start of the file to skip.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_header StageInternal#skip_header}
    */
    readonly skipHeader?: number;
    /**
    * Defines the format of time values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#time_format StageInternal#time_format}
    */
    readonly timeFormat?: string;
    /**
    * Defines the format of timestamp values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#timestamp_format StageInternal#timestamp_format}
    */
    readonly timestampFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageInternalFileFormatCsvToTerraform(struct?: StageInternalFileFormatCsvOutputReference | StageInternalFileFormatCsv): any;
export declare function stageInternalFileFormatCsvToHclTerraform(struct?: StageInternalFileFormatCsvOutputReference | StageInternalFileFormatCsv): any;
export declare class StageInternalFileFormatCsvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageInternalFileFormatCsv | undefined;
    set internalValue(value: StageInternalFileFormatCsv | undefined);
    private _binaryFormat?;
    get binaryFormat(): string;
    set binaryFormat(value: string);
    resetBinaryFormat(): void;
    get binaryFormatInput(): string | undefined;
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _dateFormat?;
    get dateFormat(): string;
    set dateFormat(value: string);
    resetDateFormat(): void;
    get dateFormatInput(): string | undefined;
    private _emptyFieldAsNull?;
    get emptyFieldAsNull(): string;
    set emptyFieldAsNull(value: string);
    resetEmptyFieldAsNull(): void;
    get emptyFieldAsNullInput(): string | undefined;
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    resetEncoding(): void;
    get encodingInput(): string | undefined;
    private _errorOnColumnCountMismatch?;
    get errorOnColumnCountMismatch(): string;
    set errorOnColumnCountMismatch(value: string);
    resetErrorOnColumnCountMismatch(): void;
    get errorOnColumnCountMismatchInput(): string | undefined;
    private _escape?;
    get escape(): string;
    set escape(value: string);
    resetEscape(): void;
    get escapeInput(): string | undefined;
    private _escapeUnenclosedField?;
    get escapeUnenclosedField(): string;
    set escapeUnenclosedField(value: string);
    resetEscapeUnenclosedField(): void;
    get escapeUnenclosedFieldInput(): string | undefined;
    private _fieldDelimiter?;
    get fieldDelimiter(): string;
    set fieldDelimiter(value: string);
    resetFieldDelimiter(): void;
    get fieldDelimiterInput(): string | undefined;
    private _fieldOptionallyEnclosedBy?;
    get fieldOptionallyEnclosedBy(): string;
    set fieldOptionallyEnclosedBy(value: string);
    resetFieldOptionallyEnclosedBy(): void;
    get fieldOptionallyEnclosedByInput(): string | undefined;
    private _fileExtension?;
    get fileExtension(): string;
    set fileExtension(value: string);
    resetFileExtension(): void;
    get fileExtensionInput(): string | undefined;
    private _multiLine?;
    get multiLine(): string;
    set multiLine(value: string);
    resetMultiLine(): void;
    get multiLineInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _parseHeader?;
    get parseHeader(): string;
    set parseHeader(value: string);
    resetParseHeader(): void;
    get parseHeaderInput(): string | undefined;
    private _recordDelimiter?;
    get recordDelimiter(): string;
    set recordDelimiter(value: string);
    resetRecordDelimiter(): void;
    get recordDelimiterInput(): string | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _skipBlankLines?;
    get skipBlankLines(): string;
    set skipBlankLines(value: string);
    resetSkipBlankLines(): void;
    get skipBlankLinesInput(): string | undefined;
    private _skipByteOrderMark?;
    get skipByteOrderMark(): string;
    set skipByteOrderMark(value: string);
    resetSkipByteOrderMark(): void;
    get skipByteOrderMarkInput(): string | undefined;
    private _skipHeader?;
    get skipHeader(): number;
    set skipHeader(value: number);
    resetSkipHeader(): void;
    get skipHeaderInput(): number | undefined;
    private _timeFormat?;
    get timeFormat(): string;
    set timeFormat(value: string);
    resetTimeFormat(): void;
    get timeFormatInput(): string | undefined;
    private _timestampFormat?;
    get timestampFormat(): string;
    set timestampFormat(value: string);
    resetTimestampFormat(): void;
    get timestampFormatInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageInternalFileFormatJson {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to allow duplicate object field names (only the last one will be preserved). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#allow_duplicate StageInternal#allow_duplicate}
    */
    readonly allowDuplicate?: string;
    /**
    * Defines the encoding format for binary input or output. Valid values: `HEX` | `BASE64` | `UTF8`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#binary_format StageInternal#binary_format}
    */
    readonly binaryFormat?: string;
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BZ2` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
    */
    readonly compression?: string;
    /**
    * Defines the format of date values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#date_format StageInternal#date_format}
    */
    readonly dateFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that enables parsing of octal numbers. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#enable_octal StageInternal#enable_octal}
    */
    readonly enableOctal?: string;
    /**
    * Specifies the extension for files unloaded to a stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#file_extension StageInternal#file_extension}
    */
    readonly fileExtension?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#ignore_utf8_errors StageInternal#ignore_utf8_errors}
    */
    readonly ignoreUtf8Errors?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to allow multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#multi_line StageInternal#multi_line}
    */
    readonly multiLine?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_byte_order_mark StageInternal#skip_byte_order_mark}
    */
    readonly skipByteOrderMark?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that instructs the JSON parser to remove object fields or array elements containing null values. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#strip_null_values StageInternal#strip_null_values}
    */
    readonly stripNullValues?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that instructs the JSON parser to remove outer brackets. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#strip_outer_array StageInternal#strip_outer_array}
    */
    readonly stripOuterArray?: string;
    /**
    * Defines the format of time values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#time_format StageInternal#time_format}
    */
    readonly timeFormat?: string;
    /**
    * Defines the format of timestamp values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#timestamp_format StageInternal#timestamp_format}
    */
    readonly timestampFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageInternalFileFormatJsonToTerraform(struct?: StageInternalFileFormatJsonOutputReference | StageInternalFileFormatJson): any;
export declare function stageInternalFileFormatJsonToHclTerraform(struct?: StageInternalFileFormatJsonOutputReference | StageInternalFileFormatJson): any;
export declare class StageInternalFileFormatJsonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageInternalFileFormatJson | undefined;
    set internalValue(value: StageInternalFileFormatJson | undefined);
    private _allowDuplicate?;
    get allowDuplicate(): string;
    set allowDuplicate(value: string);
    resetAllowDuplicate(): void;
    get allowDuplicateInput(): string | undefined;
    private _binaryFormat?;
    get binaryFormat(): string;
    set binaryFormat(value: string);
    resetBinaryFormat(): void;
    get binaryFormatInput(): string | undefined;
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _dateFormat?;
    get dateFormat(): string;
    set dateFormat(value: string);
    resetDateFormat(): void;
    get dateFormatInput(): string | undefined;
    private _enableOctal?;
    get enableOctal(): string;
    set enableOctal(value: string);
    resetEnableOctal(): void;
    get enableOctalInput(): string | undefined;
    private _fileExtension?;
    get fileExtension(): string;
    set fileExtension(value: string);
    resetFileExtension(): void;
    get fileExtensionInput(): string | undefined;
    private _ignoreUtf8Errors?;
    get ignoreUtf8Errors(): string;
    set ignoreUtf8Errors(value: string);
    resetIgnoreUtf8Errors(): void;
    get ignoreUtf8ErrorsInput(): string | undefined;
    private _multiLine?;
    get multiLine(): string;
    set multiLine(value: string);
    resetMultiLine(): void;
    get multiLineInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _skipByteOrderMark?;
    get skipByteOrderMark(): string;
    set skipByteOrderMark(value: string);
    resetSkipByteOrderMark(): void;
    get skipByteOrderMarkInput(): string | undefined;
    private _stripNullValues?;
    get stripNullValues(): string;
    set stripNullValues(value: string);
    resetStripNullValues(): void;
    get stripNullValuesInput(): string | undefined;
    private _stripOuterArray?;
    get stripOuterArray(): string;
    set stripOuterArray(value: string);
    resetStripOuterArray(): void;
    get stripOuterArrayInput(): string | undefined;
    private _timeFormat?;
    get timeFormat(): string;
    set timeFormat(value: string);
    resetTimeFormat(): void;
    get timeFormatInput(): string | undefined;
    private _timestampFormat?;
    get timestampFormat(): string;
    set timestampFormat(value: string);
    resetTimestampFormat(): void;
    get timestampFormatInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageInternalFileFormatOrc {
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageInternalFileFormatOrcToTerraform(struct?: StageInternalFileFormatOrcOutputReference | StageInternalFileFormatOrc): any;
export declare function stageInternalFileFormatOrcToHclTerraform(struct?: StageInternalFileFormatOrcOutputReference | StageInternalFileFormatOrc): any;
export declare class StageInternalFileFormatOrcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageInternalFileFormatOrc | undefined;
    set internalValue(value: StageInternalFileFormatOrc | undefined);
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageInternalFileFormatParquet {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to interpret columns with no defined logical data type as UTF-8 text. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#binary_as_text StageInternal#binary_as_text}
    */
    readonly binaryAsText?: string;
    /**
    * Specifies the compression format. Valid values: `AUTO` | `LZO` | `SNAPPY` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
    */
    readonly compression?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#null_if StageInternal#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#trim_space StageInternal#trim_space}
    */
    readonly trimSpace?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to use Parquet logical types when loading data. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#use_logical_type StageInternal#use_logical_type}
    */
    readonly useLogicalType?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to use a vectorized scanner for loading Parquet files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#use_vectorized_scanner StageInternal#use_vectorized_scanner}
    */
    readonly useVectorizedScanner?: string;
}
export declare function stageInternalFileFormatParquetToTerraform(struct?: StageInternalFileFormatParquetOutputReference | StageInternalFileFormatParquet): any;
export declare function stageInternalFileFormatParquetToHclTerraform(struct?: StageInternalFileFormatParquetOutputReference | StageInternalFileFormatParquet): any;
export declare class StageInternalFileFormatParquetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageInternalFileFormatParquet | undefined;
    set internalValue(value: StageInternalFileFormatParquet | undefined);
    private _binaryAsText?;
    get binaryAsText(): string;
    set binaryAsText(value: string);
    resetBinaryAsText(): void;
    get binaryAsTextInput(): string | undefined;
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
    private _useLogicalType?;
    get useLogicalType(): string;
    set useLogicalType(value: string);
    resetUseLogicalType(): void;
    get useLogicalTypeInput(): string | undefined;
    private _useVectorizedScanner?;
    get useVectorizedScanner(): string;
    set useVectorizedScanner(value: string);
    resetUseVectorizedScanner(): void;
    get useVectorizedScannerInput(): string | undefined;
}
export interface StageInternalFileFormatXml {
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BZ2` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#compression StageInternal#compression}
    */
    readonly compression?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether the XML parser disables automatic conversion of numeric and Boolean values from text to native representation. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#disable_auto_convert StageInternal#disable_auto_convert}
    */
    readonly disableAutoConvert?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#ignore_utf8_errors StageInternal#ignore_utf8_errors}
    */
    readonly ignoreUtf8Errors?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether the XML parser preserves leading and trailing spaces in element content. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#preserve_space StageInternal#preserve_space}
    */
    readonly preserveSpace?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#replace_invalid_characters StageInternal#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#skip_byte_order_mark StageInternal#skip_byte_order_mark}
    */
    readonly skipByteOrderMark?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether the XML parser strips out the outer XML element, exposing 2nd level elements as separate documents. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#strip_outer_element StageInternal#strip_outer_element}
    */
    readonly stripOuterElement?: string;
}
export declare function stageInternalFileFormatXmlToTerraform(struct?: StageInternalFileFormatXmlOutputReference | StageInternalFileFormatXml): any;
export declare function stageInternalFileFormatXmlToHclTerraform(struct?: StageInternalFileFormatXmlOutputReference | StageInternalFileFormatXml): any;
export declare class StageInternalFileFormatXmlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageInternalFileFormatXml | undefined;
    set internalValue(value: StageInternalFileFormatXml | undefined);
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _disableAutoConvert?;
    get disableAutoConvert(): string;
    set disableAutoConvert(value: string);
    resetDisableAutoConvert(): void;
    get disableAutoConvertInput(): string | undefined;
    private _ignoreUtf8Errors?;
    get ignoreUtf8Errors(): string;
    set ignoreUtf8Errors(value: string);
    resetIgnoreUtf8Errors(): void;
    get ignoreUtf8ErrorsInput(): string | undefined;
    private _preserveSpace?;
    get preserveSpace(): string;
    set preserveSpace(value: string);
    resetPreserveSpace(): void;
    get preserveSpaceInput(): string | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _skipByteOrderMark?;
    get skipByteOrderMark(): string;
    set skipByteOrderMark(value: string);
    resetSkipByteOrderMark(): void;
    get skipByteOrderMarkInput(): string | undefined;
    private _stripOuterElement?;
    get stripOuterElement(): string;
    set stripOuterElement(value: string);
    resetStripOuterElement(): void;
    get stripOuterElementInput(): string | undefined;
}
export interface StageInternalFileFormat {
    /**
    * Fully qualified name of the file format (e.g., 'database.schema.format_name').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#format_name StageInternal#format_name}
    */
    readonly formatName?: string;
    /**
    * avro block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#avro StageInternal#avro}
    */
    readonly avro?: StageInternalFileFormatAvro;
    /**
    * csv block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#csv StageInternal#csv}
    */
    readonly csv?: StageInternalFileFormatCsv;
    /**
    * json block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#json StageInternal#json}
    */
    readonly json?: StageInternalFileFormatJson;
    /**
    * orc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#orc StageInternal#orc}
    */
    readonly orc?: StageInternalFileFormatOrc;
    /**
    * parquet block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#parquet StageInternal#parquet}
    */
    readonly parquet?: StageInternalFileFormatParquet;
    /**
    * xml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#xml StageInternal#xml}
    */
    readonly xml?: StageInternalFileFormatXml;
}
export declare function stageInternalFileFormatToTerraform(struct?: StageInternalFileFormatOutputReference | StageInternalFileFormat): any;
export declare function stageInternalFileFormatToHclTerraform(struct?: StageInternalFileFormatOutputReference | StageInternalFileFormat): any;
export declare class StageInternalFileFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageInternalFileFormat | undefined;
    set internalValue(value: StageInternalFileFormat | undefined);
    private _formatName?;
    get formatName(): string;
    set formatName(value: string);
    resetFormatName(): void;
    get formatNameInput(): string | undefined;
    private _avro;
    get avro(): StageInternalFileFormatAvroOutputReference;
    putAvro(value: StageInternalFileFormatAvro): void;
    resetAvro(): void;
    get avroInput(): StageInternalFileFormatAvro | undefined;
    private _csv;
    get csv(): StageInternalFileFormatCsvOutputReference;
    putCsv(value: StageInternalFileFormatCsv): void;
    resetCsv(): void;
    get csvInput(): StageInternalFileFormatCsv | undefined;
    private _json;
    get json(): StageInternalFileFormatJsonOutputReference;
    putJson(value: StageInternalFileFormatJson): void;
    resetJson(): void;
    get jsonInput(): StageInternalFileFormatJson | undefined;
    private _orc;
    get orc(): StageInternalFileFormatOrcOutputReference;
    putOrc(value: StageInternalFileFormatOrc): void;
    resetOrc(): void;
    get orcInput(): StageInternalFileFormatOrc | undefined;
    private _parquet;
    get parquet(): StageInternalFileFormatParquetOutputReference;
    putParquet(value: StageInternalFileFormatParquet): void;
    resetParquet(): void;
    get parquetInput(): StageInternalFileFormatParquet | undefined;
    private _xml;
    get xml(): StageInternalFileFormatXmlOutputReference;
    putXml(value: StageInternalFileFormatXml): void;
    resetXml(): void;
    get xmlInput(): StageInternalFileFormatXml | undefined;
}
export interface StageInternalTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#create StageInternal#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#delete StageInternal#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#read StageInternal#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#update StageInternal#update}
    */
    readonly update?: string;
}
export declare function stageInternalTimeoutsToTerraform(struct?: StageInternalTimeouts | cdktn.IResolvable): any;
export declare function stageInternalTimeoutsToHclTerraform(struct?: StageInternalTimeouts | cdktn.IResolvable): any;
export declare class StageInternalTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageInternalTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: StageInternalTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal snowflake_stage_internal}
*/
export declare class StageInternal extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_stage_internal";
    /**
    * Generates CDKTN code for importing a StageInternal resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StageInternal to import
    * @param importFromId The id of the existing StageInternal that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StageInternal to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.14.0/docs/resources/stage_internal snowflake_stage_internal} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StageInternalConfig
    */
    constructor(scope: Construct, id: string, config: StageInternalConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): StageInternalDescribeOutputList;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): StageInternalShowOutputList;
    get stageType(): string;
    private _directory;
    get directory(): StageInternalDirectoryOutputReference;
    putDirectory(value: StageInternalDirectory): void;
    resetDirectory(): void;
    get directoryInput(): StageInternalDirectory | undefined;
    private _encryption;
    get encryption(): StageInternalEncryptionOutputReference;
    putEncryption(value: StageInternalEncryption): void;
    resetEncryption(): void;
    get encryptionInput(): StageInternalEncryption | undefined;
    private _fileFormat;
    get fileFormat(): StageInternalFileFormatOutputReference;
    putFileFormat(value: StageInternalFileFormat): void;
    resetFileFormat(): void;
    get fileFormatInput(): StageInternalFileFormat | undefined;
    private _timeouts;
    get timeouts(): StageInternalTimeoutsOutputReference;
    putTimeouts(value: StageInternalTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | StageInternalTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
