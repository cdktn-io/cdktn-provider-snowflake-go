/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CatalogIntegrationIcebergRestConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the default namespace for all Iceberg tables that you associate with the catalog integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#catalog_namespace CatalogIntegrationIcebergRest#catalog_namespace}
    */
    readonly catalogNamespace?: string;
    /**
    * (Default: ``) Specifies a comment for the catalog integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#comment CatalogIntegrationIcebergRest#comment}
    */
    readonly comment?: string;
    /**
    * Specifies whether the catalog integration is available for use for Iceberg tables. `true` allows users to create new Iceberg tables that reference this integration. Existing Iceberg tables that reference this integration function normally. `false` prevents users from creating new Iceberg tables that reference this integration. Existing Iceberg tables that reference this integration cannot access the catalog in the table definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#enabled CatalogIntegrationIcebergRest#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#id CatalogIntegrationIcebergRest#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier (i.e. name) of the catalog integration; must be unique in your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#name CatalogIntegrationIcebergRest#name}
    */
    readonly name: string;
    /**
    * Specifies the number of seconds to wait between attempts to poll the external Iceberg catalog for metadata updates for automated refresh. For Delta-based tables, specifies the number of seconds to wait between attempts to poll your external cloud storage for new metadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#refresh_interval_seconds CatalogIntegrationIcebergRest#refresh_interval_seconds}
    */
    readonly refreshIntervalSeconds?: number;
    /**
    * bearer_rest_authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#bearer_rest_authentication CatalogIntegrationIcebergRest#bearer_rest_authentication}
    */
    readonly bearerRestAuthentication?: CatalogIntegrationIcebergRestBearerRestAuthentication;
    /**
    * oauth_rest_authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#oauth_rest_authentication CatalogIntegrationIcebergRest#oauth_rest_authentication}
    */
    readonly oauthRestAuthentication?: CatalogIntegrationIcebergRestOauthRestAuthentication;
    /**
    * rest_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#rest_config CatalogIntegrationIcebergRest#rest_config}
    */
    readonly restConfig: CatalogIntegrationIcebergRestRestConfig;
    /**
    * sigv4_rest_authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#sigv4_rest_authentication CatalogIntegrationIcebergRest#sigv4_rest_authentication}
    */
    readonly sigv4RestAuthentication?: CatalogIntegrationIcebergRestSigv4RestAuthentication;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#timeouts CatalogIntegrationIcebergRest#timeouts}
    */
    readonly timeouts?: CatalogIntegrationIcebergRestTimeouts;
}
export interface CatalogIntegrationIcebergRestDescribeOutputBearerRestAuthentication {
}
export declare function catalogIntegrationIcebergRestDescribeOutputBearerRestAuthenticationToTerraform(struct?: CatalogIntegrationIcebergRestDescribeOutputBearerRestAuthentication): any;
export declare function catalogIntegrationIcebergRestDescribeOutputBearerRestAuthenticationToHclTerraform(struct?: CatalogIntegrationIcebergRestDescribeOutputBearerRestAuthentication): any;
export declare class CatalogIntegrationIcebergRestDescribeOutputBearerRestAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CatalogIntegrationIcebergRestDescribeOutputBearerRestAuthentication | undefined;
    set internalValue(value: CatalogIntegrationIcebergRestDescribeOutputBearerRestAuthentication | undefined);
}
export declare class CatalogIntegrationIcebergRestDescribeOutputBearerRestAuthenticationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CatalogIntegrationIcebergRestDescribeOutputBearerRestAuthenticationOutputReference;
}
export interface CatalogIntegrationIcebergRestDescribeOutputOauthRestAuthentication {
}
export declare function catalogIntegrationIcebergRestDescribeOutputOauthRestAuthenticationToTerraform(struct?: CatalogIntegrationIcebergRestDescribeOutputOauthRestAuthentication): any;
export declare function catalogIntegrationIcebergRestDescribeOutputOauthRestAuthenticationToHclTerraform(struct?: CatalogIntegrationIcebergRestDescribeOutputOauthRestAuthentication): any;
export declare class CatalogIntegrationIcebergRestDescribeOutputOauthRestAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CatalogIntegrationIcebergRestDescribeOutputOauthRestAuthentication | undefined;
    set internalValue(value: CatalogIntegrationIcebergRestDescribeOutputOauthRestAuthentication | undefined);
    get oauthAllowedScopes(): string[];
    get oauthClientId(): string;
    get oauthTokenUri(): string;
}
export declare class CatalogIntegrationIcebergRestDescribeOutputOauthRestAuthenticationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CatalogIntegrationIcebergRestDescribeOutputOauthRestAuthenticationOutputReference;
}
export interface CatalogIntegrationIcebergRestDescribeOutputRestConfig {
}
export declare function catalogIntegrationIcebergRestDescribeOutputRestConfigToTerraform(struct?: CatalogIntegrationIcebergRestDescribeOutputRestConfig): any;
export declare function catalogIntegrationIcebergRestDescribeOutputRestConfigToHclTerraform(struct?: CatalogIntegrationIcebergRestDescribeOutputRestConfig): any;
export declare class CatalogIntegrationIcebergRestDescribeOutputRestConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CatalogIntegrationIcebergRestDescribeOutputRestConfig | undefined;
    set internalValue(value: CatalogIntegrationIcebergRestDescribeOutputRestConfig | undefined);
    get accessDelegationMode(): string;
    get catalogApiType(): string;
    get catalogName(): string;
    get catalogUri(): string;
    get prefix(): string;
}
export declare class CatalogIntegrationIcebergRestDescribeOutputRestConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CatalogIntegrationIcebergRestDescribeOutputRestConfigOutputReference;
}
export interface CatalogIntegrationIcebergRestDescribeOutputSigv4RestAuthentication {
}
export declare function catalogIntegrationIcebergRestDescribeOutputSigv4RestAuthenticationToTerraform(struct?: CatalogIntegrationIcebergRestDescribeOutputSigv4RestAuthentication): any;
export declare function catalogIntegrationIcebergRestDescribeOutputSigv4RestAuthenticationToHclTerraform(struct?: CatalogIntegrationIcebergRestDescribeOutputSigv4RestAuthentication): any;
export declare class CatalogIntegrationIcebergRestDescribeOutputSigv4RestAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CatalogIntegrationIcebergRestDescribeOutputSigv4RestAuthentication | undefined;
    set internalValue(value: CatalogIntegrationIcebergRestDescribeOutputSigv4RestAuthentication | undefined);
    get sigv4IamRole(): string;
    get sigv4SigningRegion(): string;
}
export declare class CatalogIntegrationIcebergRestDescribeOutputSigv4RestAuthenticationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CatalogIntegrationIcebergRestDescribeOutputSigv4RestAuthenticationOutputReference;
}
export interface CatalogIntegrationIcebergRestDescribeOutput {
}
export declare function catalogIntegrationIcebergRestDescribeOutputToTerraform(struct?: CatalogIntegrationIcebergRestDescribeOutput): any;
export declare function catalogIntegrationIcebergRestDescribeOutputToHclTerraform(struct?: CatalogIntegrationIcebergRestDescribeOutput): any;
export declare class CatalogIntegrationIcebergRestDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CatalogIntegrationIcebergRestDescribeOutput | undefined;
    set internalValue(value: CatalogIntegrationIcebergRestDescribeOutput | undefined);
    private _bearerRestAuthentication;
    get bearerRestAuthentication(): CatalogIntegrationIcebergRestDescribeOutputBearerRestAuthenticationList;
    get catalogNamespace(): string;
    get catalogSource(): string;
    get comment(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    private _oauthRestAuthentication;
    get oauthRestAuthentication(): CatalogIntegrationIcebergRestDescribeOutputOauthRestAuthenticationList;
    get refreshIntervalSeconds(): number;
    private _restConfig;
    get restConfig(): CatalogIntegrationIcebergRestDescribeOutputRestConfigList;
    private _sigv4RestAuthentication;
    get sigv4RestAuthentication(): CatalogIntegrationIcebergRestDescribeOutputSigv4RestAuthenticationList;
    get tableFormat(): string;
}
export declare class CatalogIntegrationIcebergRestDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CatalogIntegrationIcebergRestDescribeOutputOutputReference;
}
export interface CatalogIntegrationIcebergRestShowOutput {
}
export declare function catalogIntegrationIcebergRestShowOutputToTerraform(struct?: CatalogIntegrationIcebergRestShowOutput): any;
export declare function catalogIntegrationIcebergRestShowOutputToHclTerraform(struct?: CatalogIntegrationIcebergRestShowOutput): any;
export declare class CatalogIntegrationIcebergRestShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CatalogIntegrationIcebergRestShowOutput | undefined;
    set internalValue(value: CatalogIntegrationIcebergRestShowOutput | undefined);
    get category(): string;
    get comment(): string;
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
    get type(): string;
}
export declare class CatalogIntegrationIcebergRestShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CatalogIntegrationIcebergRestShowOutputOutputReference;
}
export interface CatalogIntegrationIcebergRestBearerRestAuthentication {
    /**
    * The bearer token for the identity provider. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#bearer_token CatalogIntegrationIcebergRest#bearer_token}
    */
    readonly bearerToken: string;
}
export declare function catalogIntegrationIcebergRestBearerRestAuthenticationToTerraform(struct?: CatalogIntegrationIcebergRestBearerRestAuthenticationOutputReference | CatalogIntegrationIcebergRestBearerRestAuthentication): any;
export declare function catalogIntegrationIcebergRestBearerRestAuthenticationToHclTerraform(struct?: CatalogIntegrationIcebergRestBearerRestAuthenticationOutputReference | CatalogIntegrationIcebergRestBearerRestAuthentication): any;
export declare class CatalogIntegrationIcebergRestBearerRestAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogIntegrationIcebergRestBearerRestAuthentication | undefined;
    set internalValue(value: CatalogIntegrationIcebergRestBearerRestAuthentication | undefined);
    private _bearerToken?;
    get bearerToken(): string;
    set bearerToken(value: string);
    get bearerTokenInput(): string | undefined;
}
export interface CatalogIntegrationIcebergRestOauthRestAuthentication {
    /**
    * Specifies one or more scopes for the OAuth token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#oauth_allowed_scopes CatalogIntegrationIcebergRest#oauth_allowed_scopes}
    */
    readonly oauthAllowedScopes: string[];
    /**
    * Specifies the client ID of the OAuth2 credential.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#oauth_client_id CatalogIntegrationIcebergRest#oauth_client_id}
    */
    readonly oauthClientId: string;
    /**
    * Specifies the secret of the OAuth2 credential. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#oauth_client_secret CatalogIntegrationIcebergRest#oauth_client_secret}
    */
    readonly oauthClientSecret: string;
    /**
    * Specifies URL for the third-party identity provider. If not specified, Snowflake assumes the remote catalog provider is the identity provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#oauth_token_uri CatalogIntegrationIcebergRest#oauth_token_uri}
    */
    readonly oauthTokenUri?: string;
}
export declare function catalogIntegrationIcebergRestOauthRestAuthenticationToTerraform(struct?: CatalogIntegrationIcebergRestOauthRestAuthenticationOutputReference | CatalogIntegrationIcebergRestOauthRestAuthentication): any;
export declare function catalogIntegrationIcebergRestOauthRestAuthenticationToHclTerraform(struct?: CatalogIntegrationIcebergRestOauthRestAuthenticationOutputReference | CatalogIntegrationIcebergRestOauthRestAuthentication): any;
export declare class CatalogIntegrationIcebergRestOauthRestAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogIntegrationIcebergRestOauthRestAuthentication | undefined;
    set internalValue(value: CatalogIntegrationIcebergRestOauthRestAuthentication | undefined);
    private _oauthAllowedScopes?;
    get oauthAllowedScopes(): string[];
    set oauthAllowedScopes(value: string[]);
    get oauthAllowedScopesInput(): string[] | undefined;
    private _oauthClientId?;
    get oauthClientId(): string;
    set oauthClientId(value: string);
    get oauthClientIdInput(): string | undefined;
    private _oauthClientSecret?;
    get oauthClientSecret(): string;
    set oauthClientSecret(value: string);
    get oauthClientSecretInput(): string | undefined;
    private _oauthTokenUri?;
    get oauthTokenUri(): string;
    set oauthTokenUri(value: string);
    resetOauthTokenUri(): void;
    get oauthTokenUriInput(): string | undefined;
}
export interface CatalogIntegrationIcebergRestRestConfig {
    /**
    * Specifies the access delegation mode for accessing Iceberg table files in your external cloud storage. Valid values are (case-insensitive): `VENDED_CREDENTIALS` | `EXTERNAL_VOLUME_CREDENTIALS`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#access_delegation_mode CatalogIntegrationIcebergRest#access_delegation_mode}
    */
    readonly accessDelegationMode?: string;
    /**
    * Specifies the connection type for the catalog API. Valid values are (case-insensitive): `PUBLIC` | `PRIVATE` | `AWS_API_GATEWAY` | `AWS_PRIVATE_API_GATEWAY` | `AWS_GLUE` | `AWS_PRIVATE_GLUE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#catalog_api_type CatalogIntegrationIcebergRest#catalog_api_type}
    */
    readonly catalogApiType?: string;
    /**
    * Specifies the catalog or identifier to request from your remote catalog service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#catalog_name CatalogIntegrationIcebergRest#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Specifies the endpoint URL for the catalog REST API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#catalog_uri CatalogIntegrationIcebergRest#catalog_uri}
    */
    readonly catalogUri: string;
    /**
    * Specifies an optional prefix appended to all API routes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#prefix CatalogIntegrationIcebergRest#prefix}
    */
    readonly prefix?: string;
}
export declare function catalogIntegrationIcebergRestRestConfigToTerraform(struct?: CatalogIntegrationIcebergRestRestConfigOutputReference | CatalogIntegrationIcebergRestRestConfig): any;
export declare function catalogIntegrationIcebergRestRestConfigToHclTerraform(struct?: CatalogIntegrationIcebergRestRestConfigOutputReference | CatalogIntegrationIcebergRestRestConfig): any;
export declare class CatalogIntegrationIcebergRestRestConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogIntegrationIcebergRestRestConfig | undefined;
    set internalValue(value: CatalogIntegrationIcebergRestRestConfig | undefined);
    private _accessDelegationMode?;
    get accessDelegationMode(): string;
    set accessDelegationMode(value: string);
    resetAccessDelegationMode(): void;
    get accessDelegationModeInput(): string | undefined;
    private _catalogApiType?;
    get catalogApiType(): string;
    set catalogApiType(value: string);
    resetCatalogApiType(): void;
    get catalogApiTypeInput(): string | undefined;
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _catalogUri?;
    get catalogUri(): string;
    set catalogUri(value: string);
    get catalogUriInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
}
export interface CatalogIntegrationIcebergRestSigv4RestAuthentication {
    /**
    * Specifies an external ID that Snowflake uses to establish a trust relationship with AWS. If you don’t specify this parameter, Snowflake automatically generates a unique external ID when you create a catalog integration. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#sigv4_external_id CatalogIntegrationIcebergRest#sigv4_external_id}
    */
    readonly sigv4ExternalId?: string;
    /**
    * Specifies the Amazon Resource Name (ARN) for an IAM role that has permission to access your REST API in API Gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#sigv4_iam_role CatalogIntegrationIcebergRest#sigv4_iam_role}
    */
    readonly sigv4IamRole: string;
    /**
    * Specifies the AWS Region associated with your API in API Gateway. If you don’t specify this parameter, Snowflake uses the region in which your Snowflake account is deployed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#sigv4_signing_region CatalogIntegrationIcebergRest#sigv4_signing_region}
    */
    readonly sigv4SigningRegion?: string;
}
export declare function catalogIntegrationIcebergRestSigv4RestAuthenticationToTerraform(struct?: CatalogIntegrationIcebergRestSigv4RestAuthenticationOutputReference | CatalogIntegrationIcebergRestSigv4RestAuthentication): any;
export declare function catalogIntegrationIcebergRestSigv4RestAuthenticationToHclTerraform(struct?: CatalogIntegrationIcebergRestSigv4RestAuthenticationOutputReference | CatalogIntegrationIcebergRestSigv4RestAuthentication): any;
export declare class CatalogIntegrationIcebergRestSigv4RestAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogIntegrationIcebergRestSigv4RestAuthentication | undefined;
    set internalValue(value: CatalogIntegrationIcebergRestSigv4RestAuthentication | undefined);
    private _sigv4ExternalId?;
    get sigv4ExternalId(): string;
    set sigv4ExternalId(value: string);
    resetSigv4ExternalId(): void;
    get sigv4ExternalIdInput(): string | undefined;
    private _sigv4IamRole?;
    get sigv4IamRole(): string;
    set sigv4IamRole(value: string);
    get sigv4IamRoleInput(): string | undefined;
    private _sigv4SigningRegion?;
    get sigv4SigningRegion(): string;
    set sigv4SigningRegion(value: string);
    resetSigv4SigningRegion(): void;
    get sigv4SigningRegionInput(): string | undefined;
}
export interface CatalogIntegrationIcebergRestTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#create CatalogIntegrationIcebergRest#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#delete CatalogIntegrationIcebergRest#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#read CatalogIntegrationIcebergRest#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#update CatalogIntegrationIcebergRest#update}
    */
    readonly update?: string;
}
export declare function catalogIntegrationIcebergRestTimeoutsToTerraform(struct?: CatalogIntegrationIcebergRestTimeouts | cdktn.IResolvable): any;
export declare function catalogIntegrationIcebergRestTimeoutsToHclTerraform(struct?: CatalogIntegrationIcebergRestTimeouts | cdktn.IResolvable): any;
export declare class CatalogIntegrationIcebergRestTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogIntegrationIcebergRestTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CatalogIntegrationIcebergRestTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest snowflake_catalog_integration_iceberg_rest}
*/
export declare class CatalogIntegrationIcebergRest extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_catalog_integration_iceberg_rest";
    /**
    * Generates CDKTN code for importing a CatalogIntegrationIcebergRest resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CatalogIntegrationIcebergRest to import
    * @param importFromId The id of the existing CatalogIntegrationIcebergRest that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CatalogIntegrationIcebergRest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/catalog_integration_iceberg_rest snowflake_catalog_integration_iceberg_rest} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CatalogIntegrationIcebergRestConfig
    */
    constructor(scope: Construct, id: string, config: CatalogIntegrationIcebergRestConfig);
    private _catalogNamespace?;
    get catalogNamespace(): string;
    set catalogNamespace(value: string);
    resetCatalogNamespace(): void;
    get catalogNamespaceInput(): string | undefined;
    get catalogSource(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): CatalogIntegrationIcebergRestDescribeOutputList;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _refreshIntervalSeconds?;
    get refreshIntervalSeconds(): number;
    set refreshIntervalSeconds(value: number);
    resetRefreshIntervalSeconds(): void;
    get refreshIntervalSecondsInput(): number | undefined;
    private _showOutput;
    get showOutput(): CatalogIntegrationIcebergRestShowOutputList;
    private _bearerRestAuthentication;
    get bearerRestAuthentication(): CatalogIntegrationIcebergRestBearerRestAuthenticationOutputReference;
    putBearerRestAuthentication(value: CatalogIntegrationIcebergRestBearerRestAuthentication): void;
    resetBearerRestAuthentication(): void;
    get bearerRestAuthenticationInput(): CatalogIntegrationIcebergRestBearerRestAuthentication | undefined;
    private _oauthRestAuthentication;
    get oauthRestAuthentication(): CatalogIntegrationIcebergRestOauthRestAuthenticationOutputReference;
    putOauthRestAuthentication(value: CatalogIntegrationIcebergRestOauthRestAuthentication): void;
    resetOauthRestAuthentication(): void;
    get oauthRestAuthenticationInput(): CatalogIntegrationIcebergRestOauthRestAuthentication | undefined;
    private _restConfig;
    get restConfig(): CatalogIntegrationIcebergRestRestConfigOutputReference;
    putRestConfig(value: CatalogIntegrationIcebergRestRestConfig): void;
    get restConfigInput(): CatalogIntegrationIcebergRestRestConfig | undefined;
    private _sigv4RestAuthentication;
    get sigv4RestAuthentication(): CatalogIntegrationIcebergRestSigv4RestAuthenticationOutputReference;
    putSigv4RestAuthentication(value: CatalogIntegrationIcebergRestSigv4RestAuthentication): void;
    resetSigv4RestAuthentication(): void;
    get sigv4RestAuthenticationInput(): CatalogIntegrationIcebergRestSigv4RestAuthentication | undefined;
    private _timeouts;
    get timeouts(): CatalogIntegrationIcebergRestTimeoutsOutputReference;
    putTimeouts(value: CatalogIntegrationIcebergRestTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CatalogIntegrationIcebergRestTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
