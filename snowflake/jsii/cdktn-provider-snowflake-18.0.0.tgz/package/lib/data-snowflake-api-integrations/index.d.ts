/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeApiIntegrationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/api_integrations#id DataSnowflakeApiIntegrations#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/api_integrations#like DataSnowflakeApiIntegrations#like}
    */
    readonly like?: string;
    /**
    * (Default: `true`) Runs DESC API INTEGRATION for each integration returned by SHOW API INTEGRATIONS. The output of describe is saved to the describe_output field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/api_integrations#with_describe DataSnowflakeApiIntegrations#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
}
export interface DataSnowflakeApiIntegrationsApiIntegrationsDescribeOutput {
}
export declare function dataSnowflakeApiIntegrationsApiIntegrationsDescribeOutputToTerraform(struct?: DataSnowflakeApiIntegrationsApiIntegrationsDescribeOutput): any;
export declare function dataSnowflakeApiIntegrationsApiIntegrationsDescribeOutputToHclTerraform(struct?: DataSnowflakeApiIntegrationsApiIntegrationsDescribeOutput): any;
export declare class DataSnowflakeApiIntegrationsApiIntegrationsDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeApiIntegrationsApiIntegrationsDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeApiIntegrationsApiIntegrationsDescribeOutput | undefined);
    get allowedAuthenticationSecrets(): string;
    get allowedPrefixes(): string[];
    get apiAwsExternalId(): string;
    get apiAwsIamUserArn(): string;
    get apiAwsRoleArn(): string;
    get apiKey(): string;
    get apiProvider(): string;
    get azureAdApplicationId(): string;
    get azureConsentUrl(): string;
    get azureMultiTenantAppName(): string;
    get azureTenantId(): string;
    get blockedPrefixes(): string[];
    get comment(): string;
    get enabled(): cdktn.IResolvable;
    get googleApiServiceAccount(): string;
    get googleAudience(): string;
    get oauthAccessTokenValidity(): number;
    get oauthAllowedScopes(): string[];
    get oauthAssertionIssuer(): string;
    get oauthAuthorizationEndpoint(): string;
    get oauthClientAuthMethod(): string;
    get oauthClientId(): string;
    get oauthGrant(): string;
    get oauthRefreshTokenValidity(): number;
    get oauthResourceUrl(): string;
    get oauthTokenEndpoint(): string;
    get oauthUsername(): string;
    get tlsTrustedCertificates(): string[];
    get usePrivatelinkEndpoint(): cdktn.IResolvable;
    get userAuthType(): string;
}
export declare class DataSnowflakeApiIntegrationsApiIntegrationsDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeApiIntegrationsApiIntegrationsDescribeOutputOutputReference;
}
export interface DataSnowflakeApiIntegrationsApiIntegrationsShowOutput {
}
export declare function dataSnowflakeApiIntegrationsApiIntegrationsShowOutputToTerraform(struct?: DataSnowflakeApiIntegrationsApiIntegrationsShowOutput): any;
export declare function dataSnowflakeApiIntegrationsApiIntegrationsShowOutputToHclTerraform(struct?: DataSnowflakeApiIntegrationsApiIntegrationsShowOutput): any;
export declare class DataSnowflakeApiIntegrationsApiIntegrationsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeApiIntegrationsApiIntegrationsShowOutput | undefined;
    set internalValue(value: DataSnowflakeApiIntegrationsApiIntegrationsShowOutput | undefined);
    get apiType(): string;
    get category(): string;
    get comment(): string;
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
}
export declare class DataSnowflakeApiIntegrationsApiIntegrationsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeApiIntegrationsApiIntegrationsShowOutputOutputReference;
}
export interface DataSnowflakeApiIntegrationsApiIntegrations {
}
export declare function dataSnowflakeApiIntegrationsApiIntegrationsToTerraform(struct?: DataSnowflakeApiIntegrationsApiIntegrations): any;
export declare function dataSnowflakeApiIntegrationsApiIntegrationsToHclTerraform(struct?: DataSnowflakeApiIntegrationsApiIntegrations): any;
export declare class DataSnowflakeApiIntegrationsApiIntegrationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeApiIntegrationsApiIntegrations | undefined;
    set internalValue(value: DataSnowflakeApiIntegrationsApiIntegrations | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeApiIntegrationsApiIntegrationsDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeApiIntegrationsApiIntegrationsShowOutputList;
}
export declare class DataSnowflakeApiIntegrationsApiIntegrationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeApiIntegrationsApiIntegrationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/api_integrations snowflake_api_integrations}
*/
export declare class DataSnowflakeApiIntegrations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_api_integrations";
    /**
    * Generates CDKTN code for importing a DataSnowflakeApiIntegrations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeApiIntegrations to import
    * @param importFromId The id of the existing DataSnowflakeApiIntegrations that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/api_integrations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeApiIntegrations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/api_integrations snowflake_api_integrations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeApiIntegrationsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeApiIntegrationsConfig);
    private _apiIntegrations;
    get apiIntegrations(): DataSnowflakeApiIntegrationsApiIntegrationsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
