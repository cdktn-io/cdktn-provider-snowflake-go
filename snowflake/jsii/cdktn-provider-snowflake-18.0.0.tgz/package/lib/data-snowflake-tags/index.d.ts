/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeTagsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/tags#id DataSnowflakeTags#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/tags#like DataSnowflakeTags#like}
    */
    readonly like?: string;
    /**
    * in block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/tags#in DataSnowflakeTags#in}
    */
    readonly in?: DataSnowflakeTagsIn;
}
export interface DataSnowflakeTagsTagsShowOutput {
}
export declare function dataSnowflakeTagsTagsShowOutputToTerraform(struct?: DataSnowflakeTagsTagsShowOutput): any;
export declare function dataSnowflakeTagsTagsShowOutputToHclTerraform(struct?: DataSnowflakeTagsTagsShowOutput): any;
export declare class DataSnowflakeTagsTagsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeTagsTagsShowOutput | undefined;
    set internalValue(value: DataSnowflakeTagsTagsShowOutput | undefined);
    get allowedValues(): string[];
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get name(): string;
    get onConflict(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get propagate(): string;
    get schemaName(): string;
}
export declare class DataSnowflakeTagsTagsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeTagsTagsShowOutputOutputReference;
}
export interface DataSnowflakeTagsTags {
}
export declare function dataSnowflakeTagsTagsToTerraform(struct?: DataSnowflakeTagsTags): any;
export declare function dataSnowflakeTagsTagsToHclTerraform(struct?: DataSnowflakeTagsTags): any;
export declare class DataSnowflakeTagsTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeTagsTags | undefined;
    set internalValue(value: DataSnowflakeTagsTags | undefined);
    private _showOutput;
    get showOutput(): DataSnowflakeTagsTagsShowOutputList;
}
export declare class DataSnowflakeTagsTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeTagsTagsOutputReference;
}
export interface DataSnowflakeTagsIn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/tags#account DataSnowflakeTags#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the specified application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/tags#application DataSnowflakeTags#application}
    */
    readonly application?: string;
    /**
    * Returns records for the specified application package.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/tags#application_package DataSnowflakeTags#application_package}
    */
    readonly applicationPackage?: string;
    /**
    * Returns records for the current database in use or for a specified database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/tags#database DataSnowflakeTags#database}
    */
    readonly database?: string;
    /**
    * Returns records for the current schema in use or a specified schema. Use fully qualified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/tags#schema DataSnowflakeTags#schema}
    */
    readonly schema?: string;
}
export declare function dataSnowflakeTagsInToTerraform(struct?: DataSnowflakeTagsInOutputReference | DataSnowflakeTagsIn): any;
export declare function dataSnowflakeTagsInToHclTerraform(struct?: DataSnowflakeTagsInOutputReference | DataSnowflakeTagsIn): any;
export declare class DataSnowflakeTagsInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeTagsIn | undefined;
    set internalValue(value: DataSnowflakeTagsIn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _application?;
    get application(): string;
    set application(value: string);
    resetApplication(): void;
    get applicationInput(): string | undefined;
    private _applicationPackage?;
    get applicationPackage(): string;
    set applicationPackage(value: string);
    resetApplicationPackage(): void;
    get applicationPackageInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/tags snowflake_tags}
*/
export declare class DataSnowflakeTags extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_tags";
    /**
    * Generates CDKTN code for importing a DataSnowflakeTags resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeTags to import
    * @param importFromId The id of the existing DataSnowflakeTags that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/tags#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeTags to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/tags snowflake_tags} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeTagsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeTagsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _tags;
    get tags(): DataSnowflakeTagsTagsList;
    private _in;
    get in(): DataSnowflakeTagsInOutputReference;
    putIn(value: DataSnowflakeTagsIn): void;
    resetIn(): void;
    get inInput(): DataSnowflakeTagsIn | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
