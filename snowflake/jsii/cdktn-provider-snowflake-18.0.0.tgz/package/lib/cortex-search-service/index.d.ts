/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CortexSearchServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the list of columns in the base table to enable filtering on when issuing queries to the service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#attributes CortexSearchService#attributes}
    */
    readonly attributes?: string[];
    /**
    * Specifies a comment for the Cortex search service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#comment CortexSearchService#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the Cortex search service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#database CortexSearchService#database}
    */
    readonly database: string;
    /**
    * Specifies the embedding model to use for the Cortex search service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#embedding_model CortexSearchService#embedding_model}
    */
    readonly embeddingModel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#id CortexSearchService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the name of the Cortex search service. The name must be unique for the schema in which the service is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#name CortexSearchService#name}
    */
    readonly name: string;
    /**
    * Specifies the column to use as the search column for the Cortex search service; must be a text value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#on CortexSearchService#on}
    */
    readonly on: string;
    /**
    * Specifies the query to use to populate the Cortex search service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#query CortexSearchService#query}
    */
    readonly query: string;
    /**
    * The schema in which to create the Cortex search service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#schema CortexSearchService#schema}
    */
    readonly schema: string;
    /**
    * Specifies the maximum target lag time for the Cortex search service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#target_lag CortexSearchService#target_lag}
    */
    readonly targetLag: string;
    /**
    * The warehouse in which to create the Cortex search service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#warehouse CortexSearchService#warehouse}
    */
    readonly warehouse: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#timeouts CortexSearchService#timeouts}
    */
    readonly timeouts?: CortexSearchServiceTimeouts;
}
export interface CortexSearchServiceDescribeOutput {
}
export declare function cortexSearchServiceDescribeOutputToTerraform(struct?: CortexSearchServiceDescribeOutput): any;
export declare function cortexSearchServiceDescribeOutputToHclTerraform(struct?: CortexSearchServiceDescribeOutput): any;
export declare class CortexSearchServiceDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CortexSearchServiceDescribeOutput | undefined;
    set internalValue(value: CortexSearchServiceDescribeOutput | undefined);
    get attributeColumns(): string[];
    get columns(): string[];
    get comment(): string;
    get createdOn(): string;
    get dataTimestamp(): string;
    get databaseName(): string;
    get definition(): string;
    get embeddingModel(): string;
    get indexingError(): string;
    get indexingState(): string;
    get name(): string;
    get schemaName(): string;
    get searchColumn(): string;
    get serviceQueryUrl(): string;
    get sourceDataNumRows(): number;
    get targetLag(): string;
    get warehouse(): string;
}
export declare class CortexSearchServiceDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CortexSearchServiceDescribeOutputOutputReference;
}
export interface CortexSearchServiceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#create CortexSearchService#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#delete CortexSearchService#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#read CortexSearchService#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#update CortexSearchService#update}
    */
    readonly update?: string;
}
export declare function cortexSearchServiceTimeoutsToTerraform(struct?: CortexSearchServiceTimeouts | cdktn.IResolvable): any;
export declare function cortexSearchServiceTimeoutsToHclTerraform(struct?: CortexSearchServiceTimeouts | cdktn.IResolvable): any;
export declare class CortexSearchServiceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CortexSearchServiceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CortexSearchServiceTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service snowflake_cortex_search_service}
*/
export declare class CortexSearchService extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_cortex_search_service";
    /**
    * Generates CDKTN code for importing a CortexSearchService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CortexSearchService to import
    * @param importFromId The id of the existing CortexSearchService that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CortexSearchService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/cortex_search_service snowflake_cortex_search_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CortexSearchServiceConfig
    */
    constructor(scope: Construct, id: string, config: CortexSearchServiceConfig);
    private _attributes?;
    get attributes(): string[];
    set attributes(value: string[]);
    resetAttributes(): void;
    get attributesInput(): string[] | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get createdOn(): string;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): CortexSearchServiceDescribeOutputList;
    private _embeddingModel?;
    get embeddingModel(): string;
    set embeddingModel(value: string);
    resetEmbeddingModel(): void;
    get embeddingModelInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _on?;
    get on(): string;
    set on(value: string);
    get onInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _targetLag?;
    get targetLag(): string;
    set targetLag(value: string);
    get targetLagInput(): string | undefined;
    private _warehouse?;
    get warehouse(): string;
    set warehouse(value: string);
    get warehouseInput(): string | undefined;
    private _timeouts;
    get timeouts(): CortexSearchServiceTimeoutsOutputReference;
    putTimeouts(value: CortexSearchServiceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CortexSearchServiceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
