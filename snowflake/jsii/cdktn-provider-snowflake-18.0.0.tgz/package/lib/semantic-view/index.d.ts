/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SemanticViewConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the semantic view.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#comment SemanticView#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the semantic view. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#database SemanticView#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#id SemanticView#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the semantic view; must be unique within the schema. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#name SemanticView#name}
    */
    readonly name: string;
    /**
    * The schema in which to create the semantic view. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#schema SemanticView#schema}
    */
    readonly schema: string;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#dimensions SemanticView#dimensions}
    */
    readonly dimensions?: SemanticViewDimensions[] | cdktn.IResolvable;
    /**
    * facts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#facts SemanticView#facts}
    */
    readonly facts?: SemanticViewFacts[] | cdktn.IResolvable;
    /**
    * metrics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#metrics SemanticView#metrics}
    */
    readonly metrics?: SemanticViewMetrics[] | cdktn.IResolvable;
    /**
    * relationships block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#relationships SemanticView#relationships}
    */
    readonly relationships?: SemanticViewRelationships[] | cdktn.IResolvable;
    /**
    * tables block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#tables SemanticView#tables}
    */
    readonly tables: SemanticViewTables[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#timeouts SemanticView#timeouts}
    */
    readonly timeouts?: SemanticViewTimeouts;
}
export interface SemanticViewShowOutput {
}
export declare function semanticViewShowOutputToTerraform(struct?: SemanticViewShowOutput): any;
export declare function semanticViewShowOutputToHclTerraform(struct?: SemanticViewShowOutput): any;
export declare class SemanticViewShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SemanticViewShowOutput | undefined;
    set internalValue(value: SemanticViewShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get extension(): string;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get schemaName(): string;
}
export declare class SemanticViewShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SemanticViewShowOutputOutputReference;
}
export interface SemanticViewDimensions {
    /**
    * Specifies a comment for the dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#comment SemanticView#comment}
    */
    readonly comment?: string;
    /**
    * Specifies a qualified name for the dimension, including the table name and a unique identifier for the dimension: `<table_alias>.<semantic_expression_name>`. Remember to wrap each part in double quotes like `"\"<table_alias>\".\"<semantic_expression_name>\""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
    */
    readonly qualifiedExpressionName: string;
    /**
    * The SQL expression used to compute the dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
    */
    readonly sqlExpression: string;
    /**
    * List of synonyms for the dimension.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#synonym SemanticView#synonym}
    */
    readonly synonym?: string[];
}
export declare function semanticViewDimensionsToTerraform(struct?: SemanticViewDimensions | cdktn.IResolvable): any;
export declare function semanticViewDimensionsToHclTerraform(struct?: SemanticViewDimensions | cdktn.IResolvable): any;
export declare class SemanticViewDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SemanticViewDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: SemanticViewDimensions | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _qualifiedExpressionName?;
    get qualifiedExpressionName(): string;
    set qualifiedExpressionName(value: string);
    get qualifiedExpressionNameInput(): string | undefined;
    private _sqlExpression?;
    get sqlExpression(): string;
    set sqlExpression(value: string);
    get sqlExpressionInput(): string | undefined;
    private _synonym?;
    get synonym(): string[];
    set synonym(value: string[]);
    resetSynonym(): void;
    get synonymInput(): string[] | undefined;
}
export declare class SemanticViewDimensionsList extends cdktn.ComplexList {
    internalValue?: SemanticViewDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SemanticViewDimensionsOutputReference;
}
export interface SemanticViewFacts {
    /**
    * Specifies a comment for the fact.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#comment SemanticView#comment}
    */
    readonly comment?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether the fact is private.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#is_private SemanticView#is_private}
    */
    readonly isPrivate?: string;
    /**
    * Specifies a qualified name for the fact, including the table name and a unique identifier for the fact: `<table_alias>.<semantic_expression_name>`. Remember to wrap each part in double quotes like `"\"<table_alias>\".\"<semantic_expression_name>\""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
    */
    readonly qualifiedExpressionName: string;
    /**
    * The SQL expression used to compute the fact.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
    */
    readonly sqlExpression: string;
    /**
    * List of synonyms for the fact.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#synonym SemanticView#synonym}
    */
    readonly synonym?: string[];
}
export declare function semanticViewFactsToTerraform(struct?: SemanticViewFacts | cdktn.IResolvable): any;
export declare function semanticViewFactsToHclTerraform(struct?: SemanticViewFacts | cdktn.IResolvable): any;
export declare class SemanticViewFactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SemanticViewFacts | cdktn.IResolvable | undefined;
    set internalValue(value: SemanticViewFacts | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _isPrivate?;
    get isPrivate(): string;
    set isPrivate(value: string);
    resetIsPrivate(): void;
    get isPrivateInput(): string | undefined;
    private _qualifiedExpressionName?;
    get qualifiedExpressionName(): string;
    set qualifiedExpressionName(value: string);
    get qualifiedExpressionNameInput(): string | undefined;
    private _sqlExpression?;
    get sqlExpression(): string;
    set sqlExpression(value: string);
    get sqlExpressionInput(): string | undefined;
    private _synonym?;
    get synonym(): string[];
    set synonym(value: string[]);
    resetSynonym(): void;
    get synonymInput(): string[] | undefined;
}
export declare class SemanticViewFactsList extends cdktn.ComplexList {
    internalValue?: SemanticViewFacts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SemanticViewFactsOutputReference;
}
export interface SemanticViewMetricsSemanticExpression {
    /**
    * Specifies a comment for the semantic expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#comment SemanticView#comment}
    */
    readonly comment?: string;
    /**
    * Specifies a qualified name for the metric: `<table_alias>.<semantic_expression_name>`. Remember to wrap each part in double quotes like `"\"<table_alias>\".\"<semantic_expression_name>\""`. For the [derived metric](https://docs.snowflake.com/en/user-guide/views-semantic/sql#label-semantic-views-create-derived-metrics) omit the `<table_alias>.` part but still wrap in double quotes, e.g. `"\"<semantic_expression_name>\""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
    */
    readonly qualifiedExpressionName: string;
    /**
    * The SQL expression used to compute the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
    */
    readonly sqlExpression: string;
    /**
    * List of synonyms for this semantic expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#synonym SemanticView#synonym}
    */
    readonly synonym?: string[];
}
export declare function semanticViewMetricsSemanticExpressionToTerraform(struct?: SemanticViewMetricsSemanticExpressionOutputReference | SemanticViewMetricsSemanticExpression): any;
export declare function semanticViewMetricsSemanticExpressionToHclTerraform(struct?: SemanticViewMetricsSemanticExpressionOutputReference | SemanticViewMetricsSemanticExpression): any;
export declare class SemanticViewMetricsSemanticExpressionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SemanticViewMetricsSemanticExpression | undefined;
    set internalValue(value: SemanticViewMetricsSemanticExpression | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _qualifiedExpressionName?;
    get qualifiedExpressionName(): string;
    set qualifiedExpressionName(value: string);
    get qualifiedExpressionNameInput(): string | undefined;
    private _sqlExpression?;
    get sqlExpression(): string;
    set sqlExpression(value: string);
    get sqlExpressionInput(): string | undefined;
    private _synonym?;
    get synonym(): string[];
    set synonym(value: string[]);
    resetSynonym(): void;
    get synonymInput(): string[] | undefined;
}
export interface SemanticViewMetricsWindowFunctionOverClause {
    /**
    * Specifies an order by clause. It must be a complete SQL expression, including any `[ ASC | DESC ] [ NULLS { FIRST | LAST } ]` modifiers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#order_by SemanticView#order_by}
    */
    readonly orderBy?: string;
    /**
    * Specifies a partition by clause.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#partition_by SemanticView#partition_by}
    */
    readonly partitionBy?: string;
    /**
    * Specifies a window frame clause.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#window_frame_clause SemanticView#window_frame_clause}
    */
    readonly windowFrameClause?: string;
}
export declare function semanticViewMetricsWindowFunctionOverClauseToTerraform(struct?: SemanticViewMetricsWindowFunctionOverClauseOutputReference | SemanticViewMetricsWindowFunctionOverClause): any;
export declare function semanticViewMetricsWindowFunctionOverClauseToHclTerraform(struct?: SemanticViewMetricsWindowFunctionOverClauseOutputReference | SemanticViewMetricsWindowFunctionOverClause): any;
export declare class SemanticViewMetricsWindowFunctionOverClauseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SemanticViewMetricsWindowFunctionOverClause | undefined;
    set internalValue(value: SemanticViewMetricsWindowFunctionOverClause | undefined);
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _partitionBy?;
    get partitionBy(): string;
    set partitionBy(value: string);
    resetPartitionBy(): void;
    get partitionByInput(): string | undefined;
    private _windowFrameClause?;
    get windowFrameClause(): string;
    set windowFrameClause(value: string);
    resetWindowFrameClause(): void;
    get windowFrameClauseInput(): string | undefined;
}
export interface SemanticViewMetricsWindowFunction {
    /**
    * Specifies a qualified name for the metric: `<table_alias>.<semantic_expression_name>`. Remember to wrap each part in double quotes like `"\"<table_alias>\".\"<semantic_expression_name>\""`. For the [derived metric](https://docs.snowflake.com/en/user-guide/views-semantic/sql#label-semantic-views-create-derived-metrics) omit the `<table_alias>.` part but still wrap in double quotes, e.g. `"\"<semantic_expression_name>\""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#qualified_expression_name SemanticView#qualified_expression_name}
    */
    readonly qualifiedExpressionName: string;
    /**
    * The SQL expression used to compute the metric following the `<window_function>(<metric>)` format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#sql_expression SemanticView#sql_expression}
    */
    readonly sqlExpression: string;
    /**
    * over_clause block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#over_clause SemanticView#over_clause}
    */
    readonly overClause: SemanticViewMetricsWindowFunctionOverClause;
}
export declare function semanticViewMetricsWindowFunctionToTerraform(struct?: SemanticViewMetricsWindowFunctionOutputReference | SemanticViewMetricsWindowFunction): any;
export declare function semanticViewMetricsWindowFunctionToHclTerraform(struct?: SemanticViewMetricsWindowFunctionOutputReference | SemanticViewMetricsWindowFunction): any;
export declare class SemanticViewMetricsWindowFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SemanticViewMetricsWindowFunction | undefined;
    set internalValue(value: SemanticViewMetricsWindowFunction | undefined);
    private _qualifiedExpressionName?;
    get qualifiedExpressionName(): string;
    set qualifiedExpressionName(value: string);
    get qualifiedExpressionNameInput(): string | undefined;
    private _sqlExpression?;
    get sqlExpression(): string;
    set sqlExpression(value: string);
    get sqlExpressionInput(): string | undefined;
    private _overClause;
    get overClause(): SemanticViewMetricsWindowFunctionOverClauseOutputReference;
    putOverClause(value: SemanticViewMetricsWindowFunctionOverClause): void;
    get overClauseInput(): SemanticViewMetricsWindowFunctionOverClause | undefined;
}
export interface SemanticViewMetrics {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether the metric is private.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#is_private SemanticView#is_private}
    */
    readonly isPrivate?: string;
    /**
    * semantic_expression block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#semantic_expression SemanticView#semantic_expression}
    */
    readonly semanticExpression?: SemanticViewMetricsSemanticExpression;
    /**
    * window_function block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#window_function SemanticView#window_function}
    */
    readonly windowFunction?: SemanticViewMetricsWindowFunction;
}
export declare function semanticViewMetricsToTerraform(struct?: SemanticViewMetrics | cdktn.IResolvable): any;
export declare function semanticViewMetricsToHclTerraform(struct?: SemanticViewMetrics | cdktn.IResolvable): any;
export declare class SemanticViewMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SemanticViewMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: SemanticViewMetrics | cdktn.IResolvable | undefined);
    private _isPrivate?;
    get isPrivate(): string;
    set isPrivate(value: string);
    resetIsPrivate(): void;
    get isPrivateInput(): string | undefined;
    private _semanticExpression;
    get semanticExpression(): SemanticViewMetricsSemanticExpressionOutputReference;
    putSemanticExpression(value: SemanticViewMetricsSemanticExpression): void;
    resetSemanticExpression(): void;
    get semanticExpressionInput(): SemanticViewMetricsSemanticExpression | undefined;
    private _windowFunction;
    get windowFunction(): SemanticViewMetricsWindowFunctionOutputReference;
    putWindowFunction(value: SemanticViewMetricsWindowFunction): void;
    resetWindowFunction(): void;
    get windowFunctionInput(): SemanticViewMetricsWindowFunction | undefined;
}
export declare class SemanticViewMetricsList extends cdktn.ComplexList {
    internalValue?: SemanticViewMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SemanticViewMetricsOutputReference;
}
export interface SemanticViewRelationshipsReferencedTableNameOrAlias {
    /**
    * The alias used for the logical table, cannot be used in combination with the `table_name`. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
    */
    readonly tableAlias?: string;
    /**
    * The name of the logical table, cannot be used in combination with the `table_alias`. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#table_name SemanticView#table_name}
    */
    readonly tableName?: string;
}
export declare function semanticViewRelationshipsReferencedTableNameOrAliasToTerraform(struct?: SemanticViewRelationshipsReferencedTableNameOrAliasOutputReference | SemanticViewRelationshipsReferencedTableNameOrAlias): any;
export declare function semanticViewRelationshipsReferencedTableNameOrAliasToHclTerraform(struct?: SemanticViewRelationshipsReferencedTableNameOrAliasOutputReference | SemanticViewRelationshipsReferencedTableNameOrAlias): any;
export declare class SemanticViewRelationshipsReferencedTableNameOrAliasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SemanticViewRelationshipsReferencedTableNameOrAlias | undefined;
    set internalValue(value: SemanticViewRelationshipsReferencedTableNameOrAlias | undefined);
    private _tableAlias?;
    get tableAlias(): string;
    set tableAlias(value: string);
    resetTableAlias(): void;
    get tableAliasInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    resetTableName(): void;
    get tableNameInput(): string | undefined;
}
export interface SemanticViewRelationshipsTableNameOrAlias {
    /**
    * The alias used for the logical table, cannot be used in combination with the `table_name`. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
    */
    readonly tableAlias?: string;
    /**
    * The name of the logical table, cannot be used in combination with the `table_alias`. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#table_name SemanticView#table_name}
    */
    readonly tableName?: string;
}
export declare function semanticViewRelationshipsTableNameOrAliasToTerraform(struct?: SemanticViewRelationshipsTableNameOrAliasOutputReference | SemanticViewRelationshipsTableNameOrAlias): any;
export declare function semanticViewRelationshipsTableNameOrAliasToHclTerraform(struct?: SemanticViewRelationshipsTableNameOrAliasOutputReference | SemanticViewRelationshipsTableNameOrAlias): any;
export declare class SemanticViewRelationshipsTableNameOrAliasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SemanticViewRelationshipsTableNameOrAlias | undefined;
    set internalValue(value: SemanticViewRelationshipsTableNameOrAlias | undefined);
    private _tableAlias?;
    get tableAlias(): string;
    set tableAlias(value: string);
    resetTableAlias(): void;
    get tableAliasInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    resetTableName(): void;
    get tableNameInput(): string | undefined;
}
export interface SemanticViewRelationships {
    /**
    * Specifies one or more columns in the second logical table that are referred to by the first logical table. Column names in this list are case-sensitive - the provider uses double quotes to wrap each of them when sending the SQL to Snowflake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#referenced_relationship_columns SemanticView#referenced_relationship_columns}
    */
    readonly referencedRelationshipColumns?: string[];
    /**
    * Specifies one or more columns in the first logical table that refers to columns in another logical table. Column names in this list are case-sensitive - the provider uses double quotes to wrap each of them when sending the SQL to Snowflake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#relationship_columns SemanticView#relationship_columns}
    */
    readonly relationshipColumns: string[];
    /**
    * Specifies an optional identifier for the relationship. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#relationship_identifier SemanticView#relationship_identifier}
    */
    readonly relationshipIdentifier?: string;
    /**
    * referenced_table_name_or_alias block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#referenced_table_name_or_alias SemanticView#referenced_table_name_or_alias}
    */
    readonly referencedTableNameOrAlias: SemanticViewRelationshipsReferencedTableNameOrAlias;
    /**
    * table_name_or_alias block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#table_name_or_alias SemanticView#table_name_or_alias}
    */
    readonly tableNameOrAlias: SemanticViewRelationshipsTableNameOrAlias;
}
export declare function semanticViewRelationshipsToTerraform(struct?: SemanticViewRelationships | cdktn.IResolvable): any;
export declare function semanticViewRelationshipsToHclTerraform(struct?: SemanticViewRelationships | cdktn.IResolvable): any;
export declare class SemanticViewRelationshipsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SemanticViewRelationships | cdktn.IResolvable | undefined;
    set internalValue(value: SemanticViewRelationships | cdktn.IResolvable | undefined);
    private _referencedRelationshipColumns?;
    get referencedRelationshipColumns(): string[];
    set referencedRelationshipColumns(value: string[]);
    resetReferencedRelationshipColumns(): void;
    get referencedRelationshipColumnsInput(): string[] | undefined;
    private _relationshipColumns?;
    get relationshipColumns(): string[];
    set relationshipColumns(value: string[]);
    get relationshipColumnsInput(): string[] | undefined;
    private _relationshipIdentifier?;
    get relationshipIdentifier(): string;
    set relationshipIdentifier(value: string);
    resetRelationshipIdentifier(): void;
    get relationshipIdentifierInput(): string | undefined;
    private _referencedTableNameOrAlias;
    get referencedTableNameOrAlias(): SemanticViewRelationshipsReferencedTableNameOrAliasOutputReference;
    putReferencedTableNameOrAlias(value: SemanticViewRelationshipsReferencedTableNameOrAlias): void;
    get referencedTableNameOrAliasInput(): SemanticViewRelationshipsReferencedTableNameOrAlias | undefined;
    private _tableNameOrAlias;
    get tableNameOrAlias(): SemanticViewRelationshipsTableNameOrAliasOutputReference;
    putTableNameOrAlias(value: SemanticViewRelationshipsTableNameOrAlias): void;
    get tableNameOrAliasInput(): SemanticViewRelationshipsTableNameOrAlias | undefined;
}
export declare class SemanticViewRelationshipsList extends cdktn.ComplexList {
    internalValue?: SemanticViewRelationships[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SemanticViewRelationshipsOutputReference;
}
export interface SemanticViewTablesUnique {
    /**
    * Unique key combinations in the logical table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#values SemanticView#values}
    */
    readonly values: string[];
}
export declare function semanticViewTablesUniqueToTerraform(struct?: SemanticViewTablesUnique | cdktn.IResolvable): any;
export declare function semanticViewTablesUniqueToHclTerraform(struct?: SemanticViewTablesUnique | cdktn.IResolvable): any;
export declare class SemanticViewTablesUniqueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SemanticViewTablesUnique | cdktn.IResolvable | undefined;
    set internalValue(value: SemanticViewTablesUnique | cdktn.IResolvable | undefined);
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class SemanticViewTablesUniqueList extends cdktn.ComplexList {
    internalValue?: SemanticViewTablesUnique[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SemanticViewTablesUniqueOutputReference;
}
export interface SemanticViewTables {
    /**
    * Specifies a comment for the logical table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#comment SemanticView#comment}
    */
    readonly comment?: string;
    /**
    * Definitions of primary keys in the logical table. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#primary_key SemanticView#primary_key}
    */
    readonly primaryKey?: string[];
    /**
    * List of synonyms for the logical table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#synonym SemanticView#synonym}
    */
    readonly synonym?: string[];
    /**
    * Specifies an alias for a logical table in the semantic view. This field is case-sensitive - the provider uses double quotes to wrap it when sending the SQL to Snowflake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#table_alias SemanticView#table_alias}
    */
    readonly tableAlias: string;
    /**
    * Specifies an identifier for the logical table. Example: `"\"<db_name>\".\"<schema_name>\".\"<table_name>\""`. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#table_name SemanticView#table_name}
    */
    readonly tableName: string;
    /**
    * unique block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#unique SemanticView#unique}
    */
    readonly unique?: SemanticViewTablesUnique[] | cdktn.IResolvable;
}
export declare function semanticViewTablesToTerraform(struct?: SemanticViewTables | cdktn.IResolvable): any;
export declare function semanticViewTablesToHclTerraform(struct?: SemanticViewTables | cdktn.IResolvable): any;
export declare class SemanticViewTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SemanticViewTables | cdktn.IResolvable | undefined;
    set internalValue(value: SemanticViewTables | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _primaryKey?;
    get primaryKey(): string[];
    set primaryKey(value: string[]);
    resetPrimaryKey(): void;
    get primaryKeyInput(): string[] | undefined;
    private _synonym?;
    get synonym(): string[];
    set synonym(value: string[]);
    resetSynonym(): void;
    get synonymInput(): string[] | undefined;
    private _tableAlias?;
    get tableAlias(): string;
    set tableAlias(value: string);
    get tableAliasInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _unique;
    get unique(): SemanticViewTablesUniqueList;
    putUnique(value: SemanticViewTablesUnique[] | cdktn.IResolvable): void;
    resetUnique(): void;
    get uniqueInput(): cdktn.IResolvable | SemanticViewTablesUnique[] | undefined;
}
export declare class SemanticViewTablesList extends cdktn.ComplexList {
    internalValue?: SemanticViewTables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SemanticViewTablesOutputReference;
}
export interface SemanticViewTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#create SemanticView#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#delete SemanticView#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#read SemanticView#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#update SemanticView#update}
    */
    readonly update?: string;
}
export declare function semanticViewTimeoutsToTerraform(struct?: SemanticViewTimeouts | cdktn.IResolvable): any;
export declare function semanticViewTimeoutsToHclTerraform(struct?: SemanticViewTimeouts | cdktn.IResolvable): any;
export declare class SemanticViewTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SemanticViewTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: SemanticViewTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view snowflake_semantic_view}
*/
export declare class SemanticView extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_semantic_view";
    /**
    * Generates CDKTN code for importing a SemanticView resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SemanticView to import
    * @param importFromId The id of the existing SemanticView that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SemanticView to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/semantic_view snowflake_semantic_view} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SemanticViewConfig
    */
    constructor(scope: Construct, id: string, config: SemanticViewConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): SemanticViewShowOutputList;
    private _dimensions;
    get dimensions(): SemanticViewDimensionsList;
    putDimensions(value: SemanticViewDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | SemanticViewDimensions[] | undefined;
    private _facts;
    get facts(): SemanticViewFactsList;
    putFacts(value: SemanticViewFacts[] | cdktn.IResolvable): void;
    resetFacts(): void;
    get factsInput(): cdktn.IResolvable | SemanticViewFacts[] | undefined;
    private _metrics;
    get metrics(): SemanticViewMetricsList;
    putMetrics(value: SemanticViewMetrics[] | cdktn.IResolvable): void;
    resetMetrics(): void;
    get metricsInput(): cdktn.IResolvable | SemanticViewMetrics[] | undefined;
    private _relationships;
    get relationships(): SemanticViewRelationshipsList;
    putRelationships(value: SemanticViewRelationships[] | cdktn.IResolvable): void;
    resetRelationships(): void;
    get relationshipsInput(): cdktn.IResolvable | SemanticViewRelationships[] | undefined;
    private _tables;
    get tables(): SemanticViewTablesList;
    putTables(value: SemanticViewTables[] | cdktn.IResolvable): void;
    get tablesInput(): cdktn.IResolvable | SemanticViewTables[] | undefined;
    private _timeouts;
    get timeouts(): SemanticViewTimeoutsOutputReference;
    putTimeouts(value: SemanticViewTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | SemanticViewTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
