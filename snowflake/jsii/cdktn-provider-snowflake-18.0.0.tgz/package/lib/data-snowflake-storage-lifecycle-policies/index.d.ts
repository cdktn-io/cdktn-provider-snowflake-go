/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeStorageLifecyclePoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/storage_lifecycle_policies#id DataSnowflakeStorageLifecyclePolicies#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/storage_lifecycle_policies#like DataSnowflakeStorageLifecyclePolicies#like}
    */
    readonly like?: string;
    /**
    * (Default: `true`) Runs DESC STORAGE LIFECYCLE POLICY for each storage lifecycle policy returned by SHOW STORAGE LIFECYCLE POLICIES. The output of describe is saved to the describe_output field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/storage_lifecycle_policies#with_describe DataSnowflakeStorageLifecyclePolicies#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * in block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/storage_lifecycle_policies#in DataSnowflakeStorageLifecyclePolicies#in}
    */
    readonly in?: DataSnowflakeStorageLifecyclePoliciesIn;
}
export interface DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputSignature {
}
export declare function dataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputSignatureToTerraform(struct?: DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputSignature): any;
export declare function dataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputSignatureToHclTerraform(struct?: DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputSignature): any;
export declare class DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputSignatureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputSignature | undefined;
    set internalValue(value: DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputSignature | undefined);
    get name(): string;
    get type(): string;
}
export declare class DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputSignatureList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputSignatureOutputReference;
}
export interface DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutput {
}
export declare function dataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputToTerraform(struct?: DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutput): any;
export declare function dataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputToHclTerraform(struct?: DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutput): any;
export declare class DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutput | undefined);
    get archiveForDays(): number;
    get archiveTier(): string;
    get body(): string;
    get databaseName(): string;
    get name(): string;
    get returnType(): string;
    get schemaName(): string;
    private _signature;
    get signature(): DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputSignatureList;
}
export declare class DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputOutputReference;
}
export interface DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesShowOutput {
}
export declare function dataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesShowOutputToTerraform(struct?: DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesShowOutput): any;
export declare function dataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesShowOutputToHclTerraform(struct?: DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesShowOutput): any;
export declare class DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesShowOutput | undefined;
    set internalValue(value: DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get kind(): string;
    get name(): string;
    get options(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get schemaName(): string;
}
export declare class DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesShowOutputOutputReference;
}
export interface DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePolicies {
}
export declare function dataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesToTerraform(struct?: DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePolicies): any;
export declare function dataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesToHclTerraform(struct?: DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePolicies): any;
export declare class DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePolicies | undefined;
    set internalValue(value: DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePolicies | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesShowOutputList;
}
export declare class DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesOutputReference;
}
export interface DataSnowflakeStorageLifecyclePoliciesIn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/storage_lifecycle_policies#account DataSnowflakeStorageLifecyclePolicies#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the current database in use or for a specified database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/storage_lifecycle_policies#database DataSnowflakeStorageLifecyclePolicies#database}
    */
    readonly database?: string;
    /**
    * Returns records for the current schema in use or a specified schema. Use fully qualified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/storage_lifecycle_policies#schema DataSnowflakeStorageLifecyclePolicies#schema}
    */
    readonly schema?: string;
}
export declare function dataSnowflakeStorageLifecyclePoliciesInToTerraform(struct?: DataSnowflakeStorageLifecyclePoliciesInOutputReference | DataSnowflakeStorageLifecyclePoliciesIn): any;
export declare function dataSnowflakeStorageLifecyclePoliciesInToHclTerraform(struct?: DataSnowflakeStorageLifecyclePoliciesInOutputReference | DataSnowflakeStorageLifecyclePoliciesIn): any;
export declare class DataSnowflakeStorageLifecyclePoliciesInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeStorageLifecyclePoliciesIn | undefined;
    set internalValue(value: DataSnowflakeStorageLifecyclePoliciesIn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/storage_lifecycle_policies snowflake_storage_lifecycle_policies}
*/
export declare class DataSnowflakeStorageLifecyclePolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_storage_lifecycle_policies";
    /**
    * Generates CDKTN code for importing a DataSnowflakeStorageLifecyclePolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeStorageLifecyclePolicies to import
    * @param importFromId The id of the existing DataSnowflakeStorageLifecyclePolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/storage_lifecycle_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeStorageLifecyclePolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/storage_lifecycle_policies snowflake_storage_lifecycle_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeStorageLifecyclePoliciesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeStorageLifecyclePoliciesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _storageLifecyclePolicies;
    get storageLifecyclePolicies(): DataSnowflakeStorageLifecyclePoliciesStorageLifecyclePoliciesList;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _in;
    get in(): DataSnowflakeStorageLifecyclePoliciesInOutputReference;
    putIn(value: DataSnowflakeStorageLifecyclePoliciesIn): void;
    resetIn(): void;
    get inInput(): DataSnowflakeStorageLifecyclePoliciesIn | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
