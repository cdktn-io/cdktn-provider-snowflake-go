/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SnowflakeProviderConfig {
    /**
    * Specifies the Snowflake account identifier. Can be provided in the `org-name` format (e.g. `"myorg-myaccount"`) or as an account locator (e.g. `"xy12345"`). Use as a fallback when `account_name` and `organization_name` are not set. If both `account_name` and `organization_name` are set, they take precedence. Requires the [`PROVIDER_CONFIGURATION_ACCOUNT_FALLBACK`](../#provider_configuration_account_fallback) experiment to be enabled. Can also be sourced from the `SNOWFLAKE_ACCOUNT` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#account SnowflakeProvider#account}
    */
    readonly account?: string;
    /**
    * Specifies your Snowflake account name assigned by Snowflake. For information about account identifiers, see the [Snowflake documentation](https://docs.snowflake.com/en/user-guide/admin-account-identifier#account-name). Required unless using `profile`. Can also be sourced from the `SNOWFLAKE_ACCOUNT_NAME` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#account_name SnowflakeProvider#account_name}
    */
    readonly accountName?: string;
    /**
    * Specifies the [authentication type](https://pkg.go.dev/github.com/snowflakedb/gosnowflake#AuthType) to use when connecting to Snowflake. Valid options are: `SNOWFLAKE` | `OAUTH` | `EXTERNALBROWSER` | `OKTA` | `SNOWFLAKE_JWT` | `TOKENACCESSOR` | `USERNAMEPASSWORDMFA` | `PROGRAMMATIC_ACCESS_TOKEN` | `OAUTH_CLIENT_CREDENTIALS` | `OAUTH_AUTHORIZATION_CODE` | `WORKLOAD_IDENTITY`. Can also be sourced from the `SNOWFLAKE_AUTHENTICATOR` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#authenticator SnowflakeProvider#authenticator}
    */
    readonly authenticator?: string;
    /**
    * Specifies the certificate revocation check mode. Valid options are: `DISABLED` | `ADVISORY` | `ENABLED`. The value is case-insensitive. Can also be sourced from the `SNOWFLAKE_CERT_REVOCATION_CHECK_MODE` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#cert_revocation_check_mode SnowflakeProvider#cert_revocation_check_mode}
    */
    readonly certRevocationCheckMode?: string;
    /**
    * This field is deprecated. It will be removed in the next major release. The driver was accepting this value in the previous versions but it had no impact. Setting this field causes no action on the provider side. Can also be sourced from the `SNOWFLAKE_CLIENT_IP` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#client_ip SnowflakeProvider#client_ip}
    */
    readonly clientIp?: string;
    /**
    * When true the MFA token is cached in the credential manager. True by default in Windows/OSX. False for Linux. Can also be sourced from the `SNOWFLAKE_CLIENT_REQUEST_MFA_TOKEN` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#client_request_mfa_token SnowflakeProvider#client_request_mfa_token}
    */
    readonly clientRequestMfaToken?: string;
    /**
    * When true the ID token is cached in the credential manager. True by default in Windows/OSX. False for Linux. Can also be sourced from the `SNOWFLAKE_CLIENT_STORE_TEMPORARY_CREDENTIAL` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#client_store_temporary_credential SnowflakeProvider#client_store_temporary_credential}
    */
    readonly clientStoreTemporaryCredential?: string;
    /**
    * The timeout in seconds for the client to complete the authentication. Can also be sourced from the `SNOWFLAKE_CLIENT_TIMEOUT` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#client_timeout SnowflakeProvider#client_timeout}
    */
    readonly clientTimeout?: number;
    /**
    * Allow certificates (not short-lived) without CRL DP included to be treated as correct ones. Can also be sourced from the `SNOWFLAKE_CRL_ALLOW_CERTIFICATES_WITHOUT_CRL_URL` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#crl_allow_certificates_without_crl_url SnowflakeProvider#crl_allow_certificates_without_crl_url}
    */
    readonly crlAllowCertificatesWithoutCrlUrl?: string;
    /**
    * Timeout in seconds for HTTP client used to download CRL. Can also be sourced from the `SNOWFLAKE_CRL_HTTP_CLIENT_TIMEOUT` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#crl_http_client_timeout SnowflakeProvider#crl_http_client_timeout}
    */
    readonly crlHttpClientTimeout?: number;
    /**
    * False by default. When set to true, the CRL in-memory cache is disabled. Can also be sourced from the `SNOWFLAKE_CRL_IN_MEMORY_CACHE_DISABLED` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#crl_in_memory_cache_disabled SnowflakeProvider#crl_in_memory_cache_disabled}
    */
    readonly crlInMemoryCacheDisabled?: boolean | cdktn.IResolvable;
    /**
    * False by default. When set to true, the CRL on-disk cache is disabled. Can also be sourced from the `SNOWFLAKE_CRL_ON_DISK_CACHE_DISABLED` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#crl_on_disk_cache_disabled SnowflakeProvider#crl_on_disk_cache_disabled}
    */
    readonly crlOnDiskCacheDisabled?: boolean | cdktn.IResolvable;
    /**
    * Indicates whether console login should be disabled in the driver. Can also be sourced from the `SNOWFLAKE_DISABLE_CONSOLE_LOGIN` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#disable_console_login SnowflakeProvider#disable_console_login}
    */
    readonly disableConsoleLogin?: string;
    /**
    * False by default. When set to true, the driver doesn't check certificate revocation status. Can also be sourced from the `SNOWFLAKE_DISABLE_OCSP_CHECKS` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#disable_ocsp_checks SnowflakeProvider#disable_ocsp_checks}
    */
    readonly disableOcspChecks?: boolean | cdktn.IResolvable;
    /**
    * Disables HTAP query context cache in the driver. Can also be sourced from the `SNOWFLAKE_DISABLE_QUERY_CONTEXT_CACHE` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#disable_query_context_cache SnowflakeProvider#disable_query_context_cache}
    */
    readonly disableQueryContextCache?: boolean | cdktn.IResolvable;
    /**
    * Indicates whether the SAML URL check should be disabled. Can also be sourced from the `SNOWFLAKE_DISABLE_SAML_URL_CHECK` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#disable_saml_url_check SnowflakeProvider#disable_saml_url_check}
    */
    readonly disableSamlUrlCheck?: string;
    /**
    * This field is deprecated. It will be removed in the next major release. Use `params` to set `CLIENT_TELEMETRY_ENABLED` session parameter instead. Setting this field adds `CLIENT_TELEMETRY_ENABLED` with value `false` to `params`. Disables telemetry in the driver. Can also be sourced from the `DISABLE_TELEMETRY` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#disable_telemetry SnowflakeProvider#disable_telemetry}
    */
    readonly disableTelemetry?: boolean | cdktn.IResolvable;
    /**
    * Specifies the logging level to be used by the driver. Valid options are (case-insensitive): `TRACE` | `DEBUG` | `INFO` | `WARN` | `ERROR` | `FATAL` | `OFF`. The following values are deprecated and will be removed in v3: `WARNING` (uses `WARN` instead), `PRINT` (uses `INFO` instead), `PANIC` (uses `FATAL` instead). Can also be sourced from the `SNOWFLAKE_DRIVER_TRACING` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#driver_tracing SnowflakeProvider#driver_tracing}
    */
    readonly driverTracing?: string;
    /**
    * Enables single use refresh tokens for Snowflake IdP. Can also be sourced from the `SNOWFLAKE_ENABLE_SINGLE_USE_REFRESH_TOKENS` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#enable_single_use_refresh_tokens SnowflakeProvider#enable_single_use_refresh_tokens}
    */
    readonly enableSingleUseRefreshTokens?: boolean | cdktn.IResolvable;
    /**
    * A list of experimental features. Similarly to preview features, they are not yet stable features of the provider. Enabling given experiment is still considered a preview feature, even when applied to the stable resource. These switches offer experiments altering the provider behavior. If the given experiment is successful, it can be considered an addition in the future provider versions. This field can not be set with environmental variables. Check more details in the [experimental features section](#experimental-features). Active experiments are: `WAREHOUSE_SHOW_IMPROVED_PERFORMANCE` | `GRANTS_STRICT_PRIVILEGE_MANAGEMENT` | `PARAMETERS_IGNORE_VALUE_CHANGES_IF_NOT_ON_OBJECT_LEVEL` | `PARAMETERS_REDUCED_OUTPUT` | `USER_ENABLE_DEFAULT_WORKLOAD_IDENTITY` | `GRANTS_IMPORT_VALIDATION` | `TAGS_ALLOW_EMPTY_ALLOWED_VALUES` | `IMPORT_BOOLEAN_DEFAULT` | `GRANTS_SAFE_DESTROY` | `TAG_ASSOCIATION_SAFE_DESTROY` | `GRANT_ACCOUNT_ROLE_SHOW_CACHING` | `GRANT_ACCOUNT_ROLE_SAFE_PUBLIC_ROLE` | `HIERARCHY_RENAMES` | `INHERITED_GRANTS` | `OBJECT_PARAMETER_UNSET_ON_DELETE` | `AUTHENTICATOR_EXPLICIT_ONLY` | `PROVIDER_CONFIGURATION_ACCOUNT_FALLBACK`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#experimental_features_enabled SnowflakeProvider#experimental_features_enabled}
    */
    readonly experimentalFeaturesEnabled?: string[];
    /**
    * The timeout in seconds for the external browser to complete the authentication. Can also be sourced from the `SNOWFLAKE_EXTERNAL_BROWSER_TIMEOUT` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#external_browser_timeout SnowflakeProvider#external_browser_timeout}
    */
    readonly externalBrowserTimeout?: number;
    /**
    * Specifies a custom host value used by the driver for privatelink connections. Can also be sourced from the `SNOWFLAKE_HOST` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#host SnowflakeProvider#host}
    */
    readonly host?: string;
    /**
    * Should retried request contain retry reason. Can also be sourced from the `SNOWFLAKE_INCLUDE_RETRY_REASON` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#include_retry_reason SnowflakeProvider#include_retry_reason}
    */
    readonly includeRetryReason?: string;
    /**
    * This field is deprecated. It will be removed in the next major release. Use `disable_ocsp_checks` instead. Setting this field sets `disable_ocsp_checks` in the underlying driver. If true, bypass the Online Certificate Status Protocol (OCSP) certificate revocation check. IMPORTANT: Change the default value for testing or emergency situations only. Can also be sourced from the `SNOWFLAKE_INSECURE_MODE` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#insecure_mode SnowflakeProvider#insecure_mode}
    */
    readonly insecureMode?: boolean | cdktn.IResolvable;
    /**
    * The timeout in seconds for the JWT client to complete the authentication. Can also be sourced from the `SNOWFLAKE_JWT_CLIENT_TIMEOUT` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#jwt_client_timeout SnowflakeProvider#jwt_client_timeout}
    */
    readonly jwtClientTimeout?: number;
    /**
    * JWT expire after timeout in seconds. Can also be sourced from the `SNOWFLAKE_JWT_EXPIRE_TIMEOUT` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#jwt_expire_timeout SnowflakeProvider#jwt_expire_timeout}
    */
    readonly jwtExpireTimeout?: number;
    /**
    * Enables the session to persist even after the connection is closed. Can also be sourced from the `SNOWFLAKE_KEEP_SESSION_ALIVE` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#keep_session_alive SnowflakeProvider#keep_session_alive}
    */
    readonly keepSessionAlive?: boolean | cdktn.IResolvable;
    /**
    * When set to true, the parameters will be logged. Requires logQueryText to be enabled first. Be aware that it may include sensitive information. Default value is false. Can also be sourced from the `SNOWFLAKE_LOG_QUERY_PARAMETERS` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#log_query_parameters SnowflakeProvider#log_query_parameters}
    */
    readonly logQueryParameters?: boolean | cdktn.IResolvable;
    /**
    * When set to true, the full query text will be logged. Be aware that it may include sensitive information. Default value is false. Can also be sourced from the `SNOWFLAKE_LOG_QUERY_TEXT` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#log_query_text SnowflakeProvider#log_query_text}
    */
    readonly logQueryText?: boolean | cdktn.IResolvable;
    /**
    * Login retry timeout in seconds EXCLUDING network roundtrip and read out http response. Can also be sourced from the `SNOWFLAKE_LOGIN_TIMEOUT` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#login_timeout SnowflakeProvider#login_timeout}
    */
    readonly loginTimeout?: number;
    /**
    * Specifies how many times non-periodic HTTP request can be retried by the driver. Can also be sourced from the `SNOWFLAKE_MAX_RETRY_COUNT` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#max_retry_count SnowflakeProvider#max_retry_count}
    */
    readonly maxRetryCount?: number;
    /**
    * A comma-separated list of hostnames, domains, and IP addresses to exclude from proxying. See more in [the proxy section below](#proxy). Can also be sourced from the `SNOWFLAKE_NO_PROXY` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#no_proxy SnowflakeProvider#no_proxy}
    */
    readonly noProxy?: string;
    /**
    * Authorization URL of OAuth2 external IdP. See [Snowflake OAuth documentation](https://docs.snowflake.com/en/user-guide/oauth). Can also be sourced from the `SNOWFLAKE_OAUTH_AUTHORIZATION_URL` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#oauth_authorization_url SnowflakeProvider#oauth_authorization_url}
    */
    readonly oauthAuthorizationUrl?: string;
    /**
    * Client id for OAuth2 external IdP. See [Snowflake OAuth documentation](https://docs.snowflake.com/en/user-guide/oauth). Can also be sourced from the `SNOWFLAKE_OAUTH_CLIENT_ID` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#oauth_client_id SnowflakeProvider#oauth_client_id}
    */
    readonly oauthClientId?: string;
    /**
    * Client secret for OAuth2 external IdP. See [Snowflake OAuth documentation](https://docs.snowflake.com/en/user-guide/oauth). Can also be sourced from the `SNOWFLAKE_OAUTH_CLIENT_SECRET` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#oauth_client_secret SnowflakeProvider#oauth_client_secret}
    */
    readonly oauthClientSecret?: string;
    /**
    * Redirect URI registered in IdP. See [Snowflake OAuth documentation](https://docs.snowflake.com/en/user-guide/oauth). Can also be sourced from the `SNOWFLAKE_OAUTH_REDIRECT_URI` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#oauth_redirect_uri SnowflakeProvider#oauth_redirect_uri}
    */
    readonly oauthRedirectUri?: string;
    /**
    * Comma separated list of scopes. If empty it is derived from role. See [Snowflake OAuth documentation](https://docs.snowflake.com/en/user-guide/oauth). Can also be sourced from the `SNOWFLAKE_OAUTH_SCOPE` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#oauth_scope SnowflakeProvider#oauth_scope}
    */
    readonly oauthScope?: string;
    /**
    * Token request URL of OAuth2 external IdP. See [Snowflake OAuth documentation](https://docs.snowflake.com/en/user-guide/oauth). Can also be sourced from the `SNOWFLAKE_OAUTH_TOKEN_REQUEST_URL` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#oauth_token_request_url SnowflakeProvider#oauth_token_request_url}
    */
    readonly oauthTokenRequestUrl?: string;
    /**
    * True represents OCSP fail open mode. False represents OCSP fail closed mode. Fail open true by default. Can also be sourced from the `SNOWFLAKE_OCSP_FAIL_OPEN` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#ocsp_fail_open SnowflakeProvider#ocsp_fail_open}
    */
    readonly ocspFailOpen?: string;
    /**
    * The URL of the Okta server. e.g. https://example.okta.com. Okta URL host needs to to have a suffix `okta.com`. Read more in Snowflake [docs](https://docs.snowflake.com/en/user-guide/oauth-okta). Can also be sourced from the `SNOWFLAKE_OKTA_URL` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#okta_url SnowflakeProvider#okta_url}
    */
    readonly oktaUrl?: string;
    /**
    * Specifies your Snowflake organization name assigned by Snowflake. For information about account identifiers, see the [Snowflake documentation](https://docs.snowflake.com/en/user-guide/admin-account-identifier#organization-name). Required unless using `profile`. Can also be sourced from the `SNOWFLAKE_ORGANIZATION_NAME` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#organization_name SnowflakeProvider#organization_name}
    */
    readonly organizationName?: string;
    /**
    * Sets other connection (i.e. session) parameters. [Parameters](https://docs.snowflake.com/en/sql-reference/parameters). This field can not be set with environmental variables.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#params SnowflakeProvider#params}
    */
    readonly params?: {
        [key: string]: string;
    };
    /**
    * Specifies the passcode provided by Duo when using multi-factor authentication (MFA) for login. Can also be sourced from the `SNOWFLAKE_PASSCODE` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#passcode SnowflakeProvider#passcode}
    */
    readonly passcode?: string;
    /**
    * False by default. Set to true if the MFA passcode is embedded to the configured password. Can also be sourced from the `SNOWFLAKE_PASSCODE_IN_PASSWORD` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#passcode_in_password SnowflakeProvider#passcode_in_password}
    */
    readonly passcodeInPassword?: boolean | cdktn.IResolvable;
    /**
    * Password for user + password or [token](https://docs.snowflake.com/en/user-guide/programmatic-access-tokens#generating-a-programmatic-access-token) for [PAT auth](https://docs.snowflake.com/en/user-guide/programmatic-access-tokens). Cannot be used with `private_key` and `private_key_passphrase`. Can also be sourced from the `SNOWFLAKE_PASSWORD` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#password SnowflakeProvider#password}
    */
    readonly password?: string;
    /**
    * Specifies a custom port value used by the driver for privatelink connections. Can also be sourced from the `SNOWFLAKE_PORT` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#port SnowflakeProvider#port}
    */
    readonly port?: number;
    /**
    * A list of preview features that are handled by the provider. See [preview features list](https://github.com/Snowflake-Labs/terraform-provider-snowflake/blob/main/v1-preparations/LIST_OF_PREVIEW_FEATURES_FOR_V1.md). Preview features may have breaking changes in future releases, even without raising the major version. This field can not be set with environmental variables. Preview features that can be enabled are: `snowflake_account_authentication_policy_attachment_resource` | `snowflake_account_password_policy_attachment_resource` | `snowflake_alert_resource` | `snowflake_alerts_datasource` | `snowflake_api_integrations_datasource` | `snowflake_api_integration_resource` | `snowflake_api_integration_amazon_api_gateway_resource` | `snowflake_api_integration_azure_api_management_resource` | `snowflake_api_integration_external_mcp_dynamic_client_resource` | `snowflake_api_integration_external_mcp_oauth2_resource` | `snowflake_api_integration_git_repository_github_app_resource` | `snowflake_api_integration_git_repository_oauth2_resource` | `snowflake_api_integration_git_repository_private_link_resource` | `snowflake_api_integration_git_repository_token_resource` | `snowflake_api_integration_google_cloud_api_gateway_resource` | `snowflake_cortex_agent_resource` | `snowflake_cortex_agents_datasource` | `snowflake_cortex_search_service_resource` | `snowflake_cortex_search_services_datasource` | `snowflake_current_account_datasource` | `snowflake_database_datasource` | `snowflake_database_role_datasource` | `snowflake_dynamic_table_resource` | `snowflake_dynamic_tables_datasource` | `snowflake_external_function_resource` | `snowflake_external_functions_datasource` | `snowflake_external_table_resource` | `snowflake_external_tables_datasource` | `snowflake_failover_group_resource` | `snowflake_failover_groups_datasource` | `snowflake_file_format_resource` | `snowflake_file_format_avro_resource` | `snowflake_file_format_csv_resource` | `snowflake_file_format_json_resource` | `snowflake_file_format_orc_resource` | `snowflake_file_format_parquet_resource` | `snowflake_file_format_xml_resource` | `snowflake_file_formats_datasource` | `snowflake_function_java_resource` | `snowflake_function_javascript_resource` | `snowflake_function_python_resource` | `snowflake_function_scala_resource` | `snowflake_function_sql_resource` | `snowflake_functions_datasource` | `snowflake_iceberg_table_resource` | `snowflake_iceberg_table_from_aws_glue_resource` | `snowflake_iceberg_table_from_delta_files_resource` | `snowflake_iceberg_table_from_files_resource` | `snowflake_iceberg_table_from_rest_resource` | `snowflake_iceberg_tables_datasource` | `snowflake_job_service_resource` | `snowflake_listings_datasource` | `snowflake_managed_account_resource` | `snowflake_materialized_view_resource` | `snowflake_materialized_views_datasource` | `snowflake_mcp_server_resource` | `snowflake_mcp_servers_datasource` | `snowflake_network_policy_attachment_resource` | `snowflake_notebook_resource` | `snowflake_notebooks_datasource` | `snowflake_email_notification_integration_resource` | `snowflake_notification_integration_resource` | `snowflake_object_parameter_resource` | `snowflake_pipe_resource` | `snowflake_pipes_datasource` | `snowflake_postgres_instance_resource` | `snowflake_current_role_datasource` | `snowflake_semantic_view_resource` | `snowflake_semantic_views_datasource` | `snowflake_sequence_resource` | `snowflake_sequences_datasource` | `snowflake_share_resource` | `snowflake_shares_datasource` | `snowflake_parameters_datasource` | `snowflake_procedure_java_resource` | `snowflake_procedure_javascript_resource` | `snowflake_procedure_python_resource` | `snowflake_procedure_scala_resource` | `snowflake_procedure_sql_resource` | `snowflake_procedures_datasource` | `snowflake_stage_resource` | `snowflake_stages_datasource` | `snowflake_storage_integration_resource` | `snowflake_storage_lifecycle_policy_resource` | `snowflake_storage_lifecycle_policies_datasource` | `snowflake_system_generate_scim_access_token_datasource` | `snowflake_system_get_aws_sns_iam_policy_datasource` | `snowflake_system_get_privatelink_config_datasource` | `snowflake_system_get_snowflake_platform_info_datasource` | `snowflake_table_column_masking_policy_application_resource` | `snowflake_table_constraint_resource` | `snowflake_table_storage_lifecycle_policy_attachment_resource` | `snowflake_table_resource` | `snowflake_tables_datasource` | `snowflake_user_authentication_policy_attachment_resource` | `snowflake_user_password_policy_attachment_resource` | `snowflake_user_public_keys_resource` | `snowflake_warehouse_adaptive_resource` | `snowflake_warehouse_interactive_resource`. Promoted features that are stable and are enabled by default are: `snowflake_account_session_policy_attachment_resource` | `snowflake_authentication_policy_resource` | `snowflake_authentication_policies_datasource` | `snowflake_catalog_integration_aws_glue_resource` | `snowflake_catalog_integration_object_storage_resource` | `snowflake_catalog_integration_open_catalog_resource` | `snowflake_catalog_integration_iceberg_rest_resource` | `snowflake_catalog_integrations_datasource` | `snowflake_compute_pool_resource` | `snowflake_compute_pools_datasource` | `snowflake_current_account_resource` | `snowflake_current_organization_account_resource` | `snowflake_stage_external_azure_resource` | `snowflake_stage_external_gcs_resource` | `snowflake_stage_external_s3_resource` | `snowflake_stage_external_s3_compatible_resource` | `snowflake_external_volume_resource` | `snowflake_external_volumes_datasource` | `snowflake_git_repository_resource` | `snowflake_git_repositories_datasource` | `snowflake_image_repository_resource` | `snowflake_image_repositories_datasource` | `snowflake_stage_internal_resource` | `snowflake_listing_resource` | `snowflake_network_rule_resource` | `snowflake_network_rules_datasource` | `snowflake_password_policies_datasource` | `snowflake_password_policy_resource` | `snowflake_service_resource` | `snowflake_services_datasource` | `snowflake_session_policies_datasource` | `snowflake_session_policy_resource` | `snowflake_storage_integration_aws_resource` | `snowflake_storage_integration_azure_resource` | `snowflake_storage_integration_gcs_resource` | `snowflake_storage_integrations_datasource` | `snowflake_user_programmatic_access_token_resource` | `snowflake_user_programmatic_access_tokens_datasource` | `snowflake_user_session_policy_attachment_resource`. Promoted features can be safely removed from this field. They will be removed in the next major version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#preview_features_enabled SnowflakeProvider#preview_features_enabled}
    */
    readonly previewFeaturesEnabled?: string[];
    /**
    * Private Key for username+private-key auth. Cannot be used with `password`. Can also be sourced from the `SNOWFLAKE_PRIVATE_KEY` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#private_key SnowflakeProvider#private_key}
    */
    readonly privateKey?: string;
    /**
    * Supports the encryption ciphers aes-128-cbc, aes-128-gcm, aes-192-cbc, aes-192-gcm, aes-256-cbc, aes-256-gcm, and des-ede3-cbc. Can also be sourced from the `SNOWFLAKE_PRIVATE_KEY_PASSPHRASE` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#private_key_passphrase SnowflakeProvider#private_key_passphrase}
    */
    readonly privateKeyPassphrase?: string;
    /**
    * Sets the profile to read from ~/.snowflake/config file. Can also be sourced from the `SNOWFLAKE_PROFILE` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#profile SnowflakeProvider#profile}
    */
    readonly profile?: string;
    /**
    * A protocol used in the connection. Valid options are: `http` | `https`. Can also be sourced from the `SNOWFLAKE_PROTOCOL` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#protocol SnowflakeProvider#protocol}
    */
    readonly protocol?: string;
    /**
    * The host of the proxy to use for the connection. See more in [the proxy section below](#proxy). Can also be sourced from the `SNOWFLAKE_PROXY_HOST` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#proxy_host SnowflakeProvider#proxy_host}
    */
    readonly proxyHost?: string;
    /**
    * The password of the proxy to use for the connection. See more in [the proxy section below](#proxy). Can also be sourced from the `SNOWFLAKE_PROXY_PASSWORD` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#proxy_password SnowflakeProvider#proxy_password}
    */
    readonly proxyPassword?: string;
    /**
    * The port of the proxy to use for the connection. See more in [the proxy section below](#proxy). Can also be sourced from the `SNOWFLAKE_PROXY_PORT` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#proxy_port SnowflakeProvider#proxy_port}
    */
    readonly proxyPort?: number;
    /**
    * The protocol of the proxy to use for the connection. Valid options are: `http` | `https`. The value is case-insensitive. See more in [the proxy section below](#proxy). Can also be sourced from the `SNOWFLAKE_PROXY_PROTOCOL` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#proxy_protocol SnowflakeProvider#proxy_protocol}
    */
    readonly proxyProtocol?: string;
    /**
    * The user of the proxy to use for the connection. See more in [the proxy section below](#proxy). Can also be sourced from the `SNOWFLAKE_PROXY_USER` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#proxy_user SnowflakeProvider#proxy_user}
    */
    readonly proxyUser?: string;
    /**
    * request retry timeout in seconds EXCLUDING network roundtrip and read out http response. Can also be sourced from the `SNOWFLAKE_REQUEST_TIMEOUT` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#request_timeout SnowflakeProvider#request_timeout}
    */
    readonly requestTimeout?: number;
    /**
    * Specifies the role to use by default for accessing Snowflake objects in the client session. Can also be sourced from the `SNOWFLAKE_ROLE` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#role SnowflakeProvider#role}
    */
    readonly role?: string;
    /**
    * This field is deprecated. It will be removed in the next major release. False by default. Skips TOML configuration file permission verification. This flag has no effect on Windows systems, as the permissions are not checked on this platform. Instead of skipping the permissions verification, we recommend setting the proper privileges - see [the section below](#toml-file-limitations). Can also be sourced from the `SNOWFLAKE_SKIP_TOML_FILE_PERMISSION_VERIFICATION` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#skip_toml_file_permission_verification SnowflakeProvider#skip_toml_file_permission_verification}
    */
    readonly skipTomlFilePermissionVerification?: boolean | cdktn.IResolvable;
    /**
    * Sets temporary directory used by the driver for operations like encrypting, compressing etc. Can also be sourced from the `SNOWFLAKE_TMP_DIRECTORY_PATH` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#tmp_directory_path SnowflakeProvider#tmp_directory_path}
    */
    readonly tmpDirectoryPath?: string;
    /**
    * Token to use for OAuth and other forms of token based auth. When this field is set here, or in the TOML file, the provider sets the `authenticator` to `OAUTH`. Optionally, set the `authenticator` field to the authenticator you want to use. Can also be sourced from the `SNOWFLAKE_TOKEN` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#token SnowflakeProvider#token}
    */
    readonly token?: string;
    /**
    * False by default. When this is set to true, the provider expects the legacy TOML format. Otherwise, it expects the new format. See more in [the section below](#examples) Can also be sourced from the `SNOWFLAKE_USE_LEGACY_TOML_FILE` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#use_legacy_toml_file SnowflakeProvider#use_legacy_toml_file}
    */
    readonly useLegacyTomlFile?: boolean | cdktn.IResolvable;
    /**
    * Username. Required unless using `profile`. Can also be sourced from the `SNOWFLAKE_USER` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#user SnowflakeProvider#user}
    */
    readonly user?: string;
    /**
    * True by default. If false, disables the validation checks for Database, Schema, Warehouse and Role at the time a connection is established. Can also be sourced from the `SNOWFLAKE_VALIDATE_DEFAULT_PARAMETERS` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#validate_default_parameters SnowflakeProvider#validate_default_parameters}
    */
    readonly validateDefaultParameters?: string;
    /**
    * Specifies the virtual warehouse to use by default for queries, loading, etc. in the client session. Can also be sourced from the `SNOWFLAKE_WAREHOUSE` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#warehouse SnowflakeProvider#warehouse}
    */
    readonly warehouse?: string;
    /**
    * The resource to use for WIF authentication on Azure environment. Can also be sourced from the `SNOWFLAKE_WORKLOAD_IDENTITY_ENTRA_RESOURCE` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#workload_identity_entra_resource SnowflakeProvider#workload_identity_entra_resource}
    */
    readonly workloadIdentityEntraResource?: string;
    /**
    * The workload identity provider to use for WIF authentication. Can also be sourced from the `SNOWFLAKE_WORKLOAD_IDENTITY_PROVIDER` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#workload_identity_provider SnowflakeProvider#workload_identity_provider}
    */
    readonly workloadIdentityProvider?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#alias SnowflakeProvider#alias}
    */
    readonly alias?: string;
    /**
    * token_accessor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#token_accessor SnowflakeProvider#token_accessor}
    */
    readonly tokenAccessor?: SnowflakeProviderTokenAccessor;
}
export interface SnowflakeProviderTokenAccessor {
    /**
    * The client ID for the OAuth provider when using a refresh token to renew access token. Can also be sourced from the `SNOWFLAKE_TOKEN_ACCESSOR_CLIENT_ID` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#client_id SnowflakeProvider#client_id}
    */
    readonly clientId: string;
    /**
    * The client secret for the OAuth provider when using a refresh token to renew access token. Can also be sourced from the `SNOWFLAKE_TOKEN_ACCESSOR_CLIENT_SECRET` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#client_secret SnowflakeProvider#client_secret}
    */
    readonly clientSecret: string;
    /**
    * The redirect URI for the OAuth provider when using a refresh token to renew access token. Can also be sourced from the `SNOWFLAKE_TOKEN_ACCESSOR_REDIRECT_URI` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#redirect_uri SnowflakeProvider#redirect_uri}
    */
    readonly redirectUri: string;
    /**
    * The refresh token for the OAuth provider when using a refresh token to renew access token. Can also be sourced from the `SNOWFLAKE_TOKEN_ACCESSOR_REFRESH_TOKEN` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#refresh_token SnowflakeProvider#refresh_token}
    */
    readonly refreshToken: string;
    /**
    * The token endpoint for the OAuth provider e.g. https://{yourDomain}/oauth/token when using a refresh token to renew access token. Can also be sourced from the `SNOWFLAKE_TOKEN_ACCESSOR_TOKEN_ENDPOINT` environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#token_endpoint SnowflakeProvider#token_endpoint}
    */
    readonly tokenEndpoint: string;
}
export declare function snowflakeProviderTokenAccessorToTerraform(struct?: SnowflakeProviderTokenAccessor): any;
export declare function snowflakeProviderTokenAccessorToHclTerraform(struct?: SnowflakeProviderTokenAccessor): any;
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs snowflake}
*/
export declare class SnowflakeProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "snowflake";
    /**
    * Generates CDKTN code for importing a SnowflakeProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SnowflakeProvider to import
    * @param importFromId The id of the existing SnowflakeProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SnowflakeProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs snowflake} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SnowflakeProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: SnowflakeProviderConfig);
    private _account?;
    get account(): string | undefined;
    set account(value: string | undefined);
    resetAccount(): void;
    get accountInput(): string | undefined;
    private _accountName?;
    get accountName(): string | undefined;
    set accountName(value: string | undefined);
    resetAccountName(): void;
    get accountNameInput(): string | undefined;
    private _authenticator?;
    get authenticator(): string | undefined;
    set authenticator(value: string | undefined);
    resetAuthenticator(): void;
    get authenticatorInput(): string | undefined;
    private _certRevocationCheckMode?;
    get certRevocationCheckMode(): string | undefined;
    set certRevocationCheckMode(value: string | undefined);
    resetCertRevocationCheckMode(): void;
    get certRevocationCheckModeInput(): string | undefined;
    private _clientIp?;
    get clientIp(): string | undefined;
    set clientIp(value: string | undefined);
    resetClientIp(): void;
    get clientIpInput(): string | undefined;
    private _clientRequestMfaToken?;
    get clientRequestMfaToken(): string | undefined;
    set clientRequestMfaToken(value: string | undefined);
    resetClientRequestMfaToken(): void;
    get clientRequestMfaTokenInput(): string | undefined;
    private _clientStoreTemporaryCredential?;
    get clientStoreTemporaryCredential(): string | undefined;
    set clientStoreTemporaryCredential(value: string | undefined);
    resetClientStoreTemporaryCredential(): void;
    get clientStoreTemporaryCredentialInput(): string | undefined;
    private _clientTimeout?;
    get clientTimeout(): number | undefined;
    set clientTimeout(value: number | undefined);
    resetClientTimeout(): void;
    get clientTimeoutInput(): number | undefined;
    private _crlAllowCertificatesWithoutCrlUrl?;
    get crlAllowCertificatesWithoutCrlUrl(): string | undefined;
    set crlAllowCertificatesWithoutCrlUrl(value: string | undefined);
    resetCrlAllowCertificatesWithoutCrlUrl(): void;
    get crlAllowCertificatesWithoutCrlUrlInput(): string | undefined;
    private _crlHttpClientTimeout?;
    get crlHttpClientTimeout(): number | undefined;
    set crlHttpClientTimeout(value: number | undefined);
    resetCrlHttpClientTimeout(): void;
    get crlHttpClientTimeoutInput(): number | undefined;
    private _crlInMemoryCacheDisabled?;
    get crlInMemoryCacheDisabled(): boolean | cdktn.IResolvable | undefined;
    set crlInMemoryCacheDisabled(value: boolean | cdktn.IResolvable | undefined);
    resetCrlInMemoryCacheDisabled(): void;
    get crlInMemoryCacheDisabledInput(): boolean | cdktn.IResolvable | undefined;
    private _crlOnDiskCacheDisabled?;
    get crlOnDiskCacheDisabled(): boolean | cdktn.IResolvable | undefined;
    set crlOnDiskCacheDisabled(value: boolean | cdktn.IResolvable | undefined);
    resetCrlOnDiskCacheDisabled(): void;
    get crlOnDiskCacheDisabledInput(): boolean | cdktn.IResolvable | undefined;
    private _disableConsoleLogin?;
    get disableConsoleLogin(): string | undefined;
    set disableConsoleLogin(value: string | undefined);
    resetDisableConsoleLogin(): void;
    get disableConsoleLoginInput(): string | undefined;
    private _disableOcspChecks?;
    get disableOcspChecks(): boolean | cdktn.IResolvable | undefined;
    set disableOcspChecks(value: boolean | cdktn.IResolvable | undefined);
    resetDisableOcspChecks(): void;
    get disableOcspChecksInput(): boolean | cdktn.IResolvable | undefined;
    private _disableQueryContextCache?;
    get disableQueryContextCache(): boolean | cdktn.IResolvable | undefined;
    set disableQueryContextCache(value: boolean | cdktn.IResolvable | undefined);
    resetDisableQueryContextCache(): void;
    get disableQueryContextCacheInput(): boolean | cdktn.IResolvable | undefined;
    private _disableSamlUrlCheck?;
    get disableSamlUrlCheck(): string | undefined;
    set disableSamlUrlCheck(value: string | undefined);
    resetDisableSamlUrlCheck(): void;
    get disableSamlUrlCheckInput(): string | undefined;
    private _disableTelemetry?;
    get disableTelemetry(): boolean | cdktn.IResolvable | undefined;
    set disableTelemetry(value: boolean | cdktn.IResolvable | undefined);
    resetDisableTelemetry(): void;
    get disableTelemetryInput(): boolean | cdktn.IResolvable | undefined;
    private _driverTracing?;
    get driverTracing(): string | undefined;
    set driverTracing(value: string | undefined);
    resetDriverTracing(): void;
    get driverTracingInput(): string | undefined;
    private _enableSingleUseRefreshTokens?;
    get enableSingleUseRefreshTokens(): boolean | cdktn.IResolvable | undefined;
    set enableSingleUseRefreshTokens(value: boolean | cdktn.IResolvable | undefined);
    resetEnableSingleUseRefreshTokens(): void;
    get enableSingleUseRefreshTokensInput(): boolean | cdktn.IResolvable | undefined;
    private _experimentalFeaturesEnabled?;
    get experimentalFeaturesEnabled(): string[] | undefined;
    set experimentalFeaturesEnabled(value: string[] | undefined);
    resetExperimentalFeaturesEnabled(): void;
    get experimentalFeaturesEnabledInput(): string[] | undefined;
    private _externalBrowserTimeout?;
    get externalBrowserTimeout(): number | undefined;
    set externalBrowserTimeout(value: number | undefined);
    resetExternalBrowserTimeout(): void;
    get externalBrowserTimeoutInput(): number | undefined;
    private _host?;
    get host(): string | undefined;
    set host(value: string | undefined);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _includeRetryReason?;
    get includeRetryReason(): string | undefined;
    set includeRetryReason(value: string | undefined);
    resetIncludeRetryReason(): void;
    get includeRetryReasonInput(): string | undefined;
    private _insecureMode?;
    get insecureMode(): boolean | cdktn.IResolvable | undefined;
    set insecureMode(value: boolean | cdktn.IResolvable | undefined);
    resetInsecureMode(): void;
    get insecureModeInput(): boolean | cdktn.IResolvable | undefined;
    private _jwtClientTimeout?;
    get jwtClientTimeout(): number | undefined;
    set jwtClientTimeout(value: number | undefined);
    resetJwtClientTimeout(): void;
    get jwtClientTimeoutInput(): number | undefined;
    private _jwtExpireTimeout?;
    get jwtExpireTimeout(): number | undefined;
    set jwtExpireTimeout(value: number | undefined);
    resetJwtExpireTimeout(): void;
    get jwtExpireTimeoutInput(): number | undefined;
    private _keepSessionAlive?;
    get keepSessionAlive(): boolean | cdktn.IResolvable | undefined;
    set keepSessionAlive(value: boolean | cdktn.IResolvable | undefined);
    resetKeepSessionAlive(): void;
    get keepSessionAliveInput(): boolean | cdktn.IResolvable | undefined;
    private _logQueryParameters?;
    get logQueryParameters(): boolean | cdktn.IResolvable | undefined;
    set logQueryParameters(value: boolean | cdktn.IResolvable | undefined);
    resetLogQueryParameters(): void;
    get logQueryParametersInput(): boolean | cdktn.IResolvable | undefined;
    private _logQueryText?;
    get logQueryText(): boolean | cdktn.IResolvable | undefined;
    set logQueryText(value: boolean | cdktn.IResolvable | undefined);
    resetLogQueryText(): void;
    get logQueryTextInput(): boolean | cdktn.IResolvable | undefined;
    private _loginTimeout?;
    get loginTimeout(): number | undefined;
    set loginTimeout(value: number | undefined);
    resetLoginTimeout(): void;
    get loginTimeoutInput(): number | undefined;
    private _maxRetryCount?;
    get maxRetryCount(): number | undefined;
    set maxRetryCount(value: number | undefined);
    resetMaxRetryCount(): void;
    get maxRetryCountInput(): number | undefined;
    private _noProxy?;
    get noProxy(): string | undefined;
    set noProxy(value: string | undefined);
    resetNoProxy(): void;
    get noProxyInput(): string | undefined;
    private _oauthAuthorizationUrl?;
    get oauthAuthorizationUrl(): string | undefined;
    set oauthAuthorizationUrl(value: string | undefined);
    resetOauthAuthorizationUrl(): void;
    get oauthAuthorizationUrlInput(): string | undefined;
    private _oauthClientId?;
    get oauthClientId(): string | undefined;
    set oauthClientId(value: string | undefined);
    resetOauthClientId(): void;
    get oauthClientIdInput(): string | undefined;
    private _oauthClientSecret?;
    get oauthClientSecret(): string | undefined;
    set oauthClientSecret(value: string | undefined);
    resetOauthClientSecret(): void;
    get oauthClientSecretInput(): string | undefined;
    private _oauthRedirectUri?;
    get oauthRedirectUri(): string | undefined;
    set oauthRedirectUri(value: string | undefined);
    resetOauthRedirectUri(): void;
    get oauthRedirectUriInput(): string | undefined;
    private _oauthScope?;
    get oauthScope(): string | undefined;
    set oauthScope(value: string | undefined);
    resetOauthScope(): void;
    get oauthScopeInput(): string | undefined;
    private _oauthTokenRequestUrl?;
    get oauthTokenRequestUrl(): string | undefined;
    set oauthTokenRequestUrl(value: string | undefined);
    resetOauthTokenRequestUrl(): void;
    get oauthTokenRequestUrlInput(): string | undefined;
    private _ocspFailOpen?;
    get ocspFailOpen(): string | undefined;
    set ocspFailOpen(value: string | undefined);
    resetOcspFailOpen(): void;
    get ocspFailOpenInput(): string | undefined;
    private _oktaUrl?;
    get oktaUrl(): string | undefined;
    set oktaUrl(value: string | undefined);
    resetOktaUrl(): void;
    get oktaUrlInput(): string | undefined;
    private _organizationName?;
    get organizationName(): string | undefined;
    set organizationName(value: string | undefined);
    resetOrganizationName(): void;
    get organizationNameInput(): string | undefined;
    private _params?;
    get params(): {
        [key: string]: string;
    } | undefined;
    set params(value: {
        [key: string]: string;
    } | undefined);
    resetParams(): void;
    get paramsInput(): {
        [key: string]: string;
    } | undefined;
    private _passcode?;
    get passcode(): string | undefined;
    set passcode(value: string | undefined);
    resetPasscode(): void;
    get passcodeInput(): string | undefined;
    private _passcodeInPassword?;
    get passcodeInPassword(): boolean | cdktn.IResolvable | undefined;
    set passcodeInPassword(value: boolean | cdktn.IResolvable | undefined);
    resetPasscodeInPassword(): void;
    get passcodeInPasswordInput(): boolean | cdktn.IResolvable | undefined;
    private _password?;
    get password(): string | undefined;
    set password(value: string | undefined);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _port?;
    get port(): number | undefined;
    set port(value: number | undefined);
    resetPort(): void;
    get portInput(): number | undefined;
    private _previewFeaturesEnabled?;
    get previewFeaturesEnabled(): string[] | undefined;
    set previewFeaturesEnabled(value: string[] | undefined);
    resetPreviewFeaturesEnabled(): void;
    get previewFeaturesEnabledInput(): string[] | undefined;
    private _privateKey?;
    get privateKey(): string | undefined;
    set privateKey(value: string | undefined);
    resetPrivateKey(): void;
    get privateKeyInput(): string | undefined;
    private _privateKeyPassphrase?;
    get privateKeyPassphrase(): string | undefined;
    set privateKeyPassphrase(value: string | undefined);
    resetPrivateKeyPassphrase(): void;
    get privateKeyPassphraseInput(): string | undefined;
    private _profile?;
    get profile(): string | undefined;
    set profile(value: string | undefined);
    resetProfile(): void;
    get profileInput(): string | undefined;
    private _protocol?;
    get protocol(): string | undefined;
    set protocol(value: string | undefined);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
    private _proxyHost?;
    get proxyHost(): string | undefined;
    set proxyHost(value: string | undefined);
    resetProxyHost(): void;
    get proxyHostInput(): string | undefined;
    private _proxyPassword?;
    get proxyPassword(): string | undefined;
    set proxyPassword(value: string | undefined);
    resetProxyPassword(): void;
    get proxyPasswordInput(): string | undefined;
    private _proxyPort?;
    get proxyPort(): number | undefined;
    set proxyPort(value: number | undefined);
    resetProxyPort(): void;
    get proxyPortInput(): number | undefined;
    private _proxyProtocol?;
    get proxyProtocol(): string | undefined;
    set proxyProtocol(value: string | undefined);
    resetProxyProtocol(): void;
    get proxyProtocolInput(): string | undefined;
    private _proxyUser?;
    get proxyUser(): string | undefined;
    set proxyUser(value: string | undefined);
    resetProxyUser(): void;
    get proxyUserInput(): string | undefined;
    private _requestTimeout?;
    get requestTimeout(): number | undefined;
    set requestTimeout(value: number | undefined);
    resetRequestTimeout(): void;
    get requestTimeoutInput(): number | undefined;
    private _role?;
    get role(): string | undefined;
    set role(value: string | undefined);
    resetRole(): void;
    get roleInput(): string | undefined;
    private _skipTomlFilePermissionVerification?;
    get skipTomlFilePermissionVerification(): boolean | cdktn.IResolvable | undefined;
    set skipTomlFilePermissionVerification(value: boolean | cdktn.IResolvable | undefined);
    resetSkipTomlFilePermissionVerification(): void;
    get skipTomlFilePermissionVerificationInput(): boolean | cdktn.IResolvable | undefined;
    private _tmpDirectoryPath?;
    get tmpDirectoryPath(): string | undefined;
    set tmpDirectoryPath(value: string | undefined);
    resetTmpDirectoryPath(): void;
    get tmpDirectoryPathInput(): string | undefined;
    private _token?;
    get token(): string | undefined;
    set token(value: string | undefined);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _useLegacyTomlFile?;
    get useLegacyTomlFile(): boolean | cdktn.IResolvable | undefined;
    set useLegacyTomlFile(value: boolean | cdktn.IResolvable | undefined);
    resetUseLegacyTomlFile(): void;
    get useLegacyTomlFileInput(): boolean | cdktn.IResolvable | undefined;
    private _user?;
    get user(): string | undefined;
    set user(value: string | undefined);
    resetUser(): void;
    get userInput(): string | undefined;
    private _validateDefaultParameters?;
    get validateDefaultParameters(): string | undefined;
    set validateDefaultParameters(value: string | undefined);
    resetValidateDefaultParameters(): void;
    get validateDefaultParametersInput(): string | undefined;
    private _warehouse?;
    get warehouse(): string | undefined;
    set warehouse(value: string | undefined);
    resetWarehouse(): void;
    get warehouseInput(): string | undefined;
    private _workloadIdentityEntraResource?;
    get workloadIdentityEntraResource(): string | undefined;
    set workloadIdentityEntraResource(value: string | undefined);
    resetWorkloadIdentityEntraResource(): void;
    get workloadIdentityEntraResourceInput(): string | undefined;
    private _workloadIdentityProvider?;
    get workloadIdentityProvider(): string | undefined;
    set workloadIdentityProvider(value: string | undefined);
    resetWorkloadIdentityProvider(): void;
    get workloadIdentityProviderInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _tokenAccessor?;
    get tokenAccessor(): SnowflakeProviderTokenAccessor | undefined;
    set tokenAccessor(value: SnowflakeProviderTokenAccessor | undefined);
    resetTokenAccessor(): void;
    get tokenAccessorInput(): SnowflakeProviderTokenAccessor | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
