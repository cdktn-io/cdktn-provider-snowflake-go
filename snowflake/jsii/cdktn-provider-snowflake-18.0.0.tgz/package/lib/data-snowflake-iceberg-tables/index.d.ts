/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeIcebergTablesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/iceberg_tables#id DataSnowflakeIcebergTables#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/iceberg_tables#like DataSnowflakeIcebergTables#like}
    */
    readonly like?: string;
    /**
    * Filters the output with **case-sensitive** characters indicating the beginning of the object name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/iceberg_tables#starts_with DataSnowflakeIcebergTables#starts_with}
    */
    readonly startsWith?: string;
    /**
    * (Default: `true`) Runs DESC ICEBERG TABLE for each iceberg table returned by SHOW ICEBERG TABLES. The output of describe is saved to the describe_output field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/iceberg_tables#with_describe DataSnowflakeIcebergTables#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * (Default: `true`) Runs SHOW PARAMETERS FOR ICEBERG TABLE for each iceberg table returned by SHOW ICEBERG TABLES. The output is saved to the parameters field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/iceberg_tables#with_parameters DataSnowflakeIcebergTables#with_parameters}
    */
    readonly withParameters?: boolean | cdktn.IResolvable;
    /**
    * in block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/iceberg_tables#in DataSnowflakeIcebergTables#in}
    */
    readonly in?: DataSnowflakeIcebergTablesIn;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/iceberg_tables#limit DataSnowflakeIcebergTables#limit}
    */
    readonly limit?: DataSnowflakeIcebergTablesLimit;
}
export interface DataSnowflakeIcebergTablesIcebergTablesDescribeOutput {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesDescribeOutputToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesDescribeOutput): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesDescribeOutputToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesDescribeOutput): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesDescribeOutput | undefined);
    get check(): string;
    get comment(): string;
    get default(): string;
    get expression(): string;
    get isNullable(): cdktn.IResolvable;
    get kind(): string;
    get name(): string;
    get nameMapping(): string;
    get policyName(): string;
    get primaryKey(): cdktn.IResolvable;
    get privacyDomain(): string;
    get sourceIcebergType(): string;
    get type(): string;
    get uniqueKey(): cdktn.IResolvable;
    get writeDefault(): string;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesDescribeOutputOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesParametersCatalog {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersCatalogToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersCatalog): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersCatalogToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersCatalog): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersCatalogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesParametersCatalog | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesParametersCatalog | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersCatalogList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesParametersCatalogOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesParametersCatalogSync {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersCatalogSyncToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersCatalogSync): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersCatalogSyncToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersCatalogSync): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersCatalogSyncOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesParametersCatalogSync | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesParametersCatalogSync | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersCatalogSyncList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesParametersCatalogSyncOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesParametersDataRetentionTimeInDays {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersDataRetentionTimeInDaysToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersDataRetentionTimeInDays): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersDataRetentionTimeInDaysToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersDataRetentionTimeInDays): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersDataRetentionTimeInDaysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesParametersDataRetentionTimeInDays | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesParametersDataRetentionTimeInDays | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersDataRetentionTimeInDaysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesParametersDataRetentionTimeInDaysOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesParametersEnableDataCompaction {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersEnableDataCompactionToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersEnableDataCompaction): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersEnableDataCompactionToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersEnableDataCompaction): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersEnableDataCompactionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesParametersEnableDataCompaction | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesParametersEnableDataCompaction | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersEnableDataCompactionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesParametersEnableDataCompactionOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesParametersEnableIcebergMergeOnRead {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersEnableIcebergMergeOnReadToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersEnableIcebergMergeOnRead): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersEnableIcebergMergeOnReadToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersEnableIcebergMergeOnRead): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersEnableIcebergMergeOnReadOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesParametersEnableIcebergMergeOnRead | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesParametersEnableIcebergMergeOnRead | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersEnableIcebergMergeOnReadList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesParametersEnableIcebergMergeOnReadOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesParametersExternalVolume {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersExternalVolumeToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersExternalVolume): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersExternalVolumeToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersExternalVolume): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersExternalVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesParametersExternalVolume | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesParametersExternalVolume | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersExternalVolumeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesParametersExternalVolumeOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesParametersIcebergMergeOnReadBehavior {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersIcebergMergeOnReadBehaviorToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersIcebergMergeOnReadBehavior): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersIcebergMergeOnReadBehaviorToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersIcebergMergeOnReadBehavior): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersIcebergMergeOnReadBehaviorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesParametersIcebergMergeOnReadBehavior | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesParametersIcebergMergeOnReadBehavior | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersIcebergMergeOnReadBehaviorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesParametersIcebergMergeOnReadBehaviorOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesParametersMaxDataExtensionTimeInDays {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersMaxDataExtensionTimeInDaysToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersMaxDataExtensionTimeInDays): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersMaxDataExtensionTimeInDaysToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersMaxDataExtensionTimeInDays): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersMaxDataExtensionTimeInDaysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesParametersMaxDataExtensionTimeInDays | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesParametersMaxDataExtensionTimeInDays | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersMaxDataExtensionTimeInDaysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesParametersMaxDataExtensionTimeInDaysOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesParametersReplaceInvalidCharacters {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersReplaceInvalidCharactersToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersReplaceInvalidCharacters): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersReplaceInvalidCharactersToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersReplaceInvalidCharacters): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersReplaceInvalidCharactersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesParametersReplaceInvalidCharacters | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesParametersReplaceInvalidCharacters | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersReplaceInvalidCharactersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesParametersReplaceInvalidCharactersOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesParametersStorageSerializationPolicy {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersStorageSerializationPolicyToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersStorageSerializationPolicy): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersStorageSerializationPolicyToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersStorageSerializationPolicy): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersStorageSerializationPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesParametersStorageSerializationPolicy | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesParametersStorageSerializationPolicy | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersStorageSerializationPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesParametersStorageSerializationPolicyOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesParametersTargetFileSize {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersTargetFileSizeToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersTargetFileSize): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersTargetFileSizeToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParametersTargetFileSize): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersTargetFileSizeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesParametersTargetFileSize | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesParametersTargetFileSize | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersTargetFileSizeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesParametersTargetFileSizeOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesParameters {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParameters): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesParametersToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesParameters): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesParameters | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesParameters | undefined);
    private _catalog;
    get catalog(): DataSnowflakeIcebergTablesIcebergTablesParametersCatalogList;
    private _catalogSync;
    get catalogSync(): DataSnowflakeIcebergTablesIcebergTablesParametersCatalogSyncList;
    private _dataRetentionTimeInDays;
    get dataRetentionTimeInDays(): DataSnowflakeIcebergTablesIcebergTablesParametersDataRetentionTimeInDaysList;
    private _enableDataCompaction;
    get enableDataCompaction(): DataSnowflakeIcebergTablesIcebergTablesParametersEnableDataCompactionList;
    private _enableIcebergMergeOnRead;
    get enableIcebergMergeOnRead(): DataSnowflakeIcebergTablesIcebergTablesParametersEnableIcebergMergeOnReadList;
    private _externalVolume;
    get externalVolume(): DataSnowflakeIcebergTablesIcebergTablesParametersExternalVolumeList;
    private _icebergMergeOnReadBehavior;
    get icebergMergeOnReadBehavior(): DataSnowflakeIcebergTablesIcebergTablesParametersIcebergMergeOnReadBehaviorList;
    private _maxDataExtensionTimeInDays;
    get maxDataExtensionTimeInDays(): DataSnowflakeIcebergTablesIcebergTablesParametersMaxDataExtensionTimeInDaysList;
    private _replaceInvalidCharacters;
    get replaceInvalidCharacters(): DataSnowflakeIcebergTablesIcebergTablesParametersReplaceInvalidCharactersList;
    private _storageSerializationPolicy;
    get storageSerializationPolicy(): DataSnowflakeIcebergTablesIcebergTablesParametersStorageSerializationPolicyList;
    private _targetFileSize;
    get targetFileSize(): DataSnowflakeIcebergTablesIcebergTablesParametersTargetFileSizeList;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesParametersOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesShowOutputAutoRefreshStatus {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesShowOutputAutoRefreshStatusToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesShowOutputAutoRefreshStatus): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesShowOutputAutoRefreshStatusToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesShowOutputAutoRefreshStatus): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesShowOutputAutoRefreshStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesShowOutputAutoRefreshStatus | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesShowOutputAutoRefreshStatus | undefined);
    get currentSnapshotId(): number;
    get executionState(): string;
    get lastSnapshotTime(): string;
    get lastUpdatedTime(): string;
    get pendingSnapshotCount(): number;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesShowOutputAutoRefreshStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesShowOutputAutoRefreshStatusOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsFields {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsFieldsToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsFields): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsFieldsToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsFields): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsFields | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsFields | undefined);
    get fieldId(): number;
    get name(): string;
    get sourceId(): number;
    get transform(): string;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsFieldsOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecs {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecs): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecs): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecs | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecs | undefined);
    private _fields;
    get fields(): DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsFieldsList;
    get specId(): number;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTablesShowOutput {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesShowOutputToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesShowOutput): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesShowOutputToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTablesShowOutput): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTablesShowOutput | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTablesShowOutput | undefined);
    private _autoRefreshStatus;
    get autoRefreshStatus(): DataSnowflakeIcebergTablesIcebergTablesShowOutputAutoRefreshStatusList;
    get baseLocation(): string;
    get canWriteMetadata(): cdktn.IResolvable;
    get catalogName(): string;
    get catalogNamespace(): string;
    get catalogSyncName(): string;
    get catalogTableName(): string;
    get comment(): string;
    get createdOn(): string;
    get currentPartitionSpecId(): number;
    get databaseName(): string;
    get externalVolumeName(): string;
    get icebergTableFormatVersion(): number;
    get icebergTableType(): string;
    get name(): string;
    get nameMapping(): string;
    get owner(): string;
    get ownerRoleType(): string;
    private _partitionSpecs;
    get partitionSpecs(): DataSnowflakeIcebergTablesIcebergTablesShowOutputPartitionSpecsList;
    get schemaName(): string;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesShowOutputOutputReference;
}
export interface DataSnowflakeIcebergTablesIcebergTables {
}
export declare function dataSnowflakeIcebergTablesIcebergTablesToTerraform(struct?: DataSnowflakeIcebergTablesIcebergTables): any;
export declare function dataSnowflakeIcebergTablesIcebergTablesToHclTerraform(struct?: DataSnowflakeIcebergTablesIcebergTables): any;
export declare class DataSnowflakeIcebergTablesIcebergTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeIcebergTablesIcebergTables | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIcebergTables | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeIcebergTablesIcebergTablesDescribeOutputList;
    private _parameters;
    get parameters(): DataSnowflakeIcebergTablesIcebergTablesParametersList;
    private _showOutput;
    get showOutput(): DataSnowflakeIcebergTablesIcebergTablesShowOutputList;
}
export declare class DataSnowflakeIcebergTablesIcebergTablesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeIcebergTablesIcebergTablesOutputReference;
}
export interface DataSnowflakeIcebergTablesIn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/iceberg_tables#account DataSnowflakeIcebergTables#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the current database in use or for a specified database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/iceberg_tables#database DataSnowflakeIcebergTables#database}
    */
    readonly database?: string;
    /**
    * Returns records for the current schema in use or a specified schema. Use fully qualified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/iceberg_tables#schema DataSnowflakeIcebergTables#schema}
    */
    readonly schema?: string;
}
export declare function dataSnowflakeIcebergTablesInToTerraform(struct?: DataSnowflakeIcebergTablesInOutputReference | DataSnowflakeIcebergTablesIn): any;
export declare function dataSnowflakeIcebergTablesInToHclTerraform(struct?: DataSnowflakeIcebergTablesInOutputReference | DataSnowflakeIcebergTablesIn): any;
export declare class DataSnowflakeIcebergTablesInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeIcebergTablesIn | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesIn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export interface DataSnowflakeIcebergTablesLimit {
    /**
    * Specifies a **case-sensitive** pattern that is used to match object name. After the first match, the limit on the number of rows will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/iceberg_tables#from DataSnowflakeIcebergTables#from}
    */
    readonly from?: string;
    /**
    * The maximum number of rows to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/iceberg_tables#rows DataSnowflakeIcebergTables#rows}
    */
    readonly rows: number;
}
export declare function dataSnowflakeIcebergTablesLimitToTerraform(struct?: DataSnowflakeIcebergTablesLimitOutputReference | DataSnowflakeIcebergTablesLimit): any;
export declare function dataSnowflakeIcebergTablesLimitToHclTerraform(struct?: DataSnowflakeIcebergTablesLimitOutputReference | DataSnowflakeIcebergTablesLimit): any;
export declare class DataSnowflakeIcebergTablesLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeIcebergTablesLimit | undefined;
    set internalValue(value: DataSnowflakeIcebergTablesLimit | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _rows?;
    get rows(): number;
    set rows(value: number);
    get rowsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/iceberg_tables snowflake_iceberg_tables}
*/
export declare class DataSnowflakeIcebergTables extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_iceberg_tables";
    /**
    * Generates CDKTN code for importing a DataSnowflakeIcebergTables resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeIcebergTables to import
    * @param importFromId The id of the existing DataSnowflakeIcebergTables that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/iceberg_tables#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeIcebergTables to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/iceberg_tables snowflake_iceberg_tables} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeIcebergTablesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeIcebergTablesConfig);
    private _icebergTables;
    get icebergTables(): DataSnowflakeIcebergTablesIcebergTablesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _startsWith?;
    get startsWith(): string;
    set startsWith(value: string);
    resetStartsWith(): void;
    get startsWithInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _withParameters?;
    get withParameters(): boolean | cdktn.IResolvable;
    set withParameters(value: boolean | cdktn.IResolvable);
    resetWithParameters(): void;
    get withParametersInput(): boolean | cdktn.IResolvable | undefined;
    private _in;
    get in(): DataSnowflakeIcebergTablesInOutputReference;
    putIn(value: DataSnowflakeIcebergTablesIn): void;
    resetIn(): void;
    get inInput(): DataSnowflakeIcebergTablesIn | undefined;
    private _limit;
    get limit(): DataSnowflakeIcebergTablesLimitOutputReference;
    putLimit(value: DataSnowflakeIcebergTablesLimit): void;
    resetLimit(): void;
    get limitInput(): DataSnowflakeIcebergTablesLimit | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
