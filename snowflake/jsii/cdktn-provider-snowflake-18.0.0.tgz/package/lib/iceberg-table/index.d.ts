/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IcebergTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * The path to a directory where Snowflake can write data and metadata files for the Iceberg table. Specify a relative path from the table's `EXTERNAL_VOLUME` location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#base_location IcebergTable#base_location}
    */
    readonly baseLocation?: string;
    /**
    * Specifies the identifier for the catalog integration to use for the Iceberg table. If not specified, the account-level default is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#catalog IcebergTable#catalog}
    */
    readonly catalog?: string;
    /**
    * Specifies the name of the catalog integration that Snowflake uses to automatically synchronize the Iceberg table with an external catalog. For more information, check [CATALOG_SYNC docs](https://docs.snowflake.com/en/sql-reference/parameters#catalog-sync).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#catalog_sync IcebergTable#catalog_sync}
    */
    readonly catalogSync?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether to enable change tracking on the Iceberg table. Cannot be changed after creation. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#change_tracking IcebergTable#change_tracking}
    */
    readonly changeTracking?: string;
    /**
    * A list of one or more table columns/expressions to be used as clustering key(s) for the table. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#cluster_by IcebergTable#cluster_by}
    */
    readonly clusterBy?: string[];
    /**
    * Specifies a comment for the Iceberg table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#comment IcebergTable#comment}
    */
    readonly comment?: string;
    /**
    * Specifies the retention period for the Iceberg table so that Time Travel actions can be performed on historical data. For more information, check [DATA_RETENTION_TIME_IN_DAYS docs](https://docs.snowflake.com/en/sql-reference/parameters#data-retention-time-in-days).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#data_retention_time_in_days IcebergTable#data_retention_time_in_days}
    */
    readonly dataRetentionTimeInDays?: number;
    /**
    * The database in which to create the Iceberg table. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#database IcebergTable#database}
    */
    readonly database: string;
    /**
    * Specifies whether automatic background data compaction is enabled for the Iceberg table. For more information, check [ENABLE_DATA_COMPACTION docs](https://docs.snowflake.com/en/sql-reference/parameters#enable-data-compaction).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#enable_data_compaction IcebergTable#enable_data_compaction}
    */
    readonly enableDataCompaction?: boolean | cdktn.IResolvable;
    /**
    * Specifies whether merge-on-read is enabled for the Iceberg table. For more information, check [ENABLE_ICEBERG_MERGE_ON_READ docs](https://docs.snowflake.com/en/sql-reference/parameters#enable-iceberg-merge-on-read).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#enable_iceberg_merge_on_read IcebergTable#enable_iceberg_merge_on_read}
    */
    readonly enableIcebergMergeOnRead?: boolean | cdktn.IResolvable;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether error logging is enabled for the Iceberg table. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#error_logging IcebergTable#error_logging}
    */
    readonly errorLogging?: string;
    /**
    * Specifies the identifier for the external volume where the Iceberg table stores its metadata files and data in Parquet format. If not specified, the account-level default is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#external_volume IcebergTable#external_volume}
    */
    readonly externalVolume?: string;
    /**
    * Specifies the Iceberg table format version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#iceberg_version IcebergTable#iceberg_version}
    */
    readonly icebergVersion?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#id IcebergTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the maximum number of days for which Snowflake can extend the data retention period for the Iceberg table to prevent streams on the table from becoming stale. For more information, check [MAX_DATA_EXTENSION_TIME_IN_DAYS docs](https://docs.snowflake.com/en/sql-reference/parameters#max-data-extension-time-in-days).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#max_data_extension_time_in_days IcebergTable#max_data_extension_time_in_days}
    */
    readonly maxDataExtensionTimeInDays?: number;
    /**
    * Specifies the identifier for the Iceberg table; must be unique for the schema in which the Iceberg table is created. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#name IcebergTable#name}
    */
    readonly name: string;
    /**
    * Specifies the storage layout for the Iceberg table's Parquet files. Valid values are: [FLAT HIERARCHICAL]. Cannot be changed after creation. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#path_layout IcebergTable#path_layout}
    */
    readonly pathLayout?: string;
    /**
    * The schema in which to create the Iceberg table. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#schema IcebergTable#schema}
    */
    readonly schema: string;
    /**
    * Specifies the storage serialization policy for the Iceberg table. Valid values are: [COMPATIBLE OPTIMIZED]. Cannot be changed after creation. For more information, check [STORAGE_SERIALIZATION_POLICY docs](https://docs.snowflake.com/en/sql-reference/parameters#storage-serialization-policy).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#storage_serialization_policy IcebergTable#storage_serialization_policy}
    */
    readonly storageSerializationPolicy?: string;
    /**
    * Specifies the target file size (in bytes) used when writing the Iceberg table's Parquet files. Valid values are: [AUTO 16MB 32MB 64MB 128MB]. For more information, check [TARGET_FILE_SIZE docs](https://docs.snowflake.com/en/sql-reference/parameters#target-file-size).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#target_file_size IcebergTable#target_file_size}
    */
    readonly targetFileSize?: string;
    /**
    * aggregation_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#aggregation_policy IcebergTable#aggregation_policy}
    */
    readonly aggregationPolicy?: IcebergTableAggregationPolicy;
    /**
    * check_constraint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#check_constraint IcebergTable#check_constraint}
    */
    readonly checkConstraint?: IcebergTableCheckConstraint[] | cdktn.IResolvable;
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#column IcebergTable#column}
    */
    readonly column: IcebergTableColumn[] | cdktn.IResolvable;
    /**
    * foreign_key_constraint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#foreign_key_constraint IcebergTable#foreign_key_constraint}
    */
    readonly foreignKeyConstraint?: IcebergTableForeignKeyConstraint[] | cdktn.IResolvable;
    /**
    * partition_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#partition_by IcebergTable#partition_by}
    */
    readonly partitionBy?: IcebergTablePartitionBy[] | cdktn.IResolvable;
    /**
    * primary_key_constraint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#primary_key_constraint IcebergTable#primary_key_constraint}
    */
    readonly primaryKeyConstraint?: IcebergTablePrimaryKeyConstraint;
    /**
    * row_access_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#row_access_policy IcebergTable#row_access_policy}
    */
    readonly rowAccessPolicy?: IcebergTableRowAccessPolicy;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#timeouts IcebergTable#timeouts}
    */
    readonly timeouts?: IcebergTableTimeouts;
    /**
    * unique_constraint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#unique_constraint IcebergTable#unique_constraint}
    */
    readonly uniqueConstraint?: IcebergTableUniqueConstraint[] | cdktn.IResolvable;
}
export interface IcebergTableDescribeOutput {
}
export declare function icebergTableDescribeOutputToTerraform(struct?: IcebergTableDescribeOutput): any;
export declare function icebergTableDescribeOutputToHclTerraform(struct?: IcebergTableDescribeOutput): any;
export declare class IcebergTableDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableDescribeOutput | undefined;
    set internalValue(value: IcebergTableDescribeOutput | undefined);
    get check(): string;
    get comment(): string;
    get default(): string;
    get expression(): string;
    get isNullable(): cdktn.IResolvable;
    get kind(): string;
    get name(): string;
    get nameMapping(): string;
    get policyName(): string;
    get primaryKey(): cdktn.IResolvable;
    get privacyDomain(): string;
    get sourceIcebergType(): string;
    get type(): string;
    get uniqueKey(): cdktn.IResolvable;
    get writeDefault(): string;
}
export declare class IcebergTableDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableDescribeOutputOutputReference;
}
export interface IcebergTableParametersCatalog {
}
export declare function icebergTableParametersCatalogToTerraform(struct?: IcebergTableParametersCatalog): any;
export declare function icebergTableParametersCatalogToHclTerraform(struct?: IcebergTableParametersCatalog): any;
export declare class IcebergTableParametersCatalogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableParametersCatalog | undefined;
    set internalValue(value: IcebergTableParametersCatalog | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableParametersCatalogList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableParametersCatalogOutputReference;
}
export interface IcebergTableParametersCatalogSync {
}
export declare function icebergTableParametersCatalogSyncToTerraform(struct?: IcebergTableParametersCatalogSync): any;
export declare function icebergTableParametersCatalogSyncToHclTerraform(struct?: IcebergTableParametersCatalogSync): any;
export declare class IcebergTableParametersCatalogSyncOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableParametersCatalogSync | undefined;
    set internalValue(value: IcebergTableParametersCatalogSync | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableParametersCatalogSyncList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableParametersCatalogSyncOutputReference;
}
export interface IcebergTableParametersDataRetentionTimeInDays {
}
export declare function icebergTableParametersDataRetentionTimeInDaysToTerraform(struct?: IcebergTableParametersDataRetentionTimeInDays): any;
export declare function icebergTableParametersDataRetentionTimeInDaysToHclTerraform(struct?: IcebergTableParametersDataRetentionTimeInDays): any;
export declare class IcebergTableParametersDataRetentionTimeInDaysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableParametersDataRetentionTimeInDays | undefined;
    set internalValue(value: IcebergTableParametersDataRetentionTimeInDays | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableParametersDataRetentionTimeInDaysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableParametersDataRetentionTimeInDaysOutputReference;
}
export interface IcebergTableParametersEnableDataCompaction {
}
export declare function icebergTableParametersEnableDataCompactionToTerraform(struct?: IcebergTableParametersEnableDataCompaction): any;
export declare function icebergTableParametersEnableDataCompactionToHclTerraform(struct?: IcebergTableParametersEnableDataCompaction): any;
export declare class IcebergTableParametersEnableDataCompactionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableParametersEnableDataCompaction | undefined;
    set internalValue(value: IcebergTableParametersEnableDataCompaction | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableParametersEnableDataCompactionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableParametersEnableDataCompactionOutputReference;
}
export interface IcebergTableParametersEnableIcebergMergeOnRead {
}
export declare function icebergTableParametersEnableIcebergMergeOnReadToTerraform(struct?: IcebergTableParametersEnableIcebergMergeOnRead): any;
export declare function icebergTableParametersEnableIcebergMergeOnReadToHclTerraform(struct?: IcebergTableParametersEnableIcebergMergeOnRead): any;
export declare class IcebergTableParametersEnableIcebergMergeOnReadOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableParametersEnableIcebergMergeOnRead | undefined;
    set internalValue(value: IcebergTableParametersEnableIcebergMergeOnRead | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableParametersEnableIcebergMergeOnReadList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableParametersEnableIcebergMergeOnReadOutputReference;
}
export interface IcebergTableParametersExternalVolume {
}
export declare function icebergTableParametersExternalVolumeToTerraform(struct?: IcebergTableParametersExternalVolume): any;
export declare function icebergTableParametersExternalVolumeToHclTerraform(struct?: IcebergTableParametersExternalVolume): any;
export declare class IcebergTableParametersExternalVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableParametersExternalVolume | undefined;
    set internalValue(value: IcebergTableParametersExternalVolume | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableParametersExternalVolumeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableParametersExternalVolumeOutputReference;
}
export interface IcebergTableParametersMaxDataExtensionTimeInDays {
}
export declare function icebergTableParametersMaxDataExtensionTimeInDaysToTerraform(struct?: IcebergTableParametersMaxDataExtensionTimeInDays): any;
export declare function icebergTableParametersMaxDataExtensionTimeInDaysToHclTerraform(struct?: IcebergTableParametersMaxDataExtensionTimeInDays): any;
export declare class IcebergTableParametersMaxDataExtensionTimeInDaysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableParametersMaxDataExtensionTimeInDays | undefined;
    set internalValue(value: IcebergTableParametersMaxDataExtensionTimeInDays | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableParametersMaxDataExtensionTimeInDaysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableParametersMaxDataExtensionTimeInDaysOutputReference;
}
export interface IcebergTableParametersStorageSerializationPolicy {
}
export declare function icebergTableParametersStorageSerializationPolicyToTerraform(struct?: IcebergTableParametersStorageSerializationPolicy): any;
export declare function icebergTableParametersStorageSerializationPolicyToHclTerraform(struct?: IcebergTableParametersStorageSerializationPolicy): any;
export declare class IcebergTableParametersStorageSerializationPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableParametersStorageSerializationPolicy | undefined;
    set internalValue(value: IcebergTableParametersStorageSerializationPolicy | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableParametersStorageSerializationPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableParametersStorageSerializationPolicyOutputReference;
}
export interface IcebergTableParametersTargetFileSize {
}
export declare function icebergTableParametersTargetFileSizeToTerraform(struct?: IcebergTableParametersTargetFileSize): any;
export declare function icebergTableParametersTargetFileSizeToHclTerraform(struct?: IcebergTableParametersTargetFileSize): any;
export declare class IcebergTableParametersTargetFileSizeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableParametersTargetFileSize | undefined;
    set internalValue(value: IcebergTableParametersTargetFileSize | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableParametersTargetFileSizeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableParametersTargetFileSizeOutputReference;
}
export interface IcebergTableParameters {
}
export declare function icebergTableParametersToTerraform(struct?: IcebergTableParameters): any;
export declare function icebergTableParametersToHclTerraform(struct?: IcebergTableParameters): any;
export declare class IcebergTableParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableParameters | undefined;
    set internalValue(value: IcebergTableParameters | undefined);
    private _catalog;
    get catalog(): IcebergTableParametersCatalogList;
    private _catalogSync;
    get catalogSync(): IcebergTableParametersCatalogSyncList;
    private _dataRetentionTimeInDays;
    get dataRetentionTimeInDays(): IcebergTableParametersDataRetentionTimeInDaysList;
    private _enableDataCompaction;
    get enableDataCompaction(): IcebergTableParametersEnableDataCompactionList;
    private _enableIcebergMergeOnRead;
    get enableIcebergMergeOnRead(): IcebergTableParametersEnableIcebergMergeOnReadList;
    private _externalVolume;
    get externalVolume(): IcebergTableParametersExternalVolumeList;
    private _maxDataExtensionTimeInDays;
    get maxDataExtensionTimeInDays(): IcebergTableParametersMaxDataExtensionTimeInDaysList;
    private _storageSerializationPolicy;
    get storageSerializationPolicy(): IcebergTableParametersStorageSerializationPolicyList;
    private _targetFileSize;
    get targetFileSize(): IcebergTableParametersTargetFileSizeList;
}
export declare class IcebergTableParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableParametersOutputReference;
}
export interface IcebergTableShowOutputAutoRefreshStatus {
}
export declare function icebergTableShowOutputAutoRefreshStatusToTerraform(struct?: IcebergTableShowOutputAutoRefreshStatus): any;
export declare function icebergTableShowOutputAutoRefreshStatusToHclTerraform(struct?: IcebergTableShowOutputAutoRefreshStatus): any;
export declare class IcebergTableShowOutputAutoRefreshStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableShowOutputAutoRefreshStatus | undefined;
    set internalValue(value: IcebergTableShowOutputAutoRefreshStatus | undefined);
    get currentSnapshotId(): number;
    get executionState(): string;
    get lastSnapshotTime(): string;
    get lastUpdatedTime(): string;
    get pendingSnapshotCount(): number;
}
export declare class IcebergTableShowOutputAutoRefreshStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableShowOutputAutoRefreshStatusOutputReference;
}
export interface IcebergTableShowOutputPartitionSpecsFields {
}
export declare function icebergTableShowOutputPartitionSpecsFieldsToTerraform(struct?: IcebergTableShowOutputPartitionSpecsFields): any;
export declare function icebergTableShowOutputPartitionSpecsFieldsToHclTerraform(struct?: IcebergTableShowOutputPartitionSpecsFields): any;
export declare class IcebergTableShowOutputPartitionSpecsFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableShowOutputPartitionSpecsFields | undefined;
    set internalValue(value: IcebergTableShowOutputPartitionSpecsFields | undefined);
    get fieldId(): number;
    get name(): string;
    get sourceId(): number;
    get transform(): string;
}
export declare class IcebergTableShowOutputPartitionSpecsFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableShowOutputPartitionSpecsFieldsOutputReference;
}
export interface IcebergTableShowOutputPartitionSpecs {
}
export declare function icebergTableShowOutputPartitionSpecsToTerraform(struct?: IcebergTableShowOutputPartitionSpecs): any;
export declare function icebergTableShowOutputPartitionSpecsToHclTerraform(struct?: IcebergTableShowOutputPartitionSpecs): any;
export declare class IcebergTableShowOutputPartitionSpecsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableShowOutputPartitionSpecs | undefined;
    set internalValue(value: IcebergTableShowOutputPartitionSpecs | undefined);
    private _fields;
    get fields(): IcebergTableShowOutputPartitionSpecsFieldsList;
    get specId(): number;
}
export declare class IcebergTableShowOutputPartitionSpecsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableShowOutputPartitionSpecsOutputReference;
}
export interface IcebergTableShowOutput {
}
export declare function icebergTableShowOutputToTerraform(struct?: IcebergTableShowOutput): any;
export declare function icebergTableShowOutputToHclTerraform(struct?: IcebergTableShowOutput): any;
export declare class IcebergTableShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableShowOutput | undefined;
    set internalValue(value: IcebergTableShowOutput | undefined);
    private _autoRefreshStatus;
    get autoRefreshStatus(): IcebergTableShowOutputAutoRefreshStatusList;
    get baseLocation(): string;
    get canWriteMetadata(): cdktn.IResolvable;
    get catalogName(): string;
    get catalogNamespace(): string;
    get catalogSyncName(): string;
    get catalogTableName(): string;
    get comment(): string;
    get createdOn(): string;
    get currentPartitionSpecId(): number;
    get databaseName(): string;
    get externalVolumeName(): string;
    get icebergTableFormatVersion(): number;
    get icebergTableType(): string;
    get name(): string;
    get nameMapping(): string;
    get owner(): string;
    get ownerRoleType(): string;
    private _partitionSpecs;
    get partitionSpecs(): IcebergTableShowOutputPartitionSpecsList;
    get schemaName(): string;
}
export declare class IcebergTableShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableShowOutputOutputReference;
}
export interface IcebergTableAggregationPolicy {
    /**
    * Defines which columns uniquely identify an entity within the Iceberg table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#entity_key IcebergTable#entity_key}
    */
    readonly entityKey?: string[];
    /**
    * Aggregation policy name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#policy_name IcebergTable#policy_name}
    */
    readonly policyName: string;
}
export declare function icebergTableAggregationPolicyToTerraform(struct?: IcebergTableAggregationPolicyOutputReference | IcebergTableAggregationPolicy): any;
export declare function icebergTableAggregationPolicyToHclTerraform(struct?: IcebergTableAggregationPolicyOutputReference | IcebergTableAggregationPolicy): any;
export declare class IcebergTableAggregationPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IcebergTableAggregationPolicy | undefined;
    set internalValue(value: IcebergTableAggregationPolicy | undefined);
    private _entityKey?;
    get entityKey(): string[];
    set entityKey(value: string[]);
    resetEntityKey(): void;
    get entityKeyInput(): string[] | undefined;
    private _policyName?;
    get policyName(): string;
    set policyName(value: string);
    get policyNameInput(): string | undefined;
}
export interface IcebergTableCheckConstraint {
    /**
    * The CHECK constraint expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#expression IcebergTable#expression}
    */
    readonly expression: string;
    /**
    * Name of the constraint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#name IcebergTable#name}
    */
    readonly name?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether existing data is validated against the constraint (`true`, `ENABLE VALIDATE`) or not (`false`, `ENABLE NOVALIDATE`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#validate IcebergTable#validate}
    */
    readonly validate?: string;
}
export declare function icebergTableCheckConstraintToTerraform(struct?: IcebergTableCheckConstraint | cdktn.IResolvable): any;
export declare function icebergTableCheckConstraintToHclTerraform(struct?: IcebergTableCheckConstraint | cdktn.IResolvable): any;
export declare class IcebergTableCheckConstraintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableCheckConstraint | cdktn.IResolvable | undefined;
    set internalValue(value: IcebergTableCheckConstraint | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _validate?;
    get validate(): string;
    set validate(value: string);
    resetValidate(): void;
    get validateInput(): string | undefined;
}
export declare class IcebergTableCheckConstraintList extends cdktn.ComplexList {
    internalValue?: IcebergTableCheckConstraint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableCheckConstraintOutputReference;
}
export interface IcebergTableColumnDefault {
    /**
    * The default expression value for the column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#expression IcebergTable#expression}
    */
    readonly expression: string;
}
export declare function icebergTableColumnDefaultToTerraform(struct?: IcebergTableColumnDefaultOutputReference | IcebergTableColumnDefault): any;
export declare function icebergTableColumnDefaultToHclTerraform(struct?: IcebergTableColumnDefaultOutputReference | IcebergTableColumnDefault): any;
export declare class IcebergTableColumnDefaultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IcebergTableColumnDefault | undefined;
    set internalValue(value: IcebergTableColumnDefault | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export interface IcebergTableColumnMaskingPolicy {
    /**
    * Masking policy name. For more information about this resource, see [docs](./masking_policy).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#policy_name IcebergTable#policy_name}
    */
    readonly policyName: string;
    /**
    * Specifies the arguments to pass into the conditional masking policy SQL expression, in order. The first column in the list specifies the column for the policy conditions to mask or tokenize the data and must match the column to which the masking policy is set. The additional columns specify the columns to evaluate to determine whether to mask or tokenize the data in each row of the query result when a query is made on the first column. If the USING clause is omitted, Snowflake treats the conditional masking policy as a normal masking policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#using IcebergTable#using}
    */
    readonly using?: string[];
}
export declare function icebergTableColumnMaskingPolicyToTerraform(struct?: IcebergTableColumnMaskingPolicyOutputReference | IcebergTableColumnMaskingPolicy): any;
export declare function icebergTableColumnMaskingPolicyToHclTerraform(struct?: IcebergTableColumnMaskingPolicyOutputReference | IcebergTableColumnMaskingPolicy): any;
export declare class IcebergTableColumnMaskingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IcebergTableColumnMaskingPolicy | undefined;
    set internalValue(value: IcebergTableColumnMaskingPolicy | undefined);
    private _policyName?;
    get policyName(): string;
    set policyName(value: string);
    get policyNameInput(): string | undefined;
    private _using?;
    get using(): string[];
    set using(value: string[]);
    resetUsing(): void;
    get usingInput(): string[] | undefined;
}
export interface IcebergTableColumnProjectionPolicy {
    /**
    * Projection policy name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#policy_name IcebergTable#policy_name}
    */
    readonly policyName: string;
}
export declare function icebergTableColumnProjectionPolicyToTerraform(struct?: IcebergTableColumnProjectionPolicyOutputReference | IcebergTableColumnProjectionPolicy): any;
export declare function icebergTableColumnProjectionPolicyToHclTerraform(struct?: IcebergTableColumnProjectionPolicyOutputReference | IcebergTableColumnProjectionPolicy): any;
export declare class IcebergTableColumnProjectionPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IcebergTableColumnProjectionPolicy | undefined;
    set internalValue(value: IcebergTableColumnProjectionPolicy | undefined);
    private _policyName?;
    get policyName(): string;
    set policyName(value: string);
    get policyNameInput(): string | undefined;
}
export interface IcebergTableColumn {
    /**
    * Column comment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#comment IcebergTable#comment}
    */
    readonly comment?: string;
    /**
    * Column name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#name IcebergTable#name}
    */
    readonly name: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether to restrict the column to NOT NULL values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#not_null IcebergTable#not_null}
    */
    readonly notNull?: string;
    /**
    * Column type, e.g. VARIANT. For a full list of column types, see [Summary of Data Types](https://docs.snowflake.com/en/sql-reference/intro-summary-data-types).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#type IcebergTable#type}
    */
    readonly type: string;
    /**
    * default block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#default IcebergTable#default}
    */
    readonly default?: IcebergTableColumnDefault;
    /**
    * masking_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#masking_policy IcebergTable#masking_policy}
    */
    readonly maskingPolicy?: IcebergTableColumnMaskingPolicy;
    /**
    * projection_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#projection_policy IcebergTable#projection_policy}
    */
    readonly projectionPolicy?: IcebergTableColumnProjectionPolicy;
}
export declare function icebergTableColumnToTerraform(struct?: IcebergTableColumn | cdktn.IResolvable): any;
export declare function icebergTableColumnToHclTerraform(struct?: IcebergTableColumn | cdktn.IResolvable): any;
export declare class IcebergTableColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableColumn | cdktn.IResolvable | undefined;
    set internalValue(value: IcebergTableColumn | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _notNull?;
    get notNull(): string;
    set notNull(value: string);
    resetNotNull(): void;
    get notNullInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _default;
    get default(): IcebergTableColumnDefaultOutputReference;
    putDefault(value: IcebergTableColumnDefault): void;
    resetDefault(): void;
    get defaultInput(): IcebergTableColumnDefault | undefined;
    private _maskingPolicy;
    get maskingPolicy(): IcebergTableColumnMaskingPolicyOutputReference;
    putMaskingPolicy(value: IcebergTableColumnMaskingPolicy): void;
    resetMaskingPolicy(): void;
    get maskingPolicyInput(): IcebergTableColumnMaskingPolicy | undefined;
    private _projectionPolicy;
    get projectionPolicy(): IcebergTableColumnProjectionPolicyOutputReference;
    putProjectionPolicy(value: IcebergTableColumnProjectionPolicy): void;
    resetProjectionPolicy(): void;
    get projectionPolicyInput(): IcebergTableColumnProjectionPolicy | undefined;
}
export declare class IcebergTableColumnList extends cdktn.ComplexList {
    internalValue?: IcebergTableColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableColumnOutputReference;
}
export interface IcebergTableForeignKeyConstraint {
    /**
    * The local column(s) the foreign key is defined on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#column IcebergTable#column}
    */
    readonly column: string[];
    /**
    * Constraint comment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#comment IcebergTable#comment}
    */
    readonly comment?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether the constraint is deferrable (`true`) or not deferrable (`false`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#deferrable IcebergTable#deferrable}
    */
    readonly deferrable?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether the constraint is enabled (`true`) or disabled (`false`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#enable IcebergTable#enable}
    */
    readonly enable?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether the constraint is enforced (`true`) or not enforced (`false`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#enforced IcebergTable#enforced}
    */
    readonly enforced?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether the constraint is initially deferred (`true`) or initially immediate (`false`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#initially_deferred IcebergTable#initially_deferred}
    */
    readonly initiallyDeferred?: string;
    /**
    * The match type for the foreign key. Valid values are: [FULL SIMPLE PARTIAL].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#match IcebergTable#match}
    */
    readonly match?: string;
    /**
    * Name of the constraint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#name IcebergTable#name}
    */
    readonly name?: string;
    /**
    * Specifies the action to perform when the referenced primary/unique key is deleted. Valid values are: [CASCADE SET NULL SET DEFAULT RESTRICT NO ACTION].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#on_delete IcebergTable#on_delete}
    */
    readonly onDelete?: string;
    /**
    * Specifies the action to perform when the referenced primary/unique key is updated. Valid values are: [CASCADE SET NULL SET DEFAULT RESTRICT NO ACTION].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#on_update IcebergTable#on_update}
    */
    readonly onUpdate?: string;
    /**
    * The column(s) in the referenced table that the foreign key references.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#ref_column IcebergTable#ref_column}
    */
    readonly refColumn?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether a constraint in NOVALIDATE mode is taken into account (`true`) or not (`false`) during query rewrite. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#rely IcebergTable#rely}
    */
    readonly rely?: string;
    /**
    * The table that the foreign key references.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#table_name IcebergTable#table_name}
    */
    readonly tableName: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether to validate existing data on the table when the constraint is created (`true`) or skip validation (`false`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#validate IcebergTable#validate}
    */
    readonly validate?: string;
}
export declare function icebergTableForeignKeyConstraintToTerraform(struct?: IcebergTableForeignKeyConstraint | cdktn.IResolvable): any;
export declare function icebergTableForeignKeyConstraintToHclTerraform(struct?: IcebergTableForeignKeyConstraint | cdktn.IResolvable): any;
export declare class IcebergTableForeignKeyConstraintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableForeignKeyConstraint | cdktn.IResolvable | undefined;
    set internalValue(value: IcebergTableForeignKeyConstraint | cdktn.IResolvable | undefined);
    private _column?;
    get column(): string[];
    set column(value: string[]);
    get columnInput(): string[] | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _deferrable?;
    get deferrable(): string;
    set deferrable(value: string);
    resetDeferrable(): void;
    get deferrableInput(): string | undefined;
    private _enable?;
    get enable(): string;
    set enable(value: string);
    resetEnable(): void;
    get enableInput(): string | undefined;
    private _enforced?;
    get enforced(): string;
    set enforced(value: string);
    resetEnforced(): void;
    get enforcedInput(): string | undefined;
    private _initiallyDeferred?;
    get initiallyDeferred(): string;
    set initiallyDeferred(value: string);
    resetInitiallyDeferred(): void;
    get initiallyDeferredInput(): string | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    resetMatch(): void;
    get matchInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _onDelete?;
    get onDelete(): string;
    set onDelete(value: string);
    resetOnDelete(): void;
    get onDeleteInput(): string | undefined;
    private _onUpdate?;
    get onUpdate(): string;
    set onUpdate(value: string);
    resetOnUpdate(): void;
    get onUpdateInput(): string | undefined;
    private _refColumn?;
    get refColumn(): string[];
    set refColumn(value: string[]);
    resetRefColumn(): void;
    get refColumnInput(): string[] | undefined;
    private _rely?;
    get rely(): string;
    set rely(value: string);
    resetRely(): void;
    get relyInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _validate?;
    get validate(): string;
    set validate(value: string);
    resetValidate(): void;
    get validateInput(): string | undefined;
}
export declare class IcebergTableForeignKeyConstraintList extends cdktn.ComplexList {
    internalValue?: IcebergTableForeignKeyConstraint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableForeignKeyConstraintOutputReference;
}
export interface IcebergTablePartitionByBucket {
    /**
    * Name of the column to bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#column IcebergTable#column}
    */
    readonly column: string;
    /**
    * Number of buckets to hash the column values into.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#num_buckets IcebergTable#num_buckets}
    */
    readonly numBuckets: number;
}
export declare function icebergTablePartitionByBucketToTerraform(struct?: IcebergTablePartitionByBucketOutputReference | IcebergTablePartitionByBucket): any;
export declare function icebergTablePartitionByBucketToHclTerraform(struct?: IcebergTablePartitionByBucketOutputReference | IcebergTablePartitionByBucket): any;
export declare class IcebergTablePartitionByBucketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IcebergTablePartitionByBucket | undefined;
    set internalValue(value: IcebergTablePartitionByBucket | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    get columnInput(): string | undefined;
    private _numBuckets?;
    get numBuckets(): number;
    set numBuckets(value: number);
    get numBucketsInput(): number | undefined;
}
export interface IcebergTablePartitionByTruncate {
    /**
    * Name of the column to truncate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#column IcebergTable#column}
    */
    readonly column: string;
    /**
    * Width to truncate the column value to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#width IcebergTable#width}
    */
    readonly width: number;
}
export declare function icebergTablePartitionByTruncateToTerraform(struct?: IcebergTablePartitionByTruncateOutputReference | IcebergTablePartitionByTruncate): any;
export declare function icebergTablePartitionByTruncateToHclTerraform(struct?: IcebergTablePartitionByTruncateOutputReference | IcebergTablePartitionByTruncate): any;
export declare class IcebergTablePartitionByTruncateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IcebergTablePartitionByTruncate | undefined;
    set internalValue(value: IcebergTablePartitionByTruncate | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    get columnInput(): string | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    get widthInput(): number | undefined;
}
export interface IcebergTablePartitionBy {
    /**
    * Partitions the table by the day component of the column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#day IcebergTable#day}
    */
    readonly day?: string;
    /**
    * Partitions the table by the hour component of the column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#hour IcebergTable#hour}
    */
    readonly hour?: string;
    /**
    * Name of the column to use as-is for partitioning.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#identity IcebergTable#identity}
    */
    readonly identity?: string;
    /**
    * Partitions the table by the month component of the column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#month IcebergTable#month}
    */
    readonly month?: string;
    /**
    * Partitions the table by the year component of the column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#year IcebergTable#year}
    */
    readonly year?: string;
    /**
    * bucket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#bucket IcebergTable#bucket}
    */
    readonly bucket?: IcebergTablePartitionByBucket;
    /**
    * truncate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#truncate IcebergTable#truncate}
    */
    readonly truncate?: IcebergTablePartitionByTruncate;
}
export declare function icebergTablePartitionByToTerraform(struct?: IcebergTablePartitionBy | cdktn.IResolvable): any;
export declare function icebergTablePartitionByToHclTerraform(struct?: IcebergTablePartitionBy | cdktn.IResolvable): any;
export declare class IcebergTablePartitionByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTablePartitionBy | cdktn.IResolvable | undefined;
    set internalValue(value: IcebergTablePartitionBy | cdktn.IResolvable | undefined);
    private _day?;
    get day(): string;
    set day(value: string);
    resetDay(): void;
    get dayInput(): string | undefined;
    private _hour?;
    get hour(): string;
    set hour(value: string);
    resetHour(): void;
    get hourInput(): string | undefined;
    private _identity?;
    get identity(): string;
    set identity(value: string);
    resetIdentity(): void;
    get identityInput(): string | undefined;
    private _month?;
    get month(): string;
    set month(value: string);
    resetMonth(): void;
    get monthInput(): string | undefined;
    private _year?;
    get year(): string;
    set year(value: string);
    resetYear(): void;
    get yearInput(): string | undefined;
    private _bucket;
    get bucket(): IcebergTablePartitionByBucketOutputReference;
    putBucket(value: IcebergTablePartitionByBucket): void;
    resetBucket(): void;
    get bucketInput(): IcebergTablePartitionByBucket | undefined;
    private _truncate;
    get truncate(): IcebergTablePartitionByTruncateOutputReference;
    putTruncate(value: IcebergTablePartitionByTruncate): void;
    resetTruncate(): void;
    get truncateInput(): IcebergTablePartitionByTruncate | undefined;
}
export declare class IcebergTablePartitionByList extends cdktn.ComplexList {
    internalValue?: IcebergTablePartitionBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTablePartitionByOutputReference;
}
export interface IcebergTablePrimaryKeyConstraint {
    /**
    * The column(s) the constraint applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#column IcebergTable#column}
    */
    readonly column: string[];
    /**
    * Constraint comment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#comment IcebergTable#comment}
    */
    readonly comment?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether the constraint is deferrable (`true`) or not deferrable (`false`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#deferrable IcebergTable#deferrable}
    */
    readonly deferrable?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether the constraint is enabled (`true`) or disabled (`false`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#enable IcebergTable#enable}
    */
    readonly enable?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether the constraint is enforced (`true`) or not enforced (`false`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#enforced IcebergTable#enforced}
    */
    readonly enforced?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether the constraint is initially deferred (`true`) or initially immediate (`false`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#initially_deferred IcebergTable#initially_deferred}
    */
    readonly initiallyDeferred?: string;
    /**
    * Name of the constraint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#name IcebergTable#name}
    */
    readonly name?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether a constraint in NOVALIDATE mode is taken into account (`true`) or not (`false`) during query rewrite. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#rely IcebergTable#rely}
    */
    readonly rely?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether to validate existing data on the table when the constraint is created (`true`) or skip validation (`false`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#validate IcebergTable#validate}
    */
    readonly validate?: string;
}
export declare function icebergTablePrimaryKeyConstraintToTerraform(struct?: IcebergTablePrimaryKeyConstraintOutputReference | IcebergTablePrimaryKeyConstraint): any;
export declare function icebergTablePrimaryKeyConstraintToHclTerraform(struct?: IcebergTablePrimaryKeyConstraintOutputReference | IcebergTablePrimaryKeyConstraint): any;
export declare class IcebergTablePrimaryKeyConstraintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IcebergTablePrimaryKeyConstraint | undefined;
    set internalValue(value: IcebergTablePrimaryKeyConstraint | undefined);
    private _column?;
    get column(): string[];
    set column(value: string[]);
    get columnInput(): string[] | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _deferrable?;
    get deferrable(): string;
    set deferrable(value: string);
    resetDeferrable(): void;
    get deferrableInput(): string | undefined;
    private _enable?;
    get enable(): string;
    set enable(value: string);
    resetEnable(): void;
    get enableInput(): string | undefined;
    private _enforced?;
    get enforced(): string;
    set enforced(value: string);
    resetEnforced(): void;
    get enforcedInput(): string | undefined;
    private _initiallyDeferred?;
    get initiallyDeferred(): string;
    set initiallyDeferred(value: string);
    resetInitiallyDeferred(): void;
    get initiallyDeferredInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _rely?;
    get rely(): string;
    set rely(value: string);
    resetRely(): void;
    get relyInput(): string | undefined;
    private _validate?;
    get validate(): string;
    set validate(value: string);
    resetValidate(): void;
    get validateInput(): string | undefined;
}
export interface IcebergTableRowAccessPolicy {
    /**
    * Defines which columns are affected by the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#on IcebergTable#on}
    */
    readonly on: string[];
    /**
    * Row access policy name. For more information about this resource, see [docs](./row_access_policy).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#policy_name IcebergTable#policy_name}
    */
    readonly policyName: string;
}
export declare function icebergTableRowAccessPolicyToTerraform(struct?: IcebergTableRowAccessPolicyOutputReference | IcebergTableRowAccessPolicy): any;
export declare function icebergTableRowAccessPolicyToHclTerraform(struct?: IcebergTableRowAccessPolicyOutputReference | IcebergTableRowAccessPolicy): any;
export declare class IcebergTableRowAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IcebergTableRowAccessPolicy | undefined;
    set internalValue(value: IcebergTableRowAccessPolicy | undefined);
    private _on?;
    get on(): string[];
    set on(value: string[]);
    get onInput(): string[] | undefined;
    private _policyName?;
    get policyName(): string;
    set policyName(value: string);
    get policyNameInput(): string | undefined;
}
export interface IcebergTableTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#create IcebergTable#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#delete IcebergTable#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#read IcebergTable#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#update IcebergTable#update}
    */
    readonly update?: string;
}
export declare function icebergTableTimeoutsToTerraform(struct?: IcebergTableTimeouts | cdktn.IResolvable): any;
export declare function icebergTableTimeoutsToHclTerraform(struct?: IcebergTableTimeouts | cdktn.IResolvable): any;
export declare class IcebergTableTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IcebergTableTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: IcebergTableTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface IcebergTableUniqueConstraint {
    /**
    * The column(s) the constraint applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#column IcebergTable#column}
    */
    readonly column: string[];
    /**
    * Constraint comment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#comment IcebergTable#comment}
    */
    readonly comment?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether the constraint is deferrable (`true`) or not deferrable (`false`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#deferrable IcebergTable#deferrable}
    */
    readonly deferrable?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether the constraint is enabled (`true`) or disabled (`false`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#enable IcebergTable#enable}
    */
    readonly enable?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether the constraint is enforced (`true`) or not enforced (`false`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#enforced IcebergTable#enforced}
    */
    readonly enforced?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether the constraint is initially deferred (`true`) or initially immediate (`false`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#initially_deferred IcebergTable#initially_deferred}
    */
    readonly initiallyDeferred?: string;
    /**
    * Name of the constraint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#name IcebergTable#name}
    */
    readonly name?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether a constraint in NOVALIDATE mode is taken into account (`true`) or not (`false`) during query rewrite. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#rely IcebergTable#rely}
    */
    readonly rely?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Whether to validate existing data on the table when the constraint is created (`true`) or skip validation (`false`). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#validate IcebergTable#validate}
    */
    readonly validate?: string;
}
export declare function icebergTableUniqueConstraintToTerraform(struct?: IcebergTableUniqueConstraint | cdktn.IResolvable): any;
export declare function icebergTableUniqueConstraintToHclTerraform(struct?: IcebergTableUniqueConstraint | cdktn.IResolvable): any;
export declare class IcebergTableUniqueConstraintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableUniqueConstraint | cdktn.IResolvable | undefined;
    set internalValue(value: IcebergTableUniqueConstraint | cdktn.IResolvable | undefined);
    private _column?;
    get column(): string[];
    set column(value: string[]);
    get columnInput(): string[] | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _deferrable?;
    get deferrable(): string;
    set deferrable(value: string);
    resetDeferrable(): void;
    get deferrableInput(): string | undefined;
    private _enable?;
    get enable(): string;
    set enable(value: string);
    resetEnable(): void;
    get enableInput(): string | undefined;
    private _enforced?;
    get enforced(): string;
    set enforced(value: string);
    resetEnforced(): void;
    get enforcedInput(): string | undefined;
    private _initiallyDeferred?;
    get initiallyDeferred(): string;
    set initiallyDeferred(value: string);
    resetInitiallyDeferred(): void;
    get initiallyDeferredInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _rely?;
    get rely(): string;
    set rely(value: string);
    resetRely(): void;
    get relyInput(): string | undefined;
    private _validate?;
    get validate(): string;
    set validate(value: string);
    resetValidate(): void;
    get validateInput(): string | undefined;
}
export declare class IcebergTableUniqueConstraintList extends cdktn.ComplexList {
    internalValue?: IcebergTableUniqueConstraint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableUniqueConstraintOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table snowflake_iceberg_table}
*/
export declare class IcebergTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_iceberg_table";
    /**
    * Generates CDKTN code for importing a IcebergTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IcebergTable to import
    * @param importFromId The id of the existing IcebergTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IcebergTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table snowflake_iceberg_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IcebergTableConfig
    */
    constructor(scope: Construct, id: string, config: IcebergTableConfig);
    private _baseLocation?;
    get baseLocation(): string;
    set baseLocation(value: string);
    resetBaseLocation(): void;
    get baseLocationInput(): string | undefined;
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _catalogSync?;
    get catalogSync(): string;
    set catalogSync(value: string);
    resetCatalogSync(): void;
    get catalogSyncInput(): string | undefined;
    private _changeTracking?;
    get changeTracking(): string;
    set changeTracking(value: string);
    resetChangeTracking(): void;
    get changeTrackingInput(): string | undefined;
    private _clusterBy?;
    get clusterBy(): string[];
    set clusterBy(value: string[]);
    resetClusterBy(): void;
    get clusterByInput(): string[] | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _dataRetentionTimeInDays?;
    get dataRetentionTimeInDays(): number;
    set dataRetentionTimeInDays(value: number);
    resetDataRetentionTimeInDays(): void;
    get dataRetentionTimeInDaysInput(): number | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): IcebergTableDescribeOutputList;
    private _enableDataCompaction?;
    get enableDataCompaction(): boolean | cdktn.IResolvable;
    set enableDataCompaction(value: boolean | cdktn.IResolvable);
    resetEnableDataCompaction(): void;
    get enableDataCompactionInput(): boolean | cdktn.IResolvable | undefined;
    private _enableIcebergMergeOnRead?;
    get enableIcebergMergeOnRead(): boolean | cdktn.IResolvable;
    set enableIcebergMergeOnRead(value: boolean | cdktn.IResolvable);
    resetEnableIcebergMergeOnRead(): void;
    get enableIcebergMergeOnReadInput(): boolean | cdktn.IResolvable | undefined;
    private _errorLogging?;
    get errorLogging(): string;
    set errorLogging(value: string);
    resetErrorLogging(): void;
    get errorLoggingInput(): string | undefined;
    private _externalVolume?;
    get externalVolume(): string;
    set externalVolume(value: string);
    resetExternalVolume(): void;
    get externalVolumeInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _icebergVersion?;
    get icebergVersion(): number;
    set icebergVersion(value: number);
    resetIcebergVersion(): void;
    get icebergVersionInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxDataExtensionTimeInDays?;
    get maxDataExtensionTimeInDays(): number;
    set maxDataExtensionTimeInDays(value: number);
    resetMaxDataExtensionTimeInDays(): void;
    get maxDataExtensionTimeInDaysInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): IcebergTableParametersList;
    private _pathLayout?;
    get pathLayout(): string;
    set pathLayout(value: string);
    resetPathLayout(): void;
    get pathLayoutInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): IcebergTableShowOutputList;
    private _storageSerializationPolicy?;
    get storageSerializationPolicy(): string;
    set storageSerializationPolicy(value: string);
    resetStorageSerializationPolicy(): void;
    get storageSerializationPolicyInput(): string | undefined;
    private _targetFileSize?;
    get targetFileSize(): string;
    set targetFileSize(value: string);
    resetTargetFileSize(): void;
    get targetFileSizeInput(): string | undefined;
    private _aggregationPolicy;
    get aggregationPolicy(): IcebergTableAggregationPolicyOutputReference;
    putAggregationPolicy(value: IcebergTableAggregationPolicy): void;
    resetAggregationPolicy(): void;
    get aggregationPolicyInput(): IcebergTableAggregationPolicy | undefined;
    private _checkConstraint;
    get checkConstraint(): IcebergTableCheckConstraintList;
    putCheckConstraint(value: IcebergTableCheckConstraint[] | cdktn.IResolvable): void;
    resetCheckConstraint(): void;
    get checkConstraintInput(): cdktn.IResolvable | IcebergTableCheckConstraint[] | undefined;
    private _column;
    get column(): IcebergTableColumnList;
    putColumn(value: IcebergTableColumn[] | cdktn.IResolvable): void;
    get columnInput(): cdktn.IResolvable | IcebergTableColumn[] | undefined;
    private _foreignKeyConstraint;
    get foreignKeyConstraint(): IcebergTableForeignKeyConstraintList;
    putForeignKeyConstraint(value: IcebergTableForeignKeyConstraint[] | cdktn.IResolvable): void;
    resetForeignKeyConstraint(): void;
    get foreignKeyConstraintInput(): cdktn.IResolvable | IcebergTableForeignKeyConstraint[] | undefined;
    private _partitionBy;
    get partitionBy(): IcebergTablePartitionByList;
    putPartitionBy(value: IcebergTablePartitionBy[] | cdktn.IResolvable): void;
    resetPartitionBy(): void;
    get partitionByInput(): cdktn.IResolvable | IcebergTablePartitionBy[] | undefined;
    private _primaryKeyConstraint;
    get primaryKeyConstraint(): IcebergTablePrimaryKeyConstraintOutputReference;
    putPrimaryKeyConstraint(value: IcebergTablePrimaryKeyConstraint): void;
    resetPrimaryKeyConstraint(): void;
    get primaryKeyConstraintInput(): IcebergTablePrimaryKeyConstraint | undefined;
    private _rowAccessPolicy;
    get rowAccessPolicy(): IcebergTableRowAccessPolicyOutputReference;
    putRowAccessPolicy(value: IcebergTableRowAccessPolicy): void;
    resetRowAccessPolicy(): void;
    get rowAccessPolicyInput(): IcebergTableRowAccessPolicy | undefined;
    private _timeouts;
    get timeouts(): IcebergTableTimeoutsOutputReference;
    putTimeouts(value: IcebergTableTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | IcebergTableTimeouts | undefined;
    private _uniqueConstraint;
    get uniqueConstraint(): IcebergTableUniqueConstraintList;
    putUniqueConstraint(value: IcebergTableUniqueConstraint[] | cdktn.IResolvable): void;
    resetUniqueConstraint(): void;
    get uniqueConstraintInput(): cdktn.IResolvable | IcebergTableUniqueConstraint[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
