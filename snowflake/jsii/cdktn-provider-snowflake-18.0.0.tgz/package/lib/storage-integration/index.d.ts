/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StorageIntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * (Default: ``) Specifies the ID for your Office 365 tenant that the allowed and blocked storage accounts belong to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#azure_tenant_id StorageIntegration#azure_tenant_id}
    */
    readonly azureTenantId?: string;
    /**
    * (Default: ``) Specifies a comment for the storage integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#comment StorageIntegration#comment}
    */
    readonly comment?: string;
    /**
    * (Default: `true`)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#enabled StorageIntegration#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#id StorageIntegration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * String that specifies the identifier (i.e. name) for the integration; must be unique in your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#name StorageIntegration#name}
    */
    readonly name: string;
    /**
    * Explicitly limits external stages that use the integration to reference one or more storage locations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#storage_allowed_locations StorageIntegration#storage_allowed_locations}
    */
    readonly storageAllowedLocations: string[];
    /**
    * Optionally specifies an external ID that Snowflake uses to establish a trust relationship with AWS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#storage_aws_external_id StorageIntegration#storage_aws_external_id}
    */
    readonly storageAwsExternalId?: string;
    /**
    * "bucket-owner-full-control" Enables support for AWS access control lists (ACLs) to grant the bucket owner full control.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#storage_aws_object_acl StorageIntegration#storage_aws_object_acl}
    */
    readonly storageAwsObjectAcl?: string;
    /**
    * (Default: ``) Specifies the Amazon Resource Name (ARN) of the AWS identity and access management (IAM) role that grants privileges on the S3 bucket containing your data files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#storage_aws_role_arn StorageIntegration#storage_aws_role_arn}
    */
    readonly storageAwsRoleArn?: string;
    /**
    * Explicitly prohibits external stages that use the integration from referencing one or more storage locations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#storage_blocked_locations StorageIntegration#storage_blocked_locations}
    */
    readonly storageBlockedLocations?: string[];
    /**
    * Specifies the storage provider for the integration. Valid options are: `S3` | `S3GOV` | `S3CHINA` | `GCS` | `AZURE`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#storage_provider StorageIntegration#storage_provider}
    */
    readonly storageProvider: string;
    /**
    * (Default: `EXTERNAL_STAGE`) Specifies the type of the storage integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#type StorageIntegration#type}
    */
    readonly type?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether to use outbound private connectivity to harden the security posture. Supported for AWS S3 and Azure storage providers. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#use_privatelink_endpoint StorageIntegration#use_privatelink_endpoint}
    */
    readonly usePrivatelinkEndpoint?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#timeouts StorageIntegration#timeouts}
    */
    readonly timeouts?: StorageIntegrationTimeouts;
}
export interface StorageIntegrationDescribeOutputAzureConsentUrl {
}
export declare function storageIntegrationDescribeOutputAzureConsentUrlToTerraform(struct?: StorageIntegrationDescribeOutputAzureConsentUrl): any;
export declare function storageIntegrationDescribeOutputAzureConsentUrlToHclTerraform(struct?: StorageIntegrationDescribeOutputAzureConsentUrl): any;
export declare class StorageIntegrationDescribeOutputAzureConsentUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationDescribeOutputAzureConsentUrl | undefined;
    set internalValue(value: StorageIntegrationDescribeOutputAzureConsentUrl | undefined);
    get default(): string;
    get name(): string;
    get type(): string;
    get value(): string;
}
export declare class StorageIntegrationDescribeOutputAzureConsentUrlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationDescribeOutputAzureConsentUrlOutputReference;
}
export interface StorageIntegrationDescribeOutputAzureMultiTenantAppName {
}
export declare function storageIntegrationDescribeOutputAzureMultiTenantAppNameToTerraform(struct?: StorageIntegrationDescribeOutputAzureMultiTenantAppName): any;
export declare function storageIntegrationDescribeOutputAzureMultiTenantAppNameToHclTerraform(struct?: StorageIntegrationDescribeOutputAzureMultiTenantAppName): any;
export declare class StorageIntegrationDescribeOutputAzureMultiTenantAppNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationDescribeOutputAzureMultiTenantAppName | undefined;
    set internalValue(value: StorageIntegrationDescribeOutputAzureMultiTenantAppName | undefined);
    get default(): string;
    get name(): string;
    get type(): string;
    get value(): string;
}
export declare class StorageIntegrationDescribeOutputAzureMultiTenantAppNameList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationDescribeOutputAzureMultiTenantAppNameOutputReference;
}
export interface StorageIntegrationDescribeOutputComment {
}
export declare function storageIntegrationDescribeOutputCommentToTerraform(struct?: StorageIntegrationDescribeOutputComment): any;
export declare function storageIntegrationDescribeOutputCommentToHclTerraform(struct?: StorageIntegrationDescribeOutputComment): any;
export declare class StorageIntegrationDescribeOutputCommentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationDescribeOutputComment | undefined;
    set internalValue(value: StorageIntegrationDescribeOutputComment | undefined);
    get default(): string;
    get name(): string;
    get type(): string;
    get value(): string;
}
export declare class StorageIntegrationDescribeOutputCommentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationDescribeOutputCommentOutputReference;
}
export interface StorageIntegrationDescribeOutputEnabled {
}
export declare function storageIntegrationDescribeOutputEnabledToTerraform(struct?: StorageIntegrationDescribeOutputEnabled): any;
export declare function storageIntegrationDescribeOutputEnabledToHclTerraform(struct?: StorageIntegrationDescribeOutputEnabled): any;
export declare class StorageIntegrationDescribeOutputEnabledOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationDescribeOutputEnabled | undefined;
    set internalValue(value: StorageIntegrationDescribeOutputEnabled | undefined);
    get default(): string;
    get name(): string;
    get type(): string;
    get value(): string;
}
export declare class StorageIntegrationDescribeOutputEnabledList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationDescribeOutputEnabledOutputReference;
}
export interface StorageIntegrationDescribeOutputStorageAllowedLocations {
}
export declare function storageIntegrationDescribeOutputStorageAllowedLocationsToTerraform(struct?: StorageIntegrationDescribeOutputStorageAllowedLocations): any;
export declare function storageIntegrationDescribeOutputStorageAllowedLocationsToHclTerraform(struct?: StorageIntegrationDescribeOutputStorageAllowedLocations): any;
export declare class StorageIntegrationDescribeOutputStorageAllowedLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationDescribeOutputStorageAllowedLocations | undefined;
    set internalValue(value: StorageIntegrationDescribeOutputStorageAllowedLocations | undefined);
    get default(): string;
    get name(): string;
    get type(): string;
    get value(): string;
}
export declare class StorageIntegrationDescribeOutputStorageAllowedLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationDescribeOutputStorageAllowedLocationsOutputReference;
}
export interface StorageIntegrationDescribeOutputStorageAwsExternalId {
}
export declare function storageIntegrationDescribeOutputStorageAwsExternalIdToTerraform(struct?: StorageIntegrationDescribeOutputStorageAwsExternalId): any;
export declare function storageIntegrationDescribeOutputStorageAwsExternalIdToHclTerraform(struct?: StorageIntegrationDescribeOutputStorageAwsExternalId): any;
export declare class StorageIntegrationDescribeOutputStorageAwsExternalIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationDescribeOutputStorageAwsExternalId | undefined;
    set internalValue(value: StorageIntegrationDescribeOutputStorageAwsExternalId | undefined);
    get default(): string;
    get name(): string;
    get type(): string;
    get value(): string;
}
export declare class StorageIntegrationDescribeOutputStorageAwsExternalIdList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationDescribeOutputStorageAwsExternalIdOutputReference;
}
export interface StorageIntegrationDescribeOutputStorageAwsIamUserArn {
}
export declare function storageIntegrationDescribeOutputStorageAwsIamUserArnToTerraform(struct?: StorageIntegrationDescribeOutputStorageAwsIamUserArn): any;
export declare function storageIntegrationDescribeOutputStorageAwsIamUserArnToHclTerraform(struct?: StorageIntegrationDescribeOutputStorageAwsIamUserArn): any;
export declare class StorageIntegrationDescribeOutputStorageAwsIamUserArnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationDescribeOutputStorageAwsIamUserArn | undefined;
    set internalValue(value: StorageIntegrationDescribeOutputStorageAwsIamUserArn | undefined);
    get default(): string;
    get name(): string;
    get type(): string;
    get value(): string;
}
export declare class StorageIntegrationDescribeOutputStorageAwsIamUserArnList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationDescribeOutputStorageAwsIamUserArnOutputReference;
}
export interface StorageIntegrationDescribeOutputStorageAwsObjectAcl {
}
export declare function storageIntegrationDescribeOutputStorageAwsObjectAclToTerraform(struct?: StorageIntegrationDescribeOutputStorageAwsObjectAcl): any;
export declare function storageIntegrationDescribeOutputStorageAwsObjectAclToHclTerraform(struct?: StorageIntegrationDescribeOutputStorageAwsObjectAcl): any;
export declare class StorageIntegrationDescribeOutputStorageAwsObjectAclOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationDescribeOutputStorageAwsObjectAcl | undefined;
    set internalValue(value: StorageIntegrationDescribeOutputStorageAwsObjectAcl | undefined);
    get default(): string;
    get name(): string;
    get type(): string;
    get value(): string;
}
export declare class StorageIntegrationDescribeOutputStorageAwsObjectAclList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationDescribeOutputStorageAwsObjectAclOutputReference;
}
export interface StorageIntegrationDescribeOutputStorageAwsRoleArn {
}
export declare function storageIntegrationDescribeOutputStorageAwsRoleArnToTerraform(struct?: StorageIntegrationDescribeOutputStorageAwsRoleArn): any;
export declare function storageIntegrationDescribeOutputStorageAwsRoleArnToHclTerraform(struct?: StorageIntegrationDescribeOutputStorageAwsRoleArn): any;
export declare class StorageIntegrationDescribeOutputStorageAwsRoleArnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationDescribeOutputStorageAwsRoleArn | undefined;
    set internalValue(value: StorageIntegrationDescribeOutputStorageAwsRoleArn | undefined);
    get default(): string;
    get name(): string;
    get type(): string;
    get value(): string;
}
export declare class StorageIntegrationDescribeOutputStorageAwsRoleArnList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationDescribeOutputStorageAwsRoleArnOutputReference;
}
export interface StorageIntegrationDescribeOutputStorageBlockedLocations {
}
export declare function storageIntegrationDescribeOutputStorageBlockedLocationsToTerraform(struct?: StorageIntegrationDescribeOutputStorageBlockedLocations): any;
export declare function storageIntegrationDescribeOutputStorageBlockedLocationsToHclTerraform(struct?: StorageIntegrationDescribeOutputStorageBlockedLocations): any;
export declare class StorageIntegrationDescribeOutputStorageBlockedLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationDescribeOutputStorageBlockedLocations | undefined;
    set internalValue(value: StorageIntegrationDescribeOutputStorageBlockedLocations | undefined);
    get default(): string;
    get name(): string;
    get type(): string;
    get value(): string;
}
export declare class StorageIntegrationDescribeOutputStorageBlockedLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationDescribeOutputStorageBlockedLocationsOutputReference;
}
export interface StorageIntegrationDescribeOutputStorageGcpServiceAccount {
}
export declare function storageIntegrationDescribeOutputStorageGcpServiceAccountToTerraform(struct?: StorageIntegrationDescribeOutputStorageGcpServiceAccount): any;
export declare function storageIntegrationDescribeOutputStorageGcpServiceAccountToHclTerraform(struct?: StorageIntegrationDescribeOutputStorageGcpServiceAccount): any;
export declare class StorageIntegrationDescribeOutputStorageGcpServiceAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationDescribeOutputStorageGcpServiceAccount | undefined;
    set internalValue(value: StorageIntegrationDescribeOutputStorageGcpServiceAccount | undefined);
    get default(): string;
    get name(): string;
    get type(): string;
    get value(): string;
}
export declare class StorageIntegrationDescribeOutputStorageGcpServiceAccountList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationDescribeOutputStorageGcpServiceAccountOutputReference;
}
export interface StorageIntegrationDescribeOutputStorageProvider {
}
export declare function storageIntegrationDescribeOutputStorageProviderToTerraform(struct?: StorageIntegrationDescribeOutputStorageProvider): any;
export declare function storageIntegrationDescribeOutputStorageProviderToHclTerraform(struct?: StorageIntegrationDescribeOutputStorageProvider): any;
export declare class StorageIntegrationDescribeOutputStorageProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationDescribeOutputStorageProvider | undefined;
    set internalValue(value: StorageIntegrationDescribeOutputStorageProvider | undefined);
    get default(): string;
    get name(): string;
    get type(): string;
    get value(): string;
}
export declare class StorageIntegrationDescribeOutputStorageProviderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationDescribeOutputStorageProviderOutputReference;
}
export interface StorageIntegrationDescribeOutputUsePrivatelinkEndpoint {
}
export declare function storageIntegrationDescribeOutputUsePrivatelinkEndpointToTerraform(struct?: StorageIntegrationDescribeOutputUsePrivatelinkEndpoint): any;
export declare function storageIntegrationDescribeOutputUsePrivatelinkEndpointToHclTerraform(struct?: StorageIntegrationDescribeOutputUsePrivatelinkEndpoint): any;
export declare class StorageIntegrationDescribeOutputUsePrivatelinkEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationDescribeOutputUsePrivatelinkEndpoint | undefined;
    set internalValue(value: StorageIntegrationDescribeOutputUsePrivatelinkEndpoint | undefined);
    get default(): string;
    get name(): string;
    get type(): string;
    get value(): string;
}
export declare class StorageIntegrationDescribeOutputUsePrivatelinkEndpointList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationDescribeOutputUsePrivatelinkEndpointOutputReference;
}
export interface StorageIntegrationDescribeOutput {
}
export declare function storageIntegrationDescribeOutputToTerraform(struct?: StorageIntegrationDescribeOutput): any;
export declare function storageIntegrationDescribeOutputToHclTerraform(struct?: StorageIntegrationDescribeOutput): any;
export declare class StorageIntegrationDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationDescribeOutput | undefined;
    set internalValue(value: StorageIntegrationDescribeOutput | undefined);
    private _azureConsentUrl;
    get azureConsentUrl(): StorageIntegrationDescribeOutputAzureConsentUrlList;
    private _azureMultiTenantAppName;
    get azureMultiTenantAppName(): StorageIntegrationDescribeOutputAzureMultiTenantAppNameList;
    private _comment;
    get comment(): StorageIntegrationDescribeOutputCommentList;
    private _enabled;
    get enabled(): StorageIntegrationDescribeOutputEnabledList;
    private _storageAllowedLocations;
    get storageAllowedLocations(): StorageIntegrationDescribeOutputStorageAllowedLocationsList;
    private _storageAwsExternalId;
    get storageAwsExternalId(): StorageIntegrationDescribeOutputStorageAwsExternalIdList;
    private _storageAwsIamUserArn;
    get storageAwsIamUserArn(): StorageIntegrationDescribeOutputStorageAwsIamUserArnList;
    private _storageAwsObjectAcl;
    get storageAwsObjectAcl(): StorageIntegrationDescribeOutputStorageAwsObjectAclList;
    private _storageAwsRoleArn;
    get storageAwsRoleArn(): StorageIntegrationDescribeOutputStorageAwsRoleArnList;
    private _storageBlockedLocations;
    get storageBlockedLocations(): StorageIntegrationDescribeOutputStorageBlockedLocationsList;
    private _storageGcpServiceAccount;
    get storageGcpServiceAccount(): StorageIntegrationDescribeOutputStorageGcpServiceAccountList;
    private _storageProvider;
    get storageProvider(): StorageIntegrationDescribeOutputStorageProviderList;
    private _usePrivatelinkEndpoint;
    get usePrivatelinkEndpoint(): StorageIntegrationDescribeOutputUsePrivatelinkEndpointList;
}
export declare class StorageIntegrationDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationDescribeOutputOutputReference;
}
export interface StorageIntegrationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#create StorageIntegration#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#delete StorageIntegration#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#read StorageIntegration#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#update StorageIntegration#update}
    */
    readonly update?: string;
}
export declare function storageIntegrationTimeoutsToTerraform(struct?: StorageIntegrationTimeouts | cdktn.IResolvable): any;
export declare function storageIntegrationTimeoutsToHclTerraform(struct?: StorageIntegrationTimeouts | cdktn.IResolvable): any;
export declare class StorageIntegrationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageIntegrationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: StorageIntegrationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration snowflake_storage_integration}
*/
export declare class StorageIntegration extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_storage_integration";
    /**
    * Generates CDKTN code for importing a StorageIntegration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StorageIntegration to import
    * @param importFromId The id of the existing StorageIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StorageIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/storage_integration snowflake_storage_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StorageIntegrationConfig
    */
    constructor(scope: Construct, id: string, config: StorageIntegrationConfig);
    get azureConsentUrl(): string;
    get azureMultiTenantAppName(): string;
    private _azureTenantId?;
    get azureTenantId(): string;
    set azureTenantId(value: string);
    resetAzureTenantId(): void;
    get azureTenantIdInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get createdOn(): string;
    private _describeOutput;
    get describeOutput(): StorageIntegrationDescribeOutputList;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _storageAllowedLocations?;
    get storageAllowedLocations(): string[];
    set storageAllowedLocations(value: string[]);
    get storageAllowedLocationsInput(): string[] | undefined;
    private _storageAwsExternalId?;
    get storageAwsExternalId(): string;
    set storageAwsExternalId(value: string);
    resetStorageAwsExternalId(): void;
    get storageAwsExternalIdInput(): string | undefined;
    get storageAwsIamUserArn(): string;
    private _storageAwsObjectAcl?;
    get storageAwsObjectAcl(): string;
    set storageAwsObjectAcl(value: string);
    resetStorageAwsObjectAcl(): void;
    get storageAwsObjectAclInput(): string | undefined;
    private _storageAwsRoleArn?;
    get storageAwsRoleArn(): string;
    set storageAwsRoleArn(value: string);
    resetStorageAwsRoleArn(): void;
    get storageAwsRoleArnInput(): string | undefined;
    private _storageBlockedLocations?;
    get storageBlockedLocations(): string[];
    set storageBlockedLocations(value: string[]);
    resetStorageBlockedLocations(): void;
    get storageBlockedLocationsInput(): string[] | undefined;
    get storageGcpServiceAccount(): string;
    private _storageProvider?;
    get storageProvider(): string;
    set storageProvider(value: string);
    get storageProviderInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _usePrivatelinkEndpoint?;
    get usePrivatelinkEndpoint(): string;
    set usePrivatelinkEndpoint(value: string);
    resetUsePrivatelinkEndpoint(): void;
    get usePrivatelinkEndpointInput(): string | undefined;
    private _timeouts;
    get timeouts(): StorageIntegrationTimeoutsOutputReference;
    putTimeouts(value: StorageIntegrationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | StorageIntegrationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
