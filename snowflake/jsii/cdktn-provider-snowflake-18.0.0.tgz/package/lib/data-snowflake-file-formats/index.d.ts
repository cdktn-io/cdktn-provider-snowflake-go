/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeFileFormatsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/file_formats#id DataSnowflakeFileFormats#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/file_formats#like DataSnowflakeFileFormats#like}
    */
    readonly like?: string;
    /**
    * (Default: `true`) Runs DESC FILE FORMAT for each file format returned by SHOW FILE FORMATS. The output of describe is saved to the describe_output field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/file_formats#with_describe DataSnowflakeFileFormats#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * in block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/file_formats#in DataSnowflakeFileFormats#in}
    */
    readonly in?: DataSnowflakeFileFormatsIn;
}
export interface DataSnowflakeFileFormatsFileFormatsDescribeOutput {
}
export declare function dataSnowflakeFileFormatsFileFormatsDescribeOutputToTerraform(struct?: DataSnowflakeFileFormatsFileFormatsDescribeOutput): any;
export declare function dataSnowflakeFileFormatsFileFormatsDescribeOutputToHclTerraform(struct?: DataSnowflakeFileFormatsFileFormatsDescribeOutput): any;
export declare class DataSnowflakeFileFormatsFileFormatsDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeFileFormatsFileFormatsDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeFileFormatsFileFormatsDescribeOutput | undefined);
    get allowDuplicate(): cdktn.IResolvable;
    get binaryAsText(): cdktn.IResolvable;
    get binaryFormat(): string;
    get compression(): string;
    get dateFormat(): string;
    get disableAutoConvert(): cdktn.IResolvable;
    get emptyFieldAsNull(): cdktn.IResolvable;
    get enableOctal(): cdktn.IResolvable;
    get encoding(): string;
    get errorOnColumnCountMismatch(): cdktn.IResolvable;
    get escape(): string;
    get escapeUnenclosedField(): string;
    get fieldDelimiter(): string;
    get fieldOptionallyEnclosedBy(): string;
    get fileExtension(): string;
    get id(): string;
    get ignoreUtf8Errors(): cdktn.IResolvable;
    get multiLine(): cdktn.IResolvable;
    get nullIf(): string[];
    get parseHeader(): cdktn.IResolvable;
    get preserveSpace(): cdktn.IResolvable;
    get recordDelimiter(): string;
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipBlankLines(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get skipHeader(): number;
    get stripNullValues(): cdktn.IResolvable;
    get stripOuterArray(): cdktn.IResolvable;
    get stripOuterElement(): cdktn.IResolvable;
    get timeFormat(): string;
    get timestampFormat(): string;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
    get useLogicalType(): cdktn.IResolvable;
    get useVectorizedScanner(): cdktn.IResolvable;
    get validateUtf8(): cdktn.IResolvable;
}
export declare class DataSnowflakeFileFormatsFileFormatsDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeFileFormatsFileFormatsDescribeOutputOutputReference;
}
export interface DataSnowflakeFileFormatsFileFormatsShowOutput {
}
export declare function dataSnowflakeFileFormatsFileFormatsShowOutputToTerraform(struct?: DataSnowflakeFileFormatsFileFormatsShowOutput): any;
export declare function dataSnowflakeFileFormatsFileFormatsShowOutputToHclTerraform(struct?: DataSnowflakeFileFormatsFileFormatsShowOutput): any;
export declare class DataSnowflakeFileFormatsFileFormatsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeFileFormatsFileFormatsShowOutput | undefined;
    set internalValue(value: DataSnowflakeFileFormatsFileFormatsShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get formatOptions(): string;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get schemaName(): string;
    get type(): string;
}
export declare class DataSnowflakeFileFormatsFileFormatsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeFileFormatsFileFormatsShowOutputOutputReference;
}
export interface DataSnowflakeFileFormatsFileFormats {
}
export declare function dataSnowflakeFileFormatsFileFormatsToTerraform(struct?: DataSnowflakeFileFormatsFileFormats): any;
export declare function dataSnowflakeFileFormatsFileFormatsToHclTerraform(struct?: DataSnowflakeFileFormatsFileFormats): any;
export declare class DataSnowflakeFileFormatsFileFormatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeFileFormatsFileFormats | undefined;
    set internalValue(value: DataSnowflakeFileFormatsFileFormats | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeFileFormatsFileFormatsDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeFileFormatsFileFormatsShowOutputList;
}
export declare class DataSnowflakeFileFormatsFileFormatsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeFileFormatsFileFormatsOutputReference;
}
export interface DataSnowflakeFileFormatsIn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/file_formats#account DataSnowflakeFileFormats#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the current database in use or for a specified database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/file_formats#database DataSnowflakeFileFormats#database}
    */
    readonly database?: string;
    /**
    * Returns records for the current schema in use or a specified schema. Use fully qualified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/file_formats#schema DataSnowflakeFileFormats#schema}
    */
    readonly schema?: string;
}
export declare function dataSnowflakeFileFormatsInToTerraform(struct?: DataSnowflakeFileFormatsInOutputReference | DataSnowflakeFileFormatsIn): any;
export declare function dataSnowflakeFileFormatsInToHclTerraform(struct?: DataSnowflakeFileFormatsInOutputReference | DataSnowflakeFileFormatsIn): any;
export declare class DataSnowflakeFileFormatsInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeFileFormatsIn | undefined;
    set internalValue(value: DataSnowflakeFileFormatsIn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/file_formats snowflake_file_formats}
*/
export declare class DataSnowflakeFileFormats extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_file_formats";
    /**
    * Generates CDKTN code for importing a DataSnowflakeFileFormats resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeFileFormats to import
    * @param importFromId The id of the existing DataSnowflakeFileFormats that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/file_formats#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeFileFormats to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/file_formats snowflake_file_formats} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeFileFormatsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeFileFormatsConfig);
    private _fileFormats;
    get fileFormats(): DataSnowflakeFileFormatsFileFormatsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _in;
    get in(): DataSnowflakeFileFormatsInOutputReference;
    putIn(value: DataSnowflakeFileFormatsIn): void;
    resetIn(): void;
    get inInput(): DataSnowflakeFileFormatsIn | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
