/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeMcpServersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/mcp_servers#id DataSnowflakeMcpServers#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/mcp_servers#like DataSnowflakeMcpServers#like}
    */
    readonly like?: string;
    /**
    * (Default: `true`) Runs DESC MCP SERVER for each MCP server returned by SHOW MCP SERVERS. The output of describe is saved to the describe_output field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/mcp_servers#with_describe DataSnowflakeMcpServers#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * in block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/mcp_servers#in DataSnowflakeMcpServers#in}
    */
    readonly in?: DataSnowflakeMcpServersIn;
}
export interface DataSnowflakeMcpServersMcpServersDescribeOutput {
}
export declare function dataSnowflakeMcpServersMcpServersDescribeOutputToTerraform(struct?: DataSnowflakeMcpServersMcpServersDescribeOutput): any;
export declare function dataSnowflakeMcpServersMcpServersDescribeOutputToHclTerraform(struct?: DataSnowflakeMcpServersMcpServersDescribeOutput): any;
export declare class DataSnowflakeMcpServersMcpServersDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeMcpServersMcpServersDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeMcpServersMcpServersDescribeOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get name(): string;
    get owner(): string;
    get schemaName(): string;
    get serverSpec(): string;
}
export declare class DataSnowflakeMcpServersMcpServersDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeMcpServersMcpServersDescribeOutputOutputReference;
}
export interface DataSnowflakeMcpServersMcpServersShowOutput {
}
export declare function dataSnowflakeMcpServersMcpServersShowOutputToTerraform(struct?: DataSnowflakeMcpServersMcpServersShowOutput): any;
export declare function dataSnowflakeMcpServersMcpServersShowOutputToHclTerraform(struct?: DataSnowflakeMcpServersMcpServersShowOutput): any;
export declare class DataSnowflakeMcpServersMcpServersShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeMcpServersMcpServersShowOutput | undefined;
    set internalValue(value: DataSnowflakeMcpServersMcpServersShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get name(): string;
    get owner(): string;
    get schemaName(): string;
}
export declare class DataSnowflakeMcpServersMcpServersShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeMcpServersMcpServersShowOutputOutputReference;
}
export interface DataSnowflakeMcpServersMcpServers {
}
export declare function dataSnowflakeMcpServersMcpServersToTerraform(struct?: DataSnowflakeMcpServersMcpServers): any;
export declare function dataSnowflakeMcpServersMcpServersToHclTerraform(struct?: DataSnowflakeMcpServersMcpServers): any;
export declare class DataSnowflakeMcpServersMcpServersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeMcpServersMcpServers | undefined;
    set internalValue(value: DataSnowflakeMcpServersMcpServers | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeMcpServersMcpServersDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeMcpServersMcpServersShowOutputList;
}
export declare class DataSnowflakeMcpServersMcpServersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeMcpServersMcpServersOutputReference;
}
export interface DataSnowflakeMcpServersIn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/mcp_servers#account DataSnowflakeMcpServers#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the current database in use or for a specified database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/mcp_servers#database DataSnowflakeMcpServers#database}
    */
    readonly database?: string;
    /**
    * Returns records for the current schema in use or a specified schema. Use fully qualified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/mcp_servers#schema DataSnowflakeMcpServers#schema}
    */
    readonly schema?: string;
}
export declare function dataSnowflakeMcpServersInToTerraform(struct?: DataSnowflakeMcpServersInOutputReference | DataSnowflakeMcpServersIn): any;
export declare function dataSnowflakeMcpServersInToHclTerraform(struct?: DataSnowflakeMcpServersInOutputReference | DataSnowflakeMcpServersIn): any;
export declare class DataSnowflakeMcpServersInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeMcpServersIn | undefined;
    set internalValue(value: DataSnowflakeMcpServersIn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/mcp_servers snowflake_mcp_servers}
*/
export declare class DataSnowflakeMcpServers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_mcp_servers";
    /**
    * Generates CDKTN code for importing a DataSnowflakeMcpServers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeMcpServers to import
    * @param importFromId The id of the existing DataSnowflakeMcpServers that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/mcp_servers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeMcpServers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/data-sources/mcp_servers snowflake_mcp_servers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeMcpServersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeMcpServersConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _mcpServers;
    get mcpServers(): DataSnowflakeMcpServersMcpServersList;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _in;
    get in(): DataSnowflakeMcpServersInOutputReference;
    putIn(value: DataSnowflakeMcpServersIn): void;
    resetIn(): void;
    get inInput(): DataSnowflakeMcpServersIn | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
