/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WarehouseInteractiveConfig extends cdktn.TerraformMetaArguments {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether to automatically resume an interactive warehouse when a SQL statement (e.g. query) is submitted to it. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#auto_resume WarehouseInteractive#auto_resume}
    */
    readonly autoResume?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`-1`)) Specifies the number of seconds of inactivity after which an interactive warehouse is automatically suspended.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#auto_suspend WarehouseInteractive#auto_suspend}
    */
    readonly autoSuspend?: number;
    /**
    * Specifies a comment for the interactive warehouse.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#comment WarehouseInteractive#comment}
    */
    readonly comment?: string;
    /**
    * Specifies the name of the fallback warehouse for the interactive warehouse. For more information about this resource, see [docs](./warehouse).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#fallback_warehouse WarehouseInteractive#fallback_warehouse}
    */
    readonly fallbackWarehouse?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#id WarehouseInteractive#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies whether the interactive warehouse is created initially in the ‘Suspended’ state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#initially_suspended WarehouseInteractive#initially_suspended}
    */
    readonly initiallySuspended?: boolean | cdktn.IResolvable;
    /**
    * Specifies the maximum number of server clusters for the interactive warehouse.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#max_cluster_count WarehouseInteractive#max_cluster_count}
    */
    readonly maxClusterCount?: number;
    /**
    * Object parameter that specifies the concurrency level for SQL statements (i.e. queries and DML) executed by an interactive warehouse.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#max_concurrency_level WarehouseInteractive#max_concurrency_level}
    */
    readonly maxConcurrencyLevel?: number;
    /**
    * Specifies the minimum number of server clusters for the interactive warehouse (only applies to multi-cluster warehouses).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#min_cluster_count WarehouseInteractive#min_cluster_count}
    */
    readonly minClusterCount?: number;
    /**
    * Identifier for the interactive warehouse; must be unique for your account. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#name WarehouseInteractive#name}
    */
    readonly name: string;
    /**
    * Specifies the name of a resource monitor that is explicitly assigned to the interactive warehouse. For more information about this resource, see [docs](./resource_monitor).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#resource_monitor WarehouseInteractive#resource_monitor}
    */
    readonly resourceMonitor?: string;
    /**
    * Object parameter that specifies the time, in seconds, a SQL statement (query, DDL, DML, etc.) can be queued on an interactive warehouse before it is canceled by the system.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#statement_queued_timeout_in_seconds WarehouseInteractive#statement_queued_timeout_in_seconds}
    */
    readonly statementQueuedTimeoutInSeconds?: number;
    /**
    * Specifies the time, in seconds, after which a running SQL statement (query, DDL, DML, etc.) is canceled by the system.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#statement_timeout_in_seconds WarehouseInteractive#statement_timeout_in_seconds}
    */
    readonly statementTimeoutInSeconds?: number;
    /**
    * Specifies the fully qualified names of the tables associated with the interactive warehouse. Changes are applied incrementally (ADD TABLES / DROP TABLES) rather than by full re-association.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#tables WarehouseInteractive#tables}
    */
    readonly tables?: string[];
    /**
    * Specifies the size of the interactive warehouse. Valid values are (case-insensitive): `XSMALL` | `X-SMALL` | `SMALL` | `MEDIUM` | `LARGE` | `XLARGE` | `X-LARGE` | `XXLARGE` | `X2LARGE` | `2X-LARGE` | `XXXLARGE` | `X3LARGE` | `3X-LARGE` | `X4LARGE` | `4X-LARGE` | `X5LARGE` | `5X-LARGE` | `X6LARGE` | `6X-LARGE`. Note: changing the size briefly suspends and resumes the warehouse to apply the resize (an interactive warehouse cannot be resized while running); removing the size from config will result in the resource recreation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#warehouse_size WarehouseInteractive#warehouse_size}
    */
    readonly warehouseSize?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#timeouts WarehouseInteractive#timeouts}
    */
    readonly timeouts?: WarehouseInteractiveTimeouts;
}
export interface WarehouseInteractiveParametersFallbackWarehouse {
}
export declare function warehouseInteractiveParametersFallbackWarehouseToTerraform(struct?: WarehouseInteractiveParametersFallbackWarehouse): any;
export declare function warehouseInteractiveParametersFallbackWarehouseToHclTerraform(struct?: WarehouseInteractiveParametersFallbackWarehouse): any;
export declare class WarehouseInteractiveParametersFallbackWarehouseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WarehouseInteractiveParametersFallbackWarehouse | undefined;
    set internalValue(value: WarehouseInteractiveParametersFallbackWarehouse | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class WarehouseInteractiveParametersFallbackWarehouseList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WarehouseInteractiveParametersFallbackWarehouseOutputReference;
}
export interface WarehouseInteractiveParametersMaxConcurrencyLevel {
}
export declare function warehouseInteractiveParametersMaxConcurrencyLevelToTerraform(struct?: WarehouseInteractiveParametersMaxConcurrencyLevel): any;
export declare function warehouseInteractiveParametersMaxConcurrencyLevelToHclTerraform(struct?: WarehouseInteractiveParametersMaxConcurrencyLevel): any;
export declare class WarehouseInteractiveParametersMaxConcurrencyLevelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WarehouseInteractiveParametersMaxConcurrencyLevel | undefined;
    set internalValue(value: WarehouseInteractiveParametersMaxConcurrencyLevel | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class WarehouseInteractiveParametersMaxConcurrencyLevelList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WarehouseInteractiveParametersMaxConcurrencyLevelOutputReference;
}
export interface WarehouseInteractiveParametersStatementQueuedTimeoutInSeconds {
}
export declare function warehouseInteractiveParametersStatementQueuedTimeoutInSecondsToTerraform(struct?: WarehouseInteractiveParametersStatementQueuedTimeoutInSeconds): any;
export declare function warehouseInteractiveParametersStatementQueuedTimeoutInSecondsToHclTerraform(struct?: WarehouseInteractiveParametersStatementQueuedTimeoutInSeconds): any;
export declare class WarehouseInteractiveParametersStatementQueuedTimeoutInSecondsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WarehouseInteractiveParametersStatementQueuedTimeoutInSeconds | undefined;
    set internalValue(value: WarehouseInteractiveParametersStatementQueuedTimeoutInSeconds | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class WarehouseInteractiveParametersStatementQueuedTimeoutInSecondsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WarehouseInteractiveParametersStatementQueuedTimeoutInSecondsOutputReference;
}
export interface WarehouseInteractiveParametersStatementTimeoutInSeconds {
}
export declare function warehouseInteractiveParametersStatementTimeoutInSecondsToTerraform(struct?: WarehouseInteractiveParametersStatementTimeoutInSeconds): any;
export declare function warehouseInteractiveParametersStatementTimeoutInSecondsToHclTerraform(struct?: WarehouseInteractiveParametersStatementTimeoutInSeconds): any;
export declare class WarehouseInteractiveParametersStatementTimeoutInSecondsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WarehouseInteractiveParametersStatementTimeoutInSeconds | undefined;
    set internalValue(value: WarehouseInteractiveParametersStatementTimeoutInSeconds | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class WarehouseInteractiveParametersStatementTimeoutInSecondsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WarehouseInteractiveParametersStatementTimeoutInSecondsOutputReference;
}
export interface WarehouseInteractiveParameters {
}
export declare function warehouseInteractiveParametersToTerraform(struct?: WarehouseInteractiveParameters): any;
export declare function warehouseInteractiveParametersToHclTerraform(struct?: WarehouseInteractiveParameters): any;
export declare class WarehouseInteractiveParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WarehouseInteractiveParameters | undefined;
    set internalValue(value: WarehouseInteractiveParameters | undefined);
    private _fallbackWarehouse;
    get fallbackWarehouse(): WarehouseInteractiveParametersFallbackWarehouseList;
    private _maxConcurrencyLevel;
    get maxConcurrencyLevel(): WarehouseInteractiveParametersMaxConcurrencyLevelList;
    private _statementQueuedTimeoutInSeconds;
    get statementQueuedTimeoutInSeconds(): WarehouseInteractiveParametersStatementQueuedTimeoutInSecondsList;
    private _statementTimeoutInSeconds;
    get statementTimeoutInSeconds(): WarehouseInteractiveParametersStatementTimeoutInSecondsList;
}
export declare class WarehouseInteractiveParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WarehouseInteractiveParametersOutputReference;
}
export interface WarehouseInteractiveShowOutput {
}
export declare function warehouseInteractiveShowOutputToTerraform(struct?: WarehouseInteractiveShowOutput): any;
export declare function warehouseInteractiveShowOutputToHclTerraform(struct?: WarehouseInteractiveShowOutput): any;
export declare class WarehouseInteractiveShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WarehouseInteractiveShowOutput | undefined;
    set internalValue(value: WarehouseInteractiveShowOutput | undefined);
    get autoResume(): cdktn.IResolvable;
    get autoSuspend(): number;
    get available(): number;
    get comment(): string;
    get createdOn(): string;
    get isCurrent(): cdktn.IResolvable;
    get isDefault(): cdktn.IResolvable;
    get maxClusterCount(): number;
    get minClusterCount(): number;
    get name(): string;
    get other(): number;
    get owner(): string;
    get ownerRoleType(): string;
    get provisioning(): number;
    get queued(): number;
    get quiescing(): number;
    get resourceMonitor(): string;
    get resumedOn(): string;
    get running(): number;
    get size(): string;
    get startedClusters(): number;
    get state(): string;
    get tables(): string[];
    get type(): string;
    get updatedOn(): string;
}
export declare class WarehouseInteractiveShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WarehouseInteractiveShowOutputOutputReference;
}
export interface WarehouseInteractiveTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#create WarehouseInteractive#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#delete WarehouseInteractive#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#read WarehouseInteractive#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#update WarehouseInteractive#update}
    */
    readonly update?: string;
}
export declare function warehouseInteractiveTimeoutsToTerraform(struct?: WarehouseInteractiveTimeouts | cdktn.IResolvable): any;
export declare function warehouseInteractiveTimeoutsToHclTerraform(struct?: WarehouseInteractiveTimeouts | cdktn.IResolvable): any;
export declare class WarehouseInteractiveTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WarehouseInteractiveTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: WarehouseInteractiveTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive snowflake_warehouse_interactive}
*/
export declare class WarehouseInteractive extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_warehouse_interactive";
    /**
    * Generates CDKTN code for importing a WarehouseInteractive resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WarehouseInteractive to import
    * @param importFromId The id of the existing WarehouseInteractive that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WarehouseInteractive to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/warehouse_interactive snowflake_warehouse_interactive} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WarehouseInteractiveConfig
    */
    constructor(scope: Construct, id: string, config: WarehouseInteractiveConfig);
    private _autoResume?;
    get autoResume(): string;
    set autoResume(value: string);
    resetAutoResume(): void;
    get autoResumeInput(): string | undefined;
    private _autoSuspend?;
    get autoSuspend(): number;
    set autoSuspend(value: number);
    resetAutoSuspend(): void;
    get autoSuspendInput(): number | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _fallbackWarehouse?;
    get fallbackWarehouse(): string;
    set fallbackWarehouse(value: string);
    resetFallbackWarehouse(): void;
    get fallbackWarehouseInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _initiallySuspended?;
    get initiallySuspended(): boolean | cdktn.IResolvable;
    set initiallySuspended(value: boolean | cdktn.IResolvable);
    resetInitiallySuspended(): void;
    get initiallySuspendedInput(): boolean | cdktn.IResolvable | undefined;
    private _maxClusterCount?;
    get maxClusterCount(): number;
    set maxClusterCount(value: number);
    resetMaxClusterCount(): void;
    get maxClusterCountInput(): number | undefined;
    private _maxConcurrencyLevel?;
    get maxConcurrencyLevel(): number;
    set maxConcurrencyLevel(value: number);
    resetMaxConcurrencyLevel(): void;
    get maxConcurrencyLevelInput(): number | undefined;
    private _minClusterCount?;
    get minClusterCount(): number;
    set minClusterCount(value: number);
    resetMinClusterCount(): void;
    get minClusterCountInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): WarehouseInteractiveParametersList;
    private _resourceMonitor?;
    get resourceMonitor(): string;
    set resourceMonitor(value: string);
    resetResourceMonitor(): void;
    get resourceMonitorInput(): string | undefined;
    private _showOutput;
    get showOutput(): WarehouseInteractiveShowOutputList;
    private _statementQueuedTimeoutInSeconds?;
    get statementQueuedTimeoutInSeconds(): number;
    set statementQueuedTimeoutInSeconds(value: number);
    resetStatementQueuedTimeoutInSeconds(): void;
    get statementQueuedTimeoutInSecondsInput(): number | undefined;
    private _statementTimeoutInSeconds?;
    get statementTimeoutInSeconds(): number;
    set statementTimeoutInSeconds(value: number);
    resetStatementTimeoutInSeconds(): void;
    get statementTimeoutInSecondsInput(): number | undefined;
    private _tables?;
    get tables(): string[];
    set tables(value: string[]);
    resetTables(): void;
    get tablesInput(): string[] | undefined;
    private _warehouseSize?;
    get warehouseSize(): string;
    set warehouseSize(value: string);
    resetWarehouseSize(): void;
    get warehouseSizeInput(): string | undefined;
    get warehouseType(): string;
    private _timeouts;
    get timeouts(): WarehouseInteractiveTimeoutsOutputReference;
    putTimeouts(value: WarehouseInteractiveTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | WarehouseInteractiveTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
