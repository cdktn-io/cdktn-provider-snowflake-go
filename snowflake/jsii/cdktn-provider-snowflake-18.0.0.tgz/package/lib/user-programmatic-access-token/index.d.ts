/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface UserProgrammaticAccessTokenConfig extends cdktn.TerraformMetaArguments {
    /**
    * Descriptive comment about the programmatic access token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#comment UserProgrammaticAccessToken#comment}
    */
    readonly comment?: string;
    /**
    * The number of days that the programmatic access token can be used for authentication. This field cannot be altered after the token is created. Instead, you must rotate the token with the `keeper` field. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#days_to_expiry UserProgrammaticAccessToken#days_to_expiry}
    */
    readonly daysToExpiry?: number;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Disables or enables the programmatic access token. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#disabled UserProgrammaticAccessToken#disabled}
    */
    readonly disabled?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`-1`)) This field is only used when the token is rotated by changing the `keeper` field. Sets the expiration time of the existing token secret to expire after the specified number of hours. You can set this to a value of 0 to expire the current token secret immediately.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#expire_rotated_token_after_hours UserProgrammaticAccessToken#expire_rotated_token_after_hours}
    */
    readonly expireRotatedTokenAfterHours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#id UserProgrammaticAccessToken#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Arbitrary string that, if and only if, changed from a non-empty to a different non-empty value (or known after apply), will trigger a key to be rotated. When you add this field to the configuration, or remove it from the configuration, the rotation is not triggered. When the token is rotated, the `token` and `rotated_token_name` fields are marked as computed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#keeper UserProgrammaticAccessToken#keeper}
    */
    readonly keeper?: string;
    /**
    * The number of minutes during which a user can use this token to access Snowflake without being subject to an active network policy. External changes for this field won't be detected. In case you want to apply external changes, you can re-create the resource manually using "terraform taint".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#mins_to_bypass_network_policy_requirement UserProgrammaticAccessToken#mins_to_bypass_network_policy_requirement}
    */
    readonly minsToBypassNetworkPolicyRequirement?: number;
    /**
    * Specifies the name for the programmatic access token; must be unique for the user. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#name UserProgrammaticAccessToken#name}
    */
    readonly name: string;
    /**
    * The name of the role used for privilege evaluation and object creation. This must be one of the roles that has already been granted to the user. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#role_restriction UserProgrammaticAccessToken#role_restriction}
    */
    readonly roleRestriction?: string;
    /**
    * The name of the user that the token is associated with. A user cannot use another user's programmatic access token to authenticate. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#user UserProgrammaticAccessToken#user}
    */
    readonly user: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#timeouts UserProgrammaticAccessToken#timeouts}
    */
    readonly timeouts?: UserProgrammaticAccessTokenTimeouts;
}
export interface UserProgrammaticAccessTokenShowOutput {
}
export declare function userProgrammaticAccessTokenShowOutputToTerraform(struct?: UserProgrammaticAccessTokenShowOutput): any;
export declare function userProgrammaticAccessTokenShowOutputToHclTerraform(struct?: UserProgrammaticAccessTokenShowOutput): any;
export declare class UserProgrammaticAccessTokenShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): UserProgrammaticAccessTokenShowOutput | undefined;
    set internalValue(value: UserProgrammaticAccessTokenShowOutput | undefined);
    get comment(): string;
    get createdBy(): string;
    get createdOn(): string;
    get expiresAt(): string;
    get minsToBypassNetworkPolicyRequirement(): number;
    get name(): string;
    get roleRestriction(): string;
    get rotatedTo(): string;
    get status(): string;
    get userName(): string;
}
export declare class UserProgrammaticAccessTokenShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): UserProgrammaticAccessTokenShowOutputOutputReference;
}
export interface UserProgrammaticAccessTokenTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#create UserProgrammaticAccessToken#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#delete UserProgrammaticAccessToken#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#read UserProgrammaticAccessToken#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#update UserProgrammaticAccessToken#update}
    */
    readonly update?: string;
}
export declare function userProgrammaticAccessTokenTimeoutsToTerraform(struct?: UserProgrammaticAccessTokenTimeouts | cdktn.IResolvable): any;
export declare function userProgrammaticAccessTokenTimeoutsToHclTerraform(struct?: UserProgrammaticAccessTokenTimeouts | cdktn.IResolvable): any;
export declare class UserProgrammaticAccessTokenTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): UserProgrammaticAccessTokenTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: UserProgrammaticAccessTokenTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token snowflake_user_programmatic_access_token}
*/
export declare class UserProgrammaticAccessToken extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_user_programmatic_access_token";
    /**
    * Generates CDKTN code for importing a UserProgrammaticAccessToken resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserProgrammaticAccessToken to import
    * @param importFromId The id of the existing UserProgrammaticAccessToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserProgrammaticAccessToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/user_programmatic_access_token snowflake_user_programmatic_access_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserProgrammaticAccessTokenConfig
    */
    constructor(scope: Construct, id: string, config: UserProgrammaticAccessTokenConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _daysToExpiry?;
    get daysToExpiry(): number;
    set daysToExpiry(value: number);
    resetDaysToExpiry(): void;
    get daysToExpiryInput(): number | undefined;
    private _disabled?;
    get disabled(): string;
    set disabled(value: string);
    resetDisabled(): void;
    get disabledInput(): string | undefined;
    private _expireRotatedTokenAfterHours?;
    get expireRotatedTokenAfterHours(): number;
    set expireRotatedTokenAfterHours(value: number);
    resetExpireRotatedTokenAfterHours(): void;
    get expireRotatedTokenAfterHoursInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keeper?;
    get keeper(): string;
    set keeper(value: string);
    resetKeeper(): void;
    get keeperInput(): string | undefined;
    private _minsToBypassNetworkPolicyRequirement?;
    get minsToBypassNetworkPolicyRequirement(): number;
    set minsToBypassNetworkPolicyRequirement(value: number);
    resetMinsToBypassNetworkPolicyRequirement(): void;
    get minsToBypassNetworkPolicyRequirementInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _roleRestriction?;
    get roleRestriction(): string;
    set roleRestriction(value: string);
    resetRoleRestriction(): void;
    get roleRestrictionInput(): string | undefined;
    get rotatedTokenName(): string;
    private _showOutput;
    get showOutput(): UserProgrammaticAccessTokenShowOutputList;
    get token(): string;
    private _user?;
    get user(): string;
    set user(value: string);
    get userInput(): string | undefined;
    private _timeouts;
    get timeouts(): UserProgrammaticAccessTokenTimeoutsOutputReference;
    putTimeouts(value: UserProgrammaticAccessTokenTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | UserProgrammaticAccessTokenTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
