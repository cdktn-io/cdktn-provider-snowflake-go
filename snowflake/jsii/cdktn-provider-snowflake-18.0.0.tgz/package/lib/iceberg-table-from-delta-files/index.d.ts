/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IcebergTableFromDeltaFilesConfig extends cdktn.TerraformMetaArguments {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether Snowflake should automatically refresh the Iceberg table metadata when new files are added to the Delta table's directory. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#auto_refresh IcebergTableFromDeltaFiles#auto_refresh}
    */
    readonly autoRefresh?: string;
    /**
    * Specifies the relative path of the Delta table's directory in the external volume. Cannot be changed after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#base_location IcebergTableFromDeltaFiles#base_location}
    */
    readonly baseLocation: string;
    /**
    * Specifies the identifier for the catalog integration to use for the Iceberg table. If not specified, the account-level default is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#catalog IcebergTableFromDeltaFiles#catalog}
    */
    readonly catalog?: string;
    /**
    * Specifies a comment for the Iceberg table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#comment IcebergTableFromDeltaFiles#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the Iceberg table. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#database IcebergTableFromDeltaFiles#database}
    */
    readonly database: string;
    /**
    * Specifies the identifier for the external volume where the Iceberg table stores its metadata files and data in Parquet format. If not specified, the account-level default is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#external_volume IcebergTableFromDeltaFiles#external_volume}
    */
    readonly externalVolume?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#id IcebergTableFromDeltaFiles#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the Iceberg table; must be unique for the schema in which the Iceberg table is created. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#name IcebergTableFromDeltaFiles#name}
    */
    readonly name: string;
    /**
    * Specifies whether to replace invalid UTF-8 characters with the Unicode replacement character (`�`) in query results for an Iceberg table. For more information, check [REPLACE_INVALID_CHARACTERS docs](https://docs.snowflake.com/en/sql-reference/parameters#replace-invalid-characters).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#replace_invalid_characters IcebergTableFromDeltaFiles#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: boolean | cdktn.IResolvable;
    /**
    * The schema in which to create the Iceberg table. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#schema IcebergTableFromDeltaFiles#schema}
    */
    readonly schema: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#timeouts IcebergTableFromDeltaFiles#timeouts}
    */
    readonly timeouts?: IcebergTableFromDeltaFilesTimeouts;
}
export interface IcebergTableFromDeltaFilesDescribeOutput {
}
export declare function icebergTableFromDeltaFilesDescribeOutputToTerraform(struct?: IcebergTableFromDeltaFilesDescribeOutput): any;
export declare function icebergTableFromDeltaFilesDescribeOutputToHclTerraform(struct?: IcebergTableFromDeltaFilesDescribeOutput): any;
export declare class IcebergTableFromDeltaFilesDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromDeltaFilesDescribeOutput | undefined;
    set internalValue(value: IcebergTableFromDeltaFilesDescribeOutput | undefined);
    get check(): string;
    get comment(): string;
    get default(): string;
    get expression(): string;
    get isNullable(): cdktn.IResolvable;
    get kind(): string;
    get name(): string;
    get nameMapping(): string;
    get policyName(): string;
    get primaryKey(): cdktn.IResolvable;
    get privacyDomain(): string;
    get sourceIcebergType(): string;
    get type(): string;
    get uniqueKey(): cdktn.IResolvable;
    get writeDefault(): string;
}
export declare class IcebergTableFromDeltaFilesDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromDeltaFilesDescribeOutputOutputReference;
}
export interface IcebergTableFromDeltaFilesParametersCatalog {
}
export declare function icebergTableFromDeltaFilesParametersCatalogToTerraform(struct?: IcebergTableFromDeltaFilesParametersCatalog): any;
export declare function icebergTableFromDeltaFilesParametersCatalogToHclTerraform(struct?: IcebergTableFromDeltaFilesParametersCatalog): any;
export declare class IcebergTableFromDeltaFilesParametersCatalogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromDeltaFilesParametersCatalog | undefined;
    set internalValue(value: IcebergTableFromDeltaFilesParametersCatalog | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromDeltaFilesParametersCatalogList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromDeltaFilesParametersCatalogOutputReference;
}
export interface IcebergTableFromDeltaFilesParametersExternalVolume {
}
export declare function icebergTableFromDeltaFilesParametersExternalVolumeToTerraform(struct?: IcebergTableFromDeltaFilesParametersExternalVolume): any;
export declare function icebergTableFromDeltaFilesParametersExternalVolumeToHclTerraform(struct?: IcebergTableFromDeltaFilesParametersExternalVolume): any;
export declare class IcebergTableFromDeltaFilesParametersExternalVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromDeltaFilesParametersExternalVolume | undefined;
    set internalValue(value: IcebergTableFromDeltaFilesParametersExternalVolume | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromDeltaFilesParametersExternalVolumeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromDeltaFilesParametersExternalVolumeOutputReference;
}
export interface IcebergTableFromDeltaFilesParametersReplaceInvalidCharacters {
}
export declare function icebergTableFromDeltaFilesParametersReplaceInvalidCharactersToTerraform(struct?: IcebergTableFromDeltaFilesParametersReplaceInvalidCharacters): any;
export declare function icebergTableFromDeltaFilesParametersReplaceInvalidCharactersToHclTerraform(struct?: IcebergTableFromDeltaFilesParametersReplaceInvalidCharacters): any;
export declare class IcebergTableFromDeltaFilesParametersReplaceInvalidCharactersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromDeltaFilesParametersReplaceInvalidCharacters | undefined;
    set internalValue(value: IcebergTableFromDeltaFilesParametersReplaceInvalidCharacters | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class IcebergTableFromDeltaFilesParametersReplaceInvalidCharactersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromDeltaFilesParametersReplaceInvalidCharactersOutputReference;
}
export interface IcebergTableFromDeltaFilesParameters {
}
export declare function icebergTableFromDeltaFilesParametersToTerraform(struct?: IcebergTableFromDeltaFilesParameters): any;
export declare function icebergTableFromDeltaFilesParametersToHclTerraform(struct?: IcebergTableFromDeltaFilesParameters): any;
export declare class IcebergTableFromDeltaFilesParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromDeltaFilesParameters | undefined;
    set internalValue(value: IcebergTableFromDeltaFilesParameters | undefined);
    private _catalog;
    get catalog(): IcebergTableFromDeltaFilesParametersCatalogList;
    private _externalVolume;
    get externalVolume(): IcebergTableFromDeltaFilesParametersExternalVolumeList;
    private _replaceInvalidCharacters;
    get replaceInvalidCharacters(): IcebergTableFromDeltaFilesParametersReplaceInvalidCharactersList;
}
export declare class IcebergTableFromDeltaFilesParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromDeltaFilesParametersOutputReference;
}
export interface IcebergTableFromDeltaFilesShowOutputAutoRefreshStatus {
}
export declare function icebergTableFromDeltaFilesShowOutputAutoRefreshStatusToTerraform(struct?: IcebergTableFromDeltaFilesShowOutputAutoRefreshStatus): any;
export declare function icebergTableFromDeltaFilesShowOutputAutoRefreshStatusToHclTerraform(struct?: IcebergTableFromDeltaFilesShowOutputAutoRefreshStatus): any;
export declare class IcebergTableFromDeltaFilesShowOutputAutoRefreshStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromDeltaFilesShowOutputAutoRefreshStatus | undefined;
    set internalValue(value: IcebergTableFromDeltaFilesShowOutputAutoRefreshStatus | undefined);
    get currentSnapshotId(): number;
    get executionState(): string;
    get lastSnapshotTime(): string;
    get lastUpdatedTime(): string;
    get pendingSnapshotCount(): number;
}
export declare class IcebergTableFromDeltaFilesShowOutputAutoRefreshStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromDeltaFilesShowOutputAutoRefreshStatusOutputReference;
}
export interface IcebergTableFromDeltaFilesShowOutputPartitionSpecsFields {
}
export declare function icebergTableFromDeltaFilesShowOutputPartitionSpecsFieldsToTerraform(struct?: IcebergTableFromDeltaFilesShowOutputPartitionSpecsFields): any;
export declare function icebergTableFromDeltaFilesShowOutputPartitionSpecsFieldsToHclTerraform(struct?: IcebergTableFromDeltaFilesShowOutputPartitionSpecsFields): any;
export declare class IcebergTableFromDeltaFilesShowOutputPartitionSpecsFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromDeltaFilesShowOutputPartitionSpecsFields | undefined;
    set internalValue(value: IcebergTableFromDeltaFilesShowOutputPartitionSpecsFields | undefined);
    get fieldId(): number;
    get name(): string;
    get sourceId(): number;
    get transform(): string;
}
export declare class IcebergTableFromDeltaFilesShowOutputPartitionSpecsFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromDeltaFilesShowOutputPartitionSpecsFieldsOutputReference;
}
export interface IcebergTableFromDeltaFilesShowOutputPartitionSpecs {
}
export declare function icebergTableFromDeltaFilesShowOutputPartitionSpecsToTerraform(struct?: IcebergTableFromDeltaFilesShowOutputPartitionSpecs): any;
export declare function icebergTableFromDeltaFilesShowOutputPartitionSpecsToHclTerraform(struct?: IcebergTableFromDeltaFilesShowOutputPartitionSpecs): any;
export declare class IcebergTableFromDeltaFilesShowOutputPartitionSpecsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromDeltaFilesShowOutputPartitionSpecs | undefined;
    set internalValue(value: IcebergTableFromDeltaFilesShowOutputPartitionSpecs | undefined);
    private _fields;
    get fields(): IcebergTableFromDeltaFilesShowOutputPartitionSpecsFieldsList;
    get specId(): number;
}
export declare class IcebergTableFromDeltaFilesShowOutputPartitionSpecsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromDeltaFilesShowOutputPartitionSpecsOutputReference;
}
export interface IcebergTableFromDeltaFilesShowOutput {
}
export declare function icebergTableFromDeltaFilesShowOutputToTerraform(struct?: IcebergTableFromDeltaFilesShowOutput): any;
export declare function icebergTableFromDeltaFilesShowOutputToHclTerraform(struct?: IcebergTableFromDeltaFilesShowOutput): any;
export declare class IcebergTableFromDeltaFilesShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IcebergTableFromDeltaFilesShowOutput | undefined;
    set internalValue(value: IcebergTableFromDeltaFilesShowOutput | undefined);
    private _autoRefreshStatus;
    get autoRefreshStatus(): IcebergTableFromDeltaFilesShowOutputAutoRefreshStatusList;
    get baseLocation(): string;
    get canWriteMetadata(): cdktn.IResolvable;
    get catalogName(): string;
    get catalogNamespace(): string;
    get catalogSyncName(): string;
    get catalogTableName(): string;
    get comment(): string;
    get createdOn(): string;
    get currentPartitionSpecId(): number;
    get databaseName(): string;
    get externalVolumeName(): string;
    get icebergTableFormatVersion(): number;
    get icebergTableType(): string;
    get name(): string;
    get nameMapping(): string;
    get owner(): string;
    get ownerRoleType(): string;
    private _partitionSpecs;
    get partitionSpecs(): IcebergTableFromDeltaFilesShowOutputPartitionSpecsList;
    get schemaName(): string;
}
export declare class IcebergTableFromDeltaFilesShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IcebergTableFromDeltaFilesShowOutputOutputReference;
}
export interface IcebergTableFromDeltaFilesTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#create IcebergTableFromDeltaFiles#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#delete IcebergTableFromDeltaFiles#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#read IcebergTableFromDeltaFiles#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#update IcebergTableFromDeltaFiles#update}
    */
    readonly update?: string;
}
export declare function icebergTableFromDeltaFilesTimeoutsToTerraform(struct?: IcebergTableFromDeltaFilesTimeouts | cdktn.IResolvable): any;
export declare function icebergTableFromDeltaFilesTimeoutsToHclTerraform(struct?: IcebergTableFromDeltaFilesTimeouts | cdktn.IResolvable): any;
export declare class IcebergTableFromDeltaFilesTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IcebergTableFromDeltaFilesTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: IcebergTableFromDeltaFilesTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files snowflake_iceberg_table_from_delta_files}
*/
export declare class IcebergTableFromDeltaFiles extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_iceberg_table_from_delta_files";
    /**
    * Generates CDKTN code for importing a IcebergTableFromDeltaFiles resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IcebergTableFromDeltaFiles to import
    * @param importFromId The id of the existing IcebergTableFromDeltaFiles that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IcebergTableFromDeltaFiles to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.19.0/docs/resources/iceberg_table_from_delta_files snowflake_iceberg_table_from_delta_files} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IcebergTableFromDeltaFilesConfig
    */
    constructor(scope: Construct, id: string, config: IcebergTableFromDeltaFilesConfig);
    private _autoRefresh?;
    get autoRefresh(): string;
    set autoRefresh(value: string);
    resetAutoRefresh(): void;
    get autoRefreshInput(): string | undefined;
    private _baseLocation?;
    get baseLocation(): string;
    set baseLocation(value: string);
    get baseLocationInput(): string | undefined;
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): IcebergTableFromDeltaFilesDescribeOutputList;
    private _externalVolume?;
    get externalVolume(): string;
    set externalVolume(value: string);
    resetExternalVolume(): void;
    get externalVolumeInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): IcebergTableFromDeltaFilesParametersList;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): boolean | cdktn.IResolvable;
    set replaceInvalidCharacters(value: boolean | cdktn.IResolvable);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): boolean | cdktn.IResolvable | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): IcebergTableFromDeltaFilesShowOutputList;
    private _timeouts;
    get timeouts(): IcebergTableFromDeltaFilesTimeoutsOutputReference;
    putTimeouts(value: IcebergTableFromDeltaFilesTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | IcebergTableFromDeltaFilesTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
