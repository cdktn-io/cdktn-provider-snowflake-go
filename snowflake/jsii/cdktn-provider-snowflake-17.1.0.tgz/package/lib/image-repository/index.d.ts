/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ImageRepositoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/image_repository#comment ImageRepository#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the image repository. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/image_repository#database ImageRepository#database}
    */
    readonly database: string;
    /**
    * Specifies the encryption type for the image repository. Can only be set at creation time. Valid values are (case-insensitive): `SNOWFLAKE_FULL` | `SNOWFLAKE_SSE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/image_repository#encryption ImageRepository#encryption}
    */
    readonly encryption?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/image_repository#id ImageRepository#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the image repository; must be unique for the schema in which the image repository is created. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/image_repository#name ImageRepository#name}
    */
    readonly name: string;
    /**
    * The schema in which to create the image repository. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/image_repository#schema ImageRepository#schema}
    */
    readonly schema: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/image_repository#timeouts ImageRepository#timeouts}
    */
    readonly timeouts?: ImageRepositoryTimeouts;
}
export interface ImageRepositoryShowOutput {
}
export declare function imageRepositoryShowOutputToTerraform(struct?: ImageRepositoryShowOutput): any;
export declare function imageRepositoryShowOutputToHclTerraform(struct?: ImageRepositoryShowOutput): any;
export declare class ImageRepositoryShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ImageRepositoryShowOutput | undefined;
    set internalValue(value: ImageRepositoryShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get encryption(): string;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get privatelinkRepositoryUrl(): string;
    get repositoryUrl(): string;
    get schemaName(): string;
}
export declare class ImageRepositoryShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ImageRepositoryShowOutputOutputReference;
}
export interface ImageRepositoryTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/image_repository#create ImageRepository#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/image_repository#delete ImageRepository#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/image_repository#read ImageRepository#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/image_repository#update ImageRepository#update}
    */
    readonly update?: string;
}
export declare function imageRepositoryTimeoutsToTerraform(struct?: ImageRepositoryTimeouts | cdktn.IResolvable): any;
export declare function imageRepositoryTimeoutsToHclTerraform(struct?: ImageRepositoryTimeouts | cdktn.IResolvable): any;
export declare class ImageRepositoryTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ImageRepositoryTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ImageRepositoryTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/image_repository snowflake_image_repository}
*/
export declare class ImageRepository extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_image_repository";
    /**
    * Generates CDKTN code for importing a ImageRepository resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ImageRepository to import
    * @param importFromId The id of the existing ImageRepository that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/image_repository#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ImageRepository to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/image_repository snowflake_image_repository} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ImageRepositoryConfig
    */
    constructor(scope: Construct, id: string, config: ImageRepositoryConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _encryption?;
    get encryption(): string;
    set encryption(value: string);
    resetEncryption(): void;
    get encryptionInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): ImageRepositoryShowOutputList;
    private _timeouts;
    get timeouts(): ImageRepositoryTimeoutsOutputReference;
    putTimeouts(value: ImageRepositoryTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ImageRepositoryTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
