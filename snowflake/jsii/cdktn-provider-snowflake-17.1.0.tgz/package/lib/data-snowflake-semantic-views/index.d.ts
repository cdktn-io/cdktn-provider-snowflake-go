/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeSemanticViewsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/semantic_views#id DataSnowflakeSemanticViews#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/semantic_views#like DataSnowflakeSemanticViews#like}
    */
    readonly like?: string;
    /**
    * Filters the output with **case-sensitive** characters indicating the beginning of the object name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/semantic_views#starts_with DataSnowflakeSemanticViews#starts_with}
    */
    readonly startsWith?: string;
    /**
    * in block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/semantic_views#in DataSnowflakeSemanticViews#in}
    */
    readonly in?: DataSnowflakeSemanticViewsIn;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/semantic_views#limit DataSnowflakeSemanticViews#limit}
    */
    readonly limit?: DataSnowflakeSemanticViewsLimit;
}
export interface DataSnowflakeSemanticViewsSemanticViewsShowOutput {
}
export declare function dataSnowflakeSemanticViewsSemanticViewsShowOutputToTerraform(struct?: DataSnowflakeSemanticViewsSemanticViewsShowOutput): any;
export declare function dataSnowflakeSemanticViewsSemanticViewsShowOutputToHclTerraform(struct?: DataSnowflakeSemanticViewsSemanticViewsShowOutput): any;
export declare class DataSnowflakeSemanticViewsSemanticViewsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeSemanticViewsSemanticViewsShowOutput | undefined;
    set internalValue(value: DataSnowflakeSemanticViewsSemanticViewsShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get extension(): string;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get schemaName(): string;
}
export declare class DataSnowflakeSemanticViewsSemanticViewsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeSemanticViewsSemanticViewsShowOutputOutputReference;
}
export interface DataSnowflakeSemanticViewsSemanticViews {
}
export declare function dataSnowflakeSemanticViewsSemanticViewsToTerraform(struct?: DataSnowflakeSemanticViewsSemanticViews): any;
export declare function dataSnowflakeSemanticViewsSemanticViewsToHclTerraform(struct?: DataSnowflakeSemanticViewsSemanticViews): any;
export declare class DataSnowflakeSemanticViewsSemanticViewsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeSemanticViewsSemanticViews | undefined;
    set internalValue(value: DataSnowflakeSemanticViewsSemanticViews | undefined);
    private _showOutput;
    get showOutput(): DataSnowflakeSemanticViewsSemanticViewsShowOutputList;
}
export declare class DataSnowflakeSemanticViewsSemanticViewsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeSemanticViewsSemanticViewsOutputReference;
}
export interface DataSnowflakeSemanticViewsIn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/semantic_views#account DataSnowflakeSemanticViews#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the current database in use or for a specified database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/semantic_views#database DataSnowflakeSemanticViews#database}
    */
    readonly database?: string;
    /**
    * Returns records for the current schema in use or a specified schema. Use fully qualified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/semantic_views#schema DataSnowflakeSemanticViews#schema}
    */
    readonly schema?: string;
}
export declare function dataSnowflakeSemanticViewsInToTerraform(struct?: DataSnowflakeSemanticViewsInOutputReference | DataSnowflakeSemanticViewsIn): any;
export declare function dataSnowflakeSemanticViewsInToHclTerraform(struct?: DataSnowflakeSemanticViewsInOutputReference | DataSnowflakeSemanticViewsIn): any;
export declare class DataSnowflakeSemanticViewsInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeSemanticViewsIn | undefined;
    set internalValue(value: DataSnowflakeSemanticViewsIn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export interface DataSnowflakeSemanticViewsLimit {
    /**
    * Specifies a **case-sensitive** pattern that is used to match object name. After the first match, the limit on the number of rows will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/semantic_views#from DataSnowflakeSemanticViews#from}
    */
    readonly from?: string;
    /**
    * The maximum number of rows to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/semantic_views#rows DataSnowflakeSemanticViews#rows}
    */
    readonly rows: number;
}
export declare function dataSnowflakeSemanticViewsLimitToTerraform(struct?: DataSnowflakeSemanticViewsLimitOutputReference | DataSnowflakeSemanticViewsLimit): any;
export declare function dataSnowflakeSemanticViewsLimitToHclTerraform(struct?: DataSnowflakeSemanticViewsLimitOutputReference | DataSnowflakeSemanticViewsLimit): any;
export declare class DataSnowflakeSemanticViewsLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeSemanticViewsLimit | undefined;
    set internalValue(value: DataSnowflakeSemanticViewsLimit | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _rows?;
    get rows(): number;
    set rows(value: number);
    get rowsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/semantic_views snowflake_semantic_views}
*/
export declare class DataSnowflakeSemanticViews extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_semantic_views";
    /**
    * Generates CDKTN code for importing a DataSnowflakeSemanticViews resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeSemanticViews to import
    * @param importFromId The id of the existing DataSnowflakeSemanticViews that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/semantic_views#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeSemanticViews to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/semantic_views snowflake_semantic_views} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeSemanticViewsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeSemanticViewsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _semanticViews;
    get semanticViews(): DataSnowflakeSemanticViewsSemanticViewsList;
    private _startsWith?;
    get startsWith(): string;
    set startsWith(value: string);
    resetStartsWith(): void;
    get startsWithInput(): string | undefined;
    private _in;
    get in(): DataSnowflakeSemanticViewsInOutputReference;
    putIn(value: DataSnowflakeSemanticViewsIn): void;
    resetIn(): void;
    get inInput(): DataSnowflakeSemanticViewsIn | undefined;
    private _limit;
    get limit(): DataSnowflakeSemanticViewsLimitOutputReference;
    putLimit(value: DataSnowflakeSemanticViewsLimit): void;
    resetLimit(): void;
    get limitInput(): DataSnowflakeSemanticViewsLimit | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
