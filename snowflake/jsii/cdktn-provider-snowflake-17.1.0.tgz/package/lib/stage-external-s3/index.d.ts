/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StageExternalS3Config extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the ARN for an AWS S3 Access Point to use for data transfer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#aws_access_point_arn StageExternalS3#aws_access_point_arn}
    */
    readonly awsAccessPointArn?: string;
    /**
    * Specifies a comment for the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#comment StageExternalS3#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the stage. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#database StageExternalS3#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#id StageExternalS3#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the stage; must be unique for the database and schema in which the stage is created. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#name StageExternalS3#name}
    */
    readonly name: string;
    /**
    * The schema in which to create the stage. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#schema StageExternalS3#schema}
    */
    readonly schema: string;
    /**
    * Specifies the name of the storage integration used to delegate authentication responsibility to a Snowflake identity. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#storage_integration StageExternalS3#storage_integration}
    */
    readonly storageIntegration?: string;
    /**
    * Specifies the URL for the S3 bucket (e.g., 's3://bucket-name/path/').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#url StageExternalS3#url}
    */
    readonly url: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether to use a private link endpoint for S3 storage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#use_privatelink_endpoint StageExternalS3#use_privatelink_endpoint}
    */
    readonly usePrivatelinkEndpoint?: string;
    /**
    * credentials block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#credentials StageExternalS3#credentials}
    */
    readonly credentials?: StageExternalS3Credentials;
    /**
    * directory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#directory StageExternalS3#directory}
    */
    readonly directory?: StageExternalS3Directory;
    /**
    * encryption block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#encryption StageExternalS3#encryption}
    */
    readonly encryption?: StageExternalS3Encryption;
    /**
    * file_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#file_format StageExternalS3#file_format}
    */
    readonly fileFormat?: StageExternalS3FileFormat;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#timeouts StageExternalS3#timeouts}
    */
    readonly timeouts?: StageExternalS3Timeouts;
}
export interface StageExternalS3DescribeOutputDirectoryTable {
}
export declare function stageExternalS3DescribeOutputDirectoryTableToTerraform(struct?: StageExternalS3DescribeOutputDirectoryTable): any;
export declare function stageExternalS3DescribeOutputDirectoryTableToHclTerraform(struct?: StageExternalS3DescribeOutputDirectoryTable): any;
export declare class StageExternalS3DescribeOutputDirectoryTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalS3DescribeOutputDirectoryTable | undefined;
    set internalValue(value: StageExternalS3DescribeOutputDirectoryTable | undefined);
    get autoRefresh(): cdktn.IResolvable;
    get enable(): cdktn.IResolvable;
    get lastRefreshedOn(): string;
}
export declare class StageExternalS3DescribeOutputDirectoryTableList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalS3DescribeOutputDirectoryTableOutputReference;
}
export interface StageExternalS3DescribeOutputFileFormatAvro {
}
export declare function stageExternalS3DescribeOutputFileFormatAvroToTerraform(struct?: StageExternalS3DescribeOutputFileFormatAvro): any;
export declare function stageExternalS3DescribeOutputFileFormatAvroToHclTerraform(struct?: StageExternalS3DescribeOutputFileFormatAvro): any;
export declare class StageExternalS3DescribeOutputFileFormatAvroOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalS3DescribeOutputFileFormatAvro | undefined;
    set internalValue(value: StageExternalS3DescribeOutputFileFormatAvro | undefined);
    get compression(): string;
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageExternalS3DescribeOutputFileFormatAvroList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalS3DescribeOutputFileFormatAvroOutputReference;
}
export interface StageExternalS3DescribeOutputFileFormatCsv {
}
export declare function stageExternalS3DescribeOutputFileFormatCsvToTerraform(struct?: StageExternalS3DescribeOutputFileFormatCsv): any;
export declare function stageExternalS3DescribeOutputFileFormatCsvToHclTerraform(struct?: StageExternalS3DescribeOutputFileFormatCsv): any;
export declare class StageExternalS3DescribeOutputFileFormatCsvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalS3DescribeOutputFileFormatCsv | undefined;
    set internalValue(value: StageExternalS3DescribeOutputFileFormatCsv | undefined);
    get binaryFormat(): string;
    get compression(): string;
    get dateFormat(): string;
    get emptyFieldAsNull(): cdktn.IResolvable;
    get encoding(): string;
    get errorOnColumnCountMismatch(): cdktn.IResolvable;
    get escape(): string;
    get escapeUnenclosedField(): string;
    get fieldDelimiter(): string;
    get fieldOptionallyEnclosedBy(): string;
    get fileExtension(): string;
    get multiLine(): cdktn.IResolvable;
    get nullIf(): string[];
    get parseHeader(): cdktn.IResolvable;
    get recordDelimiter(): string;
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipBlankLines(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get skipHeader(): number;
    get timeFormat(): string;
    get timestampFormat(): string;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
    get validateUtf8(): cdktn.IResolvable;
}
export declare class StageExternalS3DescribeOutputFileFormatCsvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalS3DescribeOutputFileFormatCsvOutputReference;
}
export interface StageExternalS3DescribeOutputFileFormatJson {
}
export declare function stageExternalS3DescribeOutputFileFormatJsonToTerraform(struct?: StageExternalS3DescribeOutputFileFormatJson): any;
export declare function stageExternalS3DescribeOutputFileFormatJsonToHclTerraform(struct?: StageExternalS3DescribeOutputFileFormatJson): any;
export declare class StageExternalS3DescribeOutputFileFormatJsonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalS3DescribeOutputFileFormatJson | undefined;
    set internalValue(value: StageExternalS3DescribeOutputFileFormatJson | undefined);
    get allowDuplicate(): cdktn.IResolvable;
    get binaryFormat(): string;
    get compression(): string;
    get dateFormat(): string;
    get enableOctal(): cdktn.IResolvable;
    get fileExtension(): string;
    get ignoreUtf8Errors(): cdktn.IResolvable;
    get multiLine(): cdktn.IResolvable;
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get stripNullValues(): cdktn.IResolvable;
    get stripOuterArray(): cdktn.IResolvable;
    get timeFormat(): string;
    get timestampFormat(): string;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageExternalS3DescribeOutputFileFormatJsonList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalS3DescribeOutputFileFormatJsonOutputReference;
}
export interface StageExternalS3DescribeOutputFileFormatOrc {
}
export declare function stageExternalS3DescribeOutputFileFormatOrcToTerraform(struct?: StageExternalS3DescribeOutputFileFormatOrc): any;
export declare function stageExternalS3DescribeOutputFileFormatOrcToHclTerraform(struct?: StageExternalS3DescribeOutputFileFormatOrc): any;
export declare class StageExternalS3DescribeOutputFileFormatOrcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalS3DescribeOutputFileFormatOrc | undefined;
    set internalValue(value: StageExternalS3DescribeOutputFileFormatOrc | undefined);
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageExternalS3DescribeOutputFileFormatOrcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalS3DescribeOutputFileFormatOrcOutputReference;
}
export interface StageExternalS3DescribeOutputFileFormatParquet {
}
export declare function stageExternalS3DescribeOutputFileFormatParquetToTerraform(struct?: StageExternalS3DescribeOutputFileFormatParquet): any;
export declare function stageExternalS3DescribeOutputFileFormatParquetToHclTerraform(struct?: StageExternalS3DescribeOutputFileFormatParquet): any;
export declare class StageExternalS3DescribeOutputFileFormatParquetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalS3DescribeOutputFileFormatParquet | undefined;
    set internalValue(value: StageExternalS3DescribeOutputFileFormatParquet | undefined);
    get binaryAsText(): cdktn.IResolvable;
    get compression(): string;
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
    get useLogicalType(): cdktn.IResolvable;
    get useVectorizedScanner(): cdktn.IResolvable;
}
export declare class StageExternalS3DescribeOutputFileFormatParquetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalS3DescribeOutputFileFormatParquetOutputReference;
}
export interface StageExternalS3DescribeOutputFileFormatXml {
}
export declare function stageExternalS3DescribeOutputFileFormatXmlToTerraform(struct?: StageExternalS3DescribeOutputFileFormatXml): any;
export declare function stageExternalS3DescribeOutputFileFormatXmlToHclTerraform(struct?: StageExternalS3DescribeOutputFileFormatXml): any;
export declare class StageExternalS3DescribeOutputFileFormatXmlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalS3DescribeOutputFileFormatXml | undefined;
    set internalValue(value: StageExternalS3DescribeOutputFileFormatXml | undefined);
    get compression(): string;
    get disableAutoConvert(): cdktn.IResolvable;
    get ignoreUtf8Errors(): cdktn.IResolvable;
    get preserveSpace(): cdktn.IResolvable;
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get stripOuterElement(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageExternalS3DescribeOutputFileFormatXmlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalS3DescribeOutputFileFormatXmlOutputReference;
}
export interface StageExternalS3DescribeOutputFileFormat {
}
export declare function stageExternalS3DescribeOutputFileFormatToTerraform(struct?: StageExternalS3DescribeOutputFileFormat): any;
export declare function stageExternalS3DescribeOutputFileFormatToHclTerraform(struct?: StageExternalS3DescribeOutputFileFormat): any;
export declare class StageExternalS3DescribeOutputFileFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalS3DescribeOutputFileFormat | undefined;
    set internalValue(value: StageExternalS3DescribeOutputFileFormat | undefined);
    private _avro;
    get avro(): StageExternalS3DescribeOutputFileFormatAvroList;
    private _csv;
    get csv(): StageExternalS3DescribeOutputFileFormatCsvList;
    get formatName(): string;
    private _json;
    get json(): StageExternalS3DescribeOutputFileFormatJsonList;
    private _orc;
    get orc(): StageExternalS3DescribeOutputFileFormatOrcList;
    private _parquet;
    get parquet(): StageExternalS3DescribeOutputFileFormatParquetList;
    private _xml;
    get xml(): StageExternalS3DescribeOutputFileFormatXmlList;
}
export declare class StageExternalS3DescribeOutputFileFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalS3DescribeOutputFileFormatOutputReference;
}
export interface StageExternalS3DescribeOutputLocation {
}
export declare function stageExternalS3DescribeOutputLocationToTerraform(struct?: StageExternalS3DescribeOutputLocation): any;
export declare function stageExternalS3DescribeOutputLocationToHclTerraform(struct?: StageExternalS3DescribeOutputLocation): any;
export declare class StageExternalS3DescribeOutputLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalS3DescribeOutputLocation | undefined;
    set internalValue(value: StageExternalS3DescribeOutputLocation | undefined);
    get awsAccessPointArn(): string;
    get url(): string[];
}
export declare class StageExternalS3DescribeOutputLocationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalS3DescribeOutputLocationOutputReference;
}
export interface StageExternalS3DescribeOutputPrivatelink {
}
export declare function stageExternalS3DescribeOutputPrivatelinkToTerraform(struct?: StageExternalS3DescribeOutputPrivatelink): any;
export declare function stageExternalS3DescribeOutputPrivatelinkToHclTerraform(struct?: StageExternalS3DescribeOutputPrivatelink): any;
export declare class StageExternalS3DescribeOutputPrivatelinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalS3DescribeOutputPrivatelink | undefined;
    set internalValue(value: StageExternalS3DescribeOutputPrivatelink | undefined);
    get usePrivatelinkEndpoint(): cdktn.IResolvable;
}
export declare class StageExternalS3DescribeOutputPrivatelinkList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalS3DescribeOutputPrivatelinkOutputReference;
}
export interface StageExternalS3DescribeOutput {
}
export declare function stageExternalS3DescribeOutputToTerraform(struct?: StageExternalS3DescribeOutput): any;
export declare function stageExternalS3DescribeOutputToHclTerraform(struct?: StageExternalS3DescribeOutput): any;
export declare class StageExternalS3DescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalS3DescribeOutput | undefined;
    set internalValue(value: StageExternalS3DescribeOutput | undefined);
    private _directoryTable;
    get directoryTable(): StageExternalS3DescribeOutputDirectoryTableList;
    private _fileFormat;
    get fileFormat(): StageExternalS3DescribeOutputFileFormatList;
    private _location;
    get location(): StageExternalS3DescribeOutputLocationList;
    private _privatelink;
    get privatelink(): StageExternalS3DescribeOutputPrivatelinkList;
}
export declare class StageExternalS3DescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalS3DescribeOutputOutputReference;
}
export interface StageExternalS3ShowOutput {
}
export declare function stageExternalS3ShowOutputToTerraform(struct?: StageExternalS3ShowOutput): any;
export declare function stageExternalS3ShowOutputToHclTerraform(struct?: StageExternalS3ShowOutput): any;
export declare class StageExternalS3ShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalS3ShowOutput | undefined;
    set internalValue(value: StageExternalS3ShowOutput | undefined);
    get cloud(): string;
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get directoryEnabled(): cdktn.IResolvable;
    get endpoint(): string;
    get hasCredentials(): cdktn.IResolvable;
    get hasEncryptionKey(): cdktn.IResolvable;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get region(): string;
    get schemaName(): string;
    get storageIntegration(): string;
    get type(): string;
    get url(): string;
}
export declare class StageExternalS3ShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalS3ShowOutputOutputReference;
}
export interface StageExternalS3Credentials {
    /**
    * Specifies the AWS access key ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#aws_key_id StageExternalS3#aws_key_id}
    */
    readonly awsKeyId?: string;
    /**
    * Specifies the AWS IAM role ARN to use for accessing the bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#aws_role StageExternalS3#aws_role}
    */
    readonly awsRole?: string;
    /**
    * Specifies the AWS secret access key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#aws_secret_key StageExternalS3#aws_secret_key}
    */
    readonly awsSecretKey?: string;
    /**
    * Specifies the AWS session token for temporary credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#aws_token StageExternalS3#aws_token}
    */
    readonly awsToken?: string;
}
export declare function stageExternalS3CredentialsToTerraform(struct?: StageExternalS3CredentialsOutputReference | StageExternalS3Credentials): any;
export declare function stageExternalS3CredentialsToHclTerraform(struct?: StageExternalS3CredentialsOutputReference | StageExternalS3Credentials): any;
export declare class StageExternalS3CredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalS3Credentials | undefined;
    set internalValue(value: StageExternalS3Credentials | undefined);
    private _awsKeyId?;
    get awsKeyId(): string;
    set awsKeyId(value: string);
    resetAwsKeyId(): void;
    get awsKeyIdInput(): string | undefined;
    private _awsRole?;
    get awsRole(): string;
    set awsRole(value: string);
    resetAwsRole(): void;
    get awsRoleInput(): string | undefined;
    private _awsSecretKey?;
    get awsSecretKey(): string;
    set awsSecretKey(value: string);
    resetAwsSecretKey(): void;
    get awsSecretKeyInput(): string | undefined;
    private _awsToken?;
    get awsToken(): string;
    set awsToken(value: string);
    resetAwsToken(): void;
    get awsTokenInput(): string | undefined;
}
export interface StageExternalS3Directory {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether Snowflake should enable triggering automatic refreshes of the directory table metadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#auto_refresh StageExternalS3#auto_refresh}
    */
    readonly autoRefresh?: string;
    /**
    * Specifies whether to enable a directory table on the external stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#enable StageExternalS3#enable}
    */
    readonly enable: boolean | cdktn.IResolvable;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether to automatically refresh the directory table metadata once, immediately after the stage is created.This field is used only when creating the object. Changes on this field are ignored after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#refresh_on_create StageExternalS3#refresh_on_create}
    */
    readonly refreshOnCreate?: string;
}
export declare function stageExternalS3DirectoryToTerraform(struct?: StageExternalS3DirectoryOutputReference | StageExternalS3Directory): any;
export declare function stageExternalS3DirectoryToHclTerraform(struct?: StageExternalS3DirectoryOutputReference | StageExternalS3Directory): any;
export declare class StageExternalS3DirectoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalS3Directory | undefined;
    set internalValue(value: StageExternalS3Directory | undefined);
    private _autoRefresh?;
    get autoRefresh(): string;
    set autoRefresh(value: string);
    resetAutoRefresh(): void;
    get autoRefreshInput(): string | undefined;
    private _enable?;
    get enable(): boolean | cdktn.IResolvable;
    set enable(value: boolean | cdktn.IResolvable);
    get enableInput(): boolean | cdktn.IResolvable | undefined;
    private _refreshOnCreate?;
    get refreshOnCreate(): string;
    set refreshOnCreate(value: string);
    resetRefreshOnCreate(): void;
    get refreshOnCreateInput(): string | undefined;
}
export interface StageExternalS3EncryptionAwsCse {
    /**
    * Specifies the 128-bit or 256-bit client-side master key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#master_key StageExternalS3#master_key}
    */
    readonly masterKey: string;
}
export declare function stageExternalS3EncryptionAwsCseToTerraform(struct?: StageExternalS3EncryptionAwsCseOutputReference | StageExternalS3EncryptionAwsCse): any;
export declare function stageExternalS3EncryptionAwsCseToHclTerraform(struct?: StageExternalS3EncryptionAwsCseOutputReference | StageExternalS3EncryptionAwsCse): any;
export declare class StageExternalS3EncryptionAwsCseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalS3EncryptionAwsCse | undefined;
    set internalValue(value: StageExternalS3EncryptionAwsCse | undefined);
    private _masterKey?;
    get masterKey(): string;
    set masterKey(value: string);
    get masterKeyInput(): string | undefined;
}
export interface StageExternalS3EncryptionAwsSseKms {
    /**
    * Specifies the KMS-managed key ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#kms_key_id StageExternalS3#kms_key_id}
    */
    readonly kmsKeyId?: string;
}
export declare function stageExternalS3EncryptionAwsSseKmsToTerraform(struct?: StageExternalS3EncryptionAwsSseKmsOutputReference | StageExternalS3EncryptionAwsSseKms): any;
export declare function stageExternalS3EncryptionAwsSseKmsToHclTerraform(struct?: StageExternalS3EncryptionAwsSseKmsOutputReference | StageExternalS3EncryptionAwsSseKms): any;
export declare class StageExternalS3EncryptionAwsSseKmsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalS3EncryptionAwsSseKms | undefined;
    set internalValue(value: StageExternalS3EncryptionAwsSseKms | undefined);
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
}
export interface StageExternalS3EncryptionAwsSseS3 {
}
export declare function stageExternalS3EncryptionAwsSseS3ToTerraform(struct?: StageExternalS3EncryptionAwsSseS3OutputReference | StageExternalS3EncryptionAwsSseS3): any;
export declare function stageExternalS3EncryptionAwsSseS3ToHclTerraform(struct?: StageExternalS3EncryptionAwsSseS3OutputReference | StageExternalS3EncryptionAwsSseS3): any;
export declare class StageExternalS3EncryptionAwsSseS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalS3EncryptionAwsSseS3 | undefined;
    set internalValue(value: StageExternalS3EncryptionAwsSseS3 | undefined);
}
export interface StageExternalS3EncryptionNone {
}
export declare function stageExternalS3EncryptionNoneToTerraform(struct?: StageExternalS3EncryptionNoneOutputReference | StageExternalS3EncryptionNone): any;
export declare function stageExternalS3EncryptionNoneToHclTerraform(struct?: StageExternalS3EncryptionNoneOutputReference | StageExternalS3EncryptionNone): any;
export declare class StageExternalS3EncryptionNoneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalS3EncryptionNone | undefined;
    set internalValue(value: StageExternalS3EncryptionNone | undefined);
}
export interface StageExternalS3Encryption {
    /**
    * aws_cse block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#aws_cse StageExternalS3#aws_cse}
    */
    readonly awsCse?: StageExternalS3EncryptionAwsCse;
    /**
    * aws_sse_kms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#aws_sse_kms StageExternalS3#aws_sse_kms}
    */
    readonly awsSseKms?: StageExternalS3EncryptionAwsSseKms;
    /**
    * aws_sse_s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#aws_sse_s3 StageExternalS3#aws_sse_s3}
    */
    readonly awsSseS3?: StageExternalS3EncryptionAwsSseS3;
    /**
    * none block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#none StageExternalS3#none}
    */
    readonly none?: StageExternalS3EncryptionNone;
}
export declare function stageExternalS3EncryptionToTerraform(struct?: StageExternalS3EncryptionOutputReference | StageExternalS3Encryption): any;
export declare function stageExternalS3EncryptionToHclTerraform(struct?: StageExternalS3EncryptionOutputReference | StageExternalS3Encryption): any;
export declare class StageExternalS3EncryptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalS3Encryption | undefined;
    set internalValue(value: StageExternalS3Encryption | undefined);
    private _awsCse;
    get awsCse(): StageExternalS3EncryptionAwsCseOutputReference;
    putAwsCse(value: StageExternalS3EncryptionAwsCse): void;
    resetAwsCse(): void;
    get awsCseInput(): StageExternalS3EncryptionAwsCse | undefined;
    private _awsSseKms;
    get awsSseKms(): StageExternalS3EncryptionAwsSseKmsOutputReference;
    putAwsSseKms(value: StageExternalS3EncryptionAwsSseKms): void;
    resetAwsSseKms(): void;
    get awsSseKmsInput(): StageExternalS3EncryptionAwsSseKms | undefined;
    private _awsSseS3;
    get awsSseS3(): StageExternalS3EncryptionAwsSseS3OutputReference;
    putAwsSseS3(value: StageExternalS3EncryptionAwsSseS3): void;
    resetAwsSseS3(): void;
    get awsSseS3Input(): StageExternalS3EncryptionAwsSseS3 | undefined;
    private _none;
    get none(): StageExternalS3EncryptionNoneOutputReference;
    putNone(value: StageExternalS3EncryptionNone): void;
    resetNone(): void;
    get noneInput(): StageExternalS3EncryptionNone | undefined;
}
export interface StageExternalS3FileFormatAvro {
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#compression StageExternalS3#compression}
    */
    readonly compression?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#null_if StageExternalS3#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#replace_invalid_characters StageExternalS3#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#trim_space StageExternalS3#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageExternalS3FileFormatAvroToTerraform(struct?: StageExternalS3FileFormatAvroOutputReference | StageExternalS3FileFormatAvro): any;
export declare function stageExternalS3FileFormatAvroToHclTerraform(struct?: StageExternalS3FileFormatAvroOutputReference | StageExternalS3FileFormatAvro): any;
export declare class StageExternalS3FileFormatAvroOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalS3FileFormatAvro | undefined;
    set internalValue(value: StageExternalS3FileFormatAvro | undefined);
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageExternalS3FileFormatCsv {
    /**
    * Defines the encoding format for binary input or output. Valid values: `HEX` | `BASE64` | `UTF8`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#binary_format StageExternalS3#binary_format}
    */
    readonly binaryFormat?: string;
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BZ2` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#compression StageExternalS3#compression}
    */
    readonly compression?: string;
    /**
    * Defines the format of date values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#date_format StageExternalS3#date_format}
    */
    readonly dateFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to insert SQL NULL for empty fields in an input file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#empty_field_as_null StageExternalS3#empty_field_as_null}
    */
    readonly emptyFieldAsNull?: string;
    /**
    * Specifies the character set of the source data when loading data into a table. Valid values: `BIG5` | `EUCJP` | `EUCKR` | `GB18030` | `IBM420` | `IBM424` | `ISO2022CN` | `ISO2022JP` | `ISO2022KR` | `ISO88591` | `ISO88592` | `ISO88595` | `ISO88596` | `ISO88597` | `ISO88598` | `ISO88599` | `ISO885915` | `KOI8R` | `SHIFTJIS` | `UTF8` | `UTF16` | `UTF16BE` | `UTF16LE` | `UTF32` | `UTF32BE` | `UTF32LE` | `WINDOWS1250` | `WINDOWS1251` | `WINDOWS1252` | `WINDOWS1253` | `WINDOWS1254` | `WINDOWS1255` | `WINDOWS1256`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#encoding StageExternalS3#encoding}
    */
    readonly encoding?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to generate a parsing error if the number of delimited columns in an input file does not match the number of columns in the corresponding table. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#error_on_column_count_mismatch StageExternalS3#error_on_column_count_mismatch}
    */
    readonly errorOnColumnCountMismatch?: string;
    /**
    * Single character string used as the escape character for field values. Use `NONE` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#escape StageExternalS3#escape}
    */
    readonly escape?: string;
    /**
    * Single character string used as the escape character for unenclosed field values only. Use `NONE` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#escape_unenclosed_field StageExternalS3#escape_unenclosed_field}
    */
    readonly escapeUnenclosedField?: string;
    /**
    * One or more singlebyte or multibyte characters that separate fields in an input file. Use `NONE` to specify no delimiter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#field_delimiter StageExternalS3#field_delimiter}
    */
    readonly fieldDelimiter?: string;
    /**
    * Character used to enclose strings. Use `NONE` to specify no enclosure character.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#field_optionally_enclosed_by StageExternalS3#field_optionally_enclosed_by}
    */
    readonly fieldOptionallyEnclosedBy?: string;
    /**
    * Specifies the extension for files unloaded to a stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#file_extension StageExternalS3#file_extension}
    */
    readonly fileExtension?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to parse CSV files containing multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#multi_line StageExternalS3#multi_line}
    */
    readonly multiLine?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#null_if StageExternalS3#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to use the first row headers in the data files to determine column names. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#parse_header StageExternalS3#parse_header}
    */
    readonly parseHeader?: string;
    /**
    * One or more singlebyte or multibyte characters that separate records in an input file. Use `NONE` to specify no delimiter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#record_delimiter StageExternalS3#record_delimiter}
    */
    readonly recordDelimiter?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#replace_invalid_characters StageExternalS3#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies to skip any blank lines encountered in the data files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#skip_blank_lines StageExternalS3#skip_blank_lines}
    */
    readonly skipBlankLines?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#skip_byte_order_mark StageExternalS3#skip_byte_order_mark}
    */
    readonly skipByteOrderMark?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`-1`)) Number of lines at the start of the file to skip.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#skip_header StageExternalS3#skip_header}
    */
    readonly skipHeader?: number;
    /**
    * Defines the format of time values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#time_format StageExternalS3#time_format}
    */
    readonly timeFormat?: string;
    /**
    * Defines the format of timestamp values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#timestamp_format StageExternalS3#timestamp_format}
    */
    readonly timestampFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#trim_space StageExternalS3#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageExternalS3FileFormatCsvToTerraform(struct?: StageExternalS3FileFormatCsvOutputReference | StageExternalS3FileFormatCsv): any;
export declare function stageExternalS3FileFormatCsvToHclTerraform(struct?: StageExternalS3FileFormatCsvOutputReference | StageExternalS3FileFormatCsv): any;
export declare class StageExternalS3FileFormatCsvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalS3FileFormatCsv | undefined;
    set internalValue(value: StageExternalS3FileFormatCsv | undefined);
    private _binaryFormat?;
    get binaryFormat(): string;
    set binaryFormat(value: string);
    resetBinaryFormat(): void;
    get binaryFormatInput(): string | undefined;
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _dateFormat?;
    get dateFormat(): string;
    set dateFormat(value: string);
    resetDateFormat(): void;
    get dateFormatInput(): string | undefined;
    private _emptyFieldAsNull?;
    get emptyFieldAsNull(): string;
    set emptyFieldAsNull(value: string);
    resetEmptyFieldAsNull(): void;
    get emptyFieldAsNullInput(): string | undefined;
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    resetEncoding(): void;
    get encodingInput(): string | undefined;
    private _errorOnColumnCountMismatch?;
    get errorOnColumnCountMismatch(): string;
    set errorOnColumnCountMismatch(value: string);
    resetErrorOnColumnCountMismatch(): void;
    get errorOnColumnCountMismatchInput(): string | undefined;
    private _escape?;
    get escape(): string;
    set escape(value: string);
    resetEscape(): void;
    get escapeInput(): string | undefined;
    private _escapeUnenclosedField?;
    get escapeUnenclosedField(): string;
    set escapeUnenclosedField(value: string);
    resetEscapeUnenclosedField(): void;
    get escapeUnenclosedFieldInput(): string | undefined;
    private _fieldDelimiter?;
    get fieldDelimiter(): string;
    set fieldDelimiter(value: string);
    resetFieldDelimiter(): void;
    get fieldDelimiterInput(): string | undefined;
    private _fieldOptionallyEnclosedBy?;
    get fieldOptionallyEnclosedBy(): string;
    set fieldOptionallyEnclosedBy(value: string);
    resetFieldOptionallyEnclosedBy(): void;
    get fieldOptionallyEnclosedByInput(): string | undefined;
    private _fileExtension?;
    get fileExtension(): string;
    set fileExtension(value: string);
    resetFileExtension(): void;
    get fileExtensionInput(): string | undefined;
    private _multiLine?;
    get multiLine(): string;
    set multiLine(value: string);
    resetMultiLine(): void;
    get multiLineInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _parseHeader?;
    get parseHeader(): string;
    set parseHeader(value: string);
    resetParseHeader(): void;
    get parseHeaderInput(): string | undefined;
    private _recordDelimiter?;
    get recordDelimiter(): string;
    set recordDelimiter(value: string);
    resetRecordDelimiter(): void;
    get recordDelimiterInput(): string | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _skipBlankLines?;
    get skipBlankLines(): string;
    set skipBlankLines(value: string);
    resetSkipBlankLines(): void;
    get skipBlankLinesInput(): string | undefined;
    private _skipByteOrderMark?;
    get skipByteOrderMark(): string;
    set skipByteOrderMark(value: string);
    resetSkipByteOrderMark(): void;
    get skipByteOrderMarkInput(): string | undefined;
    private _skipHeader?;
    get skipHeader(): number;
    set skipHeader(value: number);
    resetSkipHeader(): void;
    get skipHeaderInput(): number | undefined;
    private _timeFormat?;
    get timeFormat(): string;
    set timeFormat(value: string);
    resetTimeFormat(): void;
    get timeFormatInput(): string | undefined;
    private _timestampFormat?;
    get timestampFormat(): string;
    set timestampFormat(value: string);
    resetTimestampFormat(): void;
    get timestampFormatInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageExternalS3FileFormatJson {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to allow duplicate object field names (only the last one will be preserved). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#allow_duplicate StageExternalS3#allow_duplicate}
    */
    readonly allowDuplicate?: string;
    /**
    * Defines the encoding format for binary input or output. Valid values: `HEX` | `BASE64` | `UTF8`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#binary_format StageExternalS3#binary_format}
    */
    readonly binaryFormat?: string;
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BZ2` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#compression StageExternalS3#compression}
    */
    readonly compression?: string;
    /**
    * Defines the format of date values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#date_format StageExternalS3#date_format}
    */
    readonly dateFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that enables parsing of octal numbers. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#enable_octal StageExternalS3#enable_octal}
    */
    readonly enableOctal?: string;
    /**
    * Specifies the extension for files unloaded to a stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#file_extension StageExternalS3#file_extension}
    */
    readonly fileExtension?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#ignore_utf8_errors StageExternalS3#ignore_utf8_errors}
    */
    readonly ignoreUtf8Errors?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to allow multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#multi_line StageExternalS3#multi_line}
    */
    readonly multiLine?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#null_if StageExternalS3#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#replace_invalid_characters StageExternalS3#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#skip_byte_order_mark StageExternalS3#skip_byte_order_mark}
    */
    readonly skipByteOrderMark?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that instructs the JSON parser to remove object fields or array elements containing null values. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#strip_null_values StageExternalS3#strip_null_values}
    */
    readonly stripNullValues?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that instructs the JSON parser to remove outer brackets. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#strip_outer_array StageExternalS3#strip_outer_array}
    */
    readonly stripOuterArray?: string;
    /**
    * Defines the format of time values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#time_format StageExternalS3#time_format}
    */
    readonly timeFormat?: string;
    /**
    * Defines the format of timestamp values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#timestamp_format StageExternalS3#timestamp_format}
    */
    readonly timestampFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#trim_space StageExternalS3#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageExternalS3FileFormatJsonToTerraform(struct?: StageExternalS3FileFormatJsonOutputReference | StageExternalS3FileFormatJson): any;
export declare function stageExternalS3FileFormatJsonToHclTerraform(struct?: StageExternalS3FileFormatJsonOutputReference | StageExternalS3FileFormatJson): any;
export declare class StageExternalS3FileFormatJsonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalS3FileFormatJson | undefined;
    set internalValue(value: StageExternalS3FileFormatJson | undefined);
    private _allowDuplicate?;
    get allowDuplicate(): string;
    set allowDuplicate(value: string);
    resetAllowDuplicate(): void;
    get allowDuplicateInput(): string | undefined;
    private _binaryFormat?;
    get binaryFormat(): string;
    set binaryFormat(value: string);
    resetBinaryFormat(): void;
    get binaryFormatInput(): string | undefined;
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _dateFormat?;
    get dateFormat(): string;
    set dateFormat(value: string);
    resetDateFormat(): void;
    get dateFormatInput(): string | undefined;
    private _enableOctal?;
    get enableOctal(): string;
    set enableOctal(value: string);
    resetEnableOctal(): void;
    get enableOctalInput(): string | undefined;
    private _fileExtension?;
    get fileExtension(): string;
    set fileExtension(value: string);
    resetFileExtension(): void;
    get fileExtensionInput(): string | undefined;
    private _ignoreUtf8Errors?;
    get ignoreUtf8Errors(): string;
    set ignoreUtf8Errors(value: string);
    resetIgnoreUtf8Errors(): void;
    get ignoreUtf8ErrorsInput(): string | undefined;
    private _multiLine?;
    get multiLine(): string;
    set multiLine(value: string);
    resetMultiLine(): void;
    get multiLineInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _skipByteOrderMark?;
    get skipByteOrderMark(): string;
    set skipByteOrderMark(value: string);
    resetSkipByteOrderMark(): void;
    get skipByteOrderMarkInput(): string | undefined;
    private _stripNullValues?;
    get stripNullValues(): string;
    set stripNullValues(value: string);
    resetStripNullValues(): void;
    get stripNullValuesInput(): string | undefined;
    private _stripOuterArray?;
    get stripOuterArray(): string;
    set stripOuterArray(value: string);
    resetStripOuterArray(): void;
    get stripOuterArrayInput(): string | undefined;
    private _timeFormat?;
    get timeFormat(): string;
    set timeFormat(value: string);
    resetTimeFormat(): void;
    get timeFormatInput(): string | undefined;
    private _timestampFormat?;
    get timestampFormat(): string;
    set timestampFormat(value: string);
    resetTimestampFormat(): void;
    get timestampFormatInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageExternalS3FileFormatOrc {
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#null_if StageExternalS3#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#replace_invalid_characters StageExternalS3#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#trim_space StageExternalS3#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageExternalS3FileFormatOrcToTerraform(struct?: StageExternalS3FileFormatOrcOutputReference | StageExternalS3FileFormatOrc): any;
export declare function stageExternalS3FileFormatOrcToHclTerraform(struct?: StageExternalS3FileFormatOrcOutputReference | StageExternalS3FileFormatOrc): any;
export declare class StageExternalS3FileFormatOrcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalS3FileFormatOrc | undefined;
    set internalValue(value: StageExternalS3FileFormatOrc | undefined);
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageExternalS3FileFormatParquet {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to interpret columns with no defined logical data type as UTF-8 text. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#binary_as_text StageExternalS3#binary_as_text}
    */
    readonly binaryAsText?: string;
    /**
    * Specifies the compression format. Valid values: `AUTO` | `LZO` | `SNAPPY` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#compression StageExternalS3#compression}
    */
    readonly compression?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#null_if StageExternalS3#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#replace_invalid_characters StageExternalS3#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#trim_space StageExternalS3#trim_space}
    */
    readonly trimSpace?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to use Parquet logical types when loading data. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#use_logical_type StageExternalS3#use_logical_type}
    */
    readonly useLogicalType?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to use a vectorized scanner for loading Parquet files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#use_vectorized_scanner StageExternalS3#use_vectorized_scanner}
    */
    readonly useVectorizedScanner?: string;
}
export declare function stageExternalS3FileFormatParquetToTerraform(struct?: StageExternalS3FileFormatParquetOutputReference | StageExternalS3FileFormatParquet): any;
export declare function stageExternalS3FileFormatParquetToHclTerraform(struct?: StageExternalS3FileFormatParquetOutputReference | StageExternalS3FileFormatParquet): any;
export declare class StageExternalS3FileFormatParquetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalS3FileFormatParquet | undefined;
    set internalValue(value: StageExternalS3FileFormatParquet | undefined);
    private _binaryAsText?;
    get binaryAsText(): string;
    set binaryAsText(value: string);
    resetBinaryAsText(): void;
    get binaryAsTextInput(): string | undefined;
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
    private _useLogicalType?;
    get useLogicalType(): string;
    set useLogicalType(value: string);
    resetUseLogicalType(): void;
    get useLogicalTypeInput(): string | undefined;
    private _useVectorizedScanner?;
    get useVectorizedScanner(): string;
    set useVectorizedScanner(value: string);
    resetUseVectorizedScanner(): void;
    get useVectorizedScannerInput(): string | undefined;
}
export interface StageExternalS3FileFormatXml {
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BZ2` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#compression StageExternalS3#compression}
    */
    readonly compression?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether the XML parser disables automatic conversion of numeric and Boolean values from text to native representation. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#disable_auto_convert StageExternalS3#disable_auto_convert}
    */
    readonly disableAutoConvert?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#ignore_utf8_errors StageExternalS3#ignore_utf8_errors}
    */
    readonly ignoreUtf8Errors?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether the XML parser preserves leading and trailing spaces in element content. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#preserve_space StageExternalS3#preserve_space}
    */
    readonly preserveSpace?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#replace_invalid_characters StageExternalS3#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#skip_byte_order_mark StageExternalS3#skip_byte_order_mark}
    */
    readonly skipByteOrderMark?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether the XML parser strips out the outer XML element, exposing 2nd level elements as separate documents. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#strip_outer_element StageExternalS3#strip_outer_element}
    */
    readonly stripOuterElement?: string;
}
export declare function stageExternalS3FileFormatXmlToTerraform(struct?: StageExternalS3FileFormatXmlOutputReference | StageExternalS3FileFormatXml): any;
export declare function stageExternalS3FileFormatXmlToHclTerraform(struct?: StageExternalS3FileFormatXmlOutputReference | StageExternalS3FileFormatXml): any;
export declare class StageExternalS3FileFormatXmlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalS3FileFormatXml | undefined;
    set internalValue(value: StageExternalS3FileFormatXml | undefined);
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _disableAutoConvert?;
    get disableAutoConvert(): string;
    set disableAutoConvert(value: string);
    resetDisableAutoConvert(): void;
    get disableAutoConvertInput(): string | undefined;
    private _ignoreUtf8Errors?;
    get ignoreUtf8Errors(): string;
    set ignoreUtf8Errors(value: string);
    resetIgnoreUtf8Errors(): void;
    get ignoreUtf8ErrorsInput(): string | undefined;
    private _preserveSpace?;
    get preserveSpace(): string;
    set preserveSpace(value: string);
    resetPreserveSpace(): void;
    get preserveSpaceInput(): string | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _skipByteOrderMark?;
    get skipByteOrderMark(): string;
    set skipByteOrderMark(value: string);
    resetSkipByteOrderMark(): void;
    get skipByteOrderMarkInput(): string | undefined;
    private _stripOuterElement?;
    get stripOuterElement(): string;
    set stripOuterElement(value: string);
    resetStripOuterElement(): void;
    get stripOuterElementInput(): string | undefined;
}
export interface StageExternalS3FileFormat {
    /**
    * Fully qualified name of the file format (e.g., 'database.schema.format_name').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#format_name StageExternalS3#format_name}
    */
    readonly formatName?: string;
    /**
    * avro block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#avro StageExternalS3#avro}
    */
    readonly avro?: StageExternalS3FileFormatAvro;
    /**
    * csv block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#csv StageExternalS3#csv}
    */
    readonly csv?: StageExternalS3FileFormatCsv;
    /**
    * json block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#json StageExternalS3#json}
    */
    readonly json?: StageExternalS3FileFormatJson;
    /**
    * orc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#orc StageExternalS3#orc}
    */
    readonly orc?: StageExternalS3FileFormatOrc;
    /**
    * parquet block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#parquet StageExternalS3#parquet}
    */
    readonly parquet?: StageExternalS3FileFormatParquet;
    /**
    * xml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#xml StageExternalS3#xml}
    */
    readonly xml?: StageExternalS3FileFormatXml;
}
export declare function stageExternalS3FileFormatToTerraform(struct?: StageExternalS3FileFormatOutputReference | StageExternalS3FileFormat): any;
export declare function stageExternalS3FileFormatToHclTerraform(struct?: StageExternalS3FileFormatOutputReference | StageExternalS3FileFormat): any;
export declare class StageExternalS3FileFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalS3FileFormat | undefined;
    set internalValue(value: StageExternalS3FileFormat | undefined);
    private _formatName?;
    get formatName(): string;
    set formatName(value: string);
    resetFormatName(): void;
    get formatNameInput(): string | undefined;
    private _avro;
    get avro(): StageExternalS3FileFormatAvroOutputReference;
    putAvro(value: StageExternalS3FileFormatAvro): void;
    resetAvro(): void;
    get avroInput(): StageExternalS3FileFormatAvro | undefined;
    private _csv;
    get csv(): StageExternalS3FileFormatCsvOutputReference;
    putCsv(value: StageExternalS3FileFormatCsv): void;
    resetCsv(): void;
    get csvInput(): StageExternalS3FileFormatCsv | undefined;
    private _json;
    get json(): StageExternalS3FileFormatJsonOutputReference;
    putJson(value: StageExternalS3FileFormatJson): void;
    resetJson(): void;
    get jsonInput(): StageExternalS3FileFormatJson | undefined;
    private _orc;
    get orc(): StageExternalS3FileFormatOrcOutputReference;
    putOrc(value: StageExternalS3FileFormatOrc): void;
    resetOrc(): void;
    get orcInput(): StageExternalS3FileFormatOrc | undefined;
    private _parquet;
    get parquet(): StageExternalS3FileFormatParquetOutputReference;
    putParquet(value: StageExternalS3FileFormatParquet): void;
    resetParquet(): void;
    get parquetInput(): StageExternalS3FileFormatParquet | undefined;
    private _xml;
    get xml(): StageExternalS3FileFormatXmlOutputReference;
    putXml(value: StageExternalS3FileFormatXml): void;
    resetXml(): void;
    get xmlInput(): StageExternalS3FileFormatXml | undefined;
}
export interface StageExternalS3Timeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#create StageExternalS3#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#delete StageExternalS3#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#read StageExternalS3#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#update StageExternalS3#update}
    */
    readonly update?: string;
}
export declare function stageExternalS3TimeoutsToTerraform(struct?: StageExternalS3Timeouts | cdktn.IResolvable): any;
export declare function stageExternalS3TimeoutsToHclTerraform(struct?: StageExternalS3Timeouts | cdktn.IResolvable): any;
export declare class StageExternalS3TimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalS3Timeouts | cdktn.IResolvable | undefined;
    set internalValue(value: StageExternalS3Timeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3 snowflake_stage_external_s3}
*/
export declare class StageExternalS3 extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_stage_external_s3";
    /**
    * Generates CDKTN code for importing a StageExternalS3 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StageExternalS3 to import
    * @param importFromId The id of the existing StageExternalS3 that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StageExternalS3 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_s3 snowflake_stage_external_s3} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StageExternalS3Config
    */
    constructor(scope: Construct, id: string, config: StageExternalS3Config);
    private _awsAccessPointArn?;
    get awsAccessPointArn(): string;
    set awsAccessPointArn(value: string);
    resetAwsAccessPointArn(): void;
    get awsAccessPointArnInput(): string | undefined;
    get cloud(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): StageExternalS3DescribeOutputList;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): StageExternalS3ShowOutputList;
    get stageType(): string;
    private _storageIntegration?;
    get storageIntegration(): string;
    set storageIntegration(value: string);
    resetStorageIntegration(): void;
    get storageIntegrationInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _usePrivatelinkEndpoint?;
    get usePrivatelinkEndpoint(): string;
    set usePrivatelinkEndpoint(value: string);
    resetUsePrivatelinkEndpoint(): void;
    get usePrivatelinkEndpointInput(): string | undefined;
    private _credentials;
    get credentials(): StageExternalS3CredentialsOutputReference;
    putCredentials(value: StageExternalS3Credentials): void;
    resetCredentials(): void;
    get credentialsInput(): StageExternalS3Credentials | undefined;
    private _directory;
    get directory(): StageExternalS3DirectoryOutputReference;
    putDirectory(value: StageExternalS3Directory): void;
    resetDirectory(): void;
    get directoryInput(): StageExternalS3Directory | undefined;
    private _encryption;
    get encryption(): StageExternalS3EncryptionOutputReference;
    putEncryption(value: StageExternalS3Encryption): void;
    resetEncryption(): void;
    get encryptionInput(): StageExternalS3Encryption | undefined;
    private _fileFormat;
    get fileFormat(): StageExternalS3FileFormatOutputReference;
    putFileFormat(value: StageExternalS3FileFormat): void;
    resetFileFormat(): void;
    get fileFormatInput(): StageExternalS3FileFormat | undefined;
    private _timeouts;
    get timeouts(): StageExternalS3TimeoutsOutputReference;
    putTimeouts(value: StageExternalS3Timeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | StageExternalS3Timeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
