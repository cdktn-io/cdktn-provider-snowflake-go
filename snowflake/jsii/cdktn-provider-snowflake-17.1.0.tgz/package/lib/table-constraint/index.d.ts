/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TableConstraintConfig extends cdktn.TerraformMetaArguments {
    /**
    * Columns to use in constraint key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#columns TableConstraint#columns}
    */
    readonly columns: string[];
    /**
    * Comment for the table constraint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#comment TableConstraint#comment}
    */
    readonly comment?: string;
    /**
    * (Default: `true`) Whether the constraint is deferrable
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#deferrable TableConstraint#deferrable}
    */
    readonly deferrable?: boolean | cdktn.IResolvable;
    /**
    * (Default: `true`) Specifies whether the constraint is enabled or disabled. These properties are provided for compatibility with Oracle.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#enable TableConstraint#enable}
    */
    readonly enable?: boolean | cdktn.IResolvable;
    /**
    * (Default: `false`) Whether the constraint is enforced
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#enforced TableConstraint#enforced}
    */
    readonly enforced?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#id TableConstraint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * (Default: `DEFERRED`) Whether the constraint is initially deferred or immediate
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#initially TableConstraint#initially}
    */
    readonly initially?: string;
    /**
    * Name of constraint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#name TableConstraint#name}
    */
    readonly name: string;
    /**
    * (Default: `true`) Specifies whether a constraint in NOVALIDATE mode is taken into account during query rewrite.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#rely TableConstraint#rely}
    */
    readonly rely?: boolean | cdktn.IResolvable;
    /**
    * Identifier for table to create constraint on. Format must follow: "\"&lt;db_name&gt;\".\"&lt;schema_name&gt;\".\"&lt;table_name&gt;\"" or "&lt;db_name&gt;.&lt;schema_name&gt;.&lt;table_name&gt;" (snowflake_table.my_table.id)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#table_id TableConstraint#table_id}
    */
    readonly tableId: string;
    /**
    * Type of constraint, one of 'UNIQUE', 'PRIMARY KEY', or 'FOREIGN KEY'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#type TableConstraint#type}
    */
    readonly type: string;
    /**
    * (Default: `false`) Specifies whether to validate existing data on the table when a constraint is created. Only used in conjunction with the ENABLE property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#validate TableConstraint#validate}
    */
    readonly validate?: boolean | cdktn.IResolvable;
    /**
    * foreign_key_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#foreign_key_properties TableConstraint#foreign_key_properties}
    */
    readonly foreignKeyProperties?: TableConstraintForeignKeyProperties;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#timeouts TableConstraint#timeouts}
    */
    readonly timeouts?: TableConstraintTimeouts;
}
export interface TableConstraintForeignKeyPropertiesReferences {
    /**
    * Columns to use in foreign key reference
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#columns TableConstraint#columns}
    */
    readonly columns: string[];
    /**
    * Name of constraint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#table_id TableConstraint#table_id}
    */
    readonly tableId: string;
}
export declare function tableConstraintForeignKeyPropertiesReferencesToTerraform(struct?: TableConstraintForeignKeyPropertiesReferencesOutputReference | TableConstraintForeignKeyPropertiesReferences): any;
export declare function tableConstraintForeignKeyPropertiesReferencesToHclTerraform(struct?: TableConstraintForeignKeyPropertiesReferencesOutputReference | TableConstraintForeignKeyPropertiesReferences): any;
export declare class TableConstraintForeignKeyPropertiesReferencesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TableConstraintForeignKeyPropertiesReferences | undefined;
    set internalValue(value: TableConstraintForeignKeyPropertiesReferences | undefined);
    private _columns?;
    get columns(): string[];
    set columns(value: string[]);
    get columnsInput(): string[] | undefined;
    private _tableId?;
    get tableId(): string;
    set tableId(value: string);
    get tableIdInput(): string | undefined;
}
export interface TableConstraintForeignKeyProperties {
    /**
    * (Default: `FULL`) The match type for the foreign key. Not applicable for primary/unique keys
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#match TableConstraint#match}
    */
    readonly match?: string;
    /**
    * (Default: `NO ACTION`) Specifies the action performed when the primary/unique key for the foreign key is deleted. Not applicable for primary/unique keys
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#on_delete TableConstraint#on_delete}
    */
    readonly onDelete?: string;
    /**
    * (Default: `NO ACTION`) Specifies the action performed when the primary/unique key for the foreign key is updated. Not applicable for primary/unique keys
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#on_update TableConstraint#on_update}
    */
    readonly onUpdate?: string;
    /**
    * references block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#references TableConstraint#references}
    */
    readonly references: TableConstraintForeignKeyPropertiesReferences;
}
export declare function tableConstraintForeignKeyPropertiesToTerraform(struct?: TableConstraintForeignKeyPropertiesOutputReference | TableConstraintForeignKeyProperties): any;
export declare function tableConstraintForeignKeyPropertiesToHclTerraform(struct?: TableConstraintForeignKeyPropertiesOutputReference | TableConstraintForeignKeyProperties): any;
export declare class TableConstraintForeignKeyPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TableConstraintForeignKeyProperties | undefined;
    set internalValue(value: TableConstraintForeignKeyProperties | undefined);
    private _match?;
    get match(): string;
    set match(value: string);
    resetMatch(): void;
    get matchInput(): string | undefined;
    private _onDelete?;
    get onDelete(): string;
    set onDelete(value: string);
    resetOnDelete(): void;
    get onDeleteInput(): string | undefined;
    private _onUpdate?;
    get onUpdate(): string;
    set onUpdate(value: string);
    resetOnUpdate(): void;
    get onUpdateInput(): string | undefined;
    private _references;
    get references(): TableConstraintForeignKeyPropertiesReferencesOutputReference;
    putReferences(value: TableConstraintForeignKeyPropertiesReferences): void;
    get referencesInput(): TableConstraintForeignKeyPropertiesReferences | undefined;
}
export interface TableConstraintTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#create TableConstraint#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#delete TableConstraint#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#read TableConstraint#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#update TableConstraint#update}
    */
    readonly update?: string;
}
export declare function tableConstraintTimeoutsToTerraform(struct?: TableConstraintTimeouts | cdktn.IResolvable): any;
export declare function tableConstraintTimeoutsToHclTerraform(struct?: TableConstraintTimeouts | cdktn.IResolvable): any;
export declare class TableConstraintTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TableConstraintTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: TableConstraintTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint snowflake_table_constraint}
*/
export declare class TableConstraint extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_table_constraint";
    /**
    * Generates CDKTN code for importing a TableConstraint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TableConstraint to import
    * @param importFromId The id of the existing TableConstraint that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TableConstraint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/table_constraint snowflake_table_constraint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TableConstraintConfig
    */
    constructor(scope: Construct, id: string, config: TableConstraintConfig);
    private _columns?;
    get columns(): string[];
    set columns(value: string[]);
    get columnsInput(): string[] | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _deferrable?;
    get deferrable(): boolean | cdktn.IResolvable;
    set deferrable(value: boolean | cdktn.IResolvable);
    resetDeferrable(): void;
    get deferrableInput(): boolean | cdktn.IResolvable | undefined;
    private _enable?;
    get enable(): boolean | cdktn.IResolvable;
    set enable(value: boolean | cdktn.IResolvable);
    resetEnable(): void;
    get enableInput(): boolean | cdktn.IResolvable | undefined;
    private _enforced?;
    get enforced(): boolean | cdktn.IResolvable;
    set enforced(value: boolean | cdktn.IResolvable);
    resetEnforced(): void;
    get enforcedInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _initially?;
    get initially(): string;
    set initially(value: string);
    resetInitially(): void;
    get initiallyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rely?;
    get rely(): boolean | cdktn.IResolvable;
    set rely(value: boolean | cdktn.IResolvable);
    resetRely(): void;
    get relyInput(): boolean | cdktn.IResolvable | undefined;
    private _tableId?;
    get tableId(): string;
    set tableId(value: string);
    get tableIdInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _validate?;
    get validate(): boolean | cdktn.IResolvable;
    set validate(value: boolean | cdktn.IResolvable);
    resetValidate(): void;
    get validateInput(): boolean | cdktn.IResolvable | undefined;
    private _foreignKeyProperties;
    get foreignKeyProperties(): TableConstraintForeignKeyPropertiesOutputReference;
    putForeignKeyProperties(value: TableConstraintForeignKeyProperties): void;
    resetForeignKeyProperties(): void;
    get foreignKeyPropertiesInput(): TableConstraintForeignKeyProperties | undefined;
    private _timeouts;
    get timeouts(): TableConstraintTimeoutsOutputReference;
    putTimeouts(value: TableConstraintTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TableConstraintTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
