/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeCortexAgentsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents#id DataSnowflakeCortexAgents#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents#like DataSnowflakeCortexAgents#like}
    */
    readonly like?: string;
    /**
    * Filters the output with **case-sensitive** characters indicating the beginning of the object name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents#starts_with DataSnowflakeCortexAgents#starts_with}
    */
    readonly startsWith?: string;
    /**
    * (Default: `true`) Runs DESC AGENT for each object returned by SHOW AGENTS. The output of describe is saved to the describe_output field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents#with_describe DataSnowflakeCortexAgents#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * in block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents#in DataSnowflakeCortexAgents#in}
    */
    readonly in?: DataSnowflakeCortexAgentsIn;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents#limit DataSnowflakeCortexAgents#limit}
    */
    readonly limit?: DataSnowflakeCortexAgentsLimit;
}
export interface DataSnowflakeCortexAgentsCortexAgentsDescribeOutputProfile {
}
export declare function dataSnowflakeCortexAgentsCortexAgentsDescribeOutputProfileToTerraform(struct?: DataSnowflakeCortexAgentsCortexAgentsDescribeOutputProfile): any;
export declare function dataSnowflakeCortexAgentsCortexAgentsDescribeOutputProfileToHclTerraform(struct?: DataSnowflakeCortexAgentsCortexAgentsDescribeOutputProfile): any;
export declare class DataSnowflakeCortexAgentsCortexAgentsDescribeOutputProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeCortexAgentsCortexAgentsDescribeOutputProfile | undefined;
    set internalValue(value: DataSnowflakeCortexAgentsCortexAgentsDescribeOutputProfile | undefined);
    get avatar(): string;
    get color(): string;
    get displayName(): string;
}
export declare class DataSnowflakeCortexAgentsCortexAgentsDescribeOutputProfileList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeCortexAgentsCortexAgentsDescribeOutputProfileOutputReference;
}
export interface DataSnowflakeCortexAgentsCortexAgentsDescribeOutput {
}
export declare function dataSnowflakeCortexAgentsCortexAgentsDescribeOutputToTerraform(struct?: DataSnowflakeCortexAgentsCortexAgentsDescribeOutput): any;
export declare function dataSnowflakeCortexAgentsCortexAgentsDescribeOutputToHclTerraform(struct?: DataSnowflakeCortexAgentsCortexAgentsDescribeOutput): any;
export declare class DataSnowflakeCortexAgentsCortexAgentsDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeCortexAgentsCortexAgentsDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeCortexAgentsCortexAgentsDescribeOutput | undefined);
    get agentSpec(): string;
    get aliases(): string;
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get defaultVersionName(): string;
    get name(): string;
    get owner(): string;
    private _profile;
    get profile(): DataSnowflakeCortexAgentsCortexAgentsDescribeOutputProfileList;
    get schemaName(): string;
    get versions(): string;
}
export declare class DataSnowflakeCortexAgentsCortexAgentsDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeCortexAgentsCortexAgentsDescribeOutputOutputReference;
}
export interface DataSnowflakeCortexAgentsCortexAgentsShowOutputProfile {
}
export declare function dataSnowflakeCortexAgentsCortexAgentsShowOutputProfileToTerraform(struct?: DataSnowflakeCortexAgentsCortexAgentsShowOutputProfile): any;
export declare function dataSnowflakeCortexAgentsCortexAgentsShowOutputProfileToHclTerraform(struct?: DataSnowflakeCortexAgentsCortexAgentsShowOutputProfile): any;
export declare class DataSnowflakeCortexAgentsCortexAgentsShowOutputProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeCortexAgentsCortexAgentsShowOutputProfile | undefined;
    set internalValue(value: DataSnowflakeCortexAgentsCortexAgentsShowOutputProfile | undefined);
    get avatar(): string;
    get color(): string;
    get displayName(): string;
}
export declare class DataSnowflakeCortexAgentsCortexAgentsShowOutputProfileList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeCortexAgentsCortexAgentsShowOutputProfileOutputReference;
}
export interface DataSnowflakeCortexAgentsCortexAgentsShowOutput {
}
export declare function dataSnowflakeCortexAgentsCortexAgentsShowOutputToTerraform(struct?: DataSnowflakeCortexAgentsCortexAgentsShowOutput): any;
export declare function dataSnowflakeCortexAgentsCortexAgentsShowOutputToHclTerraform(struct?: DataSnowflakeCortexAgentsCortexAgentsShowOutput): any;
export declare class DataSnowflakeCortexAgentsCortexAgentsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeCortexAgentsCortexAgentsShowOutput | undefined;
    set internalValue(value: DataSnowflakeCortexAgentsCortexAgentsShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get name(): string;
    get owner(): string;
    private _profile;
    get profile(): DataSnowflakeCortexAgentsCortexAgentsShowOutputProfileList;
    get schemaName(): string;
}
export declare class DataSnowflakeCortexAgentsCortexAgentsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeCortexAgentsCortexAgentsShowOutputOutputReference;
}
export interface DataSnowflakeCortexAgentsCortexAgents {
}
export declare function dataSnowflakeCortexAgentsCortexAgentsToTerraform(struct?: DataSnowflakeCortexAgentsCortexAgents): any;
export declare function dataSnowflakeCortexAgentsCortexAgentsToHclTerraform(struct?: DataSnowflakeCortexAgentsCortexAgents): any;
export declare class DataSnowflakeCortexAgentsCortexAgentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeCortexAgentsCortexAgents | undefined;
    set internalValue(value: DataSnowflakeCortexAgentsCortexAgents | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeCortexAgentsCortexAgentsDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeCortexAgentsCortexAgentsShowOutputList;
}
export declare class DataSnowflakeCortexAgentsCortexAgentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeCortexAgentsCortexAgentsOutputReference;
}
export interface DataSnowflakeCortexAgentsIn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents#account DataSnowflakeCortexAgents#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the specified application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents#application DataSnowflakeCortexAgents#application}
    */
    readonly application?: string;
    /**
    * Returns records for the specified application package.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents#application_package DataSnowflakeCortexAgents#application_package}
    */
    readonly applicationPackage?: string;
    /**
    * Returns records for the current database in use or for a specified database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents#database DataSnowflakeCortexAgents#database}
    */
    readonly database?: string;
    /**
    * Returns records for the current schema in use or a specified schema. Use fully qualified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents#schema DataSnowflakeCortexAgents#schema}
    */
    readonly schema?: string;
}
export declare function dataSnowflakeCortexAgentsInToTerraform(struct?: DataSnowflakeCortexAgentsInOutputReference | DataSnowflakeCortexAgentsIn): any;
export declare function dataSnowflakeCortexAgentsInToHclTerraform(struct?: DataSnowflakeCortexAgentsInOutputReference | DataSnowflakeCortexAgentsIn): any;
export declare class DataSnowflakeCortexAgentsInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeCortexAgentsIn | undefined;
    set internalValue(value: DataSnowflakeCortexAgentsIn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _application?;
    get application(): string;
    set application(value: string);
    resetApplication(): void;
    get applicationInput(): string | undefined;
    private _applicationPackage?;
    get applicationPackage(): string;
    set applicationPackage(value: string);
    resetApplicationPackage(): void;
    get applicationPackageInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export interface DataSnowflakeCortexAgentsLimit {
    /**
    * Specifies a **case-sensitive** pattern that is used to match object name. After the first match, the limit on the number of rows will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents#from DataSnowflakeCortexAgents#from}
    */
    readonly from?: string;
    /**
    * The maximum number of rows to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents#rows DataSnowflakeCortexAgents#rows}
    */
    readonly rows: number;
}
export declare function dataSnowflakeCortexAgentsLimitToTerraform(struct?: DataSnowflakeCortexAgentsLimitOutputReference | DataSnowflakeCortexAgentsLimit): any;
export declare function dataSnowflakeCortexAgentsLimitToHclTerraform(struct?: DataSnowflakeCortexAgentsLimitOutputReference | DataSnowflakeCortexAgentsLimit): any;
export declare class DataSnowflakeCortexAgentsLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeCortexAgentsLimit | undefined;
    set internalValue(value: DataSnowflakeCortexAgentsLimit | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _rows?;
    get rows(): number;
    set rows(value: number);
    get rowsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents snowflake_cortex_agents}
*/
export declare class DataSnowflakeCortexAgents extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_cortex_agents";
    /**
    * Generates CDKTN code for importing a DataSnowflakeCortexAgents resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeCortexAgents to import
    * @param importFromId The id of the existing DataSnowflakeCortexAgents that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeCortexAgents to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/cortex_agents snowflake_cortex_agents} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeCortexAgentsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeCortexAgentsConfig);
    private _cortexAgents;
    get cortexAgents(): DataSnowflakeCortexAgentsCortexAgentsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _startsWith?;
    get startsWith(): string;
    set startsWith(value: string);
    resetStartsWith(): void;
    get startsWithInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _in;
    get in(): DataSnowflakeCortexAgentsInOutputReference;
    putIn(value: DataSnowflakeCortexAgentsIn): void;
    resetIn(): void;
    get inInput(): DataSnowflakeCortexAgentsIn | undefined;
    private _limit;
    get limit(): DataSnowflakeCortexAgentsLimitOutputReference;
    putLimit(value: DataSnowflakeCortexAgentsLimit): void;
    resetLimit(): void;
    get limitInput(): DataSnowflakeCortexAgentsLimit | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
