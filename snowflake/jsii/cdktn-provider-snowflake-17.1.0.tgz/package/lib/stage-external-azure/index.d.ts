/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StageExternalAzureConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#comment StageExternalAzure#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the stage. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#database StageExternalAzure#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#id StageExternalAzure#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the stage; must be unique for the database and schema in which the stage is created. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#name StageExternalAzure#name}
    */
    readonly name: string;
    /**
    * The schema in which to create the stage. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#schema StageExternalAzure#schema}
    */
    readonly schema: string;
    /**
    * Specifies the name of the storage integration used to delegate authentication responsibility to a Snowflake identity. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#storage_integration StageExternalAzure#storage_integration}
    */
    readonly storageIntegration?: string;
    /**
    * Specifies the URL for the Azure storage container (e.g., 'azure://account.blob.core.windows.net/container').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#url StageExternalAzure#url}
    */
    readonly url: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether to use a private link endpoint for Azure storage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#use_privatelink_endpoint StageExternalAzure#use_privatelink_endpoint}
    */
    readonly usePrivatelinkEndpoint?: string;
    /**
    * credentials block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#credentials StageExternalAzure#credentials}
    */
    readonly credentials?: StageExternalAzureCredentials;
    /**
    * directory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#directory StageExternalAzure#directory}
    */
    readonly directory?: StageExternalAzureDirectory;
    /**
    * encryption block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#encryption StageExternalAzure#encryption}
    */
    readonly encryption?: StageExternalAzureEncryption;
    /**
    * file_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#file_format StageExternalAzure#file_format}
    */
    readonly fileFormat?: StageExternalAzureFileFormat;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#timeouts StageExternalAzure#timeouts}
    */
    readonly timeouts?: StageExternalAzureTimeouts;
}
export interface StageExternalAzureDescribeOutputDirectoryTable {
}
export declare function stageExternalAzureDescribeOutputDirectoryTableToTerraform(struct?: StageExternalAzureDescribeOutputDirectoryTable): any;
export declare function stageExternalAzureDescribeOutputDirectoryTableToHclTerraform(struct?: StageExternalAzureDescribeOutputDirectoryTable): any;
export declare class StageExternalAzureDescribeOutputDirectoryTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalAzureDescribeOutputDirectoryTable | undefined;
    set internalValue(value: StageExternalAzureDescribeOutputDirectoryTable | undefined);
    get autoRefresh(): cdktn.IResolvable;
    get enable(): cdktn.IResolvable;
    get lastRefreshedOn(): string;
}
export declare class StageExternalAzureDescribeOutputDirectoryTableList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalAzureDescribeOutputDirectoryTableOutputReference;
}
export interface StageExternalAzureDescribeOutputFileFormatAvro {
}
export declare function stageExternalAzureDescribeOutputFileFormatAvroToTerraform(struct?: StageExternalAzureDescribeOutputFileFormatAvro): any;
export declare function stageExternalAzureDescribeOutputFileFormatAvroToHclTerraform(struct?: StageExternalAzureDescribeOutputFileFormatAvro): any;
export declare class StageExternalAzureDescribeOutputFileFormatAvroOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalAzureDescribeOutputFileFormatAvro | undefined;
    set internalValue(value: StageExternalAzureDescribeOutputFileFormatAvro | undefined);
    get compression(): string;
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageExternalAzureDescribeOutputFileFormatAvroList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalAzureDescribeOutputFileFormatAvroOutputReference;
}
export interface StageExternalAzureDescribeOutputFileFormatCsv {
}
export declare function stageExternalAzureDescribeOutputFileFormatCsvToTerraform(struct?: StageExternalAzureDescribeOutputFileFormatCsv): any;
export declare function stageExternalAzureDescribeOutputFileFormatCsvToHclTerraform(struct?: StageExternalAzureDescribeOutputFileFormatCsv): any;
export declare class StageExternalAzureDescribeOutputFileFormatCsvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalAzureDescribeOutputFileFormatCsv | undefined;
    set internalValue(value: StageExternalAzureDescribeOutputFileFormatCsv | undefined);
    get binaryFormat(): string;
    get compression(): string;
    get dateFormat(): string;
    get emptyFieldAsNull(): cdktn.IResolvable;
    get encoding(): string;
    get errorOnColumnCountMismatch(): cdktn.IResolvable;
    get escape(): string;
    get escapeUnenclosedField(): string;
    get fieldDelimiter(): string;
    get fieldOptionallyEnclosedBy(): string;
    get fileExtension(): string;
    get multiLine(): cdktn.IResolvable;
    get nullIf(): string[];
    get parseHeader(): cdktn.IResolvable;
    get recordDelimiter(): string;
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipBlankLines(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get skipHeader(): number;
    get timeFormat(): string;
    get timestampFormat(): string;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
    get validateUtf8(): cdktn.IResolvable;
}
export declare class StageExternalAzureDescribeOutputFileFormatCsvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalAzureDescribeOutputFileFormatCsvOutputReference;
}
export interface StageExternalAzureDescribeOutputFileFormatJson {
}
export declare function stageExternalAzureDescribeOutputFileFormatJsonToTerraform(struct?: StageExternalAzureDescribeOutputFileFormatJson): any;
export declare function stageExternalAzureDescribeOutputFileFormatJsonToHclTerraform(struct?: StageExternalAzureDescribeOutputFileFormatJson): any;
export declare class StageExternalAzureDescribeOutputFileFormatJsonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalAzureDescribeOutputFileFormatJson | undefined;
    set internalValue(value: StageExternalAzureDescribeOutputFileFormatJson | undefined);
    get allowDuplicate(): cdktn.IResolvable;
    get binaryFormat(): string;
    get compression(): string;
    get dateFormat(): string;
    get enableOctal(): cdktn.IResolvable;
    get fileExtension(): string;
    get ignoreUtf8Errors(): cdktn.IResolvable;
    get multiLine(): cdktn.IResolvable;
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get stripNullValues(): cdktn.IResolvable;
    get stripOuterArray(): cdktn.IResolvable;
    get timeFormat(): string;
    get timestampFormat(): string;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageExternalAzureDescribeOutputFileFormatJsonList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalAzureDescribeOutputFileFormatJsonOutputReference;
}
export interface StageExternalAzureDescribeOutputFileFormatOrc {
}
export declare function stageExternalAzureDescribeOutputFileFormatOrcToTerraform(struct?: StageExternalAzureDescribeOutputFileFormatOrc): any;
export declare function stageExternalAzureDescribeOutputFileFormatOrcToHclTerraform(struct?: StageExternalAzureDescribeOutputFileFormatOrc): any;
export declare class StageExternalAzureDescribeOutputFileFormatOrcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalAzureDescribeOutputFileFormatOrc | undefined;
    set internalValue(value: StageExternalAzureDescribeOutputFileFormatOrc | undefined);
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageExternalAzureDescribeOutputFileFormatOrcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalAzureDescribeOutputFileFormatOrcOutputReference;
}
export interface StageExternalAzureDescribeOutputFileFormatParquet {
}
export declare function stageExternalAzureDescribeOutputFileFormatParquetToTerraform(struct?: StageExternalAzureDescribeOutputFileFormatParquet): any;
export declare function stageExternalAzureDescribeOutputFileFormatParquetToHclTerraform(struct?: StageExternalAzureDescribeOutputFileFormatParquet): any;
export declare class StageExternalAzureDescribeOutputFileFormatParquetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalAzureDescribeOutputFileFormatParquet | undefined;
    set internalValue(value: StageExternalAzureDescribeOutputFileFormatParquet | undefined);
    get binaryAsText(): cdktn.IResolvable;
    get compression(): string;
    get nullIf(): string[];
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get trimSpace(): cdktn.IResolvable;
    get type(): string;
    get useLogicalType(): cdktn.IResolvable;
    get useVectorizedScanner(): cdktn.IResolvable;
}
export declare class StageExternalAzureDescribeOutputFileFormatParquetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalAzureDescribeOutputFileFormatParquetOutputReference;
}
export interface StageExternalAzureDescribeOutputFileFormatXml {
}
export declare function stageExternalAzureDescribeOutputFileFormatXmlToTerraform(struct?: StageExternalAzureDescribeOutputFileFormatXml): any;
export declare function stageExternalAzureDescribeOutputFileFormatXmlToHclTerraform(struct?: StageExternalAzureDescribeOutputFileFormatXml): any;
export declare class StageExternalAzureDescribeOutputFileFormatXmlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalAzureDescribeOutputFileFormatXml | undefined;
    set internalValue(value: StageExternalAzureDescribeOutputFileFormatXml | undefined);
    get compression(): string;
    get disableAutoConvert(): cdktn.IResolvable;
    get ignoreUtf8Errors(): cdktn.IResolvable;
    get preserveSpace(): cdktn.IResolvable;
    get replaceInvalidCharacters(): cdktn.IResolvable;
    get skipByteOrderMark(): cdktn.IResolvable;
    get stripOuterElement(): cdktn.IResolvable;
    get type(): string;
}
export declare class StageExternalAzureDescribeOutputFileFormatXmlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalAzureDescribeOutputFileFormatXmlOutputReference;
}
export interface StageExternalAzureDescribeOutputFileFormat {
}
export declare function stageExternalAzureDescribeOutputFileFormatToTerraform(struct?: StageExternalAzureDescribeOutputFileFormat): any;
export declare function stageExternalAzureDescribeOutputFileFormatToHclTerraform(struct?: StageExternalAzureDescribeOutputFileFormat): any;
export declare class StageExternalAzureDescribeOutputFileFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalAzureDescribeOutputFileFormat | undefined;
    set internalValue(value: StageExternalAzureDescribeOutputFileFormat | undefined);
    private _avro;
    get avro(): StageExternalAzureDescribeOutputFileFormatAvroList;
    private _csv;
    get csv(): StageExternalAzureDescribeOutputFileFormatCsvList;
    get formatName(): string;
    private _json;
    get json(): StageExternalAzureDescribeOutputFileFormatJsonList;
    private _orc;
    get orc(): StageExternalAzureDescribeOutputFileFormatOrcList;
    private _parquet;
    get parquet(): StageExternalAzureDescribeOutputFileFormatParquetList;
    private _xml;
    get xml(): StageExternalAzureDescribeOutputFileFormatXmlList;
}
export declare class StageExternalAzureDescribeOutputFileFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalAzureDescribeOutputFileFormatOutputReference;
}
export interface StageExternalAzureDescribeOutput {
}
export declare function stageExternalAzureDescribeOutputToTerraform(struct?: StageExternalAzureDescribeOutput): any;
export declare function stageExternalAzureDescribeOutputToHclTerraform(struct?: StageExternalAzureDescribeOutput): any;
export declare class StageExternalAzureDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalAzureDescribeOutput | undefined;
    set internalValue(value: StageExternalAzureDescribeOutput | undefined);
    private _directoryTable;
    get directoryTable(): StageExternalAzureDescribeOutputDirectoryTableList;
    private _fileFormat;
    get fileFormat(): StageExternalAzureDescribeOutputFileFormatList;
}
export declare class StageExternalAzureDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalAzureDescribeOutputOutputReference;
}
export interface StageExternalAzureShowOutput {
}
export declare function stageExternalAzureShowOutputToTerraform(struct?: StageExternalAzureShowOutput): any;
export declare function stageExternalAzureShowOutputToHclTerraform(struct?: StageExternalAzureShowOutput): any;
export declare class StageExternalAzureShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StageExternalAzureShowOutput | undefined;
    set internalValue(value: StageExternalAzureShowOutput | undefined);
    get cloud(): string;
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get directoryEnabled(): cdktn.IResolvable;
    get endpoint(): string;
    get hasCredentials(): cdktn.IResolvable;
    get hasEncryptionKey(): cdktn.IResolvable;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get region(): string;
    get schemaName(): string;
    get storageIntegration(): string;
    get type(): string;
    get url(): string;
}
export declare class StageExternalAzureShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StageExternalAzureShowOutputOutputReference;
}
export interface StageExternalAzureCredentials {
    /**
    * Specifies the shared access signature (SAS) token for Azure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#azure_sas_token StageExternalAzure#azure_sas_token}
    */
    readonly azureSasToken: string;
}
export declare function stageExternalAzureCredentialsToTerraform(struct?: StageExternalAzureCredentialsOutputReference | StageExternalAzureCredentials): any;
export declare function stageExternalAzureCredentialsToHclTerraform(struct?: StageExternalAzureCredentialsOutputReference | StageExternalAzureCredentials): any;
export declare class StageExternalAzureCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalAzureCredentials | undefined;
    set internalValue(value: StageExternalAzureCredentials | undefined);
    private _azureSasToken?;
    get azureSasToken(): string;
    set azureSasToken(value: string);
    get azureSasTokenInput(): string | undefined;
}
export interface StageExternalAzureDirectory {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether Snowflake should enable triggering automatic refreshes of the directory table metadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#auto_refresh StageExternalAzure#auto_refresh}
    */
    readonly autoRefresh?: string;
    /**
    * Specifies whether to enable a directory table on the external stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#enable StageExternalAzure#enable}
    */
    readonly enable: boolean | cdktn.IResolvable;
    /**
    * Specifies the name of the notification integration used to automatically refresh the directory table metadata. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#notification_integration StageExternalAzure#notification_integration}
    */
    readonly notificationIntegration?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Specifies whether to automatically refresh the directory table metadata once, immediately after the stage is created.This field is used only when creating the object. Changes on this field are ignored after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#refresh_on_create StageExternalAzure#refresh_on_create}
    */
    readonly refreshOnCreate?: string;
}
export declare function stageExternalAzureDirectoryToTerraform(struct?: StageExternalAzureDirectoryOutputReference | StageExternalAzureDirectory): any;
export declare function stageExternalAzureDirectoryToHclTerraform(struct?: StageExternalAzureDirectoryOutputReference | StageExternalAzureDirectory): any;
export declare class StageExternalAzureDirectoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalAzureDirectory | undefined;
    set internalValue(value: StageExternalAzureDirectory | undefined);
    private _autoRefresh?;
    get autoRefresh(): string;
    set autoRefresh(value: string);
    resetAutoRefresh(): void;
    get autoRefreshInput(): string | undefined;
    private _enable?;
    get enable(): boolean | cdktn.IResolvable;
    set enable(value: boolean | cdktn.IResolvable);
    get enableInput(): boolean | cdktn.IResolvable | undefined;
    private _notificationIntegration?;
    get notificationIntegration(): string;
    set notificationIntegration(value: string);
    resetNotificationIntegration(): void;
    get notificationIntegrationInput(): string | undefined;
    private _refreshOnCreate?;
    get refreshOnCreate(): string;
    set refreshOnCreate(value: string);
    resetRefreshOnCreate(): void;
    get refreshOnCreateInput(): string | undefined;
}
export interface StageExternalAzureEncryptionAzureCse {
    /**
    * Specifies the 128-bit or 256-bit client-side master key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#master_key StageExternalAzure#master_key}
    */
    readonly masterKey: string;
}
export declare function stageExternalAzureEncryptionAzureCseToTerraform(struct?: StageExternalAzureEncryptionAzureCseOutputReference | StageExternalAzureEncryptionAzureCse): any;
export declare function stageExternalAzureEncryptionAzureCseToHclTerraform(struct?: StageExternalAzureEncryptionAzureCseOutputReference | StageExternalAzureEncryptionAzureCse): any;
export declare class StageExternalAzureEncryptionAzureCseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalAzureEncryptionAzureCse | undefined;
    set internalValue(value: StageExternalAzureEncryptionAzureCse | undefined);
    private _masterKey?;
    get masterKey(): string;
    set masterKey(value: string);
    get masterKeyInput(): string | undefined;
}
export interface StageExternalAzureEncryptionNone {
}
export declare function stageExternalAzureEncryptionNoneToTerraform(struct?: StageExternalAzureEncryptionNoneOutputReference | StageExternalAzureEncryptionNone): any;
export declare function stageExternalAzureEncryptionNoneToHclTerraform(struct?: StageExternalAzureEncryptionNoneOutputReference | StageExternalAzureEncryptionNone): any;
export declare class StageExternalAzureEncryptionNoneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalAzureEncryptionNone | undefined;
    set internalValue(value: StageExternalAzureEncryptionNone | undefined);
}
export interface StageExternalAzureEncryption {
    /**
    * azure_cse block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#azure_cse StageExternalAzure#azure_cse}
    */
    readonly azureCse?: StageExternalAzureEncryptionAzureCse;
    /**
    * none block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#none StageExternalAzure#none}
    */
    readonly none?: StageExternalAzureEncryptionNone;
}
export declare function stageExternalAzureEncryptionToTerraform(struct?: StageExternalAzureEncryptionOutputReference | StageExternalAzureEncryption): any;
export declare function stageExternalAzureEncryptionToHclTerraform(struct?: StageExternalAzureEncryptionOutputReference | StageExternalAzureEncryption): any;
export declare class StageExternalAzureEncryptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalAzureEncryption | undefined;
    set internalValue(value: StageExternalAzureEncryption | undefined);
    private _azureCse;
    get azureCse(): StageExternalAzureEncryptionAzureCseOutputReference;
    putAzureCse(value: StageExternalAzureEncryptionAzureCse): void;
    resetAzureCse(): void;
    get azureCseInput(): StageExternalAzureEncryptionAzureCse | undefined;
    private _none;
    get none(): StageExternalAzureEncryptionNoneOutputReference;
    putNone(value: StageExternalAzureEncryptionNone): void;
    resetNone(): void;
    get noneInput(): StageExternalAzureEncryptionNone | undefined;
}
export interface StageExternalAzureFileFormatAvro {
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
    */
    readonly compression?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageExternalAzureFileFormatAvroToTerraform(struct?: StageExternalAzureFileFormatAvroOutputReference | StageExternalAzureFileFormatAvro): any;
export declare function stageExternalAzureFileFormatAvroToHclTerraform(struct?: StageExternalAzureFileFormatAvroOutputReference | StageExternalAzureFileFormatAvro): any;
export declare class StageExternalAzureFileFormatAvroOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalAzureFileFormatAvro | undefined;
    set internalValue(value: StageExternalAzureFileFormatAvro | undefined);
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageExternalAzureFileFormatCsv {
    /**
    * Defines the encoding format for binary input or output. Valid values: `HEX` | `BASE64` | `UTF8`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#binary_format StageExternalAzure#binary_format}
    */
    readonly binaryFormat?: string;
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BZ2` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
    */
    readonly compression?: string;
    /**
    * Defines the format of date values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#date_format StageExternalAzure#date_format}
    */
    readonly dateFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to insert SQL NULL for empty fields in an input file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#empty_field_as_null StageExternalAzure#empty_field_as_null}
    */
    readonly emptyFieldAsNull?: string;
    /**
    * Specifies the character set of the source data when loading data into a table. Valid values: `BIG5` | `EUCJP` | `EUCKR` | `GB18030` | `IBM420` | `IBM424` | `ISO2022CN` | `ISO2022JP` | `ISO2022KR` | `ISO88591` | `ISO88592` | `ISO88595` | `ISO88596` | `ISO88597` | `ISO88598` | `ISO88599` | `ISO885915` | `KOI8R` | `SHIFTJIS` | `UTF8` | `UTF16` | `UTF16BE` | `UTF16LE` | `UTF32` | `UTF32BE` | `UTF32LE` | `WINDOWS1250` | `WINDOWS1251` | `WINDOWS1252` | `WINDOWS1253` | `WINDOWS1254` | `WINDOWS1255` | `WINDOWS1256`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#encoding StageExternalAzure#encoding}
    */
    readonly encoding?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to generate a parsing error if the number of delimited columns in an input file does not match the number of columns in the corresponding table. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#error_on_column_count_mismatch StageExternalAzure#error_on_column_count_mismatch}
    */
    readonly errorOnColumnCountMismatch?: string;
    /**
    * Single character string used as the escape character for field values. Use `NONE` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#escape StageExternalAzure#escape}
    */
    readonly escape?: string;
    /**
    * Single character string used as the escape character for unenclosed field values only. Use `NONE` to specify no escape character. NOTE: This value may be not imported properly from Snowflake. Snowflake returns escaped values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#escape_unenclosed_field StageExternalAzure#escape_unenclosed_field}
    */
    readonly escapeUnenclosedField?: string;
    /**
    * One or more singlebyte or multibyte characters that separate fields in an input file. Use `NONE` to specify no delimiter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#field_delimiter StageExternalAzure#field_delimiter}
    */
    readonly fieldDelimiter?: string;
    /**
    * Character used to enclose strings. Use `NONE` to specify no enclosure character.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#field_optionally_enclosed_by StageExternalAzure#field_optionally_enclosed_by}
    */
    readonly fieldOptionallyEnclosedBy?: string;
    /**
    * Specifies the extension for files unloaded to a stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#file_extension StageExternalAzure#file_extension}
    */
    readonly fileExtension?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to parse CSV files containing multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#multi_line StageExternalAzure#multi_line}
    */
    readonly multiLine?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to use the first row headers in the data files to determine column names. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#parse_header StageExternalAzure#parse_header}
    */
    readonly parseHeader?: string;
    /**
    * One or more singlebyte or multibyte characters that separate records in an input file. Use `NONE` to specify no delimiter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#record_delimiter StageExternalAzure#record_delimiter}
    */
    readonly recordDelimiter?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies to skip any blank lines encountered in the data files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#skip_blank_lines StageExternalAzure#skip_blank_lines}
    */
    readonly skipBlankLines?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#skip_byte_order_mark StageExternalAzure#skip_byte_order_mark}
    */
    readonly skipByteOrderMark?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`-1`)) Number of lines at the start of the file to skip.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#skip_header StageExternalAzure#skip_header}
    */
    readonly skipHeader?: number;
    /**
    * Defines the format of time values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#time_format StageExternalAzure#time_format}
    */
    readonly timeFormat?: string;
    /**
    * Defines the format of timestamp values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#timestamp_format StageExternalAzure#timestamp_format}
    */
    readonly timestampFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageExternalAzureFileFormatCsvToTerraform(struct?: StageExternalAzureFileFormatCsvOutputReference | StageExternalAzureFileFormatCsv): any;
export declare function stageExternalAzureFileFormatCsvToHclTerraform(struct?: StageExternalAzureFileFormatCsvOutputReference | StageExternalAzureFileFormatCsv): any;
export declare class StageExternalAzureFileFormatCsvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalAzureFileFormatCsv | undefined;
    set internalValue(value: StageExternalAzureFileFormatCsv | undefined);
    private _binaryFormat?;
    get binaryFormat(): string;
    set binaryFormat(value: string);
    resetBinaryFormat(): void;
    get binaryFormatInput(): string | undefined;
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _dateFormat?;
    get dateFormat(): string;
    set dateFormat(value: string);
    resetDateFormat(): void;
    get dateFormatInput(): string | undefined;
    private _emptyFieldAsNull?;
    get emptyFieldAsNull(): string;
    set emptyFieldAsNull(value: string);
    resetEmptyFieldAsNull(): void;
    get emptyFieldAsNullInput(): string | undefined;
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    resetEncoding(): void;
    get encodingInput(): string | undefined;
    private _errorOnColumnCountMismatch?;
    get errorOnColumnCountMismatch(): string;
    set errorOnColumnCountMismatch(value: string);
    resetErrorOnColumnCountMismatch(): void;
    get errorOnColumnCountMismatchInput(): string | undefined;
    private _escape?;
    get escape(): string;
    set escape(value: string);
    resetEscape(): void;
    get escapeInput(): string | undefined;
    private _escapeUnenclosedField?;
    get escapeUnenclosedField(): string;
    set escapeUnenclosedField(value: string);
    resetEscapeUnenclosedField(): void;
    get escapeUnenclosedFieldInput(): string | undefined;
    private _fieldDelimiter?;
    get fieldDelimiter(): string;
    set fieldDelimiter(value: string);
    resetFieldDelimiter(): void;
    get fieldDelimiterInput(): string | undefined;
    private _fieldOptionallyEnclosedBy?;
    get fieldOptionallyEnclosedBy(): string;
    set fieldOptionallyEnclosedBy(value: string);
    resetFieldOptionallyEnclosedBy(): void;
    get fieldOptionallyEnclosedByInput(): string | undefined;
    private _fileExtension?;
    get fileExtension(): string;
    set fileExtension(value: string);
    resetFileExtension(): void;
    get fileExtensionInput(): string | undefined;
    private _multiLine?;
    get multiLine(): string;
    set multiLine(value: string);
    resetMultiLine(): void;
    get multiLineInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _parseHeader?;
    get parseHeader(): string;
    set parseHeader(value: string);
    resetParseHeader(): void;
    get parseHeaderInput(): string | undefined;
    private _recordDelimiter?;
    get recordDelimiter(): string;
    set recordDelimiter(value: string);
    resetRecordDelimiter(): void;
    get recordDelimiterInput(): string | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _skipBlankLines?;
    get skipBlankLines(): string;
    set skipBlankLines(value: string);
    resetSkipBlankLines(): void;
    get skipBlankLinesInput(): string | undefined;
    private _skipByteOrderMark?;
    get skipByteOrderMark(): string;
    set skipByteOrderMark(value: string);
    resetSkipByteOrderMark(): void;
    get skipByteOrderMarkInput(): string | undefined;
    private _skipHeader?;
    get skipHeader(): number;
    set skipHeader(value: number);
    resetSkipHeader(): void;
    get skipHeaderInput(): number | undefined;
    private _timeFormat?;
    get timeFormat(): string;
    set timeFormat(value: string);
    resetTimeFormat(): void;
    get timeFormatInput(): string | undefined;
    private _timestampFormat?;
    get timestampFormat(): string;
    set timestampFormat(value: string);
    resetTimestampFormat(): void;
    get timestampFormatInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageExternalAzureFileFormatJson {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to allow duplicate object field names (only the last one will be preserved). Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#allow_duplicate StageExternalAzure#allow_duplicate}
    */
    readonly allowDuplicate?: string;
    /**
    * Defines the encoding format for binary input or output. Valid values: `HEX` | `BASE64` | `UTF8`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#binary_format StageExternalAzure#binary_format}
    */
    readonly binaryFormat?: string;
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BZ2` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
    */
    readonly compression?: string;
    /**
    * Defines the format of date values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#date_format StageExternalAzure#date_format}
    */
    readonly dateFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that enables parsing of octal numbers. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#enable_octal StageExternalAzure#enable_octal}
    */
    readonly enableOctal?: string;
    /**
    * Specifies the extension for files unloaded to a stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#file_extension StageExternalAzure#file_extension}
    */
    readonly fileExtension?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#ignore_utf8_errors StageExternalAzure#ignore_utf8_errors}
    */
    readonly ignoreUtf8Errors?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to allow multiple records on a single line. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#multi_line StageExternalAzure#multi_line}
    */
    readonly multiLine?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#skip_byte_order_mark StageExternalAzure#skip_byte_order_mark}
    */
    readonly skipByteOrderMark?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that instructs the JSON parser to remove object fields or array elements containing null values. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#strip_null_values StageExternalAzure#strip_null_values}
    */
    readonly stripNullValues?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that instructs the JSON parser to remove outer brackets. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#strip_outer_array StageExternalAzure#strip_outer_array}
    */
    readonly stripOuterArray?: string;
    /**
    * Defines the format of time values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#time_format StageExternalAzure#time_format}
    */
    readonly timeFormat?: string;
    /**
    * Defines the format of timestamp values in the data files. Use `AUTO` to have Snowflake auto-detect the format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#timestamp_format StageExternalAzure#timestamp_format}
    */
    readonly timestampFormat?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageExternalAzureFileFormatJsonToTerraform(struct?: StageExternalAzureFileFormatJsonOutputReference | StageExternalAzureFileFormatJson): any;
export declare function stageExternalAzureFileFormatJsonToHclTerraform(struct?: StageExternalAzureFileFormatJsonOutputReference | StageExternalAzureFileFormatJson): any;
export declare class StageExternalAzureFileFormatJsonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalAzureFileFormatJson | undefined;
    set internalValue(value: StageExternalAzureFileFormatJson | undefined);
    private _allowDuplicate?;
    get allowDuplicate(): string;
    set allowDuplicate(value: string);
    resetAllowDuplicate(): void;
    get allowDuplicateInput(): string | undefined;
    private _binaryFormat?;
    get binaryFormat(): string;
    set binaryFormat(value: string);
    resetBinaryFormat(): void;
    get binaryFormatInput(): string | undefined;
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _dateFormat?;
    get dateFormat(): string;
    set dateFormat(value: string);
    resetDateFormat(): void;
    get dateFormatInput(): string | undefined;
    private _enableOctal?;
    get enableOctal(): string;
    set enableOctal(value: string);
    resetEnableOctal(): void;
    get enableOctalInput(): string | undefined;
    private _fileExtension?;
    get fileExtension(): string;
    set fileExtension(value: string);
    resetFileExtension(): void;
    get fileExtensionInput(): string | undefined;
    private _ignoreUtf8Errors?;
    get ignoreUtf8Errors(): string;
    set ignoreUtf8Errors(value: string);
    resetIgnoreUtf8Errors(): void;
    get ignoreUtf8ErrorsInput(): string | undefined;
    private _multiLine?;
    get multiLine(): string;
    set multiLine(value: string);
    resetMultiLine(): void;
    get multiLineInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _skipByteOrderMark?;
    get skipByteOrderMark(): string;
    set skipByteOrderMark(value: string);
    resetSkipByteOrderMark(): void;
    get skipByteOrderMarkInput(): string | undefined;
    private _stripNullValues?;
    get stripNullValues(): string;
    set stripNullValues(value: string);
    resetStripNullValues(): void;
    get stripNullValuesInput(): string | undefined;
    private _stripOuterArray?;
    get stripOuterArray(): string;
    set stripOuterArray(value: string);
    resetStripOuterArray(): void;
    get stripOuterArrayInput(): string | undefined;
    private _timeFormat?;
    get timeFormat(): string;
    set timeFormat(value: string);
    resetTimeFormat(): void;
    get timeFormatInput(): string | undefined;
    private _timestampFormat?;
    get timestampFormat(): string;
    set timestampFormat(value: string);
    resetTimestampFormat(): void;
    get timestampFormatInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageExternalAzureFileFormatOrc {
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
    */
    readonly trimSpace?: string;
}
export declare function stageExternalAzureFileFormatOrcToTerraform(struct?: StageExternalAzureFileFormatOrcOutputReference | StageExternalAzureFileFormatOrc): any;
export declare function stageExternalAzureFileFormatOrcToHclTerraform(struct?: StageExternalAzureFileFormatOrcOutputReference | StageExternalAzureFileFormatOrc): any;
export declare class StageExternalAzureFileFormatOrcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalAzureFileFormatOrc | undefined;
    set internalValue(value: StageExternalAzureFileFormatOrc | undefined);
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
}
export interface StageExternalAzureFileFormatParquet {
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to interpret columns with no defined logical data type as UTF-8 text. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#binary_as_text StageExternalAzure#binary_as_text}
    */
    readonly binaryAsText?: string;
    /**
    * Specifies the compression format. Valid values: `AUTO` | `LZO` | `SNAPPY` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
    */
    readonly compression?: string;
    /**
    * String used to convert to and from SQL NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#null_if StageExternalAzure#null_if}
    */
    readonly nullIf?: string[];
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to remove white space from fields. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#trim_space StageExternalAzure#trim_space}
    */
    readonly trimSpace?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to use Parquet logical types when loading data. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#use_logical_type StageExternalAzure#use_logical_type}
    */
    readonly useLogicalType?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to use a vectorized scanner for loading Parquet files. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#use_vectorized_scanner StageExternalAzure#use_vectorized_scanner}
    */
    readonly useVectorizedScanner?: string;
}
export declare function stageExternalAzureFileFormatParquetToTerraform(struct?: StageExternalAzureFileFormatParquetOutputReference | StageExternalAzureFileFormatParquet): any;
export declare function stageExternalAzureFileFormatParquetToHclTerraform(struct?: StageExternalAzureFileFormatParquetOutputReference | StageExternalAzureFileFormatParquet): any;
export declare class StageExternalAzureFileFormatParquetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalAzureFileFormatParquet | undefined;
    set internalValue(value: StageExternalAzureFileFormatParquet | undefined);
    private _binaryAsText?;
    get binaryAsText(): string;
    set binaryAsText(value: string);
    resetBinaryAsText(): void;
    get binaryAsTextInput(): string | undefined;
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _nullIf?;
    get nullIf(): string[];
    set nullIf(value: string[]);
    resetNullIf(): void;
    get nullIfInput(): string[] | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _trimSpace?;
    get trimSpace(): string;
    set trimSpace(value: string);
    resetTrimSpace(): void;
    get trimSpaceInput(): string | undefined;
    private _useLogicalType?;
    get useLogicalType(): string;
    set useLogicalType(value: string);
    resetUseLogicalType(): void;
    get useLogicalTypeInput(): string | undefined;
    private _useVectorizedScanner?;
    get useVectorizedScanner(): string;
    set useVectorizedScanner(value: string);
    resetUseVectorizedScanner(): void;
    get useVectorizedScannerInput(): string | undefined;
}
export interface StageExternalAzureFileFormatXml {
    /**
    * Specifies the compression format. Valid values: `AUTO` | `GZIP` | `BZ2` | `BROTLI` | `ZSTD` | `DEFLATE` | `RAW_DEFLATE` | `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#compression StageExternalAzure#compression}
    */
    readonly compression?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether the XML parser disables automatic conversion of numeric and Boolean values from text to native representation. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#disable_auto_convert StageExternalAzure#disable_auto_convert}
    */
    readonly disableAutoConvert?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether UTF-8 encoding errors produce error conditions. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#ignore_utf8_errors StageExternalAzure#ignore_utf8_errors}
    */
    readonly ignoreUtf8Errors?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether the XML parser preserves leading and trailing spaces in element content. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#preserve_space StageExternalAzure#preserve_space}
    */
    readonly preserveSpace?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to replace invalid UTF-8 characters with the Unicode replacement character. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#replace_invalid_characters StageExternalAzure#replace_invalid_characters}
    */
    readonly replaceInvalidCharacters?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether to skip the BOM (byte order mark) if present in a data file. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#skip_byte_order_mark StageExternalAzure#skip_byte_order_mark}
    */
    readonly skipByteOrderMark?: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`default`)) Boolean that specifies whether the XML parser strips out the outer XML element, exposing 2nd level elements as separate documents. Available options are: "true" or "false". When the value is not set in the configuration the provider will put "default" there which means to use the Snowflake default for this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#strip_outer_element StageExternalAzure#strip_outer_element}
    */
    readonly stripOuterElement?: string;
}
export declare function stageExternalAzureFileFormatXmlToTerraform(struct?: StageExternalAzureFileFormatXmlOutputReference | StageExternalAzureFileFormatXml): any;
export declare function stageExternalAzureFileFormatXmlToHclTerraform(struct?: StageExternalAzureFileFormatXmlOutputReference | StageExternalAzureFileFormatXml): any;
export declare class StageExternalAzureFileFormatXmlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalAzureFileFormatXml | undefined;
    set internalValue(value: StageExternalAzureFileFormatXml | undefined);
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _disableAutoConvert?;
    get disableAutoConvert(): string;
    set disableAutoConvert(value: string);
    resetDisableAutoConvert(): void;
    get disableAutoConvertInput(): string | undefined;
    private _ignoreUtf8Errors?;
    get ignoreUtf8Errors(): string;
    set ignoreUtf8Errors(value: string);
    resetIgnoreUtf8Errors(): void;
    get ignoreUtf8ErrorsInput(): string | undefined;
    private _preserveSpace?;
    get preserveSpace(): string;
    set preserveSpace(value: string);
    resetPreserveSpace(): void;
    get preserveSpaceInput(): string | undefined;
    private _replaceInvalidCharacters?;
    get replaceInvalidCharacters(): string;
    set replaceInvalidCharacters(value: string);
    resetReplaceInvalidCharacters(): void;
    get replaceInvalidCharactersInput(): string | undefined;
    private _skipByteOrderMark?;
    get skipByteOrderMark(): string;
    set skipByteOrderMark(value: string);
    resetSkipByteOrderMark(): void;
    get skipByteOrderMarkInput(): string | undefined;
    private _stripOuterElement?;
    get stripOuterElement(): string;
    set stripOuterElement(value: string);
    resetStripOuterElement(): void;
    get stripOuterElementInput(): string | undefined;
}
export interface StageExternalAzureFileFormat {
    /**
    * Fully qualified name of the file format (e.g., 'database.schema.format_name').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#format_name StageExternalAzure#format_name}
    */
    readonly formatName?: string;
    /**
    * avro block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#avro StageExternalAzure#avro}
    */
    readonly avro?: StageExternalAzureFileFormatAvro;
    /**
    * csv block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#csv StageExternalAzure#csv}
    */
    readonly csv?: StageExternalAzureFileFormatCsv;
    /**
    * json block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#json StageExternalAzure#json}
    */
    readonly json?: StageExternalAzureFileFormatJson;
    /**
    * orc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#orc StageExternalAzure#orc}
    */
    readonly orc?: StageExternalAzureFileFormatOrc;
    /**
    * parquet block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#parquet StageExternalAzure#parquet}
    */
    readonly parquet?: StageExternalAzureFileFormatParquet;
    /**
    * xml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#xml StageExternalAzure#xml}
    */
    readonly xml?: StageExternalAzureFileFormatXml;
}
export declare function stageExternalAzureFileFormatToTerraform(struct?: StageExternalAzureFileFormatOutputReference | StageExternalAzureFileFormat): any;
export declare function stageExternalAzureFileFormatToHclTerraform(struct?: StageExternalAzureFileFormatOutputReference | StageExternalAzureFileFormat): any;
export declare class StageExternalAzureFileFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalAzureFileFormat | undefined;
    set internalValue(value: StageExternalAzureFileFormat | undefined);
    private _formatName?;
    get formatName(): string;
    set formatName(value: string);
    resetFormatName(): void;
    get formatNameInput(): string | undefined;
    private _avro;
    get avro(): StageExternalAzureFileFormatAvroOutputReference;
    putAvro(value: StageExternalAzureFileFormatAvro): void;
    resetAvro(): void;
    get avroInput(): StageExternalAzureFileFormatAvro | undefined;
    private _csv;
    get csv(): StageExternalAzureFileFormatCsvOutputReference;
    putCsv(value: StageExternalAzureFileFormatCsv): void;
    resetCsv(): void;
    get csvInput(): StageExternalAzureFileFormatCsv | undefined;
    private _json;
    get json(): StageExternalAzureFileFormatJsonOutputReference;
    putJson(value: StageExternalAzureFileFormatJson): void;
    resetJson(): void;
    get jsonInput(): StageExternalAzureFileFormatJson | undefined;
    private _orc;
    get orc(): StageExternalAzureFileFormatOrcOutputReference;
    putOrc(value: StageExternalAzureFileFormatOrc): void;
    resetOrc(): void;
    get orcInput(): StageExternalAzureFileFormatOrc | undefined;
    private _parquet;
    get parquet(): StageExternalAzureFileFormatParquetOutputReference;
    putParquet(value: StageExternalAzureFileFormatParquet): void;
    resetParquet(): void;
    get parquetInput(): StageExternalAzureFileFormatParquet | undefined;
    private _xml;
    get xml(): StageExternalAzureFileFormatXmlOutputReference;
    putXml(value: StageExternalAzureFileFormatXml): void;
    resetXml(): void;
    get xmlInput(): StageExternalAzureFileFormatXml | undefined;
}
export interface StageExternalAzureTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#create StageExternalAzure#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#delete StageExternalAzure#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#read StageExternalAzure#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#update StageExternalAzure#update}
    */
    readonly update?: string;
}
export declare function stageExternalAzureTimeoutsToTerraform(struct?: StageExternalAzureTimeouts | cdktn.IResolvable): any;
export declare function stageExternalAzureTimeoutsToHclTerraform(struct?: StageExternalAzureTimeouts | cdktn.IResolvable): any;
export declare class StageExternalAzureTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StageExternalAzureTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: StageExternalAzureTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure snowflake_stage_external_azure}
*/
export declare class StageExternalAzure extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_stage_external_azure";
    /**
    * Generates CDKTN code for importing a StageExternalAzure resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StageExternalAzure to import
    * @param importFromId The id of the existing StageExternalAzure that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StageExternalAzure to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/stage_external_azure snowflake_stage_external_azure} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StageExternalAzureConfig
    */
    constructor(scope: Construct, id: string, config: StageExternalAzureConfig);
    get cloud(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): StageExternalAzureDescribeOutputList;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _showOutput;
    get showOutput(): StageExternalAzureShowOutputList;
    get stageType(): string;
    private _storageIntegration?;
    get storageIntegration(): string;
    set storageIntegration(value: string);
    resetStorageIntegration(): void;
    get storageIntegrationInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _usePrivatelinkEndpoint?;
    get usePrivatelinkEndpoint(): string;
    set usePrivatelinkEndpoint(value: string);
    resetUsePrivatelinkEndpoint(): void;
    get usePrivatelinkEndpointInput(): string | undefined;
    private _credentials;
    get credentials(): StageExternalAzureCredentialsOutputReference;
    putCredentials(value: StageExternalAzureCredentials): void;
    resetCredentials(): void;
    get credentialsInput(): StageExternalAzureCredentials | undefined;
    private _directory;
    get directory(): StageExternalAzureDirectoryOutputReference;
    putDirectory(value: StageExternalAzureDirectory): void;
    resetDirectory(): void;
    get directoryInput(): StageExternalAzureDirectory | undefined;
    private _encryption;
    get encryption(): StageExternalAzureEncryptionOutputReference;
    putEncryption(value: StageExternalAzureEncryption): void;
    resetEncryption(): void;
    get encryptionInput(): StageExternalAzureEncryption | undefined;
    private _fileFormat;
    get fileFormat(): StageExternalAzureFileFormatOutputReference;
    putFileFormat(value: StageExternalAzureFileFormat): void;
    resetFileFormat(): void;
    get fileFormatInput(): StageExternalAzureFileFormat | undefined;
    private _timeouts;
    get timeouts(): StageExternalAzureTimeoutsOutputReference;
    putTimeouts(value: StageExternalAzureTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | StageExternalAzureTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
