/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeAccountsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/accounts#id DataSnowflakeAccounts#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/accounts#like DataSnowflakeAccounts#like}
    */
    readonly like?: string;
    /**
    * Includes dropped accounts that have not yet been deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/accounts#with_history DataSnowflakeAccounts#with_history}
    */
    readonly withHistory?: boolean | cdktn.IResolvable;
}
export interface DataSnowflakeAccountsAccountsShowOutput {
}
export declare function dataSnowflakeAccountsAccountsShowOutputToTerraform(struct?: DataSnowflakeAccountsAccountsShowOutput): any;
export declare function dataSnowflakeAccountsAccountsShowOutputToHclTerraform(struct?: DataSnowflakeAccountsAccountsShowOutput): any;
export declare class DataSnowflakeAccountsAccountsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccountsShowOutput | undefined;
    set internalValue(value: DataSnowflakeAccountsAccountsShowOutput | undefined);
    get accountLocator(): string;
    get accountLocatorUrl(): string;
    get accountName(): string;
    get accountOldUrlLastUsed(): string;
    get accountOldUrlSavedOn(): string;
    get accountUrl(): string;
    get comment(): string;
    get consumptionBillingEntityName(): string;
    get createdOn(): string;
    get droppedOn(): string;
    get edition(): string;
    get isEventsAccount(): cdktn.IResolvable;
    get isOrgAdmin(): cdktn.IResolvable;
    get isOrganizationAccount(): cdktn.IResolvable;
    get managedAccounts(): number;
    get marketplaceConsumerBillingEntityName(): string;
    get marketplaceProviderBillingEntityName(): string;
    get movedOn(): string;
    get movedToOrganization(): string;
    get oldAccountUrl(): string;
    get organizationName(): string;
    get organizationOldUrl(): string;
    get organizationOldUrlLastUsed(): string;
    get organizationOldUrlSavedOn(): string;
    get organizationUrlExpirationOn(): string;
    get regionGroup(): string;
    get restoredOn(): string;
    get scheduledDeletionTime(): string;
    get snowflakeRegion(): string;
}
export declare class DataSnowflakeAccountsAccountsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsShowOutputOutputReference;
}
export interface DataSnowflakeAccountsAccounts {
}
export declare function dataSnowflakeAccountsAccountsToTerraform(struct?: DataSnowflakeAccountsAccounts): any;
export declare function dataSnowflakeAccountsAccountsToHclTerraform(struct?: DataSnowflakeAccountsAccounts): any;
export declare class DataSnowflakeAccountsAccountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeAccountsAccounts | undefined;
    set internalValue(value: DataSnowflakeAccountsAccounts | undefined);
    private _showOutput;
    get showOutput(): DataSnowflakeAccountsAccountsShowOutputList;
}
export declare class DataSnowflakeAccountsAccountsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeAccountsAccountsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/accounts snowflake_accounts}
*/
export declare class DataSnowflakeAccounts extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_accounts";
    /**
    * Generates CDKTN code for importing a DataSnowflakeAccounts resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeAccounts to import
    * @param importFromId The id of the existing DataSnowflakeAccounts that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/accounts#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeAccounts to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/data-sources/accounts snowflake_accounts} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeAccountsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeAccountsConfig);
    private _accounts;
    get accounts(): DataSnowflakeAccountsAccountsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _withHistory?;
    get withHistory(): boolean | cdktn.IResolvable;
    set withHistory(value: boolean | cdktn.IResolvable);
    resetWithHistory(): void;
    get withHistoryInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
