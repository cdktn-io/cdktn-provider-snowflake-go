/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SessionPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the session policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#comment SessionPolicy#comment}
    */
    readonly comment?: string;
    /**
    * The database in which to create the session policy. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#database SessionPolicy#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#id SessionPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier for the session policy. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#name SessionPolicy#name}
    */
    readonly name: string;
    /**
    * The schema in which to create the session policy. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#schema SessionPolicy#schema}
    */
    readonly schema: string;
    /**
    * For Snowflake clients and programmatic clients, specifies the number of minutes in which a session can be idle before users must authenticate to Snowflake again.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#session_idle_timeout_mins SessionPolicy#session_idle_timeout_mins}
    */
    readonly sessionIdleTimeoutMins?: number;
    /**
    * For Snowsight, specifies the number of minutes in which a session can be idle before users must authenticate to Snowflake again.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#session_ui_idle_timeout_mins SessionPolicy#session_ui_idle_timeout_mins}
    */
    readonly sessionUiIdleTimeoutMins?: number;
    /**
    * allowed_secondary_roles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#allowed_secondary_roles SessionPolicy#allowed_secondary_roles}
    */
    readonly allowedSecondaryRoles?: SessionPolicyAllowedSecondaryRoles;
    /**
    * blocked_secondary_roles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#blocked_secondary_roles SessionPolicy#blocked_secondary_roles}
    */
    readonly blockedSecondaryRoles?: SessionPolicyBlockedSecondaryRoles;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#timeouts SessionPolicy#timeouts}
    */
    readonly timeouts?: SessionPolicyTimeouts;
}
export interface SessionPolicyDescribeOutput {
}
export declare function sessionPolicyDescribeOutputToTerraform(struct?: SessionPolicyDescribeOutput): any;
export declare function sessionPolicyDescribeOutputToHclTerraform(struct?: SessionPolicyDescribeOutput): any;
export declare class SessionPolicyDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SessionPolicyDescribeOutput | undefined;
    set internalValue(value: SessionPolicyDescribeOutput | undefined);
    get allowedSecondaryRoles(): string[];
    get blockedSecondaryRoles(): string[];
    get comment(): string;
    get id(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get sessionIdleTimeoutMins(): number;
    get sessionUiIdleTimeoutMins(): number;
}
export declare class SessionPolicyDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SessionPolicyDescribeOutputOutputReference;
}
export interface SessionPolicyShowOutput {
}
export declare function sessionPolicyShowOutputToTerraform(struct?: SessionPolicyShowOutput): any;
export declare function sessionPolicyShowOutputToHclTerraform(struct?: SessionPolicyShowOutput): any;
export declare class SessionPolicyShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SessionPolicyShowOutput | undefined;
    set internalValue(value: SessionPolicyShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get kind(): string;
    get name(): string;
    get options(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get schemaName(): string;
}
export declare class SessionPolicyShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SessionPolicyShowOutputOutputReference;
}
export interface SessionPolicyAllowedSecondaryRoles {
    /**
    * When true, allows all secondary roles.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#all SessionPolicy#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * When true, disallows all secondary roles.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#none SessionPolicy#none}
    */
    readonly none?: boolean | cdktn.IResolvable;
    /**
    * Specifies roles to be allowed as secondary roles.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#roles SessionPolicy#roles}
    */
    readonly roles?: string[];
}
export declare function sessionPolicyAllowedSecondaryRolesToTerraform(struct?: SessionPolicyAllowedSecondaryRolesOutputReference | SessionPolicyAllowedSecondaryRoles): any;
export declare function sessionPolicyAllowedSecondaryRolesToHclTerraform(struct?: SessionPolicyAllowedSecondaryRolesOutputReference | SessionPolicyAllowedSecondaryRoles): any;
export declare class SessionPolicyAllowedSecondaryRolesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SessionPolicyAllowedSecondaryRoles | undefined;
    set internalValue(value: SessionPolicyAllowedSecondaryRoles | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _none?;
    get none(): boolean | cdktn.IResolvable;
    set none(value: boolean | cdktn.IResolvable);
    resetNone(): void;
    get noneInput(): boolean | cdktn.IResolvable | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    resetRoles(): void;
    get rolesInput(): string[] | undefined;
}
export interface SessionPolicyBlockedSecondaryRoles {
    /**
    * When true, disallows all secondary roles.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#all SessionPolicy#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * When true, allows all secondary roles.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#none SessionPolicy#none}
    */
    readonly none?: boolean | cdktn.IResolvable;
    /**
    * Specifies roles to be blocked as secondary roles.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#roles SessionPolicy#roles}
    */
    readonly roles?: string[];
}
export declare function sessionPolicyBlockedSecondaryRolesToTerraform(struct?: SessionPolicyBlockedSecondaryRolesOutputReference | SessionPolicyBlockedSecondaryRoles): any;
export declare function sessionPolicyBlockedSecondaryRolesToHclTerraform(struct?: SessionPolicyBlockedSecondaryRolesOutputReference | SessionPolicyBlockedSecondaryRoles): any;
export declare class SessionPolicyBlockedSecondaryRolesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SessionPolicyBlockedSecondaryRoles | undefined;
    set internalValue(value: SessionPolicyBlockedSecondaryRoles | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _none?;
    get none(): boolean | cdktn.IResolvable;
    set none(value: boolean | cdktn.IResolvable);
    resetNone(): void;
    get noneInput(): boolean | cdktn.IResolvable | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    resetRoles(): void;
    get rolesInput(): string[] | undefined;
}
export interface SessionPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#create SessionPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#delete SessionPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#read SessionPolicy#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#update SessionPolicy#update}
    */
    readonly update?: string;
}
export declare function sessionPolicyTimeoutsToTerraform(struct?: SessionPolicyTimeouts | cdktn.IResolvable): any;
export declare function sessionPolicyTimeoutsToHclTerraform(struct?: SessionPolicyTimeouts | cdktn.IResolvable): any;
export declare class SessionPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SessionPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: SessionPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy snowflake_session_policy}
*/
export declare class SessionPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_session_policy";
    /**
    * Generates CDKTN code for importing a SessionPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SessionPolicy to import
    * @param importFromId The id of the existing SessionPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SessionPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.17.0/docs/resources/session_policy snowflake_session_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SessionPolicyConfig
    */
    constructor(scope: Construct, id: string, config: SessionPolicyConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): SessionPolicyDescribeOutputList;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _sessionIdleTimeoutMins?;
    get sessionIdleTimeoutMins(): number;
    set sessionIdleTimeoutMins(value: number);
    resetSessionIdleTimeoutMins(): void;
    get sessionIdleTimeoutMinsInput(): number | undefined;
    private _sessionUiIdleTimeoutMins?;
    get sessionUiIdleTimeoutMins(): number;
    set sessionUiIdleTimeoutMins(value: number);
    resetSessionUiIdleTimeoutMins(): void;
    get sessionUiIdleTimeoutMinsInput(): number | undefined;
    private _showOutput;
    get showOutput(): SessionPolicyShowOutputList;
    private _allowedSecondaryRoles;
    get allowedSecondaryRoles(): SessionPolicyAllowedSecondaryRolesOutputReference;
    putAllowedSecondaryRoles(value: SessionPolicyAllowedSecondaryRoles): void;
    resetAllowedSecondaryRoles(): void;
    get allowedSecondaryRolesInput(): SessionPolicyAllowedSecondaryRoles | undefined;
    private _blockedSecondaryRoles;
    get blockedSecondaryRoles(): SessionPolicyBlockedSecondaryRolesOutputReference;
    putBlockedSecondaryRoles(value: SessionPolicyBlockedSecondaryRoles): void;
    resetBlockedSecondaryRoles(): void;
    get blockedSecondaryRolesInput(): SessionPolicyBlockedSecondaryRoles | undefined;
    private _timeouts;
    get timeouts(): SessionPolicyTimeoutsOutputReference;
    putTimeouts(value: SessionPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | SessionPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
