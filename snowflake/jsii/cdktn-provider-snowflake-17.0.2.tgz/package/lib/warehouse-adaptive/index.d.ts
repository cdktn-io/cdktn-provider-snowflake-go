/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WarehouseAdaptiveConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the adaptive warehouse.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/warehouse_adaptive#comment WarehouseAdaptive#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/warehouse_adaptive#id WarehouseAdaptive#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the maximum query performance level for the adaptive warehouse. Determines the initial compute capacity. Valid values are (case-insensitive): `XSMALL` | `SMALL` | `MEDIUM` | `LARGE` | `XLARGE` | `XXLARGE` | `XXXLARGE` | `X4LARGE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/warehouse_adaptive#max_query_performance_level WarehouseAdaptive#max_query_performance_level}
    */
    readonly maxQueryPerformanceLevel?: string;
    /**
    * Identifier for the adaptive warehouse; must be unique for your account. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/warehouse_adaptive#name WarehouseAdaptive#name}
    */
    readonly name: string;
    /**
    * (Default: fallback to Snowflake default - uses special value that cannot be set in the configuration manually (`-1`)) Specifies the query throughput multiplier for the adaptive warehouse.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/warehouse_adaptive#query_throughput_multiplier WarehouseAdaptive#query_throughput_multiplier}
    */
    readonly queryThroughputMultiplier?: number;
    /**
    * Object parameter that specifies the time, in seconds, a SQL statement (query, DDL, DML, etc.) can be queued on a warehouse before it is canceled by the system.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/warehouse_adaptive#statement_queued_timeout_in_seconds WarehouseAdaptive#statement_queued_timeout_in_seconds}
    */
    readonly statementQueuedTimeoutInSeconds?: number;
    /**
    * Specifies the time, in seconds, after which a running SQL statement (query, DDL, DML, etc.) is canceled by the system.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/warehouse_adaptive#statement_timeout_in_seconds WarehouseAdaptive#statement_timeout_in_seconds}
    */
    readonly statementTimeoutInSeconds?: number;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/warehouse_adaptive#timeouts WarehouseAdaptive#timeouts}
    */
    readonly timeouts?: WarehouseAdaptiveTimeouts;
}
export interface WarehouseAdaptiveParametersStatementQueuedTimeoutInSeconds {
}
export declare function warehouseAdaptiveParametersStatementQueuedTimeoutInSecondsToTerraform(struct?: WarehouseAdaptiveParametersStatementQueuedTimeoutInSeconds): any;
export declare function warehouseAdaptiveParametersStatementQueuedTimeoutInSecondsToHclTerraform(struct?: WarehouseAdaptiveParametersStatementQueuedTimeoutInSeconds): any;
export declare class WarehouseAdaptiveParametersStatementQueuedTimeoutInSecondsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WarehouseAdaptiveParametersStatementQueuedTimeoutInSeconds | undefined;
    set internalValue(value: WarehouseAdaptiveParametersStatementQueuedTimeoutInSeconds | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class WarehouseAdaptiveParametersStatementQueuedTimeoutInSecondsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WarehouseAdaptiveParametersStatementQueuedTimeoutInSecondsOutputReference;
}
export interface WarehouseAdaptiveParametersStatementTimeoutInSeconds {
}
export declare function warehouseAdaptiveParametersStatementTimeoutInSecondsToTerraform(struct?: WarehouseAdaptiveParametersStatementTimeoutInSeconds): any;
export declare function warehouseAdaptiveParametersStatementTimeoutInSecondsToHclTerraform(struct?: WarehouseAdaptiveParametersStatementTimeoutInSeconds): any;
export declare class WarehouseAdaptiveParametersStatementTimeoutInSecondsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WarehouseAdaptiveParametersStatementTimeoutInSeconds | undefined;
    set internalValue(value: WarehouseAdaptiveParametersStatementTimeoutInSeconds | undefined);
    get default(): string;
    get description(): string;
    get key(): string;
    get level(): string;
    get value(): string;
}
export declare class WarehouseAdaptiveParametersStatementTimeoutInSecondsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WarehouseAdaptiveParametersStatementTimeoutInSecondsOutputReference;
}
export interface WarehouseAdaptiveParameters {
}
export declare function warehouseAdaptiveParametersToTerraform(struct?: WarehouseAdaptiveParameters): any;
export declare function warehouseAdaptiveParametersToHclTerraform(struct?: WarehouseAdaptiveParameters): any;
export declare class WarehouseAdaptiveParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WarehouseAdaptiveParameters | undefined;
    set internalValue(value: WarehouseAdaptiveParameters | undefined);
    private _statementQueuedTimeoutInSeconds;
    get statementQueuedTimeoutInSeconds(): WarehouseAdaptiveParametersStatementQueuedTimeoutInSecondsList;
    private _statementTimeoutInSeconds;
    get statementTimeoutInSeconds(): WarehouseAdaptiveParametersStatementTimeoutInSecondsList;
}
export declare class WarehouseAdaptiveParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WarehouseAdaptiveParametersOutputReference;
}
export interface WarehouseAdaptiveShowOutput {
}
export declare function warehouseAdaptiveShowOutputToTerraform(struct?: WarehouseAdaptiveShowOutput): any;
export declare function warehouseAdaptiveShowOutputToHclTerraform(struct?: WarehouseAdaptiveShowOutput): any;
export declare class WarehouseAdaptiveShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): WarehouseAdaptiveShowOutput | undefined;
    set internalValue(value: WarehouseAdaptiveShowOutput | undefined);
    get autoResume(): cdktn.IResolvable;
    get available(): number;
    get comment(): string;
    get createdOn(): string;
    get isCurrent(): cdktn.IResolvable;
    get isDefault(): cdktn.IResolvable;
    get maxQueryPerformanceLevel(): string;
    get name(): string;
    get other(): number;
    get owner(): string;
    get ownerRoleType(): string;
    get provisioning(): number;
    get queryThroughputMultiplier(): number;
    get queued(): number;
    get quiescing(): number;
    get resourceMonitor(): string;
    get resumedOn(): string;
    get running(): number;
    get state(): string;
    get type(): string;
    get updatedOn(): string;
}
export declare class WarehouseAdaptiveShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): WarehouseAdaptiveShowOutputOutputReference;
}
export interface WarehouseAdaptiveTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/warehouse_adaptive#create WarehouseAdaptive#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/warehouse_adaptive#delete WarehouseAdaptive#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/warehouse_adaptive#read WarehouseAdaptive#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/warehouse_adaptive#update WarehouseAdaptive#update}
    */
    readonly update?: string;
}
export declare function warehouseAdaptiveTimeoutsToTerraform(struct?: WarehouseAdaptiveTimeouts | cdktn.IResolvable): any;
export declare function warehouseAdaptiveTimeoutsToHclTerraform(struct?: WarehouseAdaptiveTimeouts | cdktn.IResolvable): any;
export declare class WarehouseAdaptiveTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WarehouseAdaptiveTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: WarehouseAdaptiveTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/warehouse_adaptive snowflake_warehouse_adaptive}
*/
export declare class WarehouseAdaptive extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_warehouse_adaptive";
    /**
    * Generates CDKTN code for importing a WarehouseAdaptive resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WarehouseAdaptive to import
    * @param importFromId The id of the existing WarehouseAdaptive that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/warehouse_adaptive#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WarehouseAdaptive to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/warehouse_adaptive snowflake_warehouse_adaptive} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WarehouseAdaptiveConfig
    */
    constructor(scope: Construct, id: string, config: WarehouseAdaptiveConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxQueryPerformanceLevel?;
    get maxQueryPerformanceLevel(): string;
    set maxQueryPerformanceLevel(value: string);
    resetMaxQueryPerformanceLevel(): void;
    get maxQueryPerformanceLevelInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): WarehouseAdaptiveParametersList;
    private _queryThroughputMultiplier?;
    get queryThroughputMultiplier(): number;
    set queryThroughputMultiplier(value: number);
    resetQueryThroughputMultiplier(): void;
    get queryThroughputMultiplierInput(): number | undefined;
    private _showOutput;
    get showOutput(): WarehouseAdaptiveShowOutputList;
    private _statementQueuedTimeoutInSeconds?;
    get statementQueuedTimeoutInSeconds(): number;
    set statementQueuedTimeoutInSeconds(value: number);
    resetStatementQueuedTimeoutInSeconds(): void;
    get statementQueuedTimeoutInSecondsInput(): number | undefined;
    private _statementTimeoutInSeconds?;
    get statementTimeoutInSeconds(): number;
    set statementTimeoutInSeconds(value: number);
    resetStatementTimeoutInSeconds(): void;
    get statementTimeoutInSecondsInput(): number | undefined;
    get warehouseType(): string;
    private _timeouts;
    get timeouts(): WarehouseAdaptiveTimeoutsOutputReference;
    putTimeouts(value: WarehouseAdaptiveTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | WarehouseAdaptiveTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
