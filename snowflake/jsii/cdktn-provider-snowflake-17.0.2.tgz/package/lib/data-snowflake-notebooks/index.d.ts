/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeNotebooksConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/notebooks#id DataSnowflakeNotebooks#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/notebooks#like DataSnowflakeNotebooks#like}
    */
    readonly like?: string;
    /**
    * Filters the output with **case-sensitive** characters indicating the beginning of the object name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/notebooks#starts_with DataSnowflakeNotebooks#starts_with}
    */
    readonly startsWith?: string;
    /**
    * (Default: `true`) Runs DESC NOTEBOOK for each notebook returned by SHOW NOTEBOOKS. The output of describe is saved to the description field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/notebooks#with_describe DataSnowflakeNotebooks#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/notebooks#limit DataSnowflakeNotebooks#limit}
    */
    readonly limit?: DataSnowflakeNotebooksLimit;
}
export interface DataSnowflakeNotebooksNotebooksDescribeOutput {
}
export declare function dataSnowflakeNotebooksNotebooksDescribeOutputToTerraform(struct?: DataSnowflakeNotebooksNotebooksDescribeOutput): any;
export declare function dataSnowflakeNotebooksNotebooksDescribeOutputToHclTerraform(struct?: DataSnowflakeNotebooksNotebooksDescribeOutput): any;
export declare class DataSnowflakeNotebooksNotebooksDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeNotebooksNotebooksDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeNotebooksNotebooksDescribeOutput | undefined);
    get codeWarehouse(): string;
    get comment(): string;
    get computePool(): string;
    get defaultPackages(): string;
    get defaultVersion(): string;
    get defaultVersionAlias(): string;
    get defaultVersionGitCommitHash(): string;
    get defaultVersionLocationUri(): string;
    get defaultVersionName(): string;
    get defaultVersionSourceLocationUri(): string;
    get externalAccessIntegrations(): string;
    get externalAccessSecrets(): string;
    get idleAutoShutdownTimeSeconds(): number;
    get importUrls(): string;
    get lastVersionAlias(): string;
    get lastVersionGitCommitHash(): string;
    get lastVersionLocationUri(): string;
    get lastVersionName(): string;
    get lastVersionSourceLocationUri(): string;
    get liveVersionLocationUri(): string;
    get mainFile(): string;
    get name(): string;
    get owner(): string;
    get queryWarehouse(): string;
    get runtimeEnvironmentVersion(): string;
    get runtimeName(): string;
    get title(): string;
    get urlId(): string;
    get userPackages(): string;
}
export declare class DataSnowflakeNotebooksNotebooksDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeNotebooksNotebooksDescribeOutputOutputReference;
}
export interface DataSnowflakeNotebooksNotebooksShowOutput {
}
export declare function dataSnowflakeNotebooksNotebooksShowOutputToTerraform(struct?: DataSnowflakeNotebooksNotebooksShowOutput): any;
export declare function dataSnowflakeNotebooksNotebooksShowOutputToHclTerraform(struct?: DataSnowflakeNotebooksNotebooksShowOutput): any;
export declare class DataSnowflakeNotebooksNotebooksShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeNotebooksNotebooksShowOutput | undefined;
    set internalValue(value: DataSnowflakeNotebooksNotebooksShowOutput | undefined);
    get codeWarehouse(): string;
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get queryWarehouse(): string;
    get schemaName(): string;
    get urlId(): string;
}
export declare class DataSnowflakeNotebooksNotebooksShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeNotebooksNotebooksShowOutputOutputReference;
}
export interface DataSnowflakeNotebooksNotebooks {
}
export declare function dataSnowflakeNotebooksNotebooksToTerraform(struct?: DataSnowflakeNotebooksNotebooks): any;
export declare function dataSnowflakeNotebooksNotebooksToHclTerraform(struct?: DataSnowflakeNotebooksNotebooks): any;
export declare class DataSnowflakeNotebooksNotebooksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeNotebooksNotebooks | undefined;
    set internalValue(value: DataSnowflakeNotebooksNotebooks | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeNotebooksNotebooksDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeNotebooksNotebooksShowOutputList;
}
export declare class DataSnowflakeNotebooksNotebooksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeNotebooksNotebooksOutputReference;
}
export interface DataSnowflakeNotebooksLimit {
    /**
    * Specifies a **case-sensitive** pattern that is used to match object name. After the first match, the limit on the number of rows will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/notebooks#from DataSnowflakeNotebooks#from}
    */
    readonly from?: string;
    /**
    * The maximum number of rows to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/notebooks#rows DataSnowflakeNotebooks#rows}
    */
    readonly rows: number;
}
export declare function dataSnowflakeNotebooksLimitToTerraform(struct?: DataSnowflakeNotebooksLimitOutputReference | DataSnowflakeNotebooksLimit): any;
export declare function dataSnowflakeNotebooksLimitToHclTerraform(struct?: DataSnowflakeNotebooksLimitOutputReference | DataSnowflakeNotebooksLimit): any;
export declare class DataSnowflakeNotebooksLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeNotebooksLimit | undefined;
    set internalValue(value: DataSnowflakeNotebooksLimit | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _rows?;
    get rows(): number;
    set rows(value: number);
    get rowsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/notebooks snowflake_notebooks}
*/
export declare class DataSnowflakeNotebooks extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_notebooks";
    /**
    * Generates CDKTN code for importing a DataSnowflakeNotebooks resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeNotebooks to import
    * @param importFromId The id of the existing DataSnowflakeNotebooks that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/notebooks#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeNotebooks to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/notebooks snowflake_notebooks} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeNotebooksConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeNotebooksConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _notebooks;
    get notebooks(): DataSnowflakeNotebooksNotebooksList;
    private _startsWith?;
    get startsWith(): string;
    set startsWith(value: string);
    resetStartsWith(): void;
    get startsWithInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _limit;
    get limit(): DataSnowflakeNotebooksLimitOutputReference;
    putLimit(value: DataSnowflakeNotebooksLimit): void;
    resetLimit(): void;
    get limitInput(): DataSnowflakeNotebooksLimit | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
