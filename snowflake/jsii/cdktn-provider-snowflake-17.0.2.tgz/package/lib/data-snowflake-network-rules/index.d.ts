/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeNetworkRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/network_rules#id DataSnowflakeNetworkRules#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/network_rules#like DataSnowflakeNetworkRules#like}
    */
    readonly like?: string;
    /**
    * Filters the output with **case-sensitive** characters indicating the beginning of the object name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/network_rules#starts_with DataSnowflakeNetworkRules#starts_with}
    */
    readonly startsWith?: string;
    /**
    * (Default: `true`) Runs DESC NETWORK RULE for each network rule returned by SHOW NETWORK RULES. The output of describe is saved to the description field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/network_rules#with_describe DataSnowflakeNetworkRules#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
    /**
    * in block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/network_rules#in DataSnowflakeNetworkRules#in}
    */
    readonly in?: DataSnowflakeNetworkRulesIn;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/network_rules#limit DataSnowflakeNetworkRules#limit}
    */
    readonly limit?: DataSnowflakeNetworkRulesLimit;
}
export interface DataSnowflakeNetworkRulesNetworkRulesDescribeOutput {
}
export declare function dataSnowflakeNetworkRulesNetworkRulesDescribeOutputToTerraform(struct?: DataSnowflakeNetworkRulesNetworkRulesDescribeOutput): any;
export declare function dataSnowflakeNetworkRulesNetworkRulesDescribeOutputToHclTerraform(struct?: DataSnowflakeNetworkRulesNetworkRulesDescribeOutput): any;
export declare class DataSnowflakeNetworkRulesNetworkRulesDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeNetworkRulesNetworkRulesDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeNetworkRulesNetworkRulesDescribeOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get mode(): string;
    get name(): string;
    get owner(): string;
    get schemaName(): string;
    get type(): string;
    get valueList(): string[];
}
export declare class DataSnowflakeNetworkRulesNetworkRulesDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeNetworkRulesNetworkRulesDescribeOutputOutputReference;
}
export interface DataSnowflakeNetworkRulesNetworkRulesShowOutput {
}
export declare function dataSnowflakeNetworkRulesNetworkRulesShowOutputToTerraform(struct?: DataSnowflakeNetworkRulesNetworkRulesShowOutput): any;
export declare function dataSnowflakeNetworkRulesNetworkRulesShowOutputToHclTerraform(struct?: DataSnowflakeNetworkRulesNetworkRulesShowOutput): any;
export declare class DataSnowflakeNetworkRulesNetworkRulesShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeNetworkRulesNetworkRulesShowOutput | undefined;
    set internalValue(value: DataSnowflakeNetworkRulesNetworkRulesShowOutput | undefined);
    get comment(): string;
    get createdOn(): string;
    get databaseName(): string;
    get entriesInValueList(): number;
    get mode(): string;
    get name(): string;
    get owner(): string;
    get ownerRoleType(): string;
    get schemaName(): string;
    get type(): string;
}
export declare class DataSnowflakeNetworkRulesNetworkRulesShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeNetworkRulesNetworkRulesShowOutputOutputReference;
}
export interface DataSnowflakeNetworkRulesNetworkRules {
}
export declare function dataSnowflakeNetworkRulesNetworkRulesToTerraform(struct?: DataSnowflakeNetworkRulesNetworkRules): any;
export declare function dataSnowflakeNetworkRulesNetworkRulesToHclTerraform(struct?: DataSnowflakeNetworkRulesNetworkRules): any;
export declare class DataSnowflakeNetworkRulesNetworkRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeNetworkRulesNetworkRules | undefined;
    set internalValue(value: DataSnowflakeNetworkRulesNetworkRules | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeNetworkRulesNetworkRulesDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeNetworkRulesNetworkRulesShowOutputList;
}
export declare class DataSnowflakeNetworkRulesNetworkRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeNetworkRulesNetworkRulesOutputReference;
}
export interface DataSnowflakeNetworkRulesIn {
    /**
    * Returns records for the entire account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/network_rules#account DataSnowflakeNetworkRules#account}
    */
    readonly account?: boolean | cdktn.IResolvable;
    /**
    * Returns records for the current database in use or for a specified database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/network_rules#database DataSnowflakeNetworkRules#database}
    */
    readonly database?: string;
    /**
    * Returns records for the current schema in use or a specified schema. Use fully qualified name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/network_rules#schema DataSnowflakeNetworkRules#schema}
    */
    readonly schema?: string;
}
export declare function dataSnowflakeNetworkRulesInToTerraform(struct?: DataSnowflakeNetworkRulesInOutputReference | DataSnowflakeNetworkRulesIn): any;
export declare function dataSnowflakeNetworkRulesInToHclTerraform(struct?: DataSnowflakeNetworkRulesInOutputReference | DataSnowflakeNetworkRulesIn): any;
export declare class DataSnowflakeNetworkRulesInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeNetworkRulesIn | undefined;
    set internalValue(value: DataSnowflakeNetworkRulesIn | undefined);
    private _account?;
    get account(): boolean | cdktn.IResolvable;
    set account(value: boolean | cdktn.IResolvable);
    resetAccount(): void;
    get accountInput(): boolean | cdktn.IResolvable | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export interface DataSnowflakeNetworkRulesLimit {
    /**
    * Specifies a **case-sensitive** pattern that is used to match object name. After the first match, the limit on the number of rows will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/network_rules#from DataSnowflakeNetworkRules#from}
    */
    readonly from?: string;
    /**
    * The maximum number of rows to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/network_rules#rows DataSnowflakeNetworkRules#rows}
    */
    readonly rows: number;
}
export declare function dataSnowflakeNetworkRulesLimitToTerraform(struct?: DataSnowflakeNetworkRulesLimitOutputReference | DataSnowflakeNetworkRulesLimit): any;
export declare function dataSnowflakeNetworkRulesLimitToHclTerraform(struct?: DataSnowflakeNetworkRulesLimitOutputReference | DataSnowflakeNetworkRulesLimit): any;
export declare class DataSnowflakeNetworkRulesLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataSnowflakeNetworkRulesLimit | undefined;
    set internalValue(value: DataSnowflakeNetworkRulesLimit | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _rows?;
    get rows(): number;
    set rows(value: number);
    get rowsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/network_rules snowflake_network_rules}
*/
export declare class DataSnowflakeNetworkRules extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_network_rules";
    /**
    * Generates CDKTN code for importing a DataSnowflakeNetworkRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeNetworkRules to import
    * @param importFromId The id of the existing DataSnowflakeNetworkRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/network_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeNetworkRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/network_rules snowflake_network_rules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeNetworkRulesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeNetworkRulesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _networkRules;
    get networkRules(): DataSnowflakeNetworkRulesNetworkRulesList;
    private _startsWith?;
    get startsWith(): string;
    set startsWith(value: string);
    resetStartsWith(): void;
    get startsWithInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    private _in;
    get in(): DataSnowflakeNetworkRulesInOutputReference;
    putIn(value: DataSnowflakeNetworkRulesIn): void;
    resetIn(): void;
    get inInput(): DataSnowflakeNetworkRulesIn | undefined;
    private _limit;
    get limit(): DataSnowflakeNetworkRulesLimitOutputReference;
    putLimit(value: DataSnowflakeNetworkRulesLimit): void;
    resetLimit(): void;
    get limitInput(): DataSnowflakeNetworkRulesLimit | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
