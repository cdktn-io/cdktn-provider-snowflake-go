/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CatalogIntegrationAwsGlueConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the default AWS Glue Data Catalog namespace for all Iceberg tables that you associate with the catalog integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue#catalog_namespace CatalogIntegrationAwsGlue#catalog_namespace}
    */
    readonly catalogNamespace?: string;
    /**
    * (Default: ``) Specifies a comment for the catalog integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue#comment CatalogIntegrationAwsGlue#comment}
    */
    readonly comment?: string;
    /**
    * Specifies whether the catalog integration is available for use for Iceberg tables. `true` allows users to create new Iceberg tables that reference this integration. Existing Iceberg tables that reference this integration function normally. `false` prevents users from creating new Iceberg tables that reference this integration. Existing Iceberg tables that reference this integration cannot access the catalog in the table definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue#enabled CatalogIntegrationAwsGlue#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Specifies the Amazon Resource Name (ARN) of the AWS Identity and Access Management (IAM) role to assume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue#glue_aws_role_arn CatalogIntegrationAwsGlue#glue_aws_role_arn}
    */
    readonly glueAwsRoleArn: string;
    /**
    * Specifies the ID of your AWS account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue#glue_catalog_id CatalogIntegrationAwsGlue#glue_catalog_id}
    */
    readonly glueCatalogId: string;
    /**
    * Specifies the AWS region of your AWS Glue Data Catalog. You must specify a value for this attribute if your Snowflake account is not hosted on AWS. Otherwise, the default region is the Snowflake deployment region for the account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue#glue_region CatalogIntegrationAwsGlue#glue_region}
    */
    readonly glueRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue#id CatalogIntegrationAwsGlue#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier (i.e. name) of the catalog integration; must be unique in your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue#name CatalogIntegrationAwsGlue#name}
    */
    readonly name: string;
    /**
    * Specifies the number of seconds to wait between attempts to poll the external Iceberg catalog for metadata updates for automated refresh. For Delta-based tables, specifies the number of seconds to wait between attempts to poll your external cloud storage for new metadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue#refresh_interval_seconds CatalogIntegrationAwsGlue#refresh_interval_seconds}
    */
    readonly refreshIntervalSeconds?: number;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue#timeouts CatalogIntegrationAwsGlue#timeouts}
    */
    readonly timeouts?: CatalogIntegrationAwsGlueTimeouts;
}
export interface CatalogIntegrationAwsGlueDescribeOutput {
}
export declare function catalogIntegrationAwsGlueDescribeOutputToTerraform(struct?: CatalogIntegrationAwsGlueDescribeOutput): any;
export declare function catalogIntegrationAwsGlueDescribeOutputToHclTerraform(struct?: CatalogIntegrationAwsGlueDescribeOutput): any;
export declare class CatalogIntegrationAwsGlueDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CatalogIntegrationAwsGlueDescribeOutput | undefined;
    set internalValue(value: CatalogIntegrationAwsGlueDescribeOutput | undefined);
    get catalogNamespace(): string;
    get catalogSource(): string;
    get comment(): string;
    get enabled(): cdktn.IResolvable;
    get glueAwsRoleArn(): string;
    get glueCatalogId(): string;
    get glueRegion(): string;
    get id(): string;
    get refreshIntervalSeconds(): number;
    get tableFormat(): string;
}
export declare class CatalogIntegrationAwsGlueDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CatalogIntegrationAwsGlueDescribeOutputOutputReference;
}
export interface CatalogIntegrationAwsGlueShowOutput {
}
export declare function catalogIntegrationAwsGlueShowOutputToTerraform(struct?: CatalogIntegrationAwsGlueShowOutput): any;
export declare function catalogIntegrationAwsGlueShowOutputToHclTerraform(struct?: CatalogIntegrationAwsGlueShowOutput): any;
export declare class CatalogIntegrationAwsGlueShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CatalogIntegrationAwsGlueShowOutput | undefined;
    set internalValue(value: CatalogIntegrationAwsGlueShowOutput | undefined);
    get category(): string;
    get comment(): string;
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
    get type(): string;
}
export declare class CatalogIntegrationAwsGlueShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CatalogIntegrationAwsGlueShowOutputOutputReference;
}
export interface CatalogIntegrationAwsGlueTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue#create CatalogIntegrationAwsGlue#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue#delete CatalogIntegrationAwsGlue#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue#read CatalogIntegrationAwsGlue#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue#update CatalogIntegrationAwsGlue#update}
    */
    readonly update?: string;
}
export declare function catalogIntegrationAwsGlueTimeoutsToTerraform(struct?: CatalogIntegrationAwsGlueTimeouts | cdktn.IResolvable): any;
export declare function catalogIntegrationAwsGlueTimeoutsToHclTerraform(struct?: CatalogIntegrationAwsGlueTimeouts | cdktn.IResolvable): any;
export declare class CatalogIntegrationAwsGlueTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogIntegrationAwsGlueTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CatalogIntegrationAwsGlueTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue snowflake_catalog_integration_aws_glue}
*/
export declare class CatalogIntegrationAwsGlue extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_catalog_integration_aws_glue";
    /**
    * Generates CDKTN code for importing a CatalogIntegrationAwsGlue resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CatalogIntegrationAwsGlue to import
    * @param importFromId The id of the existing CatalogIntegrationAwsGlue that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CatalogIntegrationAwsGlue to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_aws_glue snowflake_catalog_integration_aws_glue} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CatalogIntegrationAwsGlueConfig
    */
    constructor(scope: Construct, id: string, config: CatalogIntegrationAwsGlueConfig);
    private _catalogNamespace?;
    get catalogNamespace(): string;
    set catalogNamespace(value: string);
    resetCatalogNamespace(): void;
    get catalogNamespaceInput(): string | undefined;
    get catalogSource(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): CatalogIntegrationAwsGlueDescribeOutputList;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get fullyQualifiedName(): string;
    private _glueAwsRoleArn?;
    get glueAwsRoleArn(): string;
    set glueAwsRoleArn(value: string);
    get glueAwsRoleArnInput(): string | undefined;
    private _glueCatalogId?;
    get glueCatalogId(): string;
    set glueCatalogId(value: string);
    get glueCatalogIdInput(): string | undefined;
    private _glueRegion?;
    get glueRegion(): string;
    set glueRegion(value: string);
    resetGlueRegion(): void;
    get glueRegionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _refreshIntervalSeconds?;
    get refreshIntervalSeconds(): number;
    set refreshIntervalSeconds(value: number);
    resetRefreshIntervalSeconds(): void;
    get refreshIntervalSecondsInput(): number | undefined;
    private _showOutput;
    get showOutput(): CatalogIntegrationAwsGlueShowOutputList;
    private _timeouts;
    get timeouts(): CatalogIntegrationAwsGlueTimeoutsOutputReference;
    putTimeouts(value: CatalogIntegrationAwsGlueTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CatalogIntegrationAwsGlueTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
