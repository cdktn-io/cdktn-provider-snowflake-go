/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ExternalTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * (Default: `true`) Specifies whether to automatically refresh the external table metadata once, immediately after the external table is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#auto_refresh ExternalTable#auto_refresh}
    */
    readonly autoRefresh?: boolean | cdktn.IResolvable;
    /**
    * Specifies the aws sns topic for the external table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#aws_sns_topic ExternalTable#aws_sns_topic}
    */
    readonly awsSnsTopic?: string;
    /**
    * Specifies a comment for the external table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#comment ExternalTable#comment}
    */
    readonly comment?: string;
    /**
    * (Default: `false`) Specifies to retain the access permissions from the original table when an external table is recreated using the CREATE OR REPLACE TABLE variant
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#copy_grants ExternalTable#copy_grants}
    */
    readonly copyGrants?: boolean | cdktn.IResolvable;
    /**
    * The database in which to create the external table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#database ExternalTable#database}
    */
    readonly database: string;
    /**
    * Specifies the file format for the external table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#file_format ExternalTable#file_format}
    */
    readonly fileFormat: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#id ExternalTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies a location for the external table, using its FQDN. You can hardcode it (`"@MYDB.MYSCHEMA.MYSTAGE"`), or populate dynamically (`"@${snowflake_stage.mystage.fully_qualified_name}"`)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#location ExternalTable#location}
    */
    readonly location: string;
    /**
    * Specifies the identifier for the external table; must be unique for the database and schema in which the externalTable is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#name ExternalTable#name}
    */
    readonly name: string;
    /**
    * Specifies any partition columns to evaluate for the external table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#partition_by ExternalTable#partition_by}
    */
    readonly partitionBy?: string[];
    /**
    * Specifies the file names and/or paths on the external stage to match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#pattern ExternalTable#pattern}
    */
    readonly pattern?: string;
    /**
    * (Default: `true`) Specifies weather to refresh when an external table is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#refresh_on_create ExternalTable#refresh_on_create}
    */
    readonly refreshOnCreate?: boolean | cdktn.IResolvable;
    /**
    * The schema in which to create the external table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#schema ExternalTable#schema}
    */
    readonly schema: string;
    /**
    * Identifies the external table table type. For now, only "delta" for Delta Lake table format is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#table_format ExternalTable#table_format}
    */
    readonly tableFormat?: string;
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#column ExternalTable#column}
    */
    readonly column: ExternalTableColumn[] | cdktn.IResolvable;
    /**
    * tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#tag ExternalTable#tag}
    */
    readonly tag?: ExternalTableTag[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#timeouts ExternalTable#timeouts}
    */
    readonly timeouts?: ExternalTableTimeouts;
}
export interface ExternalTableColumn {
    /**
    * String that specifies the expression for the column. When queried, the column returns results derived from this expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#as ExternalTable#as}
    */
    readonly as: string;
    /**
    * Column name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#name ExternalTable#name}
    */
    readonly name: string;
    /**
    * Column type, e.g. VARIANT
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#type ExternalTable#type}
    */
    readonly type: string;
}
export declare function externalTableColumnToTerraform(struct?: ExternalTableColumn | cdktn.IResolvable): any;
export declare function externalTableColumnToHclTerraform(struct?: ExternalTableColumn | cdktn.IResolvable): any;
export declare class ExternalTableColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ExternalTableColumn | cdktn.IResolvable | undefined;
    set internalValue(value: ExternalTableColumn | cdktn.IResolvable | undefined);
    private _as?;
    get as(): string;
    set as(value: string);
    get asInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ExternalTableColumnList extends cdktn.ComplexList {
    internalValue?: ExternalTableColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ExternalTableColumnOutputReference;
}
export interface ExternalTableTag {
    /**
    * Name of the database that the tag was created in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#database ExternalTable#database}
    */
    readonly database?: string;
    /**
    * Tag name, e.g. department.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#name ExternalTable#name}
    */
    readonly name: string;
    /**
    * Name of the schema that the tag was created in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#schema ExternalTable#schema}
    */
    readonly schema?: string;
    /**
    * Tag value, e.g. marketing_info.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#value ExternalTable#value}
    */
    readonly value: string;
}
export declare function externalTableTagToTerraform(struct?: ExternalTableTag | cdktn.IResolvable): any;
export declare function externalTableTagToHclTerraform(struct?: ExternalTableTag | cdktn.IResolvable): any;
export declare class ExternalTableTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ExternalTableTag | cdktn.IResolvable | undefined;
    set internalValue(value: ExternalTableTag | cdktn.IResolvable | undefined);
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ExternalTableTagList extends cdktn.ComplexList {
    internalValue?: ExternalTableTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ExternalTableTagOutputReference;
}
export interface ExternalTableTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#create ExternalTable#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#delete ExternalTable#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#read ExternalTable#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#update ExternalTable#update}
    */
    readonly update?: string;
}
export declare function externalTableTimeoutsToTerraform(struct?: ExternalTableTimeouts | cdktn.IResolvable): any;
export declare function externalTableTimeoutsToHclTerraform(struct?: ExternalTableTimeouts | cdktn.IResolvable): any;
export declare class ExternalTableTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalTableTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ExternalTableTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table snowflake_external_table}
*/
export declare class ExternalTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_external_table";
    /**
    * Generates CDKTN code for importing a ExternalTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ExternalTable to import
    * @param importFromId The id of the existing ExternalTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ExternalTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/external_table snowflake_external_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ExternalTableConfig
    */
    constructor(scope: Construct, id: string, config: ExternalTableConfig);
    private _autoRefresh?;
    get autoRefresh(): boolean | cdktn.IResolvable;
    set autoRefresh(value: boolean | cdktn.IResolvable);
    resetAutoRefresh(): void;
    get autoRefreshInput(): boolean | cdktn.IResolvable | undefined;
    private _awsSnsTopic?;
    get awsSnsTopic(): string;
    set awsSnsTopic(value: string);
    resetAwsSnsTopic(): void;
    get awsSnsTopicInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _copyGrants?;
    get copyGrants(): boolean | cdktn.IResolvable;
    set copyGrants(value: boolean | cdktn.IResolvable);
    resetCopyGrants(): void;
    get copyGrantsInput(): boolean | cdktn.IResolvable | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _fileFormat?;
    get fileFormat(): string;
    set fileFormat(value: string);
    get fileFormatInput(): string | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get owner(): string;
    private _partitionBy?;
    get partitionBy(): string[];
    set partitionBy(value: string[]);
    resetPartitionBy(): void;
    get partitionByInput(): string[] | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _refreshOnCreate?;
    get refreshOnCreate(): boolean | cdktn.IResolvable;
    set refreshOnCreate(value: boolean | cdktn.IResolvable);
    resetRefreshOnCreate(): void;
    get refreshOnCreateInput(): boolean | cdktn.IResolvable | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    private _tableFormat?;
    get tableFormat(): string;
    set tableFormat(value: string);
    resetTableFormat(): void;
    get tableFormatInput(): string | undefined;
    private _column;
    get column(): ExternalTableColumnList;
    putColumn(value: ExternalTableColumn[] | cdktn.IResolvable): void;
    get columnInput(): cdktn.IResolvable | ExternalTableColumn[] | undefined;
    private _tag;
    get tag(): ExternalTableTagList;
    putTag(value: ExternalTableTag[] | cdktn.IResolvable): void;
    resetTag(): void;
    get tagInput(): cdktn.IResolvable | ExternalTableTag[] | undefined;
    private _timeouts;
    get timeouts(): ExternalTableTimeoutsOutputReference;
    putTimeouts(value: ExternalTableTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ExternalTableTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
