/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataSnowflakeExternalVolumesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/external_volumes#id DataSnowflakeExternalVolumes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filters the output with **case-insensitive** pattern, with support for SQL wildcard characters (`%` and `_`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/external_volumes#like DataSnowflakeExternalVolumes#like}
    */
    readonly like?: string;
    /**
    * (Default: `true`) Runs DESC EXTERNAL VOLUME for each external volume returned by SHOW EXTERNAL VOLUMES. The output of describe is saved to the describe_output field. By default this value is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/external_volumes#with_describe DataSnowflakeExternalVolumes#with_describe}
    */
    readonly withDescribe?: boolean | cdktn.IResolvable;
}
export interface DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsAzureStorageLocation {
}
export declare function dataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsAzureStorageLocationToTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsAzureStorageLocation): any;
export declare function dataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsAzureStorageLocationToHclTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsAzureStorageLocation): any;
export declare class DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsAzureStorageLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsAzureStorageLocation | undefined;
    set internalValue(value: DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsAzureStorageLocation | undefined);
    get azureConsentUrl(): string;
    get azureMultiTenantAppName(): string;
    get azureTenantId(): string;
}
export declare class DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsAzureStorageLocationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsAzureStorageLocationOutputReference;
}
export interface DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsGcsStorageLocation {
}
export declare function dataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsGcsStorageLocationToTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsGcsStorageLocation): any;
export declare function dataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsGcsStorageLocationToHclTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsGcsStorageLocation): any;
export declare class DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsGcsStorageLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsGcsStorageLocation | undefined;
    set internalValue(value: DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsGcsStorageLocation | undefined);
    get encryptionKmsKeyId(): string;
    get storageGcpServiceAccount(): string;
}
export declare class DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsGcsStorageLocationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsGcsStorageLocationOutputReference;
}
export interface DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3CompatStorageLocation {
}
export declare function dataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3CompatStorageLocationToTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3CompatStorageLocation): any;
export declare function dataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3CompatStorageLocationToHclTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3CompatStorageLocation): any;
export declare class DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3CompatStorageLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3CompatStorageLocation | undefined;
    set internalValue(value: DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3CompatStorageLocation | undefined);
    get awsAccessKeyId(): string;
    get encryptionKmsKeyId(): string;
    get endpoint(): string;
}
export declare class DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3CompatStorageLocationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3CompatStorageLocationOutputReference;
}
export interface DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3StorageLocation {
}
export declare function dataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3StorageLocationToTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3StorageLocation): any;
export declare function dataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3StorageLocationToHclTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3StorageLocation): any;
export declare class DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3StorageLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3StorageLocation | undefined;
    set internalValue(value: DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3StorageLocation | undefined);
    get encryptionKmsKeyId(): string;
    get storageAwsAccessPointArn(): string;
    get storageAwsExternalId(): string;
    get storageAwsIamUserArn(): string;
    get storageAwsRoleArn(): string;
    get usePrivatelinkEndpoint(): string;
}
export declare class DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3StorageLocationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3StorageLocationOutputReference;
}
export interface DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocations {
}
export declare function dataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsToTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocations): any;
export declare function dataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsToHclTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocations): any;
export declare class DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocations | undefined;
    set internalValue(value: DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocations | undefined);
    private _azureStorageLocation;
    get azureStorageLocation(): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsAzureStorageLocationList;
    get encryptionType(): string;
    private _gcsStorageLocation;
    get gcsStorageLocation(): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsGcsStorageLocationList;
    get name(): string;
    private _s3CompatStorageLocation;
    get s3CompatStorageLocation(): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3CompatStorageLocationList;
    private _s3StorageLocation;
    get s3StorageLocation(): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsS3StorageLocationList;
    get storageAllowedLocations(): string[];
    get storageBaseUrl(): string;
    get storageProvider(): string;
}
export declare class DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsOutputReference;
}
export interface DataSnowflakeExternalVolumesExternalVolumesDescribeOutput {
}
export declare function dataSnowflakeExternalVolumesExternalVolumesDescribeOutputToTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumesDescribeOutput): any;
export declare function dataSnowflakeExternalVolumesExternalVolumesDescribeOutputToHclTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumesDescribeOutput): any;
export declare class DataSnowflakeExternalVolumesExternalVolumesDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeExternalVolumesExternalVolumesDescribeOutput | undefined;
    set internalValue(value: DataSnowflakeExternalVolumesExternalVolumesDescribeOutput | undefined);
    get active(): string;
    get allowWrites(): string;
    get comment(): string;
    private _storageLocations;
    get storageLocations(): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputStorageLocationsList;
}
export declare class DataSnowflakeExternalVolumesExternalVolumesDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputOutputReference;
}
export interface DataSnowflakeExternalVolumesExternalVolumesShowOutput {
}
export declare function dataSnowflakeExternalVolumesExternalVolumesShowOutputToTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumesShowOutput): any;
export declare function dataSnowflakeExternalVolumesExternalVolumesShowOutputToHclTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumesShowOutput): any;
export declare class DataSnowflakeExternalVolumesExternalVolumesShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeExternalVolumesExternalVolumesShowOutput | undefined;
    set internalValue(value: DataSnowflakeExternalVolumesExternalVolumesShowOutput | undefined);
    get allowWrites(): cdktn.IResolvable;
    get comment(): string;
    get name(): string;
}
export declare class DataSnowflakeExternalVolumesExternalVolumesShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeExternalVolumesExternalVolumesShowOutputOutputReference;
}
export interface DataSnowflakeExternalVolumesExternalVolumes {
}
export declare function dataSnowflakeExternalVolumesExternalVolumesToTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumes): any;
export declare function dataSnowflakeExternalVolumesExternalVolumesToHclTerraform(struct?: DataSnowflakeExternalVolumesExternalVolumes): any;
export declare class DataSnowflakeExternalVolumesExternalVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataSnowflakeExternalVolumesExternalVolumes | undefined;
    set internalValue(value: DataSnowflakeExternalVolumesExternalVolumes | undefined);
    private _describeOutput;
    get describeOutput(): DataSnowflakeExternalVolumesExternalVolumesDescribeOutputList;
    private _showOutput;
    get showOutput(): DataSnowflakeExternalVolumesExternalVolumesShowOutputList;
}
export declare class DataSnowflakeExternalVolumesExternalVolumesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataSnowflakeExternalVolumesExternalVolumesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/external_volumes snowflake_external_volumes}
*/
export declare class DataSnowflakeExternalVolumes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "snowflake_external_volumes";
    /**
    * Generates CDKTN code for importing a DataSnowflakeExternalVolumes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataSnowflakeExternalVolumes to import
    * @param importFromId The id of the existing DataSnowflakeExternalVolumes that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/external_volumes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataSnowflakeExternalVolumes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/data-sources/external_volumes snowflake_external_volumes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataSnowflakeExternalVolumesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataSnowflakeExternalVolumesConfig);
    private _externalVolumes;
    get externalVolumes(): DataSnowflakeExternalVolumesExternalVolumesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _like?;
    get like(): string;
    set like(value: string);
    resetLike(): void;
    get likeInput(): string | undefined;
    private _withDescribe?;
    get withDescribe(): boolean | cdktn.IResolvable;
    set withDescribe(value: boolean | cdktn.IResolvable);
    resetWithDescribe(): void;
    get withDescribeInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
