/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TableColumnMaskingPolicyApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The column to apply the masking policy to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/table_column_masking_policy_application#column TableColumnMaskingPolicyApplication#column}
    */
    readonly column: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/table_column_masking_policy_application#id TableColumnMaskingPolicyApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Fully qualified name (`database.schema.policyname`) of the policy to apply.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/table_column_masking_policy_application#masking_policy TableColumnMaskingPolicyApplication#masking_policy}
    */
    readonly maskingPolicy: string;
    /**
    * The fully qualified name (`database.schema.table`) of the table to apply the masking policy to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/table_column_masking_policy_application#table TableColumnMaskingPolicyApplication#table}
    */
    readonly table: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/table_column_masking_policy_application#timeouts TableColumnMaskingPolicyApplication#timeouts}
    */
    readonly timeouts?: TableColumnMaskingPolicyApplicationTimeouts;
}
export interface TableColumnMaskingPolicyApplicationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/table_column_masking_policy_application#create TableColumnMaskingPolicyApplication#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/table_column_masking_policy_application#delete TableColumnMaskingPolicyApplication#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/table_column_masking_policy_application#read TableColumnMaskingPolicyApplication#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/table_column_masking_policy_application#update TableColumnMaskingPolicyApplication#update}
    */
    readonly update?: string;
}
export declare function tableColumnMaskingPolicyApplicationTimeoutsToTerraform(struct?: TableColumnMaskingPolicyApplicationTimeouts | cdktn.IResolvable): any;
export declare function tableColumnMaskingPolicyApplicationTimeoutsToHclTerraform(struct?: TableColumnMaskingPolicyApplicationTimeouts | cdktn.IResolvable): any;
export declare class TableColumnMaskingPolicyApplicationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TableColumnMaskingPolicyApplicationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: TableColumnMaskingPolicyApplicationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/table_column_masking_policy_application snowflake_table_column_masking_policy_application}
*/
export declare class TableColumnMaskingPolicyApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_table_column_masking_policy_application";
    /**
    * Generates CDKTN code for importing a TableColumnMaskingPolicyApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TableColumnMaskingPolicyApplication to import
    * @param importFromId The id of the existing TableColumnMaskingPolicyApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/table_column_masking_policy_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TableColumnMaskingPolicyApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/table_column_masking_policy_application snowflake_table_column_masking_policy_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TableColumnMaskingPolicyApplicationConfig
    */
    constructor(scope: Construct, id: string, config: TableColumnMaskingPolicyApplicationConfig);
    private _column?;
    get column(): string;
    set column(value: string);
    get columnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maskingPolicy?;
    get maskingPolicy(): string;
    set maskingPolicy(value: string);
    get maskingPolicyInput(): string | undefined;
    private _table?;
    get table(): string;
    set table(value: string);
    get tableInput(): string | undefined;
    private _timeouts;
    get timeouts(): TableColumnMaskingPolicyApplicationTimeoutsOutputReference;
    putTimeouts(value: TableColumnMaskingPolicyApplicationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TableColumnMaskingPolicyApplicationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
