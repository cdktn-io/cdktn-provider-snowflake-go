/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StorageIntegrationGcsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a comment for the storage integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/storage_integration_gcs#comment StorageIntegrationGcs#comment}
    */
    readonly comment?: string;
    /**
    * Specifies whether this storage integration is available for usage in stages. `TRUE` allows users to create new stages that reference this integration. Existing stages that reference this integration function normally. `FALSE` prevents users from creating new stages that reference this integration. Existing stages that reference this integration cannot access the storage location in the stage definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/storage_integration_gcs#enabled StorageIntegrationGcs#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/storage_integration_gcs#id StorageIntegrationGcs#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * String that specifies the identifier (i.e. name) for the integration; must be unique in your account. Due to technical limitations (read more [here](../guides/identifiers_rework_design_decisions#known-limitations-and-identifier-recommendations)), avoid using the following characters: `|`, `.`, `"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/storage_integration_gcs#name StorageIntegrationGcs#name}
    */
    readonly name: string;
    /**
    * Explicitly limits external stages that use the integration to reference one or more storage locations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/storage_integration_gcs#storage_allowed_locations StorageIntegrationGcs#storage_allowed_locations}
    */
    readonly storageAllowedLocations: string[];
    /**
    * Explicitly prohibits external stages that use the integration from referencing one or more storage locations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/storage_integration_gcs#storage_blocked_locations StorageIntegrationGcs#storage_blocked_locations}
    */
    readonly storageBlockedLocations?: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/storage_integration_gcs#timeouts StorageIntegrationGcs#timeouts}
    */
    readonly timeouts?: StorageIntegrationGcsTimeouts;
}
export interface StorageIntegrationGcsDescribeOutput {
}
export declare function storageIntegrationGcsDescribeOutputToTerraform(struct?: StorageIntegrationGcsDescribeOutput): any;
export declare function storageIntegrationGcsDescribeOutputToHclTerraform(struct?: StorageIntegrationGcsDescribeOutput): any;
export declare class StorageIntegrationGcsDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationGcsDescribeOutput | undefined;
    set internalValue(value: StorageIntegrationGcsDescribeOutput | undefined);
    get allowedLocations(): string[];
    get blockedLocations(): string[];
    get comment(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get provider(): string;
    get serviceAccount(): string;
    get usePrivatelinkEndpoint(): cdktn.IResolvable;
}
export declare class StorageIntegrationGcsDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationGcsDescribeOutputOutputReference;
}
export interface StorageIntegrationGcsShowOutput {
}
export declare function storageIntegrationGcsShowOutputToTerraform(struct?: StorageIntegrationGcsShowOutput): any;
export declare function storageIntegrationGcsShowOutputToHclTerraform(struct?: StorageIntegrationGcsShowOutput): any;
export declare class StorageIntegrationGcsShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): StorageIntegrationGcsShowOutput | undefined;
    set internalValue(value: StorageIntegrationGcsShowOutput | undefined);
    get category(): string;
    get comment(): string;
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
    get storageType(): string;
}
export declare class StorageIntegrationGcsShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): StorageIntegrationGcsShowOutputOutputReference;
}
export interface StorageIntegrationGcsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/storage_integration_gcs#create StorageIntegrationGcs#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/storage_integration_gcs#delete StorageIntegrationGcs#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/storage_integration_gcs#read StorageIntegrationGcs#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/storage_integration_gcs#update StorageIntegrationGcs#update}
    */
    readonly update?: string;
}
export declare function storageIntegrationGcsTimeoutsToTerraform(struct?: StorageIntegrationGcsTimeouts | cdktn.IResolvable): any;
export declare function storageIntegrationGcsTimeoutsToHclTerraform(struct?: StorageIntegrationGcsTimeouts | cdktn.IResolvable): any;
export declare class StorageIntegrationGcsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageIntegrationGcsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: StorageIntegrationGcsTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/storage_integration_gcs snowflake_storage_integration_gcs}
*/
export declare class StorageIntegrationGcs extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_storage_integration_gcs";
    /**
    * Generates CDKTN code for importing a StorageIntegrationGcs resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StorageIntegrationGcs to import
    * @param importFromId The id of the existing StorageIntegrationGcs that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/storage_integration_gcs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StorageIntegrationGcs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/storage_integration_gcs snowflake_storage_integration_gcs} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StorageIntegrationGcsConfig
    */
    constructor(scope: Construct, id: string, config: StorageIntegrationGcsConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): StorageIntegrationGcsDescribeOutputList;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _showOutput;
    get showOutput(): StorageIntegrationGcsShowOutputList;
    private _storageAllowedLocations?;
    get storageAllowedLocations(): string[];
    set storageAllowedLocations(value: string[]);
    get storageAllowedLocationsInput(): string[] | undefined;
    private _storageBlockedLocations?;
    get storageBlockedLocations(): string[];
    set storageBlockedLocations(value: string[]);
    resetStorageBlockedLocations(): void;
    get storageBlockedLocationsInput(): string[] | undefined;
    private _timeouts;
    get timeouts(): StorageIntegrationGcsTimeoutsOutputReference;
    putTimeouts(value: StorageIntegrationGcsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | StorageIntegrationGcsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
