/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CatalogIntegrationObjectStorageConfig extends cdktn.TerraformMetaArguments {
    /**
    * (Default: ``) Specifies a comment for the catalog integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_object_storage#comment CatalogIntegrationObjectStorage#comment}
    */
    readonly comment?: string;
    /**
    * Specifies whether the catalog integration is available for use for Iceberg tables. `true` allows users to create new Iceberg tables that reference this integration. Existing Iceberg tables that reference this integration function normally. `false` prevents users from creating new Iceberg tables that reference this integration. Existing Iceberg tables that reference this integration cannot access the catalog in the table definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_object_storage#enabled CatalogIntegrationObjectStorage#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_object_storage#id CatalogIntegrationObjectStorage#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies the identifier (i.e. name) of the catalog integration; must be unique in your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_object_storage#name CatalogIntegrationObjectStorage#name}
    */
    readonly name: string;
    /**
    * Specifies the number of seconds to wait between attempts to poll the external Iceberg catalog for metadata updates for automated refresh. For Delta-based tables, specifies the number of seconds to wait between attempts to poll your external cloud storage for new metadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_object_storage#refresh_interval_seconds CatalogIntegrationObjectStorage#refresh_interval_seconds}
    */
    readonly refreshIntervalSeconds?: number;
    /**
    * Specifies the table format. Valid values are (case-insensitive): `ICEBERG` | `DELTA`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_object_storage#table_format CatalogIntegrationObjectStorage#table_format}
    */
    readonly tableFormat: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_object_storage#timeouts CatalogIntegrationObjectStorage#timeouts}
    */
    readonly timeouts?: CatalogIntegrationObjectStorageTimeouts;
}
export interface CatalogIntegrationObjectStorageDescribeOutput {
}
export declare function catalogIntegrationObjectStorageDescribeOutputToTerraform(struct?: CatalogIntegrationObjectStorageDescribeOutput): any;
export declare function catalogIntegrationObjectStorageDescribeOutputToHclTerraform(struct?: CatalogIntegrationObjectStorageDescribeOutput): any;
export declare class CatalogIntegrationObjectStorageDescribeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CatalogIntegrationObjectStorageDescribeOutput | undefined;
    set internalValue(value: CatalogIntegrationObjectStorageDescribeOutput | undefined);
    get catalogSource(): string;
    get comment(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get refreshIntervalSeconds(): number;
    get tableFormat(): string;
}
export declare class CatalogIntegrationObjectStorageDescribeOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CatalogIntegrationObjectStorageDescribeOutputOutputReference;
}
export interface CatalogIntegrationObjectStorageShowOutput {
}
export declare function catalogIntegrationObjectStorageShowOutputToTerraform(struct?: CatalogIntegrationObjectStorageShowOutput): any;
export declare function catalogIntegrationObjectStorageShowOutputToHclTerraform(struct?: CatalogIntegrationObjectStorageShowOutput): any;
export declare class CatalogIntegrationObjectStorageShowOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CatalogIntegrationObjectStorageShowOutput | undefined;
    set internalValue(value: CatalogIntegrationObjectStorageShowOutput | undefined);
    get category(): string;
    get comment(): string;
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
    get type(): string;
}
export declare class CatalogIntegrationObjectStorageShowOutputList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CatalogIntegrationObjectStorageShowOutputOutputReference;
}
export interface CatalogIntegrationObjectStorageTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_object_storage#create CatalogIntegrationObjectStorage#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_object_storage#delete CatalogIntegrationObjectStorage#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_object_storage#read CatalogIntegrationObjectStorage#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_object_storage#update CatalogIntegrationObjectStorage#update}
    */
    readonly update?: string;
}
export declare function catalogIntegrationObjectStorageTimeoutsToTerraform(struct?: CatalogIntegrationObjectStorageTimeouts | cdktn.IResolvable): any;
export declare function catalogIntegrationObjectStorageTimeoutsToHclTerraform(struct?: CatalogIntegrationObjectStorageTimeouts | cdktn.IResolvable): any;
export declare class CatalogIntegrationObjectStorageTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogIntegrationObjectStorageTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CatalogIntegrationObjectStorageTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_object_storage snowflake_catalog_integration_object_storage}
*/
export declare class CatalogIntegrationObjectStorage extends cdktn.TerraformResource {
    static readonly tfResourceType = "snowflake_catalog_integration_object_storage";
    /**
    * Generates CDKTN code for importing a CatalogIntegrationObjectStorage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CatalogIntegrationObjectStorage to import
    * @param importFromId The id of the existing CatalogIntegrationObjectStorage that should be imported. Refer to the {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_object_storage#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CatalogIntegrationObjectStorage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/snowflakedb/snowflake/2.16.0/docs/resources/catalog_integration_object_storage snowflake_catalog_integration_object_storage} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CatalogIntegrationObjectStorageConfig
    */
    constructor(scope: Construct, id: string, config: CatalogIntegrationObjectStorageConfig);
    get catalogSource(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _describeOutput;
    get describeOutput(): CatalogIntegrationObjectStorageDescribeOutputList;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get fullyQualifiedName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _refreshIntervalSeconds?;
    get refreshIntervalSeconds(): number;
    set refreshIntervalSeconds(value: number);
    resetRefreshIntervalSeconds(): void;
    get refreshIntervalSecondsInput(): number | undefined;
    private _showOutput;
    get showOutput(): CatalogIntegrationObjectStorageShowOutputList;
    private _tableFormat?;
    get tableFormat(): string;
    set tableFormat(value: string);
    get tableFormatInput(): string | undefined;
    private _timeouts;
    get timeouts(): CatalogIntegrationObjectStorageTimeoutsOutputReference;
    putTimeouts(value: CatalogIntegrationObjectStorageTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CatalogIntegrationObjectStorageTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
